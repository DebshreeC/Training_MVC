﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Data;
using AT.BAL.Managers;
using AT.BAL.ViewModel;

namespace Automation_Tracker_Inhouse.Controllers
{
    public class InprogressController : Controller
    {
        //
        // GET: /Inprogress/
        IinProgresServices objI = new InProgressManager();
        InProgressManager objM = new InProgressManager();

        public ActionResult Inprogress()
        {
            return View();
        }

        public ActionResult getInprogressProject(int strProjectID, string strStatus, string DbCondition)
        {
            return PartialView("_Inprogress", objM.ATADDEditProject(strProjectID, strStatus, DbCondition));
        }
        public ActionResult InprogressUAT()
        {
            return View();
        }
        public ActionResult InprogressLIVE()
        {
            return View();
        }
        public ActionResult getInProgressUATProject(string status, string strFntype)
        {
            return PartialView("_InProgressUAT", objI.getOpenProject(status, strFntype));
        }
        public ActionResult ATADDEditProject(int strProjectID, string strStatus, string DbCondition)
        {
            return PartialView("_InProgressUAT", objM.ATADDEditProject(strProjectID, strStatus, DbCondition));

        }
        public ActionResult getInProgressLiveProject(int strProjectID, string strStatus, string DbCondition)
        {
            return PartialView("_InProgressLIVE", objM.ATADDEditProject(strProjectID, strStatus, DbCondition));
        }

        [HttpPost]
        public JsonResult InprogressSave(string listOfAccounts, string strStatus, string strReason)
        {
            objI.InprogressSave(listOfAccounts, strStatus, strReason);
            return Json("", JsonRequestBehavior.AllowGet);
        }

        public ActionResult Completed()
        {
            return View();
        }

        public ActionResult getCompletedProjectDetails(int strProjectID, string strStatus, string DbCondition)
        {
            return PartialView("_completed", objM.ATADDEditProject(strProjectID, strStatus, DbCondition));
        }

        public ActionResult OnHold()
        {
            return View();
        }

        public ActionResult getOnHoldProjectDetails(int strProjectID, string strStatus, string DbCondition)
        {
            return PartialView("_OnHold", objM.ATADDEditProject(strProjectID, strStatus, DbCondition));
        }

        [HttpPost]
        public JsonResult OnHoldDataSave(string listOfAccounts, string strStatus, string strReasontoRevert)
        {
            objI.OnHoldDataSave(listOfAccounts, strStatus, strReasontoRevert);
            return Json("", JsonRequestBehavior.AllowGet);
        }

        public JsonResult InprogressUATSave(string listOfAccounts, string strStatus)
        {
            AT.BAL.Managers.PipelineManager objp = new PipelineManager();

            objp.inprogressSave(listOfAccounts, strStatus);
            return Json("", JsonRequestBehavior.AllowGet);
        }
        public JsonResult InprogressLiveSave(string listOfAccounts, string strStatus)
        {
            AT.BAL.Managers.PipelineManager objp = new PipelineManager();

            objp.inprogressLiveSave(listOfAccounts, strStatus);
            return Json("", JsonRequestBehavior.AllowGet);
        }

        public JsonResult getESTProjectDetails(int strProjectUniqueID)
        {
            return Json(objM.getESTProjectDetails(strProjectUniqueID), JsonRequestBehavior.AllowGet);
        }
    }
}
