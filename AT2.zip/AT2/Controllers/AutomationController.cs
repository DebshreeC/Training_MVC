﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Data;
using System.Data.SqlClient;
using Automation_Tracker.Models;

namespace Automation_Tracker.Controllers
{
    public class AutomationController : Controller
    {
        //
        // GET: /Automation/       
        Automation_Tracker_Services objTrackerService = new Automation_Tracker_Services();

        public ActionResult Index()
        {
            return View();
        }

        public ActionResult Insert_Project()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Insert_Project(FormCollection collection)
        {
            try
            {
                string confirmValue = collection["confirm_msg"].ToString();
                if (confirmValue == "Yes")
                {
                    Automation_Tracker_Master objTrackerMaster = new Automation_Tracker_Master();

                    objTrackerMaster.Client = collection["Client"].ToString();
                    objTrackerMaster.Project_Name = collection["Project_Name"].ToString();
                    objTrackerMaster.Process = collection["Process"].ToString();
                    objTrackerMaster.Description = collection["Description"].ToString();
                    objTrackerMaster.Type = collection["Type"].ToString();
                    objTrackerMaster.Status = collection["Status"].ToString();
                    objTrackerMaster.Project_Status = collection["Project_Status"].ToString();
                    if (collection["InProgress_Status"].ToString() == "Select")
                    {
                        objTrackerMaster.InProgress_Status = "";
                    }
                    else
                    {
                        objTrackerMaster.InProgress_Status = collection["InProgress_Status"].ToString();
                    }
                    DateTime? date = null;
                    if (!string.IsNullOrEmpty(collection["Request_Received_Date"].ToString()))
                    {
                        string dateString = collection["Request_Received_Date"].ToString();
                        date = Convert.ToDateTime(dateString, System.Globalization.CultureInfo.GetCultureInfo("ur-PK").DateTimeFormat);
                    }
                    objTrackerMaster.Request_Received_Date = date;

                    DateTime? ApprovedRejectedDate = null;
                    if (!string.IsNullOrEmpty(collection["Approved_Rejected_Date"].ToString()))
                    {
                        string Approved_Rejected_Date = collection["Approved_Rejected_Date"].ToString();
                        ApprovedRejectedDate = Convert.ToDateTime(Approved_Rejected_Date, System.Globalization.CultureInfo.GetCultureInfo("ur-PK").DateTimeFormat);
                    }
                    objTrackerMaster.Approved_Rejected_Date = ApprovedRejectedDate;

                    objTrackerMaster.Location = collection["Location"].ToString();
                    objTrackerMaster.Vertical = collection["Vertical"].ToString();

                    objTrackerMaster.Fully_Loaded_FTE_Cost_dollar = collection["Fully_Loaded_FTE_Cost_dollar"].ToString();
                    objTrackerMaster.Est_dollar_savings = collection["Est_dollar_savings"].ToString();
                    objTrackerMaster.Est_Effort_Cost_dollar = collection["Est_Effort_Cost_dollar"].ToString();

                    objTrackerMaster.Manager = collection["Manager"].ToString();
                    objTrackerMaster.SPOC = collection["SPOC"].ToString();
                    objTrackerMaster.Remarks = collection["Remarks"].ToString();
                    objTrackerMaster.EXT = "";
                    objTrackerMaster.Priority = "";

                    DateTime? ProjectStartDate = null;
                    //if (!string.IsNullOrEmpty(collection["Project_Start_Date"].ToString()))
                    //{
                    //    string Project_Start_DateString = collection["Project_Start_Date"].ToString();
                    //    ProjectStartDate = Convert.ToDateTime(Project_Start_DateString, System.Globalization.CultureInfo.GetCultureInfo("ur-PK").DateTimeFormat);
                    //}
                    objTrackerMaster.Project_Start_Date = ProjectStartDate;

                    DateTime? PlannedCompletionDate = null;
                    //if (!string.IsNullOrEmpty(collection["Planned_Completion_Date"].ToString()))
                    //{
                    //    string Planned_Completion_DateString = collection["Planned_Completion_Date"].ToString();
                    //    PlannedCompletionDate = Convert.ToDateTime(Planned_Completion_DateString, System.Globalization.CultureInfo.GetCultureInfo("ur-PK").DateTimeFormat);
                    //}
                    objTrackerMaster.Planned_Completion_Date = PlannedCompletionDate;

                    DateTime? ActualCompletionDate = null;
                    //if (!string.IsNullOrEmpty(collection["Actual_Completion_Date"].ToString()))
                    //{
                    //    string Actual_Completion_DateString = collection["Actual_Completion_Date"].ToString();
                    //    ActualCompletionDate = Convert.ToDateTime(Actual_Completion_DateString, System.Globalization.CultureInfo.GetCultureInfo("ur-PK").DateTimeFormat);
                    //}
                    objTrackerMaster.Actual_Completion_Date = ActualCompletionDate;

                    objTrackerMaster.Resources_Involved = "";
                    objTrackerMaster.Hash_Resources_Required = "";

                    DateTime? UATReleaseDate = null;
                    //if (!string.IsNullOrEmpty(collection["UAT_Release_Date"].ToString()))
                    //{
                    //    string UAT_Release_Date = collection["UAT_Release_Date"].ToString();
                    //    UATReleaseDate = Convert.ToDateTime(UAT_Release_Date, System.Globalization.CultureInfo.GetCultureInfo("ur-PK").DateTimeFormat);
                    //}
                    objTrackerMaster.UAT_Release_Date = UATReleaseDate;

                    DateTime? LIVEReleaseDate = null;
                    //if (!string.IsNullOrEmpty(collection["LIVE_Release_Date"].ToString()))
                    //{
                    //    string LIVE_Release_Date = collection["LIVE_Release_Date"].ToString();
                    //    LIVEReleaseDate = Convert.ToDateTime(LIVE_Release_Date, System.Globalization.CultureInfo.GetCultureInfo("ur-PK").DateTimeFormat);
                    //}
                    objTrackerMaster.LIVE_Release_Date = LIVEReleaseDate;

                    objTrackerMaster.UAT_Remarks = "";
                    objTrackerMaster.LIVE_Remarks = "";

                    DateTime? ReleaseDateString = null;
                    string Release_DateString = string.Empty;
                    //if (!string.IsNullOrEmpty(collection["Release_Date"].ToString()))
                    //{
                    //    Release_DateString = collection["Release_Date"].ToString();
                    //    ReleaseDateString = Convert.ToDateTime(Release_DateString, System.Globalization.CultureInfo.GetCultureInfo("ur-PK").DateTimeFormat);
                    //}
                    objTrackerMaster.Release_Date = ReleaseDateString;

                    objTrackerMaster.Release_Type = "";

                    DateTime? BenefitSignoffDateString = null;
                    //if (!string.IsNullOrEmpty(collection["Benefit_Sign_off_Date"].ToString()))
                    //{
                    //    string Benefit_Sign_off_DateString = collection["Benefit_Sign_off_Date"].ToString();
                    //    BenefitSignoffDateString = Convert.ToDateTime(Benefit_Sign_off_DateString, System.Globalization.CultureInfo.GetCultureInfo("ur-PK").DateTimeFormat);
                    //}
                    objTrackerMaster.Benefit_Sign_off_Date = BenefitSignoffDateString;

                    objTrackerMaster.Process_Re_engineering = "";
                    objTrackerMaster.No_FTEs_Involved = "";
                    objTrackerMaster.Effort_Man_days = collection["Effort_Man_days"].ToString(); ;
                    objTrackerMaster.Est_Prod_Impv_percent = "";
                    objTrackerMaster.Act_Prod_Impv_percent = "";
                    objTrackerMaster.Est_Quality_Impv_percent = "";
                    objTrackerMaster.Act_Quality_Impv_percent = "";
                    objTrackerMaster.Est_FTE_Saving = collection["Est_FTE_Saving"].ToString();
                    objTrackerMaster.Revised_Est_FTE_Saving = "";
                    objTrackerMaster.Act_FTE_Saving = "";
                    objTrackerMaster.Est_Hours_saved_FTE = "";
                    objTrackerMaster.Act_Hours_saved_FTE = "";
                    objTrackerMaster.Comments = "";
                    objTrackerMaster.Application = "";
                    objTrackerMaster.Enter_By = System.Environment.UserName.ToString();
                    objTrackerService.Enter_Project(objTrackerMaster);


                    //return JavaScript("testval()");
                    return RedirectToAction("Index", "Tracker_Display");
                }
                else
                {
                    return View();
                }
            }
            catch (Exception ex)
            {
                return View();
            }


        }


        [HttpPost]
        public ActionResult Select_All_Project()
        {
            return RedirectToAction("Index", "Tracker_Display");
            //return View();
        }
        public ActionResult Summary()
        {
            Automation_Tracker_Master objTrackerMaster = new Automation_Tracker_Master();
            //ATM.Project_Unique_ID = rID.ToString();

            DataSet ds_big = objTrackerService.Project_Track_Details_Summary("GREAT");
            ViewBag.p_summary = ds_big.Tables[0];

            DataSet ds_less = objTrackerService.Project_Track_Details_Summary("LESS");
            ViewBag.l_summary = ds_less.Tables[0];

            DataSet sampleDataSet = new DataSet();
            //sampleDataSet.Locale = CultureInfo.InvariantCulture;
            DataTable sampleDataTable = sampleDataSet.Tables.Add("SampleData");

            sampleDataTable.Columns.Add("Pipeline", typeof(int));
            sampleDataTable.Columns.Add("InProgress", typeof(int));
            sampleDataTable.Columns.Add("Completed", typeof(int));

            DataRow sampleDataRow;
            sampleDataRow = sampleDataTable.NewRow();
            sampleDataRow["Pipeline"] = Convert.ToInt32(ds_big.Tables[0].Rows[0][0].ToString()) + Convert.ToInt32(ds_less.Tables[0].Rows[0][0].ToString());
            sampleDataRow["InProgress"] = Convert.ToInt32(ds_big.Tables[0].Rows[0][1].ToString()) + Convert.ToInt32(ds_less.Tables[0].Rows[0][1].ToString());
            sampleDataRow["Completed"] = Convert.ToInt32(ds_big.Tables[0].Rows[0][2].ToString()) + Convert.ToInt32(ds_less.Tables[0].Rows[0][2].ToString());

            sampleDataTable.Rows.Add(sampleDataRow);

            ViewBag.total_summary = sampleDataSet.Tables[0];

            int g_total = Convert.ToInt32(sampleDataSet.Tables[0].Rows[0][0].ToString()) + Convert.ToInt32(sampleDataSet.Tables[0].Rows[0][1].ToString()) + Convert.ToInt32(sampleDataSet.Tables[0].Rows[0][2].ToString());
            ViewBag.grandtotal = g_total;

            DataSet ds_Pending_big = objTrackerService.Project_Track_Details_Summary("PendingG");
            ViewBag.PG_summary = ds_Pending_big.Tables[0].Rows[0][0].ToString();


            DataSet ds_Pending_less = objTrackerService.Project_Track_Details_Summary("PendingL");
            ViewBag.Pl_summary = ds_Pending_less.Tables[0].Rows[0][0].ToString();

            ViewBag.P_Total_summary = Convert.ToInt32(ds_Pending_big.Tables[0].Rows[0][0].ToString()) + Convert.ToInt32(ds_Pending_less.Tables[0].Rows[0][0].ToString());


            //return RedirectToAction("Index", "Tracker_Display");
            return View();
        }

        public ActionResult Sub_Index(string Project_Status = "Pipeline", string Inprogress_Status=null)
        {
            DataTable dt = new DataTable();
            if (Project_Status.ToString() == "Pipeline")
            {
                ViewBag.ProjectHeading = "Pipeline Project Display";
                if (Convert.ToString(Inprogress_Status) !="")
                {
                    dt = objTrackerService.Select_ColumnList_Track_Details_subcolumn_Dyna(1, Project_Status.ToString(), null);
                }
                else if (Inprogress_Status.ToString() == "Approved")
                {
                    dt = objTrackerService.Select_ColumnList_Track_Details_subcolumn_Dyna(1, Project_Status.ToString(), Inprogress_Status.ToString());
                }
                else if (Inprogress_Status.ToString() == "Tentatively Approved")
                {
                    dt = objTrackerService.Select_ColumnList_Track_Details_subcolumn_Dyna(1, Project_Status.ToString(), Inprogress_Status.ToString());
                }
            }
            else if (Project_Status.ToString() == "InProgress")
            {
                ViewBag.ProjectHeading = "InProgress Project Display";
                if (Inprogress_Status.ToString() == "''")
                {
                    dt = objTrackerService.Select_ColumnList_Track_Details_subcolumn_Dyna(2, Project_Status.ToString(), null);
                }
                else if (Inprogress_Status.ToString() == "InProgress")
                {
                    dt = objTrackerService.Select_ColumnList_Track_Details_subcolumn_Dyna(2, Project_Status.ToString(), Inprogress_Status.ToString());
                }
                else if (Inprogress_Status.ToString() == "UAT")
                {
                    dt = objTrackerService.Select_ColumnList_Track_Details_subcolumn_Dyna(2, Project_Status.ToString(), Inprogress_Status.ToString());
                }
                else if (Inprogress_Status.ToString() == "Re-Open")
                {
                    dt = objTrackerService.Select_ColumnList_Track_Details_subcolumn_Dyna(2, Project_Status.ToString(), Inprogress_Status.ToString());
                }
                else if (Inprogress_Status.ToString() == "LIVE")
                {
                    dt = objTrackerService.Select_ColumnList_Track_Details_subcolumn_Dyna(2, Project_Status.ToString(), Inprogress_Status.ToString());
                }
                else if (Inprogress_Status.ToString() == "On-Hold")
                {
                    dt = objTrackerService.Select_ColumnList_Track_Details_subcolumn_Dyna(2, Project_Status.ToString(), Inprogress_Status.ToString());
                }
            }
            else if (Project_Status.ToString() == "Completed")
            {
                ViewBag.ProjectHeading = "Completed Project Display";
                if (Inprogress_Status.ToString() == "''")
                {
                    dt = objTrackerService.Select_ColumnList_Track_Details_subcolumn_Dyna(3, Project_Status.ToString(), null);
                }
                else if (Inprogress_Status.ToString() == "UAT")
                {
                    dt = objTrackerService.Select_ColumnList_Track_Details_subcolumn_Dyna(3, Project_Status.ToString(), Inprogress_Status.ToString());
                }
                else if (Inprogress_Status.ToString() == "LIVE")
                {
                    dt = objTrackerService.Select_ColumnList_Track_Details_subcolumn_Dyna(3, Project_Status.ToString(), Inprogress_Status.ToString());
                }
            }
            else if (Project_Status.ToString() == "Obsolete")
            {
                ViewBag.ProjectHeading = "Obsolete Project Display";
                if (Inprogress_Status.ToString() == "''")
                {
                    dt = objTrackerService.Select_ColumnList_Track_Details_subcolumn_Dyna(4, Project_Status.ToString(), null);
                }
                else if (Inprogress_Status.ToString() == "Rejected")
                {
                    dt = objTrackerService.Select_ColumnList_Track_Details_subcolumn_Dyna(4, Project_Status.ToString(), Inprogress_Status.ToString());
                }
                else if (Inprogress_Status.ToString() == "Project Closed")
                {
                    dt = objTrackerService.Select_ColumnList_Track_Details_subcolumn_Dyna(4, Project_Status.ToString(), Inprogress_Status.ToString());
                }
            }
            return View(dt);
        }

        public void count()
        {
            DataSet ds_count = objTrackerService.Track_Details_Count_All_Details();
            if (ds_count.Tables[0].Rows.Count > 0)
            {
                Session["count_Pipeline_0"] = ds_count.Tables[0].Rows[0][0].ToString();
                Session["count_Pipeline_Re_Open"] = ds_count.Tables[0].Rows[0][1].ToString();
                Session["count_Pipeline_On_Hold"] = ds_count.Tables[0].Rows[0][2].ToString();
                Session["count_InProgress_0"] = ds_count.Tables[0].Rows[0][3].ToString();
                Session["count_InProgress_InProgress"] = ds_count.Tables[0].Rows[0][4].ToString();
                Session["count_InProgress_UAT"] = ds_count.Tables[0].Rows[0][5].ToString();
                Session["count_InProgress_Re_Open"] = ds_count.Tables[0].Rows[0][6].ToString();
                Session["count_InProgress_LIVE"] = ds_count.Tables[0].Rows[0][7].ToString();
                Session["count_InProgress_On_Hold"] = ds_count.Tables[0].Rows[0][8].ToString();
                Session["count_Completed_0"] = ds_count.Tables[0].Rows[0][9].ToString();
                Session["count_Completed_UAT"] = ds_count.Tables[0].Rows[0][10].ToString();
                Session["count_Completed_LIVE"] = ds_count.Tables[0].Rows[0][11].ToString();
                Session["count_Obsolete_0"] = ds_count.Tables[0].Rows[0][12].ToString();
                Session["count_Obsolete_Re_Open"] = ds_count.Tables[0].Rows[0][13].ToString();
                Session["count_Obsolete_On_Hold"] = ds_count.Tables[0].Rows[0][14].ToString();
            }
            else
            {
                Session["count_Pipeline_0"] = null;
                Session["count_Pipeline_Re_Open"] = null;
                Session["count_Pipeline_On_Hold"] = null;
                Session["count_InProgress_0"] = null;
                Session["count_InProgress_InProgress"] = null;
                Session["count_InProgress_UAT"] = null;
                Session["count_InProgress_Re_Open"] = null;
                Session["count_InProgress_LIVE"] = null;
                Session["count_InProgress_On_Hold"] = null;
                Session["count_Completed_0"] = null;
                Session["count_Completed_UAT"] = null;
                Session["count_Completed_LIVE"] = null;
                Session["count_Obsolete_0"] = null;
                Session["count_Obsolete_Re_Open"] = null;
                Session["count_Obsolete_On_Hold"] = null;
            }

            if (Session["count_Pipeline_0"] != null)
            { }
            else
            {
                Session["count_Pipeline_0"] = "0";
            }
            if (Session["count_Pipeline_Re_Open"] != null)
            { }
            else
            {
                Session["count_Pipeline_Re_Open"] = "0";
            }
            if (Session["count_Pipeline_On_Hold"] != null)
            { }
            else
            {
                Session["count_Pipeline_On_Hold"] = "0";
            }
            if (Session["count_InProgress_0"] != null)
            { }
            else
            {
                Session["count_InProgress_0"] = "0";
            }
            if (Session["count_InProgress_InProgress"] != null)
            { }
            else
            {
                Session["count_InProgress_InProgress"] = "0";
            }
            if (Session["count_InProgress_UAT"] != null)
            { }
            else
            {
                Session["count_InProgress_UAT"] = "0";
            }
            if (Session["count_InProgress_Re_Open"] != null)
            { }
            else
            {
                Session["count_InProgress_Re_Open"] = "0";
            }
            if (Session["count_InProgress_LIVE"] != null)
            { }
            else
            {
                Session["count_InProgress_LIVE"] = "0";
            }
            if (Session["count_InProgress_On_Hold"] != null)
            { }
            else
            {
                Session["count_InProgress_On_Hold"] = "0";
            }
            if (Session["count_Completed_0"] != null)
            { }
            else
            {
                Session["count_Completed_0"] = "0";
            }
            if (Session["count_Completed_UAT"] != null)
            { }
            else
            {
                Session["count_Completed_UAT"] = "0";
            }
            if (Session["count_Completed_LIVE"] != null)
            { }
            else
            {
                Session["count_Completed_LIVE"] = "0";
            }
            if (Session["count_Obsolete_0"] != null)
            { }
            else
            {
                Session["count_Obsolete_0"] = "0";
            }
            if (Session["count_Obsolete_Re_Open"] != null)
            { }
            else
            {
                Session["count_Obsolete_Re_Open"] = "0";
            }
            if (Session["count_Obsolete_On_Hold"] != null)
            { }
            else
            {
                Session["count_Obsolete_On_Hold"] = "0";
            }
            Session["count_Pipeline_total"] = Convert.ToInt32(Session["count_Pipeline_0"].ToString()) + Convert.ToInt32(Session["count_Pipeline_Re_Open"].ToString()) + Convert.ToInt32(Session["count_Pipeline_On_Hold"].ToString());
            Session["count_Inprogress_total"] = Convert.ToInt32(Session["count_InProgress_0"].ToString()) + Convert.ToInt32(Session["count_InProgress_InProgress"].ToString()) + Convert.ToInt32(Session["count_InProgress_UAT"].ToString()) + Convert.ToInt32(Session["count_InProgress_Re_Open"].ToString()) + Convert.ToInt32(Session["count_InProgress_LIVE"].ToString()) + Convert.ToInt32(Session["count_InProgress_On_Hold"].ToString());
        }
        public void session_activate()
        {
            if (Session["count_Pipeline"] != null)
            { }
            else
            {
                Session["count_Pipeline"] = "0";
            }
            if (Session["count_InProgress"] != null)
            { }
            else
            {
                Session["count_InProgress"] = "0";
            }
            if (Session["count_Completed"] != null)
            { }
            else
            {
                Session["count_Completed"] = "0";
            }
            if (Session["count_Obsolete"] != null)
            { }
            else
            {
                Session["count_Obsolete"] = "0";
            }
            if (Session["count_Accomplishments"] != null)
            { }
            else
            {
                Session["count_Accomplishments"] = "0";
            }
        }

        public ActionResult URL_Index(string name)
        {
          
            DataSet ds=new DataSet();
            try
            {
                if (name == null)
                {
                    ds = objTrackerService.URL_Index_Open();
                    ViewBag.ColumnList = ds.Tables[0];
                }
                else
                {
                    ds = objTrackerService.URL_Index_Open();
                    ViewBag.ColumnList = ds.Tables[0];
                    System.Diagnostics.Process.Start("explorer", name);
                }
                
            }
            catch (Exception ex)
            {

            }
            return View();
        }       
    }
}
