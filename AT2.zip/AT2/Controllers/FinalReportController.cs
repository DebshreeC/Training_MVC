﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Automation_Tracker_Inhouse.Controllers
{
    public class FinalReportController : Controller
    {
        //
        // GET: /FinalReport/
        AT.BAL.Managers.FTEReportManager objF = new AT.BAL.Managers.FTEReportManager();
        public ActionResult FinalReport()
        {
            return View();
        }


        public ActionResult getFinalReport(string strStatus, string dtFromdate, string dtTodate)
        {
            return PartialView("_FinalReport", objF.getFinalReport(dtFromdate, dtTodate));
        }


    }
}
