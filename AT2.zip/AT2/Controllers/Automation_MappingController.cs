﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Data;
using Automation_Tracker.Models;
using System.Configuration;
using Automation_Tracker_Admin.Models;
using System.ComponentModel.DataAnnotations;

namespace Automation_Tracker_Admin.Controllers
{
    public class Automation_MappingController : Controller
    {
        //
        // GET: /Automation_Mapping/
        Automation_Tracker_Services objTrackerService = new Automation_Tracker_Services();
        public ActionResult Index()
        {
            return View();
        }
        public ActionResult Display()
        {
            return View();
        }
        [HttpGet]
        public ActionResult Display(FormCollection collection)
        {
            try
            {                
                string id = "";
                int val = 0;
                int val_i = 0;
                if (RouteData.Values["id"] == null)
                {

                }
                else
                {
                    id = RouteData.Values["id"].ToString();
                    val = Convert.ToInt32(id.Substring(0, 1));
                    val_i = Convert.ToInt32(id.Substring(id.Length - 1));
                }
                DataSet ds = new DataSet();
                if (val == 0)
                {
                    ds = objTrackerService.Project_Track_Details_Select();
                }
                else
                {
                    ds = objTrackerService.Automation_Project_column_Details_Select(val, val_i);
                    //Session["val"] = val;
                }
                ViewBag.ColumnList = ds.Tables[0];
            }
            catch (Exception ex)
            {

            }
            return View();
        }

        public ActionResult Enter_Mapping_Column_List(FormCollection collection)
        {
            try
            {
                int val = 0;

                if (collection["hdprocess"].ToString() != "")
                {
                    val = Convert.ToInt32(collection["hdprocess"].ToString());
                }
                if (val == 0)
                {
                    
                }
                else
                {
                    int val_i = 0;
                    if (collection["hdinprocess"].ToString() != "")
                    {
                        val_i = Convert.ToInt32(collection["hdinprocess"].ToString());
                    }
                    string arr = collection["input_hidden_field"].ToString();
                    string[] array = arr.Split(',');

                    string confirmValue = collection["confirm_msg"].ToString();
                    //string confirmValue_req = Request["confirm_value"].ToString();
                    if (confirmValue == "Yes")
                    {
                        Automation_Tracker_Master objTrackerMaster = new Automation_Tracker_Master();
                        DataTable table = new DataTable();
                        table.Columns.Add("Column_Id", typeof(int));
                        table.Columns.Add("Project_Status_Id", typeof(int));
                        table.Columns.Add("Inprogress_Status_Id", typeof(int));
                        table.Columns.Add("Enter_By", typeof(string));
                        for (int i = 0; i < array.Count(); i++)
                        {
                            int column_value = Convert.ToInt32(array[i].ToString());
                            table.Rows.Add(column_value, val, val_i, System.Environment.UserName.ToString());
                        }
                        objTrackerService.Enter_Mapping_Column_List(table);
                    }
                    else
                    {

                    }
                }
            }
            catch (Exception ex)
            {

            }
            return RedirectToAction("Display", "Automation_Mapping");
        }

        public ActionResult Alloted_Display(Automation_Tracker.Models.Automation_Tracker_Mapping_Master selectmodel)
        {
            try
            {
                string id = "";
                if (RouteData.Values["id"] == null)
                {
                    id = Session["id"].ToString();
                }
                else
                {
                    id = RouteData.Values["id"].ToString();
                    Session["id"] = id;
                }
                string rID = id.ToString();
                string val, val_i;
                val = rID.Substring(0, 1);
                val_i = rID.Substring(rID.Length - 1);
                DataSet ds = objTrackerService.Project_column_Details_Select(val, val_i);
                ViewBag.ColumnList_project = ds.Tables[0];
            }
            catch (Exception ex)
            {

            }
            return View(selectmodel);
        }
    }
}
