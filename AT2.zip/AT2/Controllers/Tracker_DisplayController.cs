﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Data;
using System.Data.SqlClient;
using Automation_Tracker.Models;
using System.ComponentModel.DataAnnotations;
using AT.BAL.Managers;
using AT.BAL.ViewModel;

namespace Automation_Tracker.Controllers
{
    public class Tracker_DisplayController : Controller
    {
        //
        // GET: /Tracker_Display/
        IUserMenuService objM = new MenuManager();
        ATMapping objAT = new ATMapping();
        Automation_Tracker_Services objTrackerService = new Automation_Tracker_Services();

        public ActionResult Tracker()
        {
            return View();
        }
        [HttpGet]
        public ActionResult Index(string Project_Status)
        {
            Session["UserName"] = System.Environment.UserName.ToString();

            objM.saveSessiondetails();
           // objM.GetSideMenu();

            if (Project_Status == null)
            {
                ViewBag.total = objTrackerService.GetAllProject().ToList().Count;
                Session["count"] = ViewBag.total;
                DataSet ds_count = objTrackerService.Track_Details_Count();
                //DataSet ds_count = objTrackerService.GetAll_Track_Project();
                //ViewBag.total = ds_count.Tables[0].Rows.Count;
                //Session["count"] = ViewBag.total;
                if (ds_count.Tables[0].Rows.Count > 0)
                {
                    Session["count_Pipeline"] = ds_count.Tables[0].Rows[0][1].ToString();
                    Session["count_InProgress"] = ds_count.Tables[0].Rows[0][2].ToString();
                    Session["count_Completed"] = ds_count.Tables[0].Rows[0][3].ToString();
                    Session["count_Obsolete"] = ds_count.Tables[0].Rows[0][5].ToString();
                    Session["count_Accomplishments"] = ds_count.Tables[0].Rows[0][4].ToString();
                }
                else
                {
                    Session["count_Pipeline"] = null;
                    Session["count_InProgress"] = null;
                    Session["count_Completed"] = null;
                    Session["count_Obsolete"] = null;
                    Session["count_Accomplishments"] = null;
                }




                Session["Status"] = "";
                ViewBag.ProjectHeading = "All Project Display";
                session_activate();
                count();
                DataTable dt = objTrackerService.GetAll_Track_Project();
                return View(dt);
            }
            else
            {
                if (Project_Status.ToString() == "Pipeline")
                {
                    ViewBag.total = objTrackerService.GetProject_by_Project_Status(Project_Status).ToList().Count;
                    Session["count_Pipeline"] = ViewBag.total;
                    DataSet ds_count = objTrackerService.Track_Details_Count();
                    if (ds_count.Tables[0].Rows.Count > 0)
                    {
                        //Session["count_Pipeline"] = ds_count.Tables[0].Rows[0][0].ToString();
                        Session["count_InProgress"] = ds_count.Tables[0].Rows[0][1].ToString();
                        Session["count_Completed"] = ds_count.Tables[0].Rows[0][2].ToString();
                        Session["count_Obsolete"] = ds_count.Tables[0].Rows[0][3].ToString();
                        Session["count_Accomplishments"] = ds_count.Tables[0].Rows[0][4].ToString();
                    }
                    else
                    {
                        //Session["count_Pipeline"] = null;
                        Session["count_InProgress"] = null;
                        Session["count_Completed"] = null;
                        Session["count_Obsolete"] = null;
                        Session["count_Accomplishments"] = null;
                    }
                    Session["Status"] = "Pipeline";
                    ViewBag.ProjectHeading = "Pipeline Project Display";
                    session_activate();
                    count();
                    DataTable dt = objTrackerService.Select_ColumnList_Track_Details_Dyna(1, 0, Project_Status.ToString());
                    return View(dt);
                    //return View(objTrackerService.GetProject_by_Project_Status(Project_Status).ToList());
                }
                else if (Project_Status.ToString() == "InProgress")
                {
                    ViewBag.total = objTrackerService.GetProject_by_Project_Status(Project_Status).ToList().Count;
                    Session["count_InProgress"] = ViewBag.total;
                    DataSet ds_count = objTrackerService.Track_Details_Count();
                    if (ds_count.Tables[0].Rows.Count > 0)
                    {
                        Session["count_Pipeline"] = ds_count.Tables[0].Rows[0][0].ToString();
                        //Session["count_InProgress"] = ds_count.Tables[0].Rows[0][1].ToString();
                        Session["count_Completed"] = ds_count.Tables[0].Rows[0][2].ToString();
                        Session["count_Obsolete"] = ds_count.Tables[0].Rows[0][3].ToString();
                        Session["count_Accomplishments"] = ds_count.Tables[0].Rows[0][4].ToString();
                    }
                    else
                    {

                        Session["count_Pipeline"] = null;
                        //Session["count_InProgress"] = null;
                        Session["count_Completed"] = null;
                        Session["count_Obsolete"] = null;
                        Session["count_Accomplishments"] = null;
                    }
                    Session["Status"] = "InProgress";
                    ViewBag.ProjectHeading = "InProgress Project Display";
                    session_activate();
                    count();
                    DataTable dt = objTrackerService.Select_ColumnList_Track_Details_Dyna(2, 0, Project_Status.ToString());
                    return View(dt);
                    //return View(objTrackerService.GetProject_by_Project_Status(Project_Status).ToList());
                }
                else if (Project_Status.ToString() == "Completed")
                {
                    ViewBag.total = objTrackerService.GetProject_by_Project_Status(Project_Status).ToList().Count;
                    Session["count_Completed"] = ViewBag.total;
                    DataSet ds_count = objTrackerService.Track_Details_Count();
                    if (ds_count.Tables[0].Rows.Count > 0)
                    {
                        Session["count_Pipeline"] = ds_count.Tables[0].Rows[0][0].ToString();
                        Session["count_InProgress"] = ds_count.Tables[0].Rows[0][1].ToString();
                        //Session["count_Completed"] = ds_count.Tables[0].Rows[0][2].ToString();
                        Session["count_Obsolete"] = ds_count.Tables[0].Rows[0][3].ToString();
                        Session["count_Accomplishments"] = ds_count.Tables[0].Rows[0][4].ToString();
                    }
                    else
                    {

                        Session["count_Pipeline"] = null;
                        Session["count_InProgress"] = null;
                        //Session["count_Completed"] = null;
                        Session["count_Obsolete"] = null;
                        Session["count_Accomplishments"] = null;
                    }
                    Session["Status"] = "Completed";
                    ViewBag.ProjectHeading = "Completed Project Display";
                    session_activate();
                    count();
                    DataTable dt = objTrackerService.Select_ColumnList_Track_Details_Dyna(3, 0, Project_Status.ToString());
                    return View(dt);
                    //return View(objTrackerService.GetProject_by_Project_Status(Project_Status).ToList());
                }
                else if (Project_Status.ToString() == "Obsolete")
                {
                    ViewBag.total = objTrackerService.GetProject_by_Project_Status(Project_Status).ToList().Count;
                    Session["count_Obsolete"] = ViewBag.total;
                    DataSet ds_count = objTrackerService.Track_Details_Count();
                    if (ds_count.Tables[0].Rows.Count > 0)
                    {
                        Session["count_Pipeline"] = ds_count.Tables[0].Rows[0][0].ToString();
                        Session["count_InProgress"] = ds_count.Tables[0].Rows[0][1].ToString();
                        Session["count_Completed"] = ds_count.Tables[0].Rows[0][2].ToString();
                        //Session["count_Obsolete"] = ds_count.Tables[0].Rows[0][3].ToString();
                        Session["count_Accomplishments"] = ds_count.Tables[0].Rows[0][4].ToString();
                    }
                    else
                    {

                        Session["count_Pipeline"] = null;
                        Session["count_InProgress"] = null;
                        //Session["count_Completed"] = null;
                        Session["count_Obsolete"] = null;
                        Session["count_Accomplishments"] = null;
                    }

                    Session["Status"] = "Obsolete";
                    ViewBag.ProjectHeading = "Obsolete Project Display";
                    session_activate();
                    count();
                    DataTable dt = objTrackerService.Select_ColumnList_Track_Details_Dyna(4, 0, Project_Status.ToString());
                    return View(dt);
                    //return View(objTrackerService.GetProject_by_Project_Status(Project_Status).ToList());
                }
                else if (Project_Status.ToString() == "Accomplishments")
                {
                    ViewBag.total = objTrackerService.GetTeamAccomplishmentsProject().ToList().Count;
                    Session["count_Accomplishments"] = ViewBag.total;
                    DataSet ds_count = objTrackerService.Track_Details_Count();
                    if (ds_count.Tables[0].Rows.Count > 0)
                    {
                        Session["count_Pipeline"] = ds_count.Tables[0].Rows[0][0].ToString();
                        Session["count_InProgress"] = ds_count.Tables[0].Rows[0][1].ToString();
                        Session["count_Completed"] = ds_count.Tables[0].Rows[0][2].ToString();
                        Session["count_Obsolete"] = ds_count.Tables[0].Rows[0][3].ToString();
                        //Session["count_Accomplishments"] = ds_count.Tables[0].Rows[0][4].ToString();
                    }
                    else
                    {

                        Session["count_Pipeline"] = null;
                        Session["count_InProgress"] = null;
                        Session["count_Completed"] = null;
                        Session["count_Obsolete"] = null;
                        //Session["count_Accomplishments"] = null;
                    }
                    Session["Status"] = "Accomplishments";
                    ViewBag.ProjectHeading = "Team Accomplishments Project Display";
                    session_activate();
                    count();
                    DataTable dt = objTrackerService.Select_ColumnList_Track_Details_Dyna(2, 4, Project_Status.ToString());
                    return View(dt);
                    //return View(objTrackerService.GetTeamAccomplishmentsProject().ToList());
                }
                else
                {
                    ViewBag.total = objTrackerService.GetAllProject().ToList().Count;
                    Session["count"] = ViewBag.total;
                    DataSet ds_count = objTrackerService.Track_Details_Count();
                    //DataSet ds_count = objTrackerService.GetAll_Track_Project();
                    //ViewBag.total = ds_count.Tables[0].Rows.Count;
                    //Session["count"] = ViewBag.total;
                    if (ds_count.Tables[0].Rows.Count > 0)
                    {
                        Session["count_Pipeline"] = ds_count.Tables[0].Rows[0][0].ToString();
                        Session["count_InProgress"] = ds_count.Tables[0].Rows[0][1].ToString();
                        Session["count_Completed"] = ds_count.Tables[0].Rows[0][2].ToString();
                        Session["count_Obsolete"] = ds_count.Tables[0].Rows[0][3].ToString();
                        Session["count_Accomplishments"] = ds_count.Tables[0].Rows[0][4].ToString();
                    }
                    else
                    {
                        Session["count_Pipeline"] = null;
                        Session["count_InProgress"] = null;
                        Session["count_Completed"] = null;
                        Session["count_Obsolete"] = null;
                        Session["count_Accomplishments"] = null;
                    }
                    Session["Status"] = "";
                    ViewBag.ProjectHeading = "All Project Display";
                    session_activate();
                    count();
                    DataTable dt = objTrackerService.GetAll_Track_Project();
                    return View(dt);
                }
            }

        }

        public ActionResult GetHeaderCount()
        {
            return PartialView("_ATCount", objTrackerService.Track_Count());

        }

        public ActionResult GetMenuCount()
        {
            return PartialView("_SideMenuPartial", objM.GetSideMenustring());

        }


        public ActionResult EditTrackerDisplayPage()
        {
            List<ColumnListModel> PLM = new List<ColumnListModel>();
            PLM = objAT.GetListofColumns("S");
            return PartialView("_EditTrackerDisplay", PLM);
        }


        public ActionResult Multiselect()
        {
            return View();
        }


        public ActionResult ShowUpdate(Automation_Tracker.Models.Automation_Tracker_Master selectmodel)
        {
            string id = "";
            if (RouteData.Values["id"] == null)
            {
                id = Session["id"].ToString();
            }
            else
            {
                id = RouteData.Values["id"].ToString();
                Session["id"] = id;

            }
            int rID = Convert.ToInt32(id.ToString());
            Automation_Tracker_Master objTrackerMaster = new Automation_Tracker_Master();
            //ATM.Project_Unique_ID = rID.ToString();        

            DataSet ds = objTrackerService.GetProject_by_Project_unique_Id(rID);

            ViewBag.AuthorList = ds.Tables[0];

            // ViewBag.Request_Request_Received_Date_Date1 = Convert.ToDateTime(ds.Tables[0].Rows[0]["Request_Received_Date"].ToString());

            List<SelectListItem> Project_Status_items = new List<SelectListItem>();

            if (ds.Tables[0].Rows[0]["Project_Status"].ToString() == "Pipeline")
            {
                Project_Status_items.Add(new SelectListItem { Text = "Select", Value = "Select" });
                Project_Status_items.Add(new SelectListItem { Text = "Pipeline", Value = "Pipeline" });
                Project_Status_items.Add(new SelectListItem { Text = "InProgress", Value = "InProgress" });
            }
            else if (ds.Tables[0].Rows[0]["Project_Status"].ToString() == "InProgress")
            {
                Project_Status_items.Add(new SelectListItem { Text = "Select", Value = "Select" });
                //Project_Status_items.Add(new SelectListItem { Text = "Pipeline", Value = "Pipeline" });
                Project_Status_items.Add(new SelectListItem { Text = "InProgress", Value = "InProgress" });
                Project_Status_items.Add(new SelectListItem { Text = "Completed", Value = "Completed" });
            }
            else if (ds.Tables[0].Rows[0]["Project_Status"].ToString() == "Completed")
            {
                Project_Status_items.Add(new SelectListItem { Text = "Select", Value = "Select" });
                //Project_Status_items.Add(new SelectListItem { Text = "Pipeline", Value = "Pipeline" });
                //Project_Status_items.Add(new SelectListItem { Text = "InProgress", Value = "InProgress" });
                Project_Status_items.Add(new SelectListItem { Text = "Completed", Value = "Completed" });
                //Project_Status_items.Add(new SelectListItem { Text = "Obsolete", Value = "Obsolete" });
            }
            else if (ds.Tables[0].Rows[0]["Project_Status"].ToString() == "Obsolete")
            {
                Project_Status_items.Add(new SelectListItem { Text = "Select", Value = "Select" });
                Project_Status_items.Add(new SelectListItem { Text = "Pipeline", Value = "Pipeline" });
                //Project_Status_items.Add(new SelectListItem { Text = "InProgress", Value = "InProgress" });
                //Project_Status_items.Add(new SelectListItem { Text = "Completed", Value = "Completed" });
                Project_Status_items.Add(new SelectListItem { Text = "Obsolete", Value = "Obsolete" });
            }
            else
            {
                Project_Status_items.Add(new SelectListItem { Text = "Select", Value = "Select" });
                Project_Status_items.Add(new SelectListItem { Text = "Pipeline", Value = "Pipeline" });
                Project_Status_items.Add(new SelectListItem { Text = "InProgress", Value = "InProgress" });
                Project_Status_items.Add(new SelectListItem { Text = "Completed", Value = "Completed" });
                Project_Status_items.Add(new SelectListItem { Text = "Obsolete", Value = "Obsolete" });
            }

            selectmodel.LoadStatusList = Project_Status_items;

            selectmodel.Selectedvalue = ds.Tables[0].Rows[0]["Project_Status"].ToString();

            List<SelectListItem> Type_items = new List<SelectListItem>();

            Type_items.Add(new SelectListItem() { Text = "Select", Value = "Select" });
            Type_items.Add(new SelectListItem() { Text = "Leveraging Existing Tool" });
            Type_items.Add(new SelectListItem() { Text = "Macro", Value = "Macro" });
            Type_items.Add(new SelectListItem() { Text = "New Automation", Value = "New Automation" });
            Type_items.Add(new SelectListItem() { Text = "Web App", Value = "Web App" });

            selectmodel.TypeList = Type_items;

            selectmodel.Type = ds.Tables[0].Rows[0]["Type"].ToString();

            List<SelectListItem> Status_items = new List<SelectListItem>();

            Status_items.Add(new SelectListItem() { Text = "Select", Value = "Select" });
            Status_items.Add(new SelectListItem() { Text = "Open", Value = "Open" });
            Status_items.Add(new SelectListItem() { Text = "Approved", Value = "Approved" });
            Status_items.Add(new SelectListItem() { Text = "Tentatively Approved", Value = "Tentatively Approved" });
            Status_items.Add(new SelectListItem() { Text = "Rejected", Value = "Rejected" });

            selectmodel.StatusList = Status_items;

            selectmodel.Status = ds.Tables[0].Rows[0]["Status"].ToString();

            List<SelectListItem> InProgress_Status_items = new List<SelectListItem>();
            if (ds.Tables[0].Rows[0]["Project_Status"].ToString() == "InProgress")
            {
                InProgress_Status_items.Add(new SelectListItem() { Text = "Select", Value = "Select" });
                InProgress_Status_items.Add(new SelectListItem() { Text = "InProgress", Value = "InProgress" });
                InProgress_Status_items.Add(new SelectListItem() { Text = "UAT", Value = "UAT" });
                //InProgress_Status_items.Add(new SelectListItem() { Text = "Re-Open", Value = "Re-Open" });
                InProgress_Status_items.Add(new SelectListItem() { Text = "LIVE", Value = "LIVE" });
                //InProgress_Status_items.Add(new SelectListItem() { Text = "On-Hold", Value = "On-Hold" });
            }
            else if (ds.Tables[0].Rows[0]["Project_Status"].ToString() == "Completed")
            {
                InProgress_Status_items.Add(new SelectListItem() { Text = "Select", Value = "Select" });
                //InProgress_Status_items.Add(new SelectListItem() { Text = "InProgress", Value = "InProgress" });
                InProgress_Status_items.Add(new SelectListItem() { Text = "UAT", Value = "UAT" });
                //InProgress_Status_items.Add(new SelectListItem() { Text = "Re-Open", Value = "Re-Open" });
                InProgress_Status_items.Add(new SelectListItem() { Text = "LIVE", Value = "LIVE" });
                //InProgress_Status_items.Add(new SelectListItem() { Text = "On-Hold", Value = "On-Hold" });
            }
            else if (ds.Tables[0].Rows[0]["Project_Status"].ToString() == "Obsolete")
            {
                InProgress_Status_items.Add(new SelectListItem() { Text = "Select", Value = "Select" });
                //InProgress_Status_items.Add(new SelectListItem() { Text = "InProgress", Value = "InProgress" });
                //InProgress_Status_items.Add(new SelectListItem() { Text = "UAT", Value = "UAT" });
                InProgress_Status_items.Add(new SelectListItem() { Text = "Re-Open", Value = "Re-Open" });
                //InProgress_Status_items.Add(new SelectListItem() { Text = "LIVE", Value = "LIVE" });
                //InProgress_Status_items.Add(new SelectListItem() { Text = "On-Hold", Value = "On-Hold" });
            }
            else
            {
                InProgress_Status_items.Add(new SelectListItem() { Text = "Select", Value = "Select" });
                InProgress_Status_items.Add(new SelectListItem() { Text = "InProgress", Value = "InProgress" });
                InProgress_Status_items.Add(new SelectListItem() { Text = "UAT", Value = "UAT" });
                InProgress_Status_items.Add(new SelectListItem() { Text = "Re-Open", Value = "Re-Open" });
                InProgress_Status_items.Add(new SelectListItem() { Text = "LIVE", Value = "LIVE" });
                InProgress_Status_items.Add(new SelectListItem() { Text = "On-Hold", Value = "On-Hold" });
            }


            selectmodel.InProgress_StatusList = InProgress_Status_items;
            if (ds.Tables[0].Rows[0]["InProgress_Status"].ToString() == "")
            {
                selectmodel.InProgress_Status = "Select";
            }
            else
            {
                selectmodel.InProgress_Status = ds.Tables[0].Rows[0]["InProgress_Status"].ToString();
            }

            List<SelectListItem> Location_items = new List<SelectListItem>();

            Location_items.Add(new SelectListItem() { Text = "Select", Value = "Select" });
            Location_items.Add(new SelectListItem() { Text = "Bangalore I", Value = "Bangalore I" });
            Location_items.Add(new SelectListItem() { Text = "Bangalore II", Value = "Bangalore II" });
            Location_items.Add(new SelectListItem() { Text = "Chennai I", Value = "Chennai I" });
            Location_items.Add(new SelectListItem() { Text = "Chennai II", Value = "Chennai II" });
            Location_items.Add(new SelectListItem() { Text = "Trichy I", Value = "Trichy I" });
            Location_items.Add(new SelectListItem() { Text = "Trichy II", Value = "Trichy II" });
            Location_items.Add(new SelectListItem() { Text = "Trichy III", Value = "Trichy III" });
            Location_items.Add(new SelectListItem() { Text = "Manila", Value = "Manila" });
            Location_items.Add(new SelectListItem() { Text = "Bhimavaram", Value = "Bhimavaram" });

            selectmodel.LocationList = Location_items;

            selectmodel.Location = ds.Tables[0].Rows[0]["Location"].ToString();

            List<SelectListItem> Vertical_items = new List<SelectListItem>();

            Vertical_items.Add(new SelectListItem() { Text = "Select", Value = "Select" });
            Vertical_items.Add(new SelectListItem() { Text = "DATA", Value = "DATA" });
            Vertical_items.Add(new SelectListItem() { Text = "CODING", Value = "CODING" });
            Vertical_items.Add(new SelectListItem() { Text = "AR", Value = "AR" });
            Vertical_items.Add(new SelectListItem() { Text = "RCM", Value = "RCM" });
            Vertical_items.Add(new SelectListItem() { Text = "CENTREX", Value = "CENTREX" });

            selectmodel.VerticalList = Vertical_items;

            selectmodel.Vertical = ds.Tables[0].Rows[0]["Vertical"].ToString();

            List<SelectListItem> Priority_items = new List<SelectListItem>();

            Priority_items.Add(new SelectListItem() { Text = "Select", Value = "Select" });
            Priority_items.Add(new SelectListItem() { Text = "HIGH", Value = "HIGH" });
            Priority_items.Add(new SelectListItem() { Text = "MEDIUM", Value = "MEDIUM" });
            Priority_items.Add(new SelectListItem() { Text = "LOW", Value = "LOW" });

            selectmodel.PriorityList = Priority_items;

            selectmodel.Priority = ds.Tables[0].Rows[0]["Priority"].ToString();

            List<SelectListItem> Process_Re_engineering_items = new List<SelectListItem>();

            Process_Re_engineering_items.Add(new SelectListItem() { Text = "Select", Value = "Select", Selected = true });
            Process_Re_engineering_items.Add(new SelectListItem() { Text = "YES", Value = "YES" });
            Process_Re_engineering_items.Add(new SelectListItem() { Text = "NO", Value = "NO" });

            selectmodel.Process_Re_engineeringList = Process_Re_engineering_items;

            selectmodel.Process_Re_engineering = ds.Tables[0].Rows[0]["Process_Re_engineering"].ToString();

            return View(selectmodel);
        }

        [HttpPost]
        public ActionResult Update_Project(FormCollection collection)
        {
            string confirmValue = Request.Form["confirm_value"];
            string confirmdelvalue = Request.Form["confirmdel_value"];
            if (confirmValue != null && confirmdelvalue == null)
            {
                if (confirmValue == "Yes")
                {
                    Automation_Tracker_Master objTrackerMaster = new Automation_Tracker_Master();

                    //objTrackerMaster.Project_Name = collection["txtProjectName"].ToString();
                    objTrackerMaster.Project_Unique_ID = Convert.ToInt32(Session["id"].ToString());
                    objTrackerMaster.Client = collection["txtClient"].ToString();
                    objTrackerMaster.Project_Name = collection["txtProjectName"].ToString();
                    objTrackerMaster.Process = collection["txtProcess"].ToString();
                    objTrackerMaster.Description = collection["txtDescription"].ToString();
                    objTrackerMaster.Type = collection["Type"].ToString();
                    objTrackerMaster.Status = collection["Status"].ToString();
                    objTrackerMaster.Project_Status = collection["Selectedvalue"].ToString();
                    if (collection["InProgress_Status"].ToString() == "Select")
                    {
                        objTrackerMaster.InProgress_Status = "";
                    }
                    else
                    {
                        objTrackerMaster.InProgress_Status = collection["InProgress_Status"].ToString();
                    }
                    DateTime? date = null;
                    if (!string.IsNullOrEmpty(collection["txtRequest_Received_Date"].ToString()))
                    {
                        string dateString = collection["txtRequest_Received_Date"].ToString();
                        date = Convert.ToDateTime(dateString, System.Globalization.CultureInfo.GetCultureInfo("ur-PK").DateTimeFormat);
                    }
                    else if (!string.IsNullOrEmpty(collection["txtRequest_Received_Date"].ToString()))
                    {
                        string dateString = collection["txtRequest_Received_Date"].ToString();
                        date = Convert.ToDateTime(dateString, System.Globalization.CultureInfo.GetCultureInfo("ur-PK").DateTimeFormat);
                    }
                    objTrackerMaster.Request_Received_Date = date;

                    DateTime? ApprovedRejectedDate = null;
                    if (!string.IsNullOrEmpty(collection["txtApproved_Rejected_Date"].ToString()))
                    {
                        string Approved_Rejected_Date = collection["txtApproved_Rejected_Date"].ToString();
                        ApprovedRejectedDate = Convert.ToDateTime(Approved_Rejected_Date, System.Globalization.CultureInfo.GetCultureInfo("ur-PK").DateTimeFormat);
                    }
                    else if (!string.IsNullOrEmpty(collection["txtApproved_Rejected_Date"].ToString()))
                    {
                        string Approved_Rejected_Date = collection["txtApproved_Rejected_Date"].ToString();
                        ApprovedRejectedDate = Convert.ToDateTime(Approved_Rejected_Date, System.Globalization.CultureInfo.GetCultureInfo("ur-PK").DateTimeFormat);
                    }
                    objTrackerMaster.Approved_Rejected_Date = ApprovedRejectedDate;

                    objTrackerMaster.Location = collection["Location"].ToString();
                    objTrackerMaster.Vertical = collection["Vertical"].ToString();

                    objTrackerMaster.Fully_Loaded_FTE_Cost_dollar = collection["txtFully_Loaded_FTE_Cost_dollar"].ToString();
                    objTrackerMaster.Est_dollar_savings = collection["txtEst_dollar_savings"].ToString();
                    objTrackerMaster.Est_Effort_Cost_dollar = collection["txtEst_Effort_Cost_dollar"].ToString();

                    objTrackerMaster.Manager = collection["txtManager"].ToString();
                    objTrackerMaster.SPOC = collection["txtSPOC"].ToString();
                    objTrackerMaster.Remarks = collection["txtRemarks"].ToString();
                    objTrackerMaster.EXT = collection["txtEXT"].ToString();
                    //objTrackerMaster.Priority = collection["Priority"].ToString();
                    if (collection["Priority"].ToString() == "Select")
                    {
                        objTrackerMaster.Priority = "";
                    }
                    else
                    {
                        objTrackerMaster.Priority = collection["Priority"].ToString();
                    }
                    DateTime? ProjectStartDate = null;
                    if (!string.IsNullOrEmpty(collection["txtProject_Start_Date"].ToString()))
                    {
                        string Project_Start_DateString = collection["txtProject_Start_Date"].ToString();
                        ProjectStartDate = Convert.ToDateTime(Project_Start_DateString, System.Globalization.CultureInfo.GetCultureInfo("ur-PK").DateTimeFormat);
                    }
                    else if (!string.IsNullOrEmpty(collection["txtProject_Start_Date"].ToString()))
                    {
                        string Project_Start_DateString = collection["txtProject_Start_Date"].ToString();
                        ProjectStartDate = Convert.ToDateTime(Project_Start_DateString, System.Globalization.CultureInfo.GetCultureInfo("ur-PK").DateTimeFormat);
                    }
                    objTrackerMaster.Project_Start_Date = ProjectStartDate;

                    DateTime? PlannedCompletionDate = null;
                    if (!string.IsNullOrEmpty(collection["txtPlanned_Completion_Date"].ToString()))
                    {
                        string Planned_Completion_DateString = collection["txtPlanned_Completion_Date"].ToString();
                        PlannedCompletionDate = Convert.ToDateTime(Planned_Completion_DateString, System.Globalization.CultureInfo.GetCultureInfo("ur-PK").DateTimeFormat);
                    }
                    else if (!string.IsNullOrEmpty(collection["txtPlanned_Completion_Date"].ToString()))
                    {
                        string Planned_Completion_DateString = collection["hPlanned_Completion_Date"].ToString();
                        PlannedCompletionDate = Convert.ToDateTime(Planned_Completion_DateString, System.Globalization.CultureInfo.GetCultureInfo("ur-PK").DateTimeFormat);
                    }
                    objTrackerMaster.Planned_Completion_Date = PlannedCompletionDate;

                    DateTime? ActualCompletionDate = null;
                    if (!string.IsNullOrEmpty(collection["txtActual_Completion_Date"].ToString()))
                    {
                        string Actual_Completion_DateString = collection["txtActual_Completion_Date"].ToString();
                        ActualCompletionDate = Convert.ToDateTime(Actual_Completion_DateString, System.Globalization.CultureInfo.GetCultureInfo("ur-PK").DateTimeFormat);
                    }
                    else if (!string.IsNullOrEmpty(collection["txtActual_Completion_Date"].ToString()))
                    {
                        string Actual_Completion_DateString = collection["txtActual_Completion_Date"].ToString();
                        ActualCompletionDate = Convert.ToDateTime(Actual_Completion_DateString, System.Globalization.CultureInfo.GetCultureInfo("ur-PK").DateTimeFormat);
                    }
                    objTrackerMaster.Actual_Completion_Date = ActualCompletionDate;

                    objTrackerMaster.Resources_Involved = collection["txtResources_Involved"].ToString();
                    objTrackerMaster.Hash_Resources_Required = collection["txtHash_Resources_Required"].ToString();

                    DateTime? UATReleaseDate = null;
                    if (!string.IsNullOrEmpty(collection["txtUAT_Release_Date"].ToString()))
                    {
                        string UAT_Release_Date = collection["txtUAT_Release_Date"].ToString();
                        UATReleaseDate = Convert.ToDateTime(UAT_Release_Date, System.Globalization.CultureInfo.GetCultureInfo("ur-PK").DateTimeFormat);
                    }
                    else if (!string.IsNullOrEmpty(collection["txtUAT_Release_Date"].ToString()))
                    {
                        string UAT_Release_Date = collection["txtUAT_Release_Date"].ToString();
                        UATReleaseDate = Convert.ToDateTime(UAT_Release_Date, System.Globalization.CultureInfo.GetCultureInfo("ur-PK").DateTimeFormat);
                    }
                    objTrackerMaster.UAT_Release_Date = UATReleaseDate;

                    DateTime? LIVEReleaseDate = null;
                    if (!string.IsNullOrEmpty(collection["txtLIVE_Release_Date"].ToString()))
                    {
                        string LIVE_Release_Date = collection["txtLIVE_Release_Date"].ToString();
                        LIVEReleaseDate = Convert.ToDateTime(LIVE_Release_Date, System.Globalization.CultureInfo.GetCultureInfo("ur-PK").DateTimeFormat);
                    }
                    else if (!string.IsNullOrEmpty(collection["txtLIVE_Release_Date"].ToString()))
                    {
                        string LIVE_Release_Date = collection["txtLIVE_Release_Date"].ToString();
                        LIVEReleaseDate = Convert.ToDateTime(LIVE_Release_Date, System.Globalization.CultureInfo.GetCultureInfo("ur-PK").DateTimeFormat);
                    }
                    objTrackerMaster.LIVE_Release_Date = LIVEReleaseDate;

                    objTrackerMaster.UAT_Remarks = collection["txtUAT_Remarks"].ToString();
                    objTrackerMaster.LIVE_Remarks = collection["txtLIVE_Remarks"].ToString();


                    DateTime? ReleaseDateString = null;
                    string Release_DateString = string.Empty;
                    if (!string.IsNullOrEmpty(collection["txtRelease_Date"].ToString()))
                    {
                        Release_DateString = collection["txtRelease_Date"].ToString();
                        ReleaseDateString = Convert.ToDateTime(Release_DateString, System.Globalization.CultureInfo.GetCultureInfo("ur-PK").DateTimeFormat);
                    }
                    else if (!string.IsNullOrEmpty(collection["txtRelease_Date"].ToString()))
                    {
                        Release_DateString = collection["txtRelease_Date"].ToString();
                        ReleaseDateString = Convert.ToDateTime(Release_DateString, System.Globalization.CultureInfo.GetCultureInfo("ur-PK").DateTimeFormat);
                    }

                    objTrackerMaster.Release_Date = ReleaseDateString;

                    objTrackerMaster.Release_Type = collection["txtRelease_Type"].ToString();

                    DateTime? BenefitSignoffDateString = null;
                    if (!string.IsNullOrEmpty(collection["txtBenefit_Sign_off_Date"].ToString()))
                    {
                        string Benefit_Sign_off_DateString = collection["txtBenefit_Sign_off_Date"].ToString();
                        BenefitSignoffDateString = Convert.ToDateTime(Benefit_Sign_off_DateString, System.Globalization.CultureInfo.GetCultureInfo("ur-PK").DateTimeFormat);
                    }
                    else if (!string.IsNullOrEmpty(collection["txtBenefit_Sign_off_Date"].ToString()))
                    {
                        string Benefit_Sign_off_DateString = collection["txtBenefit_Sign_off_Date"].ToString();
                        BenefitSignoffDateString = Convert.ToDateTime(Benefit_Sign_off_DateString, System.Globalization.CultureInfo.GetCultureInfo("ur-PK").DateTimeFormat);
                    }
                    objTrackerMaster.Benefit_Sign_off_Date = BenefitSignoffDateString;

                    //objTrackerMaster.Process_Re_engineering = collection["Process_Re_engineering"].ToString();
                    if (collection["Process_Re_engineering"].ToString() == "Select")
                    {
                        objTrackerMaster.Process_Re_engineering = "";
                    }
                    else
                    {
                        objTrackerMaster.Priority = collection["Process_Re_engineering"].ToString();
                    }
                    objTrackerMaster.No_FTEs_Involved = collection["txtNo_FTEs_Involved"].ToString();
                    objTrackerMaster.Effort_Man_days = collection["txtEffort_Man_days"].ToString();
                    objTrackerMaster.Est_Prod_Impv_percent = collection["txtEst_Prod_Impv_percent"].ToString();
                    objTrackerMaster.Act_Prod_Impv_percent = collection["txtAct_Prod_Impv_percent"].ToString();
                    objTrackerMaster.Est_Quality_Impv_percent = collection["txtEst_Quality_Impv_percent"].ToString();
                    objTrackerMaster.Act_Quality_Impv_percent = collection["txtAct_Quality_Impv_percent"].ToString();
                    objTrackerMaster.Est_FTE_Saving = collection["txtEst_FTE_Saving"].ToString();
                    objTrackerMaster.Revised_Est_FTE_Saving = collection["txtRevised_Est_FTE_Saving"].ToString();
                    objTrackerMaster.Act_FTE_Saving = collection["txtAct_FTE_Saving"].ToString();
                    objTrackerMaster.Est_Hours_saved_FTE = collection["txtEst_Hours_saved_FTE"].ToString();
                    objTrackerMaster.Act_Hours_saved_FTE = collection["txtAct_Hours_saved_FTE"].ToString();
                    objTrackerMaster.Comments = collection["txtComments"].ToString();
                    objTrackerMaster.Application = collection["txtApplication"].ToString();
                    objTrackerMaster.Enter_By = System.Environment.UserName.ToString();
                    objTrackerService.Update_Project(objTrackerMaster);
                    return RedirectToAction("Index", "Tracker_Display");
                }
                else
                {

                    return RedirectToAction("ShowUpdate", "Tracker_Display");
                }
            }
            else if (confirmValue == null && confirmdelvalue != null)
            {
                if (confirmdelvalue == "Yes")
                {
                    Automation_Tracker_Master objTrackerMaster = new Automation_Tracker_Master();

                    //objTrackerMaster.Project_Name = collection["txtProjectName"].ToString();
                    objTrackerMaster.Project_Unique_ID = Convert.ToInt32(Session["id"].ToString());

                    objTrackerService.Delete_Project(objTrackerMaster);
                    return RedirectToAction("Index", "Tracker_Display");
                }
                else
                {

                    return RedirectToAction("Index", "Tracker_Display");
                }
            }
            else
            {
                return RedirectToAction("Index", "Tracker_Display");
            }

        }

        public ActionResult StatusWithViewBag()
        {
            List<SelectListItem> items = new List<SelectListItem>();

            items.Add(new SelectListItem
            {
                Text = "Select",
                Value = "0",
            });

            items.Add(new SelectListItem { Text = "Pipeline", Value = "Pipeline" });

            items.Add(new SelectListItem { Text = "InProgress", Value = "InProgress" });

            items.Add(new SelectListItem { Text = "Completed", Value = "Completed" });

            items.Add(new SelectListItem { Text = "Absolute", Value = "Absolute" });

            ViewBag.StatusType = new SelectList(items, "Value", "Text");
            //var model = new CategoryModel()
            //{
            //    lstCategory = items,
            //    selected = 1
            //};

            return View();
        }

        public void count()
        {
            Session["Count_Total"] = Convert.ToInt32(Session["count_InProgress"].ToString()) + Convert.ToInt32(Session["count_Accomplishments"].ToString());
            DataSet ds_count = objTrackerService.Track_Details_Count_All_Details();
            if (ds_count.Tables[0].Rows.Count > 0)
            {
                Session["count_Pipeline_0"] = ds_count.Tables[0].Rows[0][0].ToString();
                Session["count_Pipeline_Re_Open"] = ds_count.Tables[0].Rows[0][1].ToString();
                Session["count_Pipeline_On_Hold"] = ds_count.Tables[0].Rows[0][2].ToString();
                Session["count_InProgress_0"] = ds_count.Tables[0].Rows[0][3].ToString();
                Session["count_InProgress_InProgress"] = ds_count.Tables[0].Rows[0][4].ToString();
                Session["count_InProgress_UAT"] = ds_count.Tables[0].Rows[0][5].ToString();
                Session["count_InProgress_Re_Open"] = ds_count.Tables[0].Rows[0][6].ToString();
                Session["count_InProgress_LIVE"] = ds_count.Tables[0].Rows[0][7].ToString();
                Session["count_InProgress_On_Hold"] = ds_count.Tables[0].Rows[0][8].ToString();
                Session["count_Completed_0"] = ds_count.Tables[0].Rows[0][9].ToString();
                Session["count_Completed_UAT"] = ds_count.Tables[0].Rows[0][10].ToString();
                Session["count_Completed_LIVE"] = ds_count.Tables[0].Rows[0][11].ToString();
                Session["count_Obsolete_0"] = ds_count.Tables[0].Rows[0][12].ToString();
                Session["count_Obsolete_Re_Open"] = ds_count.Tables[0].Rows[0][13].ToString();
                Session["count_Obsolete_On_Hold"] = ds_count.Tables[0].Rows[0][14].ToString();
            }
            else
            {
                Session["count_Pipeline_0"] = null;
                Session["count_Pipeline_Re_Open"] = null;
                Session["count_Pipeline_On_Hold"] = null;
                Session["count_InProgress_0"] = null;
                Session["count_InProgress_InProgress"] = null;
                Session["count_InProgress_UAT"] = null;
                Session["count_InProgress_Re_Open"] = null;
                Session["count_InProgress_LIVE"] = null;
                Session["count_InProgress_On_Hold"] = null;
                Session["count_Completed_0"] = null;
                Session["count_Completed_UAT"] = null;
                Session["count_Completed_LIVE"] = null;
                Session["count_Obsolete_0"] = null;
                Session["count_Obsolete_Re_Open"] = null;
                Session["count_Obsolete_On_Hold"] = null;
            }

            if (Session["count_Pipeline_0"] != null)
            { }
            else
            {
                Session["count_Pipeline_0"] = "0";
            }
            if (Session["count_Pipeline_Re_Open"] != null)
            { }
            else
            {
                Session["count_Pipeline_Re_Open"] = "0";
            }
            if (Session["count_Pipeline_On_Hold"] != null)
            { }
            else
            {
                Session["count_Pipeline_On_Hold"] = "0";
            }
            if (Session["count_InProgress_0"] != null)
            { }
            else
            {
                Session["count_InProgress_0"] = "0";
            }
            if (Session["count_InProgress_InProgress"] != null)
            { }
            else
            {
                Session["count_InProgress_InProgress"] = "0";
            }
            if (Session["count_InProgress_UAT"] != null)
            { }
            else
            {
                Session["count_InProgress_UAT"] = "0";
            }
            if (Session["count_InProgress_Re_Open"] != null)
            { }
            else
            {
                Session["count_InProgress_Re_Open"] = "0";
            }
            if (Session["count_InProgress_LIVE"] != null)
            { }
            else
            {
                Session["count_InProgress_LIVE"] = "0";
            }
            if (Session["count_InProgress_On_Hold"] != null)
            { }
            else
            {
                Session["count_InProgress_On_Hold"] = "0";
            }
            if (Session["count_Completed_0"] != null)
            { }
            else
            {
                Session["count_Completed_0"] = "0";
            }
            if (Session["count_Completed_UAT"] != null)
            { }
            else
            {
                Session["count_Completed_UAT"] = "0";
            }
            if (Session["count_Completed_LIVE"] != null)
            { }
            else
            {
                Session["count_Completed_LIVE"] = "0";
            }
            if (Session["count_Obsolete_0"] != null)
            { }
            else
            {
                Session["count_Obsolete_0"] = "0";
            }
            if (Session["count_Obsolete_Re_Open"] != null)
            { }
            else
            {
                Session["count_Obsolete_Re_Open"] = "0";
            }
            if (Session["count_Obsolete_On_Hold"] != null)
            { }
            else
            {
                Session["count_Obsolete_On_Hold"] = "0";
            }
            Session["count_Pipeline_total"] = Convert.ToInt32(Session["count_Pipeline_0"].ToString()) + Convert.ToInt32(Session["count_Pipeline_Re_Open"].ToString()) + Convert.ToInt32(Session["count_Pipeline_On_Hold"].ToString());
            Session["count_Inprogress_total"] = Convert.ToInt32(Session["count_InProgress_0"].ToString()) + Convert.ToInt32(Session["count_InProgress_InProgress"].ToString()) + Convert.ToInt32(Session["count_InProgress_UAT"].ToString()) + Convert.ToInt32(Session["count_InProgress_Re_Open"].ToString()) + Convert.ToInt32(Session["count_InProgress_LIVE"].ToString()) + Convert.ToInt32(Session["count_InProgress_On_Hold"].ToString());
        }
        public void session_activate()
        {
            if (Session["count_Pipeline"] != null)
            { }
            else
            {
                Session["count_Pipeline"] = "0";
            }
            if (Session["count_InProgress"] != null)
            { }
            else
            {
                Session["count_InProgress"] = "0";
            }
            if (Session["count_Completed"] != null)
            { }
            else
            {
                Session["count_Completed"] = "0";
            }
            if (Session["count_Obsolete"] != null)
            { }
            else
            {
                Session["count_Obsolete"] = "0";
            }
            if (Session["count_Accomplishments"] != null)
            { }
            else
            {
                Session["count_Accomplishments"] = "0";
            }
        }



        public ActionResult ATEditProject(int strProjectID, string strStatus = null)
        {
            return PartialView("_ATEditProject", objAT.ATEditProject(strProjectID, strStatus));
        }

        public ActionResult ATADDProject(int strProjectID, string strStatus = null)
        {
            return PartialView("_ATAddProject", objAT.ATADDProject(strProjectID, strStatus));
        }


        public ActionResult ATADDEditProject(int strProjectID, string strStatus = null, string DbCondition = null)
        {

            if (DbCondition == "Edit")
            {
                return PartialView("_ATEditProject", objAT.ATADDEditProject(strProjectID, strStatus, DbCondition));
            }
            else 
            {
                return PartialView("_ATAddProject", objAT.ATADDEditProject(strProjectID, strStatus, DbCondition));
            }          
        }
    }

}
