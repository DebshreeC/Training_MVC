﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Automation_Tracker_Inhouse.Controllers
{
    public class BUHAllprojectController : Controller
    {
        //
        // GET: /BUHAllproject/
        AT.BAL.Managers.BUHAllProject objF = new AT.BAL.Managers.BUHAllProject();
        public ActionResult BUHAllproject()
        {
            return View();
        }

        public ActionResult getBUHAllProjectDetails( string dtFromdate, string dtTodate)
        {
            return PartialView("_BUHAllProject", objF.getBUHAllProjectDetails(dtFromdate, dtTodate));
        }

    }
}
