﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using AT.BAL.Managers;

namespace Automation_Tracker_Inhouse.Controllers
{
    public class SummaryController : Controller
    {
        //
        // GET: /Summary/


        SummaryManager objS = new SummaryManager();

        public ActionResult Summary()
        {
            return View();
        }


        public ActionResult getFirstReport(string strFntype)
        {
            return PartialView("_Firstsummary", objS.getsummaryData(strFntype));
        }
        public ActionResult getSecondReport(string strFntype)
        {
            return PartialView("_Secondsummary", objS.getsummaryData(strFntype));
        }
        public ActionResult getThirdReport(string strFntype)
        {
            return PartialView("_thirdreport", objS.getsummaryData(strFntype));
        }
    }
}
