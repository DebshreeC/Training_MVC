﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using AT.BAL;
using AT.BAL.Managers;
using AT.BAL.ViewModel;

namespace Automation_Tracker_Inhouse.Controllers
{
    public class TeamsAccomplishmentsController : Controller
    {
        //
        // GET: /TeamsAccomplishments/

        TeamsAccomplishmentsManager objT = new TeamsAccomplishmentsManager();
        public ActionResult Index()
        {
            return View();
        }
        public ActionResult TeamsAccomplishments()
        {
            return View();
        }        
        public ActionResult ATADDEditProject(int strProjectID, string strStatus, string DbCondition)
        {
            return PartialView("_TeamsAccomplishments", objT.ATADDEditProject(strProjectID, strStatus, DbCondition));
        }
    }
}
