﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Data;
using System.Data.SqlClient;
using Automation_Tracker.Models;
using System.ComponentModel.DataAnnotations;

namespace Automation_Tracker_Inhouse.Controllers
{
    public class ApprovedController : Controller
    {
        //
        // GET: /Approved/
        Automation_Tracker_Services objTrackerService = new Automation_Tracker_Services();
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult ApprovedProject(string Approval_Status)
        {
            Session["UserName"] = System.Environment.UserName.ToString();
            string Project_Status = "Pipeline";
            ViewBag.total = objTrackerService.GetProject_by_Project_Status(Project_Status).ToList().Count;
            Session["count_Pipeline"] = ViewBag.total;
           
            Session["Status"] = "Pipeline";
            ViewBag.ProjectHeading = "Pipeline Project List";
            if (Approval_Status == null)
            {
                DataTable dt = objTrackerService.Select_ColumnList_Track_Details_Approved(1, 0, Project_Status.ToString(), "Open");
                return View(dt);
            }
            else
            {
                if (Approval_Status.ToString() == "Open")
                {
                    DataTable dt = objTrackerService.Select_ColumnList_Track_Details_Approved(1, 0, Project_Status.ToString(), "Open");
                    return View(dt);
                }
                else if (Approval_Status.ToString() == "Approved")
                {
                    DataTable dt = objTrackerService.Select_ColumnList_Track_Details_Approved(1, 0, Project_Status.ToString(), "Approved");
                    return View(dt);
                }
                else if (Approval_Status.ToString() == "TentativelyApproved")
                {
                    DataTable dt = objTrackerService.Select_ColumnList_Track_Details_Approved(1, 0, Project_Status.ToString(), "Tentatively Approved");
                    return View(dt);
                }
                else if (Approval_Status.ToString() == "Rejected")
                {
                    DataTable dt = objTrackerService.Select_ColumnList_Track_Details_Approved(1, 0, Project_Status.ToString(), "Rejected");
                    return View(dt);
                }
                else
                {
                    DataTable dt = objTrackerService.Select_ColumnList_Track_Details_Approved(1, 0, Project_Status.ToString(), "Open");
                    return View(dt);
                }
            }

            
        }


        public ActionResult Approved_Project(string confirm_msg, string Project_no, string Status)
        {
            try
            {
                string confirmValue = confirm_msg.ToString();
                if (confirmValue == "Yes")
                {
                    Automation_Tracker_Master objTrackerMaster = new Automation_Tracker_Master();
                    objTrackerMaster.Project_Unique_ID = Convert.ToInt32(Project_no.ToString());
                    objTrackerMaster.Status = Status;
                    objTrackerService.Track_Details_Approved(objTrackerMaster);
                    //return JavaScript("testval()");
                    return RedirectToAction("ApprovedProject", "Approved");
                }
                else
                {
                    return View();
                }
            }
            catch (Exception ex)
            {
                return View();
            }
        }


        public ActionResult Date()
        {


            return View();
        }
    }
}
