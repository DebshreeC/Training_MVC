﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using AT.BAL;
using AT.BAL.Managers;
using AT.BAL.ViewModel;
namespace Automation_Tracker_Inhouse.Controllers
{
    public class DevCostController : Controller
    {
        //
        // GET: /DevCost/
        AT.BAL.Managers.DevcostManager obj = new AT.BAL.Managers.DevcostManager();
        ATMapping objAT = new ATMapping();
        public ActionResult DevCost()
        {
            return View();
        }



        public JsonResult InsertDevCost(decimal dev_cost, string strEffectivedate, string strCon, string strdevid, string strResourceid)
        {
            obj.InsertProject(dev_cost, strEffectivedate, strCon, strdevid, strResourceid);
            return Json("", JsonRequestBehavior.AllowGet);

        }

        public ActionResult getDevCostDetails(string status)
        {
            return PartialView("_Devcost", obj.getDevCostDetails(status));
        }


        public ActionResult getResourceName(string strFntype)
        {
              AT.BAL.ViewModel.DevCostModel objI = new AT.BAL.ViewModel.DevCostModel();
            IEnumerable<SelectListItem> DevnameList = objAT.GetResourceNames(strFntype);
            var result = new SelectList(DevnameList, "Value", "Text");

            return Json(result, JsonRequestBehavior.AllowGet);

        }
    }
}
