﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.Mvc;
using System.Xml;
using System.Xml.Serialization;
using System.Web.UI.WebControls;
using System.Web.UI;
using System.Data;

namespace Automation_Tracker_Inhouse.Controllers
{
    public class FTEReportController : Controller
    {
        //
        // GET: /FTEReport/

        AT.BAL.Managers.FTEReportManager objF = new AT.BAL.Managers.FTEReportManager();
        public ActionResult FTEReport()
        {
            return View();
        }


        public ActionResult getFTEProjectDetails(string strStatus, string dtFromdate, string dtTodate)
        {
            return PartialView("_FTEReport", objF.getFTEProjectDetails(strStatus, dtFromdate, dtTodate));
        }

        public ActionResult CheckFinyear(string dtFromdate, string dtTodate)
        {

            string str = objF.CheckFinyear(dtFromdate, dtTodate);
            return Json(str, JsonRequestBehavior.AllowGet);
            

        }

        public ActionResult OverallReportResult( string dtFromdate, string dtTodate)
        {
            return PartialView("_OverallReport", objF.OverallSaving(dtFromdate, dtTodate));
        }


        public ActionResult OverallReport()
        {
            return View();
        }

        //public JsonResult OverallReport(AT.BAL.ViewModel.FTEReportModel mol)
        //{
        //    DataTable dt = objF.OverallSaving(mol.strfromDate, mol.strTodate );
        //    var list = dt.AsEnumerable().Select(x => x.ItemArray.ToList()).ToList();

        //    return Json(list, JsonRequestBehavior.AllowGet);

        //}


        [HttpPost]
        public JsonResult ExportToExcel(string strStatus, string dtFromdate, string dtTodate)
        {
            DataTable dt = objF.getFTEProjectDetails(strStatus, dtFromdate, dtTodate);
            var list = dt.AsEnumerable().Select(x => x.ItemArray.ToList()).ToList();

            return Json(list, JsonRequestBehavior.AllowGet);

        }
        [HttpPost]
        public ActionResult ExportExcel(AT.BAL.ViewModel.FTEReportModel obj)
        {
            DataTable dt = new DataTable();

            dt = objF.getFTEProjectDetails("", obj.strfromDate, obj.strTodate);

            try
            {
                FileExcel(dt, "BUHReport");
                return Json(new { successCode = "1" });
            }
            catch (Exception ex)
            {
                return Json(new { successCode = "0" });
            }
        }

        public void FileExcel(DataTable dt,string strFilename)
        {
            GridView gv = new GridView();
            gv.DataSource = dt;
            gv.DataBind();

            HttpContext context = System.Web.HttpContext.Current;
            context.Response.ClearContent();
            context.Response.Buffer = true;
            context.Response.AddHeader("content-disposition", "attachment; filename="+ strFilename +".xls");
            context.Response.ContentType = "application/ms-excel";
            context.Response.Charset = "";
            StringWriter sw = new StringWriter();
            HtmlTextWriter htw = new HtmlTextWriter(sw);
            gv.RenderControl(htw);
            context.Response.Output.Write(sw.ToString());
            context.Response.Flush();
            htw.Close();
            sw.Close();
            context.Response.End();
        }


        public ActionResult OverAllExportExcel(AT.BAL.ViewModel.FTEReportModel obj)
        {
            DataTable dt = new DataTable();

            dt = objF.OverallSaving(obj.strfromDate, obj.strTodate);

            try
            {
                FileExcel(dt,"OverAllReport");
                return Json(new { successCode = "1" });
            }
            catch (Exception ex)
            {
                return Json(new { successCode = "0" });
            }
        }

        public ActionResult LoadFiscalYear(string strFntype)
        {
            IEnumerable<SelectListItem> BatchList = objF.LoadFiscalYear(strFntype);
            var result = new SelectList(BatchList, "Value", "Text");
            return Json(result, JsonRequestBehavior.AllowGet);
        }

        public ActionResult Search()
        {
            return View();
        }


        public ActionResult SearchPage(string strFntype)
        {
            return PartialView("_SearchPage", objF.SearchPage());
        }


    }
}
