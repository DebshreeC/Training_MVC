﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Automation_Tracker_Inhouse.Controllers
{
    public class insertProjectController : Controller
    {
        //
        // GET: /insertProject/
        AT.BAL.Managers.ATMapping objAT = new AT.BAL.Managers.ATMapping(); 
        public ActionResult insertProject()
        {
            AT.BAL.ViewModel.InsertProjectModel objI = new AT.BAL.ViewModel.InsertProjectModel();
            objI.BuhnameList = objAT.GetBUHNames();
            objI.clientList = objAT.GetBUHNames("Client");
            objI.ProcessList = objAT.GetBUHNames("Process");
            objI.SDHList = objAT.GetBUHNames("SDH");
            objI.LocationList = objAT.GetManagerNames("location");
            objI.VerticalList = objAT.GetManagerNames("Vertical");
            objI.ManagerList = objAT.GetManagerNames("Manager");
            objI.SPOCList = objAT.GetManagerNames("SPOC");
            return View(objI);
        }

        public ActionResult getclientName(string strFntype,string StrBUH,string strClient)
        {
            AT.BAL.ViewModel.InsertProjectModel objI = new AT.BAL.ViewModel.InsertProjectModel();
            IEnumerable<SelectListItem> BatchList = objAT.GetBUHNames(strFntype, StrBUH, strClient);
            var result = new SelectList(BatchList, "Value", "Text");
            return Json(result, JsonRequestBehavior.AllowGet);
        }

        public ActionResult GetManagerNames(string strFntype, string StrBUH, string strClient,string strProcess,string strLocation,string strVerical,string strManager)
        {
            AT.BAL.ViewModel.InsertProjectModel objI = new AT.BAL.ViewModel.InsertProjectModel();
            IEnumerable<SelectListItem> BatchList = objAT.GetManagerNames(strFntype, StrBUH, strClient, strProcess, strLocation, strVerical, strManager);
            var result = new SelectList(BatchList, "Value", "Text");
            return Json(result, JsonRequestBehavior.AllowGet);
        }

        public ActionResult GetBenefitsignedoffbyNames(string strFntype, string StrBUH, string strProjectid)
        {
            AT.BAL.ViewModel.InsertProjectModel objI = new AT.BAL.ViewModel.InsertProjectModel();
            IEnumerable<SelectListItem> BatchList = objAT.GetBenefitsignedoffbyNames(strFntype, StrBUH, strProjectid);
            var result = new SelectList(BatchList, "Value", "Text");
            return Json(result, JsonRequestBehavior.AllowGet);
        }


        public ActionResult GetEMPNames(string fntype, string project_unique_id, string emp_id)
        {
            AT.BAL.ViewModel.InsertProjectModel objI = new AT.BAL.ViewModel.InsertProjectModel();
            IEnumerable<SelectListItem> BatchList = objAT.GetEMPNames(fntype, project_unique_id, emp_id);
            var result = new SelectList(BatchList, "Value", "Text");
            return Json(result, JsonRequestBehavior.AllowGet);
        }
    }
}
