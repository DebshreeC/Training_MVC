﻿using AT.BAL.Managers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Automation_Tracker_Inhouse.Controllers
{
    public class ObsoleteController : Controller
    {
        //
        // GET: /Obsolete/
        InProgressManager objM = new InProgressManager();

        public ActionResult RejectedProjects()
        {
            return View();
        }

        public ActionResult getObsoleteProjectDetails(int strProjectID, string strStatus, string DbCondition)
        {
            return PartialView("_RejectedProjects", objM.ATADDEditProject(strProjectID, strStatus, DbCondition));
        }
    }
}
