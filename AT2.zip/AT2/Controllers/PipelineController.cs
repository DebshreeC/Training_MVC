﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Data;
using AT.BAL.Managers;
using AT.BAL.ViewModel;

namespace Automation_Tracker_Inhouse.Controllers
{
    public class PipelineController : Controller
    {
        //
        // GET: /Pipeline/
        PipelineManager objM = new PipelineManager();

        public ActionResult PipelineOpen()
        {
            return View();
        }


        public ActionResult ATADDEditProject(int strProjectID, string strStatus,string DbCondition)
        {
            return PartialView("_PipelineOpen", objM.ATADDEditProject(strProjectID, strStatus, DbCondition));
        }

        public ActionResult Pipeline()
        {
            return View();
        }

        public ActionResult getOpenProject(int strProjectID, string strStatus, string DbCondition)
        {
            return PartialView("_Pipelineproject", objM.ATADDEditProject(strProjectID, strStatus, DbCondition));
        }

        [HttpPost]
        public JsonResult TechCouncilapproval(string listOfAccounts, string strStatus, string strReason)
        {
            objM.TechCouncilapproval(listOfAccounts, strStatus, strReason);
            return Json("", JsonRequestBehavior.AllowGet);
        }
         
        public ActionResult PipelineApproved()
        {
            return View();
        }

        public ActionResult getApprovedProject(int strProjectID, string strStatus, string DbCondition)
        {
            return PartialView("_ApprovalProject", objM.ATADDEditProject(strProjectID, strStatus, DbCondition));
        }

        public ActionResult getTentativelyProject(int strProjectID, string strStatus, string DbCondition)
        {
            return PartialView("_TentativelyApproved", objM.ATADDEditProject(strProjectID, strStatus, DbCondition));
        }
        public ActionResult TentativelyApproved()
        {
            return View();
        }

        public ActionResult EditApprovedProject(int strProjectID)
        {
            PipelineModel objM = new PipelineModel();
            objM.strProjectID =Convert.ToString(strProjectID);
            return PartialView("_EditProject", objM);
        }

        [HttpPost]
        public JsonResult PipelineEditApproval(int Project_Unique_ID, string strResourceName, string strRequiredResource, string strPriority, string strProjectStartDate)
        {
            objM.PipelineEditApproval(Project_Unique_ID, strResourceName, strRequiredResource, strPriority, strProjectStartDate);
            return Json("", JsonRequestBehavior.AllowGet);
        }


        
        public JsonResult PipelineopenSave(string listOfAccounts, string strStatus,string strReason)
        {
            objM.PipeLineSave(listOfAccounts, strStatus, strReason);
            return Json("", JsonRequestBehavior.AllowGet);
        }

        public JsonResult PipelineApprovedSave(string listOfAccounts, string strStatus)
        {
            objM.PipeLineApprovedSave(listOfAccounts, strStatus);
            return Json("", JsonRequestBehavior.AllowGet);
        }

        public JsonResult TentativeApprovedSave(string listOfAccounts, string strStatus)
        {
            objM.TentativeApprovedSave(listOfAccounts, strStatus);
            return Json("", JsonRequestBehavior.AllowGet);
        }

        public ActionResult getESTDetails(string Poject_id)
        {

            var res = objM.getESTDetails(Poject_id);
            return Json(res, JsonRequestBehavior.AllowGet);
        }

        public ActionResult getResourceUpdatedata(string Poject_id)
        {

            var res = objM.getResourceUpdatedata(Poject_id);
            return Json(res, JsonRequestBehavior.AllowGet);
        }

        public ActionResult getACTDetails(string Poject_id)
        {

            var res = objM.getACTDetails(Poject_id);
            return Json(res, JsonRequestBehavior.AllowGet);
        }

    }
}
