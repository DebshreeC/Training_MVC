﻿using AT.BAL.Managers;
using AT.BAL.ViewModel;
using Automation_Tracker.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.Mvc;

namespace Automation_Tracker_Inhouse.Controllers
{
    public class ATController : Controller
    {
        //
        // GET: /AT/
        ATMapping objAT = new ATMapping();
        public ActionResult Index()
        {
            return View();
        }


        public ActionResult GetInsertPage()
        {

            //List<ColumnListModel> PLM = new List<ColumnListModel>();
            //PLM = objAT.GetListofColumns();
            InsertProjectModel obj = new InsertProjectModel();
            return PartialView("_ATInsertPage", obj);
        }

        public ActionResult EditGridRecord(int ProjectId, string Client, string ProjectName)
        {
            objAT.EditGridRecord(ProjectId, Client, ProjectName);
            return View();
        }

        public ActionResult EditDynamicColumn(string ProjectHeader, string SubMenu, string MappingList, string Dbcondition)
        {
            objAT.EditDynamicColumn(ProjectHeader, SubMenu, MappingList, Dbcondition);
            return View();
        }

        public JsonResult getEditDynamicColumn(int SubMenuId, string DbCondition)
        {
            return Json(objAT.getEditDynamicColumn(SubMenuId, DbCondition), JsonRequestBehavior.AllowGet);

        }
        public ActionResult Home()
        {
            return View();
        }
        public ActionResult InsertMapping()
        {

            List<ColumnListModel> CLM = new List<ColumnListModel>();
            CLM = objAT.GetListofColumns("S");
            return View(CLM);
        }

        public ActionResult LoadColumn(string DbCondition)
        {
            return PartialView("_InsertMapping", objAT.GetListofColumns(DbCondition));
        }

        public JsonResult InsertProject(List<AT.BAL.ViewModel.InsertProjectModel> cpt)
        {
            objAT.InsertProject(cpt);
            return Json("", JsonRequestBehavior.AllowGet);

        }

        [HttpPost]
        public ActionResult UpdateChanges(FormCollection frm, string Command)
        {
            //char C_s = '"';
            //StringBuilder StrBul = new StringBuilder();
            //string strRes = string.Empty;
            //foreach (var key in frm.AllKeys)
            //{
            //    StrBul.Append( " "+ key + " = " + C_s + frm[key] + C_s );

            //    //var value = frm[key];
            //    // etc.
            //}
            //strRes = "<Item><Item" + ((StrBul.ToString())) + "/></Item>";

            int strProjectID = Convert.ToInt32(frm["Project_Unique_ID"]);
            string status = frm["status"];
            string strAddStatus = frm["AddStatus"];
            string strTeam = frm["teamAcc"];

            if (Command != "Reject")
            {
                objAT.UpdateProjectRecord(frm, strProjectID, status, strAddStatus);

                if (status == "PipelineOpen")
                {
                    return RedirectToAction("PipelineOpen", "Pipeline");
                }
                else if (status == "Approved")
                {
                    return RedirectToAction("PipelineApproved", "Pipeline");
                }
                else if (status == "TentativelyApproved")
                {
                    return RedirectToAction("TentativelyApproved", "Pipeline");
                }
                else if (status == "In-Progress")
                {
                    return RedirectToAction("Inprogress", "Inprogress");
                }
                else if (status == "InprogressUAT")
                {
                    return RedirectToAction("InprogressUAT", "Inprogress");
                }
                else if (status == "InprogressLive")
                {
                    return RedirectToAction("InprogressLIVE", "Inprogress");
                }
                else if (strTeam == "TeamsAccomplishments")
                {
                    return RedirectToAction("TeamsAccomplishments", "TeamsAccomplishments");
                }
                else
                {
                    return RedirectToAction("Index", "Tracker_Display");
                }
            }
            else
            {
                objAT.RejectProject(frm, strProjectID, status, strAddStatus);
                if (status == "PipelineOpen")
                {
                    return RedirectToAction("PipelineOpen", "Pipeline");
                }
                else
                {
                    return RedirectToAction("Index", "Tracker_Display");
                }

            }
        }
         
        public ActionResult getResourceName(string strFntype)
        {
            AT.BAL.ViewModel.InsertProjectModel objI = new AT.BAL.ViewModel.InsertProjectModel();
            IEnumerable<SelectListItem> BatchList = objAT.GetResourceNames(strFntype);
            var result = new SelectList(BatchList, "Value", "Text");

            return Json(result, JsonRequestBehavior.AllowGet);

        }

        public ActionResult CheckAdditionfunction(string strStatus, string strProjectid)
        {
            string str = objAT.CheckAdditionfunction(strStatus, strProjectid);
            return Json(str, JsonRequestBehavior.AllowGet);

        }

         
    }
}
