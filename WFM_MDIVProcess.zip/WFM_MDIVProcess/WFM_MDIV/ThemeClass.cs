﻿using System.Windows.Forms;
using System.Drawing;

namespace WFMMDIV
{
    public class ThemeClass
    {
        static void ApplyTheme(TextBox c)
        {
            c.Font = new Font("Calabri", 11.0f); 
        }
        static void ApplyTheme(Label c)
        {
            c.Font = new Font("Calabri", 11.0f); 
        }
        static void ApplyTheme(Button c)
        {
            c.Font = new Font("Calabri", 11.0f);
        }
        static void ApplyTheme(Form c)
        {
            c.Font = new Font("Calabri", 11.0f); 
        }
        static void ApplyTheme(GroupBox c)
        {
            c.Font = new Font("Calabri", 11.0f);
        }
        public static void UseTheme(Form form)
        {
            ApplyTheme(form);
            foreach (var c in form.Controls)
            {
                switch (c.GetType().ToString())
                {
                    case "System.Windows.Forms.TextBox":
                        ApplyTheme((TextBox)c);
                        break;
                    case "System.Windows.Forms.Label":
                        ApplyTheme((Label)c);
                        break;


                }
            }
        }
    }
}
