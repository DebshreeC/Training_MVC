﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Threading;
using System.Data.SqlClient;
using System.Data.OleDb;
using CPYDLL;
using System.Configuration;
using WFICALib;
using System.Net.Mail;
using System.IO;

namespace WFMMDIV
{
    public partial class WFMMDIV : Form
    {
        DataTable xldt = new DataTable("Sheet1");
        DataTable dtop = new DataTable("Sheet1");
        DataTable dtbatch = new DataTable("Sheet1");
        DataTable dtadmin = new DataTable();
        DataTable dtFormetExcel = new DataTable();
        DataTable dtadminlst = new DataTable();
        DataTable inputDataTable = new DataTable();
        DataTable dtFinalOutput = new DataTable();
        int resultId = 0; List<string> Outer = new List<string>();
        string AdminName = ""; string batchName,batchDESC,date,noOfEncounters,clientid,clientname,accountname,batchdt;
        String Filename = ""; string clinicselect = "";
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["WFMMDIV"].ConnectionString);
        AdminClass objclass = new AdminClass();
        ICAClientClass ica = new ICAClientClass();
        [System.Runtime.InteropServices.DllImport("user32.dll")]
        static extern IntPtr CloseClipboard();

        [System.Runtime.InteropServices.DllImport("user32.dll")]
        static extern bool SetCursorPos(int x, int y);

        [System.Runtime.InteropServices.DllImport("user32.dll")]
        public static extern void mouse_event(int dwFlags, int dx, int dy, int cButtons, int dwExtraInfo);

        public WFMMDIV()
        {
            InitializeComponent();
            ThemeClass.UseTheme(this);
            comboBox1.SelectedIndex = 0;
        }

        private void Batch_Click(object sender, EventArgs e)
        {
            if (unixuser.Text != "" && unixpssword.Text != "")
            {
                if (chkmd4User.SelectedIndex != -1 && md4password.Text != "")
                {
                    try
                    {
                        clinicselect = cmbclinic.Text.ToString();
                        
                        IntPtr pts1 = IntPtr.Zero;
                        for (int i = 0; i < 10; i++)
                        {
                            pts1 = Automater.UIAutomationHelper.FindWindowAndFocus(@"Omega Imgnow - desktop new - Citrix online plug-in");
                            if (pts1 == IntPtr.Zero)
                            {
                                pts1 = Automater.UIAutomationHelper.FindWindowAndFocus(@"Server - Citrix XenApp Plugins for Hosted Apps");
                            }
                            if (pts1 == IntPtr.Zero)
                            {
                                pts1 = Automater.UIAutomationHelper.FindWindowAndFocus(@"Omega Imgnow - desktop new - Citrix Receiver");
                            }
                            if (pts1 != IntPtr.Zero) { break; }
                        }

                        foreach (object itemChecked in chkmd4User.CheckedItems)
                        {
                            DataRowView dritem = itemChecked as DataRowView;
                            if (dritem["Admin"].ToString() != "Select All")
                            {
                                AdminName = dritem["Admin"].ToString();
                                if (!Outer.Any(item => item.Equals(AdminName)))
                                {
                                    var newRow = inputDataTable.NewRow();
                                    newRow[0] = AdminName;
                                    Outer.Add(newRow[0].ToString());
                                    inputDataTable.Rows.Add(newRow);
                                }
                            }
                        }
                        dtbatch.Clear(); dtbatch.Reset();
                        dtbatch.Columns.Add("ID");
                        dtbatch.Columns.Add("Date");
                        dtbatch.Columns.Add("Record");
                        dtbatch.Columns.Add("AdminName");
                        Thread.Sleep(1000);
                        sayenter2ctx("{alt+c+1}");
                        Thread.Sleep(1000);

                        sayenter2ctx(unixuser.Text.ToString() + "{enter}");
                        Thread.Sleep(2000);
                        sayenter2ctx(unixpssword.Text.ToString() + "{enter}");
                        Thread.Sleep(2000);

                        for (int i = 0; i < inputDataTable.Rows.Count; i++)
                        {
                            Thread.Sleep(2000);
                            string adminsrn = cplcpy();
                            if (!adminsrn.Contains("Enter account name"))
                            {
                                sayenter2ctx("{alt+c+1}");
                                Thread.Sleep(200);
                                sayenter2ctx(unixuser.Text.ToString() + "{enter}");
                                Thread.Sleep(1500);
                                sayenter2ctx(unixpssword.Text.ToString() + "{enter}");
                                Thread.Sleep(1500);
                            }
                            DataTable dt = inputDataTable;
                            AdminName = inputDataTable.Rows[i]["Admin"].ToString().Trim();

                            Thread.Sleep(1500);
                            sayenter2ctx(AdminName);
                            sayenter2ctx("{enter}");
                            Thread.Sleep(2000);
                            sayenter2ctx(md4password.Text.ToString());
                            sayenter2ctx("{enter}");
                            Thread.Sleep(2000);

                            sayenter2ctx("{alt+e+a}");
                            Thread.Sleep(1000);
                            string s = cplcpy();
                            Thread.Sleep(1000);
                            if (!s.Contains("DISPLAY SYSTEM MESSAGES")) { throw new Exception("Omega Imgnow - desktop not Available"); }

                            sayenter2ctx("{enter}");
                            Thread.Sleep(1000);
                            sayenter2ctx("{alt+e+a}");
                            Thread.Sleep(1000);
                            s = cplcpy();
                            Thread.Sleep(1000);
                            if (s.Contains("DO YOU WISH TO CHANGE YOUR PASSWORD NOW (Y/N)?"))
                            {
                                sayenter2ctx("N{enter}");
                                Thread.Sleep(1000);
                            }

                            sayenter2ctx("{alt+e+a}");
                            Thread.Sleep(1000);
                            s = cplcpy();
                            Thread.Sleep(1000);

                            while (!s.Contains("2. CLIENT TRANSACTIONS"))
                            {
                                s = "";
                                sayenter2ctx("{enter}");
                                Thread.Sleep(1000);
                                sayenter2ctx("{alt+e+a}");
                                Thread.Sleep(1000);
                                s = cplcpy();
                                Thread.Sleep(1000);
                                if (s.Contains("2. CLIENT TRANSACTIONS")) break;
                                else continue;
                            }
                            if (!s.Contains("2. CLIENT TRANSACTIONS"))
                            {
                                sayenter2ctx("{enter}");
                                Thread.Sleep(1000);
                            }
                            sayenter2ctx("{alt+e+a}");
                            Thread.Sleep(1000);
                            s = cplcpy();
                            Thread.Sleep(1000);
                            if (s.Contains("DO YOU WISH TO CHANGE YOUR PASSWORD NOW (Y/N)?"))
                            {
                                sayenter2ctx("N{enter}");
                                Thread.Sleep(1000);

                                sayenter2ctx("{alt+e+a}");
                                Thread.Sleep(1000);
                                s = cplcpy();
                                Thread.Sleep(1000);
                                if (!s.Contains("2. CLIENT TRANSACTIONS"))
                                {
                                    sayenter2ctx("{enter}");
                                    Thread.Sleep(1000);
                                }
                            }
                            sayenter2ctx("2{enter}");
                            Thread.Sleep(1000);
                            sayenter2ctx("{enter}");
                            Thread.Sleep(1500);

                            sayenter2ctx("{alt+e+a}");
                            Thread.Sleep(1000);
                            string totcount = cplcpy();
                            Thread.Sleep(1000);
                            string[] totcountarr = totcount.Split(new char[] { '\n', '\r' });
                            List<string> toty = totcountarr.ToList<string>();
                            toty.RemoveAll(p => string.IsNullOrEmpty(p));
                            string[] totcountFinalarr = toty.ToArray();

                            int STARTindx = Array.FindIndex(totcountFinalarr, ContainsSTART);
                            int ENDindx = Array.FindIndex(totcountFinalarr, ContainsEND);
                            string[] totadd = null; string[] resadd = new string[50]; int n = 0;
                            try
                            {
                                for (int indxmatch = STARTindx + 2; indxmatch < ENDindx; indxmatch++)
                                {
                                    if (totcountFinalarr[indxmatch] != " " && totcountFinalarr[indxmatch] != "")
                                    {
                                        string[] finalval = totcountFinalarr[indxmatch].Split('.');
                                        resadd[n] = finalval[0].ToString();
                                        if (clinicselect == "One") break;
                                        n++;
                                    }
                                    else break;
                                }
                            }
                            catch (Exception ex)
                            {

                            }

                            for (int j = 1; resadd[j - 1] != null; j++)// account loop
                            {
                            loopreturn:
                                sayenter2ctx(j.ToString());
                                Thread.Sleep(500);
                                
                                sayenter2ctx("{enter}");
                                Thread.Sleep(1000);
                                sayenter2ctx("Y{enter}");
                                Thread.Sleep(1000);

                                sayenter2ctx("{alt+e+a}");
                                Thread.Sleep(1000);
                                string securitycd = cplcpy();
                                Thread.Sleep(1000);
                                if (securitycd.Contains("SECURITY CODE"))
                                {
                                    sayenter2ctx("{enter}");
                                    sayenter2ctx("{escape}");
                                    sayenter2ctx("{enter}");
                                    goto securityerr;
                                }
                                sayenter2ctx("DD05{enter}");
                                Thread.Sleep(1500);

                                sayenter2ctx("{alt+e+a}");
                                Thread.Sleep(1000);
                                string telnetwarn = cplcpy();
                                Thread.Sleep(1000);
                                if (telnetwarn.Contains("WARNING, THIS SITE INACTIVE ON"))
                                {
                                    sayenter2ctx("CONTINUE");
                                    sayenter2ctx("{enter}");

                                    string telnetwarn1 = "";
                                    sayenter2ctx("{alt+e+a}");
                                    Thread.Sleep(1000);
                                    telnetwarn1 = cplcpy();
                                    Thread.Sleep(1000);
                                    if (telnetwarn1.Contains("WARNING, THIS SITE INACTIVE ON"))
                                    {
                                        sayenter2ctx("END");
                                        sayenter2ctx("{enter}");
                                        sayenter2ctx("{enter}");
                                        goto loopreturn;
                                    }
                                }
                                telnetwarn = "";
                                sayenter2ctx("{alt+e+a}");
                                Thread.Sleep(1000);
                                telnetwarn = cplcpy();
                                Thread.Sleep(1000);
                                if (telnetwarn.Contains("BATCH OR <Enter> FOR LIST"))
                                {
                                    sayenter2ctx("DD05{enter}");
                                }
                                Thread.Sleep(1000);
                                sayenter2ctx("12");
                                Thread.Sleep(1000);
                                sayenter2ctx("{alt+e+a}");
                                Thread.Sleep(1000);
                                s = cplcpy();
                                Thread.Sleep(1000);
                                if (s.Contains("Inquiry by Work Queue"))
                                {
                                    while (!s.Contains("Enter Line#"))
                                    {
                                        sayenter2ctx("{alt+e+a}");
                                        Thread.Sleep(1000);
                                        s = cplcpy();
                                        Thread.Sleep(1000);
                                    }
                                }
                                else { throw new Exception("Omega Imgnow - desktop not Available"); }
                                string prv = "";
                               
                                for (int pgcnt = 0; pgcnt < 6; pgcnt++)
                                {
                                    if (!s.Contains("DEN")&&!s.Contains("DFE"))
                                    {
                                        Thread.Sleep(1000);
                                        sayenter2ctx("{enter}");
                                        Thread.Sleep(1000);
                                        sayenter2ctx("{alt+e+a}");
                                        Thread.Sleep(1000);
                                        s = cplcpy();
                                        Thread.Sleep(1000);
                                    }
                                   
                                }

                                if (s.Contains("Inquiry by Work Queue"))
                                {
                                    while (true)
                                    {
                                        prv = s;
                                        string[] arr = s.Split(new char[] { '\n' });
                                        List<string> y = arr.ToList<string>();
                                        y.RemoveAll(p => string.IsNullOrEmpty(p));
                                        string[] Finalarr = y.ToArray();
                                        int startmatch = Array.FindIndex(Finalarr, StartStr);
                                        int endmatch = Array.FindIndex(Finalarr, EndStr);

                                        for (int match = startmatch + 1; match < endmatch; match++)
                                        {
                                            try
                                            {
                                                if ((Finalarr[match].Contains("DEN") || Finalarr[match].Contains("DFE")) && !Finalarr[match].Contains("DEFAULT"))
                                                {
                                                    DataRow dr = dtbatch.NewRow();
                                                    dr[0] = Finalarr[match].Substring((Finalarr[match].IndexOf('*') + 1), (Finalarr[match].IndexOf(" ", 3) - Finalarr[match].IndexOf('*')));
                                                    string[] dtstr = Finalarr[match].Split('*');

                                                    try
                                                    {
                                                        if ((dtstr[0].Contains("DEN") || dtstr[0].Contains("DFE")) && !Finalarr[match].Contains("DEFAULT"))
                                                        {
                                                            if (dtstr[1].Substring((dtstr[1].IndexOf('-') - 2), 15).Any(char.IsLetter))
                                                            {
                                                                if (dtstr[1].Substring((dtstr[1].IndexOf('-') - 2), 15).Contains("PLZ") || dtstr[1].Substring((dtstr[1].IndexOf('-') - 2), 15).Contains("OdM") || dtstr[1].Substring((dtstr[1].IndexOf('-') - 2), 15).Contains("oS8") || dtstr[1].Substring((dtstr[1].IndexOf('-') - 2), 15).Contains("OAD") || dtstr[1].Substring((dtstr[1].IndexOf('-') - 2), 15).Contains("OAs"))
                                                                {
                                                                    dr[1] = dtstr[1].Substring((dtstr[1].IndexOf('-') - 2), 17);
                                                                }
                                                                else
                                                                {
                                                                    dr[1] = dtstr[1].Substring((dtstr[1].IndexOf('-') + 6), 15);
                                                                }

                                                            }
                                                            else
                                                            {
                                                                dr[1] = dtstr[1].Substring((dtstr[1].IndexOf('-') - 2), 15);
                                                            }
                                                            dr[2] = Finalarr[match].Substring((Finalarr[match].IndexOf('.') + 1));
                                                            dr[3] = AdminName;
                                                        }
                                                        else
                                                        {
                                                            if (dtstr[1].Substring((dtstr[1].IndexOf('-') - 2), 19).Any(char.IsLetter))
                                                            {
                                                                dr[1] = dtstr[1].Substring((dtstr[1].IndexOf('-') + 6), 15);
                                                            }
                                                            else
                                                            {
                                                                dr[1] = dtstr[1].Substring((dtstr[1].IndexOf('-') - 2), 19);
                                                            }
                                                            dr[2] = Finalarr[match].Substring((Finalarr[match].IndexOf('.') + 1));
                                                            dr[3] = AdminName;
                                                        }
                                                    }

                                                    catch (Exception ex)
                                                    {
                                                        dr[1] = dtstr[1].Substring((dtstr[1].IndexOf('-') - 2), 19);
                                                        dr[2] = Finalarr[match].Substring((Finalarr[match].IndexOf('.') + 1));
                                                        dr[3] = AdminName;
                                                    }
                                                    dtbatch.Rows.Add(dr);
                                                }
                                            }

                                            catch(Exception ex)
                                            {

                                            }
                                        }

                                        int k = 0;

                                        Thread.Sleep(1000);
                                        sayenter2ctx("{enter}");
                                        Thread.Sleep(1000);
                                        sayenter2ctx("{alt+e+a}");
                                        Thread.Sleep(1000);
                                        s = cplcpy();
                                        Thread.Sleep(1500);
                                        if (prv == s)
                                        {
                                            break;
                                        }
                                        if (!s.Contains("Inquiry by Work Queue"))
                                        { break; }
                                    }
                                }
                                else { throw new Exception("Omega Imgnow - desktop not Available"); }
                                sayenter2ctx("E");
                                sayenter2ctx("{enter}");
                                sayenter2ctx("{escape}");
                                sayenter2ctx("{enter}");
                                sayenter2ctx("{escape}");
                                sayenter2ctx("{escape}");
                                sayenter2ctx("{escape}");
                                sayenter2ctx("{enter}");
                                sayenter2ctx("{alt+e+a}");
                                Thread.Sleep(1000);
                                string clipgchk = cplcpy();
                                if (clipgchk.Contains("CLIENT TRANSACTIONS"))
                                {
                                    sayenter2ctx("2");
                                    sayenter2ctx("{enter}"); sayenter2ctx("{enter}");
                                }
                            }
                          
                            sayenter2ctx("{escape}");
                            sayenter2ctx("{escape}");
                            sayenter2ctx("{enter}");
                        securityerr:
                            sayenter2ctx("1");
                            sayenter2ctx("{enter}");
                            string exitadminchk = "";
                            Thread.Sleep(500);
                            exitadminchk = cplcpy();
                            Thread.Sleep(500);
                            if (exitadminchk.Contains("EXIT MDIV"))
                            {
                                sayenter2ctx("1");
                                sayenter2ctx("{enter}");
                            }
                            Thread.Sleep(500);
                        }
                        if (dtbatch.Rows.Count > 0)
                        { EXCEL.ConvertToExcel(dtbatch, "DEN_batches"); dtbatch.Rows.Clear(); }
                        Thread.Sleep(1000);
                        sayenter2ctx("{alt+c+d}"); Thread.Sleep(1000);
                        // BatchPulling();
                        // EXCEL.ConvertToExcel(dtbatch, chkmd4User.Text + "_Batch_");
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error: " + ex.Message);
                        if (dtbatch.Rows.Count > 0)
                        {
                            EXCEL.ConvertToExcel(dtbatch, "DEN_batches");
                        }
                        sendmail(ex);
                        throw ex;
                    }
                }
                else
                {
                    MessageBox.Show("Please Provide MDIV Username and Password!!");
                }
            }
            else
            {
                MessageBox.Show("Please Enter UNIX Username and Password!!");
            }
        }
        public static bool StartStr(string li)
        {
            return li.Contains("ID") && li.Contains("DESCRIPTION") && li.Contains("SYSDATE");
        }
        public static bool EndStr(string li)
        {
            return li.Contains("Enter Line#, <+/->Scroll, <T>op, <B>ottom, <E>nd");
        }
    
        private string cplcpy()
        {
            Thread.Sleep(100);
            Cpyctxdetails eecpy = new Cpyctxdetails();
            string res = eecpy.cpydetails("test");
            return res;
        }

        private void sayenter2ctx(string values)
        {
            IntPtr pts1 = IntPtr.Zero;
            for (int i = 0; i < 10; i++)
            {
                pts1 = Automater.UIAutomationHelper.FindWindowAndFocus(@"Omega Imgnow - desktop new - Citrix online plug-in");
                if (pts1 == IntPtr.Zero)
                {
                    pts1 = Automater.UIAutomationHelper.FindWindowAndFocus(@"Server - Citrix XenApp Plugins for Hosted Apps");
                }
                if (pts1 == IntPtr.Zero)
                {
                    pts1 = Automater.UIAutomationHelper.FindWindowAndFocus(@"Omega Imgnow - desktop new - Citrix Receiver");
                }
                if (pts1 != IntPtr.Zero) { break; }
            }
            if (pts1 == IntPtr.Zero)
            { throw new Exception("Omega Imgnow - desktop not Available"); }

            AutomationHelper AutomationHelperval = new AutomationHelper();
            bool AutomationHelperval1 = AutomationHelperval.AutomationsysConnection("Test");

            if (AutomationHelperval1 == true)
            {
                string m_text = values;
                KIBDEVNTS KBDevntss = new KIBDEVNTS();
                bool KBDevntssval = KBDevntss.AutomationKIBDEVNTS(m_text);
            }
            else
            {
                AutomationHelper AutomationHelperval2 = new AutomationHelper();
                bool AutomationHelperval22 = AutomationHelperval2.AutomationsysConnection2("Test");
                string m_text = values;
                KIBDEVNTS KBDevntss = new KIBDEVNTS();
                bool KBDevntssval = KBDevntss.AutomationKIBDEVNTS(m_text);
            }
        }

        #region Import excel data and tracking
        private void importExcel()
        {
            try
            {
                xldt.Rows.Clear();
                OpenFileDialog fDialog = new OpenFileDialog();
                fDialog.Title = "Select file to be upload";
                fDialog.Filter = "(*.xlsx)|*.xlsx";
                if (fDialog.ShowDialog() == DialogResult.OK)
                {
                    Filename = fDialog.FileName.ToString();
                    OleDbConnection theConnection = new OleDbConnection(@"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + Filename + ";Extended Properties=\"Excel 8.0;\"");
                    theConnection.Open();
                    // OleDbDataAdapter theDataAdapter = new OleDbDataAdapter("SELECT * FROM [Sheet1$] order by [Trip Number]", theConnection);
                    OleDbDataAdapter theDataAdapter = new OleDbDataAdapter("SELECT * FROM [Sheet1$]", theConnection);
                    theDataAdapter.Fill(xldt);
                    theConnection.Close();
                }
            }
            catch (Exception e7)
            {
                MessageBox.Show(e7.ToString());
            }
        }

        private void dbtracking()
        {
            try
            {
                using (SqlCommand cmd = new SqlCommand("Insert_MCK_Tracking", con))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@User_Name", Environment.UserName);
                    cmd.Parameters.AddWithValue("@Date_Used", DateTime.Now);
                    cmd.Parameters.AddWithValue("@Accounts_Loaded", xldt.Rows.Count);
                    cmd.Parameters.AddWithValue("@Issue_Log", "MCK_Bangalore_" + Environment.MachineName);
                    cmd.Parameters.AddWithValue("@FileName", Filename);
                    con.Open();
                    cmd.ExecuteNonQuery();
                }
            }
            catch (Exception e)
            {
                MessageBox.Show("Connection Error: " + e.Message);
                throw e;
            }
            finally { con.Close(); }
        }


        #endregion

        private void Citrixlaunch_Click(object sender, EventArgs e)
        {
            if (CitrixUserNameTextbox.Text != "" && CitrixPasswordTextbox.Text != "")
            {

                string addressvalue = string.Empty;
                if (comboBox1.SelectedItem != null)
                {
                    addressvalue = comboBox1.SelectedItem.ToString();

                }
                if ((addressvalue != "") && (addressvalue != "Select server"))
                {
                    if (button2.Text == "Citrix Launch")
                    {
                        //ica.Application = "Omega Imgnow - desktop";
                        ica.Application = "Omega Imgnow - desktop new";
                        ica.Launch = true;
                        if (comboBox1.SelectedIndex == 1)
                        {
                           // ica.Address = "10.1.1.87";
                            ica.Address = "10.1.1.78";
                        }
                        else
                        {
                            ica.Address = "10.1.1.90";
                        }
                        ica.Username = CitrixUserNameTextbox.Text.Trim();
                        ica.Domain = "NAMCK";
                        ica.SetProp("Password", CitrixPasswordTextbox.Text.Trim());
                        ica.DesiredHRes = 1024;
                        ica.DesiredVRes = 786;
                        ica.Connect();

                        Thread.Sleep(4000);
                        sayenter2ctx("{enter}");
                        
                        button2.Text = "Stop";

                        //panel1.Visible = true;

                    }
                    else
                    {
                        button2.Text = "Citrix Launch";
                        Thread.Sleep(500);
                        ica.Logoff();
                    }

                }
                else
                {
                    MessageBox.Show("Select Server");
                }
            }
            else
            {
                MessageBox.Show("Please Enter Citrix Username and Password!!");
            }

        }
      
        public static void sendmail(Exception ex)
        {
            try
            {
                string mailid = "nagasatyavathi.koppolu@omegahms.com";
                string strContent = string.Empty;
                string strSender = "AutomationTeam@omegahms.com";
                string Subject = "WFM_MCK  Error Details";
                Mail objMail = new Mail();
                #region Body of mail
                //--------Body of mail
                StringBuilder sb = new StringBuilder();
                sb.Append("Team,");
                sb.Append("</br>"); sb.Append("</br>");
                if (ex.Message != null)
                {
                    sb.Append("<b>");
                    sb.Append(ex.Message.ToString());
                    sb.Append("</b>");
                }
                sb.Append("</br>");
                sb.Append("</br>");
                sb.Append("</br>");
                sb.Append("Regards,</br>");
                sb.Append("Automation Team</br>");
                strContent = sb.ToString();
                #endregion

                objMail.SendMail(strSender, mailid, "nagasatyavathi.koppolu@omegahms.com", Subject, strContent);
            }
            catch (Exception x)
            {

                MessageBox.Show("Mail Sending error has occurred");
                throw x;
            }
        }

        private void MCK_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
            Environment.Exit(-1);
        }

        private void MCK_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
            Environment.Exit(-1);
        }

        private void cmbtelnet_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                if (chkmd4User.Items.Count > 1) ((ListBox)this.chkmd4User).DataSource = null;
                chkmd4User.Visible = true;
                string zoneSelected = cmbtelnet.SelectedItem.ToString();
                if (zoneSelected != "Select Zone")
                {
                    if (chkmd4User.Items.Count > 1)
                    {
                        ((ListBox)this.chkmd4User).DataSource = null;
                        chkmd4User.Refresh();
                    }

                    dtadminlst = objclass.getData(cmbtelnet.SelectedItem.ToString());

                    var pFound = dtadminlst.Select("Admin = 'Select All'");
                    if (pFound.Length == 0)
                    {
                        DataRow dr = dtadminlst.NewRow();
                        dr[0] = "Select All";
                        dtadminlst.Rows.InsertAt(dr, 0);
                    }

                    ((ListBox)this.chkmd4User).DataSource = dtadminlst;
                    ((ListBox)this.chkmd4User).DisplayMember = "Admin";
                }
               
            }
            catch(Exception ex)
            {
                
            }
        }

        private void MCK_Load(object sender, EventArgs e)
        {
            inputDataTable.Columns.Add("Admin");

            dtFinalOutput.Columns.Add("BATCH_NAME");
            dtFinalOutput.Columns.Add("INPUT_DESCRIPTION");
            dtFinalOutput.Columns.Add("DFE_DATE");
            dtFinalOutput.Columns.Add("NO_OF_ENCOUNTERS");
            dtFinalOutput.Columns.Add("ACCOUNT_NO_DFE");
            dtFinalOutput.Columns.Add("INSURANCE_NO");
            dtFinalOutput.Columns.Add("CODER_DESCRIPTION");
            dtFinalOutput.Columns.Add("CODER_EXPLANATION");
            dtFinalOutput.Columns.Add("ERROR_CODE");
            dtFinalOutput.Columns.Add("ERROR_TYPE");
            dtFinalOutput.Columns.Add("CLIENT_ID");
            dtFinalOutput.Columns.Add("CLIENT_NAME");
            dtFinalOutput.Columns.Add("ACCOUNT_NAME");
            dtFinalOutput.Columns.Add("CODER_LOGIN_ID");
            dtFinalOutput.Columns.Add("EMP_ID");
            dtFinalOutput.Columns.Add("EMP_NAME");
        }

        private void chkmd4User_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmbtelnet.SelectedItem != null && chkmd4User.Items.Count>1)
            {
                //cmbclinic.DataSource = objclass.getClient(cmbtelnet.SelectedItem.ToString(), chkmd4User.SelectedValue.ToString());
                //cmbclinic.DisplayMember = "ClientName";
                //cmbclinic.ValueMember = "Id";
                string st = chkmd4User.GetItemCheckState(1).ToString();
                string st1 = chkmd4User.Text;
                if ((chkmd4User.Text == "Select All") && (chkmd4User.GetItemCheckState(0).ToString() == "Unchecked"))
                {
                    for (int i = 0; i < chkmd4User.Items.Count; i++)
                    {
                        if (i >= 1)
                        {
                            chkmd4User.SetItemChecked(i, true);
                            TextBox textbox = new TextBox();
                        }
                    }
                }
                else if ((chkmd4User.Text == "Select All") && (chkmd4User.GetItemCheckState(0).ToString() == "Checked"))
                {
                    for (int i = 0; i < chkmd4User.Items.Count; i++)
                    {
                        if (i >= 1)
                        {
                            chkmd4User.SetItemChecked(i, false);
                            TextBox textbox = new TextBox();
                        }
                    }
                }
                else
                {
                    TextBox textbox = new TextBox();
                }

            }
        }
       
        public static bool ContainsSTART(string li)
        {
            return li.Contains("ACRONYM") && li.Contains("SYSTEM") && li.Contains("CLIENT NAME") && li.Contains("ADMIN");
        }
        public static bool ContainsEND(string li)
        {
            return li.Contains("Enter selection, <+/->scroll, <T>op, <B>ottom or <Esc/END>exit");
        }


        private void IDdataExtract(string strid, int loopCnt)
        {
            if (strid != "")
            {
                Thread.Sleep(500);
                sayenter2ctx(strid);
                Thread.Sleep(500);
                sayenter2ctx("{enter}");
                Thread.Sleep(500);
                sayenter2ctx("Y");
                Thread.Sleep(500);
                sayenter2ctx("{enter}");
                Thread.Sleep(500);
                sayenter2ctx("{alt+e+a}");
                Thread.Sleep(500);
                string rsaccounts = cplcpy();
                Thread.Sleep(500);
                if (dtop.Columns.Count == 0) dtop.Columns.Add("Description");
                string rs = "";
                while (!rsaccounts.Contains("Inquiry by Save-List complete") && rsaccounts.Contains("<A>dj, c<R>edit, <D>etail, <O>DX, <I>nqy, <P>revious, <S>kip, <E>nd :"))
                {
                    dtop.Rows.Add();
                    rs = remove_space(rsaccounts);
                    EXCELGeneration(rs, loopCnt);
                    loopCnt++;
                    dtop.Rows[resultId]["Description"] = rs.ToString();
                    resultId++;
                    Thread.Sleep(500);
                    sayenter2ctx("I"); sayenter2ctx("{enter}"); sayenter2ctx("{enter}"); sayenter2ctx("F"); sayenter2ctx("{enter}");
                    Thread.Sleep(500);
                    Thread.Sleep(500);
                    sayenter2ctx("{alt+e+a}");
                    Thread.Sleep(500);
                    rsaccounts = cplcpy();
                    Thread.Sleep(500);
                }
                Thread.Sleep(500);
                sayenter2ctx("e");
                Thread.Sleep(500);
                sayenter2ctx("{enter}");
                Thread.Sleep(500);
                sayenter2ctx("12");
                Thread.Sleep(500);
                sayenter2ctx("{enter}");
                Thread.Sleep(500);
            }
            else
            {
                Thread.Sleep(500);
            }
        }
        private void EXCELGeneration(string AccInfo, int loopCnt)
        {

            string CLIENTNAME, BATCH, ACCOUNTNO, PATIENTNAME, DOB, DOS, BALANCEAMOUNT, INSNAME, charge; int nameInd, chargeInd;

            if (loopCnt == 0)
            {
                dtFormetExcel.Clear(); 
                if (dtFormetExcel.Columns.Count == 0)
                {
                    dtFormetExcel.Columns.Add("CLIENT NAME");
                    dtFormetExcel.Columns.Add("BATCH");
                    dtFormetExcel.Columns.Add("ACCOUNT#");
                    dtFormetExcel.Columns.Add("PATIENT NAME");
                    dtFormetExcel.Columns.Add("DOB");
                    dtFormetExcel.Columns.Add("DOS");
                    dtFormetExcel.Columns.Add("BALANCE AMOUNT");
                    dtFormetExcel.Columns.Add("INS NAME");
                    dtFormetExcel.Columns.Add("ERR CODE");
                    dtFormetExcel.Columns.Add("ERR DESC");
                }

            }

            DataRow ExportExcelDR = dtFormetExcel.NewRow(); DataRow finalRow = dtFinalOutput.NewRow();
            try
            {
                var resultdrr = AccInfo.Split('\n').ToArray();

               
                if (resultdrr[4].Contains("ACCT#"))
                {
                    string[] arrsplit = resultdrr[4].Split(' ');
                    string[] valu = arrsplit[1].Split('*');
                    CLIENTNAME = valu[0].ToString();
                    clientname = objclass.getClientName(cmbtelnet.SelectedText, AdminName, CLIENTNAME);
                    ExportExcelDR["CLIENT NAME"] = CLIENTNAME;
                    ACCOUNTNO = valu[1].ToString();
                    ExportExcelDR["ACCOUNT#"] = ACCOUNTNO;
                                        

                    if (rdDFE.Checked == true)
                    {
                        finalRow["ACCOUNT_NO_DFE"] = ACCOUNTNO;
                        finalRow["CLIENT_ID"] = CLIENTNAME;
                        finalRow["ACCOUNT_NAME"] = accountname;
                        finalRow["DFE_DATE"] = batchdt;
                        finalRow["INPUT_DESCRIPTION"] = batchDESC;
                        finalRow["CLIENT_NAME"] = clientname;

                        for (int lp = 0; lp < arrsplit.Length; lp++)
                        {
                            if (arrsplit[lp].Contains("/"))
                            {
                                string[] encounter= arrsplit[lp].ToString().Split('/');
                                finalRow["NO_OF_ENCOUNTERS"] = encounter[1];
                            }
                            if (arrsplit[lp].Contains("q"))
                                finalRow["BATCH_NAME"] = arrsplit[lp + 1].ToString();
                        }
                    }
                }
                 if (resultdrr[3].Contains("ACCT#"))
                {
                    string[] arrsplit = resultdrr[3].Split(' ');
                    string[] valu = arrsplit[1].Split('*');
                    CLIENTNAME = valu[0].ToString();
                    clientname = objclass.getClientName(cmbtelnet.Text, AdminName, CLIENTNAME);
                    ExportExcelDR["CLIENT NAME"] = CLIENTNAME;
                    ACCOUNTNO = valu[1].ToString();
                    ExportExcelDR["ACCOUNT#"] = ACCOUNTNO;

                    if (rdDFE.Checked == true)
                    {
                        finalRow["ACCOUNT_NO_DFE"] = ACCOUNTNO;
                        finalRow["CLIENT_ID"] = CLIENTNAME;
                        finalRow["ACCOUNT_NAME"] = accountname;
                        finalRow["DFE_DATE"] = batchdt;
                        finalRow["INPUT_DESCRIPTION"] = batchDESC;
                        finalRow["CLIENT_NAME"] = clientname;

                        for (int lp = 0; lp < arrsplit.Length; lp++)
                        {
                            if (arrsplit[lp].Contains("/"))
                            {
                                string[] encounter = arrsplit[lp].ToString().Split('/');
                                finalRow["NO_OF_ENCOUNTERS"] = encounter[1].ToString();
                            }
                            if (arrsplit[lp].Contains("q"))
                                finalRow["BATCH_NAME"] = arrsplit[lp + 1].ToString();
                        }
                    }
                }
                 if (resultdrr[5].Contains("ACCT#"))
                {
                    string[] arrsplit = resultdrr[5].Split(' ');
                    string[] valu = arrsplit[1].Split('*');
                    CLIENTNAME = valu[0].ToString();
                    clientname = objclass.getClientName(cmbtelnet.SelectedText, AdminName, CLIENTNAME);
                    ExportExcelDR["CLIENT NAME"] = CLIENTNAME;
                    ACCOUNTNO = valu[1].ToString();
                    ExportExcelDR["ACCOUNT#"] = ACCOUNTNO;

                    if (rdDFE.Checked == true)
                    {
                        finalRow["ACCOUNT_NO_DFE"] = ACCOUNTNO;
                        finalRow["CLIENT_ID"] = CLIENTNAME;
                        finalRow["ACCOUNT_NAME"] = accountname;
                        finalRow["DFE_DATE"] = batchdt;
                        finalRow["INPUT_DESCRIPTION"] = batchDESC;
                        finalRow["CODER_LOGIN_ID"] = unixuser.Text.Trim();
                        for (int lp = 0; lp < arrsplit.Length; lp++)
                        {
                            if (arrsplit[lp].Contains("/"))
                            {
                                string[] encounter = arrsplit[lp].ToString().Split('/');
                                finalRow["NO_OF_ENCOUNTERS"] = encounter[1].ToString();
                            }
                            if (arrsplit[lp].Contains("q"))
                                finalRow["BATCH_NAME"] = arrsplit[lp + 1].ToString();
                        }
                    }
                }

                 if (resultdrr[5].Contains("encounter BAL"))
                {
                    string[] arrsplit = resultdrr[5+1].Split(' ');                    
                    ExportExcelDR["INS NAME"] = arrsplit[0].ToString();

                    finalRow["INSURANCE_NO"] = arrsplit[0].ToString();
                }

                 if (resultdrr[10].Contains("SYSDATE  ERR # PROGRAM NAME"))
                {
                    string[] arrsplit = resultdrr[10+1].Split(' ');
                    ExportExcelDR["ERR CODE"] = arrsplit[1].ToString();
                    ExportExcelDR["ERR DESC"] = resultdrr[10 + 2].ToString() + resultdrr[10 + 3].ToString();

                    finalRow["ERROR_CODE"] = arrsplit[1].ToString();
                    finalRow["ERROR_TYPE"] = resultdrr[10 + 2].ToString() + resultdrr[10 + 3].ToString();
                }

              if(resultdrr[12].Contains("TAXID GRP"))
              {
                  ExportExcelDR["ERR CODE"] = resultdrr[13].ToString().Substring(0,4);
                  ExportExcelDR["ERR DESC"] = resultdrr[13].ToString().Substring(4);
              }
              else
              {
                  if (resultdrr[11].Contains("TAXID GRP"))
                  {
                      ExportExcelDR["ERR CODE"] = resultdrr[12].ToString().Substring(0, 4);
                      ExportExcelDR["ERR DESC"] = resultdrr[12].ToString().Substring(4);
                  }

                  else
                  {

                  }
              }
                nameInd = AccInfo.IndexOf("NAME");
                Name = AccInfo.Substring(nameInd + 4, 23);
                ExportExcelDR["PATIENT NAME"] = Name;

                chargeInd = AccInfo.IndexOf("encounter BAL");
                charge = AccInfo.Substring(chargeInd + 14, 10);
                ExportExcelDR["BALANCE AMOUNT"] = "$" + charge;

                int dobInd = AccInfo.IndexOf("BDTE");
                string dob = AccInfo.Substring(dobInd + 5, 8);
                ExportExcelDR["DOB"] = dob;
                

                var result1 = AccInfo.Split('\n').Reverse().ToArray();



                dtFormetExcel.Rows.Add(ExportExcelDR); dtFinalOutput.Rows.Add(finalRow);
            }
            catch (Exception ex)
            {

            }

        }
        private string remove_space(string st)
        {
            String final = "";

            char[] b = new char[] { '\r', '\n' };
            String[] lines = st.Split(b, StringSplitOptions.RemoveEmptyEntries);
            foreach (String s in lines)
            {
                if (!String.IsNullOrEmpty(s))
                {
                    final += s;
                    final += Environment.NewLine;
                }
            }
            return final;
        }
        private void export(DataTable dtoutput)
        {

            try
            {
                // Bind table data to Stream Writer to export data to respective folder
                string fl_path = @"C:\WFM_MCK\" + DateTime.Now.ToString("dd-MM-yyyy");
                if (!Directory.Exists(fl_path)) { Directory.CreateDirectory(fl_path); }
                string FileName = "Result.xls";
                string file = fl_path + @"\" + System.DateTime.Now.ToString("HH.mm.ss") + FileName;
                StreamWriter wr = new StreamWriter(file);
                // Write Columns to excel file
                for (int i = 0; i < dtoutput.Columns.Count; i++)
                {
                    wr.Write(dtoutput.Columns[i].ToString().ToUpper() + "\t");
                }
                wr.WriteLine();
                //write rows to excel file
                for (int i = 0; i < (dtoutput.Rows.Count); i++)
                {
                    for (int j = 0; j < dtoutput.Columns.Count; j++)
                    {
                        if (dtoutput.Rows[i][j] != null)
                        {
                            wr.Write(Convert.ToString(dtoutput.Rows[i][j]) + "\t");
                        }
                        else
                        {
                            wr.Write("\t");
                        }
                    }
                    wr.WriteLine();
                }
                wr.Close();

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        private void btnExtract_Click(object sender, EventArgs e)
        {            
            if(dtbatch.Rows.Count>0) dtbatch.Rows.Clear();
            if (dtbatch.Columns.Count > 0) dtbatch.Columns.Clear();
            if (dtop.Rows.Count > 0) dtop.Rows.Clear();
            if (dtop.Columns.Count > 0) dtop.Columns.Clear();
            clinicselect = cmbclinic.SelectedItem.ToString();
            if (unixuser.Text != "" && unixpssword.Text != "")
            {
                if (chkmd4User.SelectedIndex != -1 && md4password.Text != "")
                {
                    try
                    {
                        clinicselect = cmbclinic.Text.ToString();

                        for (int i = 0; i < 10; i++)
                        {
                            IntPtr pts1 = IntPtr.Zero;
                            pts1 = Automater.UIAutomationHelper.FindWindowAndFocus("Omega Imgnow - desktop new - Citrix Receiver", null);
                            if (pts1 != IntPtr.Zero)
                            {
                                Automater.Win32.SetForegroundWindow(pts1);
                            }
                            if (pts1 != IntPtr.Zero) { break; }
                        }
                        inputDataTable.Rows.Clear();
                        foreach (object itemChecked in chkmd4User.CheckedItems)
                        {
                            DataRowView dritem = itemChecked as DataRowView;
                            if (dritem["Admin"].ToString() != "Select All")
                            {
                                AdminName = dritem["Admin"].ToString();
                                if (!Outer.Any(item => item.Equals(AdminName)))
                                {
                                    var newRow = inputDataTable.NewRow();
                                    newRow[0] = AdminName;
                                    Outer.Add(newRow[0].ToString());
                                    inputDataTable.Rows.Add(newRow);
                                }
                            }
                        }

                        dtbatch.Clear(); dtbatch.Reset();
                        dtbatch.Columns.Add("ID");
                        dtbatch.Columns.Add("Description");
                        dtbatch.Columns.Add("Date");
                        dtbatch.Columns.Add("User");
                        dtFormetExcel.Clear(); dtFormetExcel.Reset();

                        Thread.Sleep(500);
                        sayenter2ctx("{alt+c+1}");

                        Thread.Sleep(500);
                        sayenter2ctx(unixuser.Text.ToString());
                        Thread.Sleep(1000);
                        sayenter2ctx("{enter}");
                        Thread.Sleep(1000);

                        sayenter2ctx("{alt+e+a}");
                        Thread.Sleep(1000);
                        string loginverify = cplcpy();
                        Thread.Sleep(1000);
                        if (loginverify.Contains("Password") || loginverify.Contains("login:"))
                        {
                            sayenter2ctx(unixpssword.Text.ToString());
                            Thread.Sleep(1000);
                            sayenter2ctx("{enter}");
                            Thread.Sleep(1000);
                        }
                        else
                        {
                            sayenter2ctx("{alt+c+1}");

                            goto exeExit;
                        }
                        Thread.Sleep(1000);
                        for (int i = 0; i < inputDataTable.Rows.Count; i++)
                        {
                            Thread.Sleep(1000);
                            DataTable dt = inputDataTable;
                            AdminName = inputDataTable.Rows[i]["Admin"].ToString().Trim();

                            sayenter2ctx(AdminName + "{enter}");
                            Thread.Sleep(1000);
                            sayenter2ctx(md4password.Text.ToString()); Thread.Sleep(500);
                            sayenter2ctx("{enter}");
                            Thread.Sleep(1000);

                            sayenter2ctx("{alt+e+a}");
                            Thread.Sleep(1000);
                            string pwdverify = cplcpy();
                            Thread.Sleep(1000);
                            if (pwdverify.Contains("Enter Password"))
                            {
                                // sayenter2ctx(txtpwd.Text.Trim());
                                Thread.Sleep(1000);
                                sayenter2ctx("{enter}");
                                Thread.Sleep(1000);
                                sayenter2ctx(md4password.Text.ToString());
                                Thread.Sleep(1000);
                                sayenter2ctx("{enter}");
                                Thread.Sleep(1000);
                            }
                            else
                            {
                                sayenter2ctx("{alt+e+a}");
                                Thread.Sleep(1000);
                                string validac = cplcpy();
                                Thread.Sleep(1000);
                                if (!validac.Contains("not a valid account") && !validac.Contains("DISPLAY SYSTEM MESSAGES"))
                                {
                                    sayenter2ctx(md4password.Text.ToString());
                                    Thread.Sleep(1000);
                                    sayenter2ctx("{enter}");
                                    Thread.Sleep(1000);
                                }
                                else if (validac.Contains("not a valid account"))
                                {
                                    sayenter2ctx("{alt+c+d}");
                                    Application.Exit();
                                }
                            }

                            sayenter2ctx("{alt+e+a}");
                            Thread.Sleep(1000);
                            string s = cplcpy();
                            Thread.Sleep(1000);
                            if (!s.Contains("DISPLAY SYSTEM MESSAGES")) { throw new Exception("Omega Imgnow - desktop not Available"); }

                            sayenter2ctx("{enter}");
                            Thread.Sleep(1000);
                            sayenter2ctx("{alt+e+a}");
                            Thread.Sleep(1000);
                            s = cplcpy();
                            Thread.Sleep(1000);
                            if (s.Contains("DO YOU WISH TO CHANGE YOUR PASSWORD NOW (Y/N)?"))
                            {
                                sayenter2ctx("N{enter}");
                                Thread.Sleep(1000);
                            }

                            sayenter2ctx("{alt+e+a}");
                            Thread.Sleep(1000);
                            s = cplcpy();
                            Thread.Sleep(1000);
                            if (!s.Contains("2. CLIENT TRANSACTIONS"))
                            {
                                sayenter2ctx("{enter}");
                                Thread.Sleep(1000);

                                sayenter2ctx("{alt+e+a}");
                                Thread.Sleep(1000);
                                s = cplcpy();
                                Thread.Sleep(1000);
                                if (s.Contains("***** DO YOU WISH TO CHANGE YOUR PASSWORD NOW (Y/N)?"))
                                {
                                    sayenter2ctx("N");
                                    Thread.Sleep(1000);
                                    sayenter2ctx("{enter}");
                                    Thread.Sleep(1000);
                                    sayenter2ctx("{alt+e+a}");
                                    Thread.Sleep(1000);
                                    s = cplcpy();
                                    Thread.Sleep(1000);
                                }

                            }
                            sayenter2ctx("{alt+e+a}");
                            Thread.Sleep(1000);
                            s = cplcpy();
                            Thread.Sleep(1000);

                            while (!s.Contains("2. CLIENT TRANSACTIONS"))
                            {
                                s = "";
                                sayenter2ctx("{enter}");
                                Thread.Sleep(1000);
                                sayenter2ctx("{alt+e+a}");
                                Thread.Sleep(1000);
                                s = cplcpy();
                                Thread.Sleep(1000);
                                if (s.Contains("2. CLIENT TRANSACTIONS")) break;
                                else continue;
                            }
                            sayenter2ctx("2{enter}");
                            Thread.Sleep(1000);
                            sayenter2ctx("{enter}");
                            Thread.Sleep(1000);

                            sayenter2ctx("{alt+e+a}");
                            Thread.Sleep(1000);
                            string totcount = cplcpy();
                            Thread.Sleep(1000);
                            string[] totcountarr = totcount.Split(new char[] { '\n', '\r' });
                            List<string> toty = totcountarr.ToList<string>();
                            toty.RemoveAll(p => string.IsNullOrEmpty(p));
                            string[] totcountFinalarr = toty.ToArray();

                            int STARTindx = Array.FindIndex(totcountFinalarr, ContainsSTART);
                            int ENDindx = Array.FindIndex(totcountFinalarr, ContainsEND);
                            string[] totadd = null; string[] resadd = new string[10]; int n = 0;
                            for (int indxmatch = STARTindx + 2; indxmatch < ENDindx; indxmatch++)
                            {

                                if (totcountFinalarr[indxmatch] != " " && totcountFinalarr[indxmatch] != "")
                                {
                                    string[] finalval = totcountFinalarr[indxmatch].Split('.');
                                    resadd[n] = finalval[0].ToString();
                                    if (clinicselect == "One") break;
                                    n++;
                                }
                                else break;
                            }

                            for (int j = 1; resadd[j - 1] != null; j++)// account loop
                            {
                                sayenter2ctx(j.ToString());
                                Thread.Sleep(1000);
                                sayenter2ctx("{enter}");
                                Thread.Sleep(1000);
                                sayenter2ctx("Y{enter}");
                                Thread.Sleep(1000);
                                sayenter2ctx("DD05{enter}");
                                Thread.Sleep(1000);
                                sayenter2ctx("12");
                                Thread.Sleep(1000);
                                sayenter2ctx("{alt+e+a}");
                                Thread.Sleep(1000);
                                s = cplcpy();
                                Thread.Sleep(1000);
                                if (s.Contains("Inquiry by Work Queue"))
                                {
                                    while (!s.Contains("Enter Line#"))
                                    {
                                        sayenter2ctx("{alt+e+a}");
                                        Thread.Sleep(1000);
                                        s = cplcpy();
                                        Thread.Sleep(1000);
                                    }
                                }
                                else { throw new Exception("Omega Imgnow - desktop not Available"); }
                                string prv = "";
                                if (rdDFE.Checked == true)
                                {
                                    while (!s.Contains("DFE"))
                                    {

                                        prv = s;
                                        Thread.Sleep(1000);
                                        sayenter2ctx("{enter}");
                                        Thread.Sleep(1000);
                                        sayenter2ctx("{alt+e+a}");
                                        Thread.Sleep(1000);
                                        s = cplcpy();
                                        Thread.Sleep(1000);

                                        if (prv == s) break;
                                        else if (s.Contains("DFE"))
                                        {
                                            break;
                                        }
                                    }
                                }

                                else if (rdDFE.Checked == false)
                                {
                                    while (!s.Contains("DEN"))
                                    {

                                        prv = s;
                                        Thread.Sleep(1000);
                                        sayenter2ctx("{enter}");
                                        Thread.Sleep(1000);
                                        sayenter2ctx("{alt+e+a}");
                                        Thread.Sleep(1000);
                                        s = cplcpy();
                                        Thread.Sleep(1000);

                                        if (prv == s) break;
                                        else if (s.Contains("DEN"))
                                        {
                                            break;
                                        }
                                    }
                                }


                                Thread.Sleep(1000);
                                int k = 0;
                                int loopcnt = 0;
                                if (s.Contains("Inquiry by Work Queue"))
                                {

                                    while (true)
                                    {
                                    repeat:
                                        Thread.Sleep(1000);
                                        prv = s;
                                        string[] arr = s.Split(new char[] { '\n' });
                                        List<string> y = arr.ToList<string>();
                                        y.RemoveAll(p => string.IsNullOrEmpty(p));
                                        string[] Finalarr = y.ToArray();
                                        int startmatch = Array.FindIndex(Finalarr, StartStr);
                                        int endmatch = Array.FindIndex(Finalarr, EndStr);
                                        if (rdDFE.Checked == true)
                                        {
                                            if (s.Contains("DFE"))
                                            {
                                                for (int match = startmatch + 1; match < endmatch; match++)
                                                {
                                                    if (!Finalarr[match].Contains('*'))
                                                    { break; }
                                                    string[] arrsplit = Finalarr[match].Split('*');

                                                    if ((arrsplit[0].Contains("DFE")) && !arrsplit[0].Contains("DEFAULT") && !arrsplit[1].Contains("DEFAULT"))
                                                    {
                                                        dtbatch.Rows.Add();
                                                        Thread.Sleep(500);
                                                        string[] id = arrsplit[0].ToString().Split('.');

                                                        dtbatch.Rows[k]["ID"] = id[0].ToString().Trim();
                                                        dtbatch.Rows[k]["Description"] = arrsplit[1].ToString().Trim();

                                                        batchName = arrsplit[0].ToString().Trim().Substring(3); batchDESC = arrsplit[1].ToString().Trim();

                                                        accountname = AdminName;

                                                        string[] arrbatch = batchDESC.Split(' ');

                                                        if (rdDFE.Checked == true)
                                                        {
                                                            for (int batchdate = 0; batchdate < arrbatch.Length; batchdate++)
                                                            {
                                                                if (arrbatch[batchdate].Contains("-"))
                                                                {
                                                                    batchdt = arrbatch[batchdate].ToString();
                                                                    break;
                                                                }

                                                            }

                                                            string[] secondsplit = batchDESC.Split('-');

                                                            batchDESC = secondsplit[0].Trim();
                                                        }
                                                        IDdataExtract(dtbatch.Rows[k]["ID"].ToString().Trim(), loopcnt);
                                                        k++;
                                                        loopcnt++;

                                                    }
                                                }
                                            }
                                        }

                                        else if (rdDFE.Checked == false)
                                        {
                                            if (s.Contains("DEN"))
                                            {
                                                for (int match = startmatch + 1; match < endmatch; match++)
                                                {
                                                    if (!Finalarr[match].Contains('*'))
                                                    { break; }
                                                    string[] arrsplit = Finalarr[match].Split('*');

                                                    if ((arrsplit[0].Contains("DEN")) && !arrsplit[0].Contains("DEFAULT") && !arrsplit[1].Contains("DEFAULT"))
                                                    {
                                                        dtbatch.Rows.Add();
                                                        Thread.Sleep(500);
                                                        string[] id = arrsplit[0].ToString().Split('.');


                                                        dtbatch.Rows[k]["ID"] = id[0].ToString().Trim();
                                                        dtbatch.Rows[k]["Description"] = arrsplit[1].ToString().Trim();

                                                        IDdataExtract(dtbatch.Rows[k]["ID"].ToString().Trim(), loopcnt);
                                                        k++;
                                                        loopcnt++;

                                                    }
                                                }
                                            }
                                        }
                                        if (rdDFE.Checked == true)
                                        {
                                            while (!s.Contains("DFE") || (s.Contains("DFE") && s.Contains("DEFAULT")))
                                            {

                                                prv = s;
                                                Thread.Sleep(1000);
                                                sayenter2ctx("{enter}");
                                                Thread.Sleep(1000);
                                                sayenter2ctx("{alt+e+a}");
                                                Thread.Sleep(1000);
                                                s = cplcpy();
                                                Thread.Sleep(500);

                                                if (prv == s) break;
                                                else if (s.Contains("DFE"))
                                                {
                                                    goto repeat;
                                                }
                                            }
                                        }
                                        else if (rdDFE.Checked == false)
                                        {
                                            while (!s.Contains("DEN") || (s.Contains("DEN") && s.Contains("DEFAULT")))
                                            {

                                                prv = s;
                                                Thread.Sleep(1000);
                                                sayenter2ctx("{enter}");
                                                Thread.Sleep(1000);
                                                sayenter2ctx("{alt+e+a}");
                                                Thread.Sleep(1000);
                                                s = cplcpy();
                                                Thread.Sleep(500);

                                                if (prv == s) break;
                                                else if (s.Contains("DEN"))
                                                {
                                                    goto repeat;
                                                }
                                            }
                                        }


                                        if (prv == s)
                                            break;
                                    }
                                }
                                else { throw new Exception("Omega Imgnow - desktop not Available"); }

                                Thread.Sleep(500);

                                if (dtbatch.Rows.Count > 0)
                                {
                                    export(dtbatch);
                                    Thread.Sleep(500);
                                }
                                if (dtop.Rows.Count > 0)
                                {
                                    EXCEL.export(dtop, chkmd4User.Text.ToString(), "");
                                    if (dtFormetExcel.Rows.Count > 0)
                                        EXCEL.ConvertToExcel(dtFormetExcel, chkmd4User.Text + "_" + "");
                                    if (dtFinalOutput.Rows.Count > 0)
                                        EXCEL.ConvertToExcel(dtFinalOutput, "CodingTeam_" + chkmd4User.Text + "_" + "");
                                    // EXCEL.export(dtFinalOutput, "CodingTeam_"+chkmd4User.Text.ToString(), "");
                                }
                                sayenter2ctx("E");
                                Thread.Sleep(500);
                                sayenter2ctx("{enter}");
                                Thread.Sleep(500);
                                sayenter2ctx("{escape}");
                                Thread.Sleep(500);
                                sayenter2ctx("{enter}");
                                Thread.Sleep(500);
                                sayenter2ctx("{escape}");
                                Thread.Sleep(500);
                                sayenter2ctx("{escape}");
                                Thread.Sleep(500);
                                sayenter2ctx("{enter}");
                                Thread.Sleep(500);
                                resultId = 0; if (dtop.Rows.Count > 0) dtop.Rows.Clear(); if (dtbatch.Rows.Count > 0) dtbatch.Rows.Clear();

                            }
                            sayenter2ctx("{escape}");
                            Thread.Sleep(500);
                            sayenter2ctx("{escape}");
                            Thread.Sleep(500);
                            sayenter2ctx("{enter}");
                            Thread.Sleep(500);
                        securityerr:
                            sayenter2ctx("1");
                            sayenter2ctx("{enter}");
                            Thread.Sleep(500);

                        }//Account loop
                                            
                  
                        Thread.Sleep(500);


                        dbtracking();
                        sayenter2ctx("{alt+c+d}"); Thread.Sleep(500);

                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error: " + ex.Message);

                        if (dtop.Rows.Count > 0)
                        {
                            EXCEL.export(dtop, chkmd4User.Text.ToString(), "");
                            if (dtFormetExcel.Rows.Count > 0)
                                EXCEL.ConvertToExcel(dtFormetExcel, chkmd4User.Text + "_" + "");

                        }
                        Application.Exit();
                        System.Environment.Exit(-1);
                    }
                }
                else
                {
                    MessageBox.Show("Please Provide MDIV Username and Password!!");
                }
            exeExit:
                Thread.Sleep(500);
            }
            else
            {
                MessageBox.Show("Please Enter UNIX Username and Password!!");
            }
        }

        private void cmbclinic_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void chkmd4User_MouseClick(object sender, MouseEventArgs e)
        {
            string st = chkmd4User.GetItemCheckState(1).ToString();
            string st1 = chkmd4User.Text;
            if ((chkmd4User.Text == "Select All") && (chkmd4User.GetItemCheckState(0).ToString() == "Unchecked"))
            {
                for (int i = 0; i < chkmd4User.Items.Count; i++)
                {
                    if (i >= 1)
                    {
                        chkmd4User.SetItemChecked(i, true);
                        TextBox textbox = new TextBox();
                    }
                }
            }
            else if ((chkmd4User.Text == "Select All") && (chkmd4User.GetItemCheckState(0).ToString() == "Checked"))
            {
                for (int i = 0; i < chkmd4User.Items.Count; i++)
                {
                    if (i >= 1)
                    {
                        chkmd4User.SetItemChecked(i, false);
                        TextBox textbox = new TextBox();
                    }
                }
            }
            else
            {
                TextBox textbox = new TextBox();
            }           
        }

        private void btnstop_Click(object sender, EventArgs e)
        {
            if (dtop.Rows.Count > 0)
            {
                EXCEL.export(dtop, chkmd4User.Text.ToString(), "");
                EXCEL.ConvertToExcel(dtFormetExcel, chkmd4User.Text + "_" + "");               
            }
            else if (dtbatch.Rows.Count > 0)
                export(dtbatch);
            Application.Exit();
            System.Environment.Exit(-1);
        }

        private void rdDFE_CheckedChanged(object sender, EventArgs e)
        {

        }       
    }
}
