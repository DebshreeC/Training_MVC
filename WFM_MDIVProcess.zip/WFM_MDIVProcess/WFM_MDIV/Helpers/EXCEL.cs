﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Excel = Microsoft.Office.Interop.Excel;
using System.Reflection;
using System.IO;
using System.IO.Packaging;
using System.Data;


namespace WFMMDIV
{
    class EXCEL
    {
        internal void toexcl(System.Data.DataSet dtwide)
        {
            string statusfileName = "Output_Status_" + DateTime.Now.ToString("MMddyyyy_HHmm") + ".xls";
            string fileName = Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location) + "\\" + statusfileName;

            Excel.Application oXL;
            Excel.Workbook oWB;
            Excel.Worksheet oSheet;
            Excel.Range oRange;

            // Start Excel and get Application object. 
            oXL = new Excel.Application();

            // Set some properties 
            oXL.Visible = true;
            oXL.DisplayAlerts = false;

            // Get a new workbook. 
            oWB = oXL.Workbooks.Add(Missing.Value);

            // Get the active sheet 
            oSheet = (Excel.Worksheet)oWB.ActiveSheet;
            oSheet.Name = "Sheet1";

            // Process the DataTable 
            // BE SURE TO CHANGE THIS LINE TO USE *YOUR* DATATABLE 
            DataTable dt = dtwide.Tables[0];

            int rowCount = 1;
            foreach (DataRow dr in dt.Rows)
            {
                rowCount += 1;
                for (int i = 1; i < dt.Columns.Count + 1; i++)
                {
                    // Add the header the first time through 
                    if (rowCount == 2)
                    {
                        oSheet.Cells[1, i] = dt.Columns[i - 1].ColumnName;
                    }
                    oSheet.Cells[rowCount, i] = dr[i - 1].ToString();
                }
            }

            // Resize the columns 
            oRange = oSheet.get_Range(oSheet.Cells[1, 1],
                          oSheet.Cells[rowCount, dt.Columns.Count]);
            oRange.EntireColumn.AutoFit();

            // Save the sheet and close 
            oSheet = null;
            oRange = null;

            if (dtwide.Tables.Count > 1)
            {
                oSheet = (Excel.Worksheet)oWB.ActiveSheet;
                oSheet.Name = "Table2";

                // Process the DataTable 
                // BE SURE TO CHANGE THIS LINE TO USE *YOUR* DATATABLE 
                DataTable dt2 = dtwide.Tables[1];

                int rowCount2 = 1;
                foreach (DataRow dr in dt2.Rows)
                {
                    rowCount += 1;
                    for (int i = 1; i < dt2.Columns.Count + 1; i++)
                    {
                        // Add the header the first time through 
                        if (rowCount2 == 2)
                        {
                            oSheet.Cells[1, i] = dt2.Columns[i - 1].ColumnName;
                        }
                        oSheet.Cells[rowCount2, i] = dr[i - 1].ToString();
                    }
                }

                // Resize the columns 
                oRange = oSheet.get_Range(oSheet.Cells[1, 1],
                              oSheet.Cells[rowCount2, dt.Columns.Count]);
                oRange.EntireColumn.AutoFit();

                // Save the sheet and close 
                oSheet = null;
                oRange = null;
            }

            oWB.SaveAs(fileName, Excel.XlFileFormat.xlWorkbookNormal,
                Missing.Value, Missing.Value, Missing.Value, Missing.Value,
                Excel.XlSaveAsAccessMode.xlExclusive,
                Missing.Value, Missing.Value, Missing.Value,
                Missing.Value, Missing.Value);
            oWB.Close(Missing.Value, Missing.Value, Missing.Value);
            oWB = null;
            oXL.Quit();

            // Clean up 
            // NOTE: When in release mode, this does the trick 
            GC.WaitForPendingFinalizers();
            GC.Collect();
            GC.WaitForPendingFinalizers();
            GC.Collect();


        }

        public static void ConvertToExcel(DataTable dtable, string fileName)
        {
             fileName += DateTime.Now.ToString("MMddyyyy_HHmm") + ".xlsx";
            try
            {               
              CreateExcelFile.CreateExcelDocument(dtable, fileName);
            }
            catch (Exception ex)
            {
                System.Windows.Forms.MessageBox.Show("Couldn't create Excel file.\r\nException: " + ex.Message);
                //return;
            }

            //  Step 3:  Let's open our new Excel file and shut down this application.
            System.Diagnostics.Process p = new System.Diagnostics.Process();
            p.StartInfo = new System.Diagnostics.ProcessStartInfo(fileName);
            p.Start();

            // return statusfileName;
        }

        public static void ConvertToExcel(DataSet ds)
        {
            string statusfileName = "" + DateTime.Now.ToString("MMddyyyy_HHmm") + ".xlsx";
            try
            {
                CreateExcelFile.CreateExcelDocument(ds, statusfileName);
            }
            catch (Exception ex)
            {
                System.Windows.Forms.MessageBox.Show("Couldn't create Excel file.\r\nException: " + ex.Message);
                //return;
            }

            //  Step 3:  Let's open our new Excel file and shut down this application.
            System.Diagnostics.Process p = new System.Diagnostics.Process();
            p.StartInfo = new System.Diagnostics.ProcessStartInfo(statusfileName);
            p.Start();

            // return statusfileName;
        }

        public static void toexcl1(System.Data.DataSet dtwide)
        {

          Excel.ApplicationClass ExcelApp = new Excel.ApplicationClass();
            Excel.Workbook xlWorkbook = ExcelApp.Workbooks.Add(Microsoft.Office.Interop.Excel.XlWBATemplate.xlWBATWorksheet);

          //  xlWorkbook.FullName = "Availity_Output" + DateTime.Now.ToString("MMDDYYY_HHmm");
            DataTableCollection collection = dtwide.Tables;
            int p = collection.Count;
            for (int i = collection.Count; i > 0; i--)
            {

                Excel.Sheets xlSheets = null;

                Excel.Worksheet xlWorksheet = null;

                //Create Excel Sheets

                xlSheets = ExcelApp.Sheets;

                xlWorksheet = (Excel.Worksheet)xlSheets.Add(xlSheets[1],

                               Type.Missing, Type.Missing, Type.Missing);


                System.Data.DataTable table = collection[i - 1];

                xlWorksheet.Name = "Table"+(p--).ToString();


                for (int j = 1; j < table.Columns.Count + 1; j++)
                {

                    ExcelApp.Cells[1, j] = table.Columns[j - 1].ColumnName;

                }


                for (int k = 0; k < table.Rows.Count; k++)
                {

                    for (int l = 0; l < table.Columns.Count; l++)
                    {

                        ExcelApp.Cells[k + 2, l + 1] =

                        table.Rows[k].ItemArray[l].ToString();

                    }

                }

                ExcelApp.Columns.AutoFit();

            }

            ((Excel.Worksheet)ExcelApp.ActiveWorkbook.Sheets[ExcelApp.ActiveWorkbook.Sheets.Count]).Delete();

            ExcelApp.Visible = true;

        }
        public static void export(DataTable dtoutput, string filename, string account)
        {

            try
            {
                string fl_path = "";
                // Bind table data to Stream Writer to export data to respective folder
               
                    fl_path = @"C:\WFM_MCK\" + DateTime.Now.ToString("dd-MM-yyyy");
               
                if (!Directory.Exists(fl_path)) { Directory.CreateDirectory(fl_path); }
                string FileName = filename + ".xls";
                string file = fl_path + @"\" + System.DateTime.Now.ToString("HH.mm.ss") + FileName;
                StreamWriter wr = new StreamWriter(file);
                // Write Columns to excel file
                for (int i = 0; i < dtoutput.Columns.Count; i++)
                {
                    wr.Write(dtoutput.Columns[i].ToString().ToUpper() + "\t");
                }
                wr.WriteLine();
                //write rows to excel file
                for (int i = 0; i < (dtoutput.Rows.Count); i++)
                {
                    for (int j = 0; j < dtoutput.Columns.Count; j++)
                    {
                        if (dtoutput.Rows[i][j] != null)
                        {
                            wr.Write(Convert.ToString(dtoutput.Rows[i][j]) + "\t");
                        }
                        else
                        {
                            wr.Write("\t");
                        }
                    }
                    wr.WriteLine();
                }
                wr.Close();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
