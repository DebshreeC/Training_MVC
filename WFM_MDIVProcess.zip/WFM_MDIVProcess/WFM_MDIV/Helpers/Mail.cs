﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;

using System.Linq;
using System.Text;
//using System.Windows.Forms;
using System.Net.Mail;
using System.Configuration;
using System.IO;
using System.Collections;


namespace WFMMDIV
{
    public class Mail
    {
        public Mail()
        {
            //

            // TODO: Add constructor logic here
            //
        }

        public void SendMail(string from, string to, string bcc, string subject, string body)
        {
            try
            {// Instantiate a new instance of MailMessage
                MailMessage mMailMessage = new MailMessage();
                // Set the sender address of the mail message
                mMailMessage.From = new MailAddress(from);
                // Set the recepient address of the mail message

                mMailMessage.To.Add(new MailAddress(to.ToString()));

                //  mMailMessage.To.Add(new MailAddress(to));
                // Check if the bcc value is null or an empty string
                if ((bcc != null) && (bcc != string.Empty))
                {
                    // Set the Bcc address of the mail message
                    mMailMessage.Bcc.Add(new MailAddress(bcc));
                }
                // Check if the cc value is null or an empty value
                //if ((cc != null) && (cc != string.Empty))
                //{
                //    // Set the CC address of the mail message
                //    mMailMessage.CC.Add(new MailAddress(cc));
                //}

                //Attachment attachFile = new Attachment("D:\\dailylog.xls");
                //mMailMessage.Attachments.Add(attachFile);


                // Set the subject of the mail message
                mMailMessage.Subject = subject;
                // Set the body of the mail message
                mMailMessage.Body = body;
                // Set the format of the mail message body as HTML
                mMailMessage.IsBodyHtml = true;
                // Set the priority of the mail message to normal
                mMailMessage.Priority = MailPriority.Normal;
                // Instantiate a new instance of SmtpClient

                //SmtpClient mSmtpClient = new SmtpClient(System.Configuration.ConfigurationManager.AppSettings["EmailServerLocation"]);

                // <add key="EmailServerLocation" value="Omg-outlook.omegahms.com"/>
                //SmtpClient mSmtpClient = new SmtpClient("10.1.2.72");
                SmtpClient mSmtpClient = new SmtpClient("Omg-outlook.omegahms.com");

                // Send the mail message
                mSmtpClient.Send(mMailMessage);
                mMailMessage.Dispose();
            }

            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}