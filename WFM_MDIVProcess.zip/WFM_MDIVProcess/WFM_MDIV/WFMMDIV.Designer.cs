﻿namespace WFMMDIV
{
    partial class WFMMDIV
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.CitrixUserNameTextbox = new System.Windows.Forms.TextBox();
            this.CitrixPasswordTextbox = new System.Windows.Forms.TextBox();
            this.button2 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.unixpssword = new System.Windows.Forms.TextBox();
            this.unixuser = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.md4password = new System.Windows.Forms.TextBox();
            this.cmbtelnet = new System.Windows.Forms.ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.cmbclinic = new System.Windows.Forms.ComboBox();
            this.label7 = new System.Windows.Forms.Label();
            this.btnExtract = new System.Windows.Forms.Button();
            this.chkmd4User = new System.Windows.Forms.CheckedListBox();
            this.btnstop = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.rdDFE = new System.Windows.Forms.RadioButton();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.panel1.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // comboBox1
            // 
            this.comboBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "Select server",
            "Server-1",
            "Server-2"});
            this.comboBox1.Location = new System.Drawing.Point(123, 25);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(121, 23);
            this.comboBox1.TabIndex = 1;
            // 
            // CitrixUserNameTextbox
            // 
            this.CitrixUserNameTextbox.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CitrixUserNameTextbox.Location = new System.Drawing.Point(123, 62);
            this.CitrixUserNameTextbox.Name = "CitrixUserNameTextbox";
            this.CitrixUserNameTextbox.Size = new System.Drawing.Size(121, 21);
            this.CitrixUserNameTextbox.TabIndex = 2;
            this.CitrixUserNameTextbox.Text = "eaqsfc6";
            // 
            // CitrixPasswordTextbox
            // 
            this.CitrixPasswordTextbox.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CitrixPasswordTextbox.Location = new System.Drawing.Point(123, 100);
            this.CitrixPasswordTextbox.Name = "CitrixPasswordTextbox";
            this.CitrixPasswordTextbox.PasswordChar = '*';
            this.CitrixPasswordTextbox.Size = new System.Drawing.Size(121, 21);
            this.CitrixPasswordTextbox.TabIndex = 3;
            this.CitrixPasswordTextbox.Text = "Omega987#";
            // 
            // button2
            // 
            this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.Location = new System.Drawing.Point(75, 137);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(119, 34);
            this.button2.TabIndex = 4;
            this.button2.Text = "Citrix Launch";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.Citrixlaunch_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(21, 25);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(79, 15);
            this.label1.TabIndex = 5;
            this.label1.Text = "Select Server";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(21, 60);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(97, 15);
            this.label2.TabIndex = 6;
            this.label2.Text = "Citrix UserName";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(21, 97);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(91, 15);
            this.label3.TabIndex = 7;
            this.label3.Text = "Citrix Password";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(6, 66);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(98, 15);
            this.label8.TabIndex = 15;
            this.label8.Text = "Telnet Password";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(6, 29);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(104, 15);
            this.label9.TabIndex = 14;
            this.label9.Text = "Telnet UserName";
            // 
            // unixpssword
            // 
            this.unixpssword.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.unixpssword.Location = new System.Drawing.Point(114, 66);
            this.unixpssword.Name = "unixpssword";
            this.unixpssword.PasswordChar = '*';
            this.unixpssword.Size = new System.Drawing.Size(121, 21);
            this.unixpssword.TabIndex = 13;
            this.unixpssword.Text = "Tomck123*";
            // 
            // unixuser
            // 
            this.unixuser.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.unixuser.Location = new System.Drawing.Point(114, 26);
            this.unixuser.Name = "unixuser";
            this.unixuser.Size = new System.Drawing.Size(121, 21);
            this.unixuser.TabIndex = 12;
            this.unixuser.Text = "exazkha";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(13, 92);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(94, 15);
            this.label10.TabIndex = 19;
            this.label10.Text = "MDIV Password";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(13, 49);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(75, 15);
            this.label11.TabIndex = 18;
            this.label11.Text = "MDIV Admin";
            // 
            // md4password
            // 
            this.md4password.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.md4password.Location = new System.Drawing.Point(121, 86);
            this.md4password.Name = "md4password";
            this.md4password.PasswordChar = '*';
            this.md4password.Size = new System.Drawing.Size(101, 21);
            this.md4password.TabIndex = 17;
            this.md4password.Text = "Tomck123*";
            // 
            // cmbtelnet
            // 
            this.cmbtelnet.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbtelnet.FormattingEnabled = true;
            this.cmbtelnet.Items.AddRange(new object[] {
            "Select Telnet",
            "CHS01",
            "CHS02",
            "CHS03",
            "CHS05",
            "CHS07",
            "CHS08",
            "CHS09",
            "CHS10"});
            this.cmbtelnet.Location = new System.Drawing.Point(111, 22);
            this.cmbtelnet.Name = "cmbtelnet";
            this.cmbtelnet.Size = new System.Drawing.Size(121, 23);
            this.cmbtelnet.TabIndex = 23;
            this.cmbtelnet.SelectedIndexChanged += new System.EventHandler(this.cmbtelnet_SelectedIndexChanged);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(15, 25);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(71, 15);
            this.label6.TabIndex = 22;
            this.label6.Text = "MDIVTelnet";
            // 
            // cmbclinic
            // 
            this.cmbclinic.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbclinic.FormattingEnabled = true;
            this.cmbclinic.Items.AddRange(new object[] {
            "One",
            "More thanOne"});
            this.cmbclinic.Location = new System.Drawing.Point(111, 53);
            this.cmbclinic.Name = "cmbclinic";
            this.cmbclinic.Size = new System.Drawing.Size(121, 23);
            this.cmbclinic.TabIndex = 25;
            this.cmbclinic.SelectedIndexChanged += new System.EventHandler(this.cmbclinic_SelectedIndexChanged);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(15, 56);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(91, 15);
            this.label7.TabIndex = 24;
            this.label7.Text = "Clinic Selection";
            // 
            // btnExtract
            // 
            this.btnExtract.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExtract.Location = new System.Drawing.Point(171, 49);
            this.btnExtract.Name = "btnExtract";
            this.btnExtract.Size = new System.Drawing.Size(114, 33);
            this.btnExtract.TabIndex = 26;
            this.btnExtract.Text = "Batch Extract";
            this.btnExtract.UseVisualStyleBackColor = true;
            this.btnExtract.Click += new System.EventHandler(this.btnExtract_Click);
            // 
            // chkmd4User
            // 
            this.chkmd4User.BackColor = System.Drawing.Color.LightSkyBlue;
            this.chkmd4User.CheckOnClick = true;
            this.chkmd4User.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkmd4User.FormattingEnabled = true;
            this.chkmd4User.Location = new System.Drawing.Point(121, 16);
            this.chkmd4User.Name = "chkmd4User";
            this.chkmd4User.Size = new System.Drawing.Size(101, 67);
            this.chkmd4User.TabIndex = 28;
            this.chkmd4User.MouseClick += new System.Windows.Forms.MouseEventHandler(this.chkmd4User_MouseClick);
            this.chkmd4User.SelectedIndexChanged += new System.EventHandler(this.chkmd4User_SelectedIndexChanged);
            // 
            // btnstop
            // 
            this.btnstop.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnstop.Location = new System.Drawing.Point(678, 262);
            this.btnstop.Name = "btnstop";
            this.btnstop.Size = new System.Drawing.Size(75, 23);
            this.btnstop.TabIndex = 29;
            this.btnstop.Text = "STOP";
            this.btnstop.UseVisualStyleBackColor = true;
            this.btnstop.Click += new System.EventHandler(this.btnstop_Click);
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(27, 49);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(121, 33);
            this.button1.TabIndex = 30;
            this.button1.Text = "Batch Search";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.Batch_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Gray;
            this.panel1.Controls.Add(this.groupBox5);
            this.panel1.Controls.Add(this.groupBox4);
            this.panel1.Controls.Add(this.groupBox3);
            this.panel1.Controls.Add(this.groupBox2);
            this.panel1.Controls.Add(this.btnstop);
            this.panel1.Controls.Add(this.groupBox1);
            this.panel1.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel1.Location = new System.Drawing.Point(2, 6);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(857, 345);
            this.panel1.TabIndex = 31;
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.rdDFE);
            this.groupBox5.Controls.Add(this.button1);
            this.groupBox5.Controls.Add(this.btnExtract);
            this.groupBox5.Location = new System.Drawing.Point(301, 228);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(314, 88);
            this.groupBox5.TabIndex = 35;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Processes";
            // 
            // rdDFE
            // 
            this.rdDFE.AutoSize = true;
            this.rdDFE.Location = new System.Drawing.Point(106, 21);
            this.rdDFE.Name = "rdDFE";
            this.rdDFE.Size = new System.Drawing.Size(100, 22);
            this.rdDFE.TabIndex = 29;
            this.rdDFE.Text = "DFE batches";
            this.rdDFE.UseVisualStyleBackColor = true;
            this.rdDFE.CheckedChanged += new System.EventHandler(this.rdDFE_CheckedChanged);
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.label11);
            this.groupBox4.Controls.Add(this.label10);
            this.groupBox4.Controls.Add(this.md4password);
            this.groupBox4.Controls.Add(this.chkmd4User);
            this.groupBox4.Location = new System.Drawing.Point(578, 36);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(255, 170);
            this.groupBox4.TabIndex = 34;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "MDIV Login";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.cmbtelnet);
            this.groupBox3.Controls.Add(this.label6);
            this.groupBox3.Controls.Add(this.label7);
            this.groupBox3.Controls.Add(this.cmbclinic);
            this.groupBox3.Location = new System.Drawing.Point(328, 135);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(244, 87);
            this.groupBox3.TabIndex = 33;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Selection Criteria";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.label9);
            this.groupBox2.Controls.Add(this.unixuser);
            this.groupBox2.Controls.Add(this.unixpssword);
            this.groupBox2.Controls.Add(this.label8);
            this.groupBox2.Location = new System.Drawing.Point(324, 35);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(250, 100);
            this.groupBox2.TabIndex = 32;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Telnet Login";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.comboBox1);
            this.groupBox1.Controls.Add(this.CitrixUserNameTextbox);
            this.groupBox1.Controls.Add(this.CitrixPasswordTextbox);
            this.groupBox1.Controls.Add(this.button2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Location = new System.Drawing.Point(27, 35);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(291, 187);
            this.groupBox1.TabIndex = 32;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Citrix Login";
            // 
            // WFMMDIV
            // 
            this.BackColor = System.Drawing.Color.Gray;
            this.ClientSize = new System.Drawing.Size(865, 357);
            this.Controls.Add(this.panel1);
            this.Name = "WFMMDIV";
            this.Text = "WFM MDIV";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.MCK_FormClosing);
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.MCK_FormClosed);
            this.Load += new System.EventHandler(this.MCK_Load);
            this.panel1.ResumeLayout(false);
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.TextBox CitrixUserNameTextbox;
        private System.Windows.Forms.TextBox CitrixPasswordTextbox;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox unixpssword;
        private System.Windows.Forms.TextBox unixuser;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox md4password;
        private System.Windows.Forms.ComboBox cmbtelnet;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ComboBox cmbclinic;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button btnExtract;
        private System.Windows.Forms.CheckedListBox chkmd4User;
        private System.Windows.Forms.Button btnstop;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.RadioButton rdDFE;
    }
}

