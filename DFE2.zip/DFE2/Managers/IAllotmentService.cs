﻿using Denial_Coding.BAL.ViewModels;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.Mvc;

namespace Denial_Coding.BAL.Managers
{
    public interface IAllotmentService
    {
        
        List<SelectListItem> getCoderNames(int tl, int user);
        DataTable GetAccountDetails(string status, string fromDos, string toDos, int PracticeId);
        List<SelectListItem> GetPracticeList();
        void AllotToCoder(string listOfAccounts, string PracticeId, string codername);
        void UpdateAllotToCoder(string listOfAccounts, string PracticeId, string codername);
        DataTable GetDuplicateAccountDetails(string status, string fromDos, string toDos, int PracticeId);

    }
}
