﻿using CBIplus.BAL.Managers;
using CBIplus.BAL.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Web;
using System.Web.Mvc;

namespace CBIplus.Controllers
{
    public class AllotmentController : Controller
    {
        IMedDataAllotmentManager managerObj =new MedDataAllotmentManager();

        //
        // GET: /Allotment/
        public ActionResult CodingAllotment()
        {
            AllotmentModel model = new AllotmentModel();
            model=managerObj.All();
            model.Status = managerObj.getStatusNames("Coding_Allotment");
            model.availableCount = managerObj.availableCount("P","","");
            return View(model);
        }

        public JsonResult GetCoderList(string tl,string user,string Location)
        {
            return Json(managerObj.getCoderNames(tl, user, Location), JsonRequestBehavior.AllowGet);
        }
        //Auto allotment-- by subhaja 23/05/2017
        public JsonResult GetCoderforSelectedTL(string tl,string location)
        {
            return Json(managerObj.GetCoderforSelectedTL(tl,location), JsonRequestBehavior.AllowGet);
        }
        public JsonResult getBatchNamesBULK(string location, string fromDate, string toDate)
        {
            return Json(managerObj.getBatchNamesBULK(location, fromDate, toDate), JsonRequestBehavior.AllowGet);
        } 
        public ActionResult GetTLList(string Location)
        {
            AllotmentModel TL = new AllotmentModel();
            TL.TLList = managerObj.getTLNames(Location);
                List<SelectListItem> selectedItems = TL.TLList.ToList();
                return Json(managerObj.getTLNames(Location), JsonRequestBehavior.AllowGet);
        }
        public JsonResult GetAvailableCount(string EncounterType, string BatchName, string location)
        {
            return Json(managerObj.availableCount(EncounterType, BatchName, location), JsonRequestBehavior.AllowGet);
        }
        [HttpPost]
        public ActionResult BulkAllotmentCodingFresh(AllotmentModel model, string listOfCoders, int ToBeAllocateCount, string buttonText, string location, int NOOFUSERS, string ENCOUTERTYPE, string BATCHNAME)
        {
            //if (buttonText == "Allot")
            //{                
              return Json(managerObj.AllotToCoderBulk(model, listOfCoders, ToBeAllocateCount, location, NOOFUSERS, ENCOUTERTYPE, BATCHNAME), JsonRequestBehavior.AllowGet);
            //}           
          
        }
        //
        //Auto allotment-- by subhaja 23/05/2017
        public ActionResult GetAccountDetails(string status, string fromDos, string toDos, string encounterType)
        {

            return PartialView("_CoderAllotmentGrid", managerObj.GetAccountDetails(status, fromDos, toDos, encounterType));
           
        }

        public ActionResult GetBatchCodingAllotment(string batchName, string status)
        {
            return PartialView("_CoderAllotmentGrid", managerObj.BatchWiseFilterAccounts(batchName,status));
        }

        public ActionResult GetEncounterTypeAccounts(string status, string encounterType)
        {
            return PartialView("_CoderAllotmentGrid", managerObj.EncounterTypeWiseFilterAccounts(status, encounterType));
        }
        [HttpPost]
        public JsonResult CodingAllotment(AllotmentModel model, string listOfAccounts, string buttonText)
        {
            if (buttonText == "Allot")
            {
                managerObj.AllotToCoder(model, listOfAccounts);
            }
            else if (buttonText == "Submit")
            {
                managerObj.SubmitAllotment(model, listOfAccounts);
            }
            else if (buttonText=="Swap")
            {
                managerObj.Reassign(model, listOfAccounts);
            }
            return Json("",JsonRequestBehavior.AllowGet);
        }
        public JsonResult GetDistnctBatches()
        {
            return Json(Session["distinctBatchs"], JsonRequestBehavior.AllowGet);
        }

        public ActionResult QcAllotment()
        {
            AllotmentModel model = new AllotmentModel();
            model = managerObj.All();
            model.Status = managerObj.getStatusNames("QC_Allotment");
            //model.CoderList = managerObj.getCoderNames("Coder-QC-TL", "QC","").OrderBy(x => x.Text).ToList();
            return View(model);
        }

        public JsonResult GetQCList(string tl, string user, string Location)
        {
            return Json(managerObj.getCoderNames(tl, user, Location), JsonRequestBehavior.AllowGet);
        }
        
       
        public ActionResult CodingAllotmentExport()
        {
            managerObj.GetAllotmentDetails();
            return Json("",JsonRequestBehavior.AllowGet);
        }

        public ActionResult QCAllotmentExport()
        {
            managerObj.GetQCAllotmentDetails();
            return Json("", JsonRequestBehavior.AllowGet);
        }
        public JsonResult QCAllotmentt(AllotmentModel model, string listOfAccounts, string buttonText, string auditType=null)
        {
            if (buttonText == "Allot")
            {
                managerObj.AllotToQC(model, listOfAccounts);
            }
            else if (buttonText == "Submit")
            {
                managerObj.SubmitQCAllotment(model, listOfAccounts,auditType);
            }
            return Json("", JsonRequestBehavior.AllowGet);
        }

        public ActionResult GetQCAccountDetails(string status, string fromDos, string toDos)
        {
             return PartialView("_QCAllotmentGrid", managerObj.GetQCAccountDetails(status, fromDos, toDos));
        }

        public async Task<ActionResult> GetQcAccountDetailsHighMark(string status, string fromDos, string toDos, string auditType, string encounterType)
        {
            return PartialView("_QCAllotmentGrid",managerObj.GetQcAccountDetailsHighMark(status, fromDos, toDos, auditType, encounterType));
        }

        public JsonResult QCSkip(AllotmentModel model, string listOfAccounts)
        {
            return Json(managerObj.QCSkip(model, listOfAccounts), JsonRequestBehavior.AllowGet);
        }
        //Added by DebshreeC
        public JsonResult SendBackAccountQC2CODER(string selectedAccounts)
        {
            managerObj.SendBackAccountQC2CODER(selectedAccounts);
            string qc = Session["QCED"].ToString();
            return Json(qc, JsonRequestBehavior.AllowGet);
        }
	}
}