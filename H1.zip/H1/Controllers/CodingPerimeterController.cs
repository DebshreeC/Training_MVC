﻿using CBIplus.BAL.Managers;
using CBIplus.BAL.ViewModels;
using System;
using System.Collections.Generic;
//using System.IO;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace CBIplus.Controllers
{
    public class CodingPerimeterController : Controller
    {
         IPeriMeterCoderService managerObj =new PeriMeterCoderManager();
     

        public ActionResult CodingPerimeter()
        {

            return View(managerObj.LoadMasterDropdownData());
        }
        public ActionResult LoadCoderInbox()
        {
            return PartialView("_CoderInbox",managerObj.LoadCoderInboxData());
        }
        public ActionResult LoadCodedAccounts()
        {
            return PartialView("_CodedAccounts",managerObj.LoadCodedAccounts());
        }
        public JsonResult LoadAccountDropdowns(string selectedFacility, string accNumber)
        {
            return Json(managerObj.LoadAccountDropdowns(selectedFacility,accNumber), JsonRequestBehavior.AllowGet);
        }
        public JsonResult ChangeSelectedCPT(string CPT)
        {
            return Json(managerObj.GetSelectedCPT(CPT), JsonRequestBehavior.AllowGet);
        }
        [HttpPost]
        public JsonResult SaveChartChanges(List<CodingPeriModel> model, string status)
        {
            managerObj.SaveChartChanges(model,status);
            return Json("", JsonRequestBehavior.AllowGet);
        }
        public ActionResult ViewAccountDetails(CodingPeriModel model)
        {
            CodingPeriModel newModel = managerObj.LoadAccountDropdowns(model.Facility,model.AccountNumber,"updateAccount");
            model.AttendingPhyList = newModel.AttendingPhyList;
            model.NPPAList = newModel.NPPAList;
            model.ScribeList = newModel.ScribeList;
            model.PatientStatusDCStatusList = newModel.PatientStatusDCStatusList;
            model.ResidentList = newModel.ResidentList;
            model.DowncodedFormList = newModel.DowncodedFormList;
            
            return PartialView("_UpdateAccount",model);
        }
        public ActionResult AddCPT(int transId, int transDetailsId, string status,string accountNum,string facility)
        {       
            return PartialView("_AddCPT",managerObj.GetCptICDDetails(transId, transDetailsId, status, accountNum, facility));
        }
        public JsonResult SaveAndUpdateCPTChanges(CodingPeriModel model)
        {
            managerObj.SaveAndUpdateCPTChanges(model);
            return Json("", JsonRequestBehavior.AllowGet);
        }
        public ActionResult ViewCPTGrid(int transId, string accountNumber, string Facility)
        {
            return PartialView("_ViewPeriCPTGrid", managerObj.GetCPTGridData(transId, accountNumber, Facility));
        }
        public JsonResult DeleteAccountCPT(string CPT,int transId)
        {
            managerObj.DeleteAccountCPT(CPT,transId);
            return Json("",JsonRequestBehavior.AllowGet);
        }
        public JsonResult _ValidateCPT(string CPTValue,int TRANSID)
        {
           // managerObj.GetValidCPTList(CPTValue, TRANSID);
            return Json("", JsonRequestBehavior.AllowGet);
        }
        public ActionResult DeleteCPT(int transDetailsId)
        {
            managerObj.DeleteCPT(transDetailsId);
            return Json(transDetailsId, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public JsonResult UpdateAccountDetails(CodingPeriModel model)
        {
            managerObj.UpdateAccountDetails(model);
            return Json("", JsonRequestBehavior.AllowGet);
        }

        public ActionResult ConvertToPDF(string AccNo)
        {
            return Json(managerObj.ConvertToPDF(AccNo), JsonRequestBehavior.AllowGet);
        }
	}
}