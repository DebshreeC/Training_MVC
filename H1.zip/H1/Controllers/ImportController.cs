﻿using CBIplus.BAL.Generics;
using CBIplus.BAL.Managers;
using CBIplus.BAL.ViewModels;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.OleDb;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.UI;


namespace CBIplus.Controllers
{
    public class ImportController : Controller
    {
        IUserMenuService managerObj=new UserMenuManager();
      
        public ActionResult Index(UserMenuModel model)
        {
            managerObj.SaveSessionDetails(model);
            managerObj.GetSideMenu();
            return View();
        }
        public ActionResult Import()
        {
            ImportModel model = new ImportModel();
            model.ProjectId = Session[Constants.ProjectId].ToString();
            return View(model);
        }
        [HttpPost]
        public ActionResult Import(HttpPostedFileBase file,ImportModel modal)
        {
           
            if (Request != null)
            {
              
                if ((file != null) && (file.ContentLength > 0) && !string.IsNullOrEmpty(file.FileName))
                {
                    string fileName = file.FileName;
                    string fileContentType = file.ContentType;
                   modal= ReadExcel(fileName, file, 1,string.Empty);

                }
            }
            modal.ProjectId = Session[Constants.ProjectId].ToString();
            return View(modal);
           
        }
        public ActionResult UploadHCC()
        {
            ImportModel model = new ImportModel();
            return View(model);
        }
        public ActionResult LoadHccGrid()
        {
            return PartialView("_HccGrid");
        }
        [HttpPost]
        public ActionResult UploadHCC(HttpPostedFileBase file, ImportModel modal)
        {
            if (Request != null)
            {

                if ((file != null) && (file.ContentLength > 0) && !string.IsNullOrEmpty(file.FileName))
                {
                    string fileName = file.FileName;
                    string fileContentType = file.ContentType;
                    modal = ReadExcel(fileName, file, 1,"HCC");
                }
            }
            return View(modal);
        }
        [HttpPost]
        public ActionResult UpdateInnerGrid(List<ImportModel> modelList, string operation)
        {
            managerObj.ManageImportAccounts(modelList, operation);
          
            return Json("Success",JsonRequestBehavior.AllowGet);
        }
        public ActionResult GetHeaderCount()
        {
            if (Session[Constants.UserName] == null)
            {
                return RedirectToAction("Home", "Home");
            }
            else
            {
                managerObj.GetHeaderCounts();
                return PartialView("_Header");
            }    
        }
        public ActionResult HCCUploadAccounts()
        {
            return PartialView("_HccPartial",managerObj.GetHCCUploadedAccounts());
        }
        private ImportModel ReadExcel(string FileName, HttpPostedFileBase FilePath, int CId,string type)
        {
            var excelConnectionString = string.Empty;
          
            ImportModel modal = new ImportModel();
            DataSet ds = new DataSet();
            try
            {
                if (Request.Files["file"].ContentLength > 0)
                {
                    string fileExtension = System.IO.Path.GetExtension(Request.Files["file"].FileName);

                    if (fileExtension == ".xls" || fileExtension == ".xlsx")
                    {
                        string fileLocation = Path.Combine(Server.MapPath("~/Scripts"), Path.GetFileName(FilePath.FileName));
                        if (System.IO.File.Exists(fileLocation))
                        {
                            System.IO.File.Delete(fileLocation);
                        }
                        // File is saving into Input Folder 

                        Request.Files["file"].SaveAs(fileLocation);

                        //excelConnectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + fileLocation + ";Extended Properties=\"Excel 12.0;HDR=Yes;IMEX=2\"";

                        //connection String for xls file format.

                        if (fileExtension.Trim() == ".xls")
                        {
                            excelConnectionString = string.Format(@"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + fileLocation + ";Extended Properties=\"Excel 8.0;IMEX=1;HDR=YES;TypeGuessRows=0;ImportMixedTypes=Text\"");
                        }
                        else if (fileExtension.Trim() == ".xlsx")
                        {
                            excelConnectionString = string.Format(@"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + fileLocation + @";Extended Properties=""Excel 12.0;IMEX=1;HDR=YES;TypeGuessRows=0;ImportMixedTypes=Text""");
                        }

                        //Create Connection to Excel work book and add oledb namespace
                        OleDbConnection excelConnection = new OleDbConnection(excelConnectionString);
                        excelConnection.Open();

                        string query = string.Format("Select * from [Sheet1$]");

                        using (OleDbDataAdapter dataAdapter = new OleDbDataAdapter(query, excelConnection))
                        {
                            dataAdapter.Fill(ds);
                        }
                        excelConnection.Close();
                    }

                    //DataTable table = new DataTable();
                    //DataColumn column;
                    //DataRow row;

                    //column = new DataColumn();
                    //column.ColumnName = "id";
                    //table.Columns.Add(column);
                    //foreach (DataRow dr in ds.Tables[0].Rows)
                    //{
                    //    row = table.NewRow();
                    //    row["id"] = CryptoGraphy.Encrypt(dr["AccNO"].ToString());
                    //    table.Rows.Add(row);
                    //}

                    if (ds.Tables[0].Rows.Count > 0)
                    {
                        ViewBag.Message = "Data has been Uploaded";
                        return managerObj.InsertExcelData(ds, type);
                    }
                    else
                    {
                        ViewBag.Message = "Data is not availble in uploaded Excel";
                        return modal;
                    }
                }
                else
                {
                    return modal;
                }
            }
            catch(Exception ex)
            {
                ViewBag.Message = "Excel is not in correct format";
                ds.Dispose();
                return modal;
            }
        }

        public ActionResult LoadUnsuccessfulGrid()
        {
            string connectionString = ConfigurationManager.ConnectionStrings["sqlCon"].ConnectionString;
            return PartialView("_ImportPartialGrid", managerObj.GetUnsuccessFullUploadData());
        }

        public ActionResult DeleteRecords()
        {
            return PartialView("", managerObj.DeleteRecords());
        }
    }
}