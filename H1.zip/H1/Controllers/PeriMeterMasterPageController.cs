﻿using CBIplus.BAL.Managers;
using CBIplus.BAL.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;


namespace CBIplus.Controllers
{
    public class PeriMeterMasterPageController : Controller
    {
         IPeriMeterMasterService managerObj=new PeriMeterMasterManager();
       

        public ActionResult MasterPage()
        {
            PerimeterMasterModel model = new PerimeterMasterModel();
            List<SelectListItem> listIt = new List<SelectListItem>
            {
                new SelectListItem{Text="Facility",Value="Facility"},new SelectListItem{Text="NPPA",Value="NPPA"},
                new SelectListItem{Text="Attending Phy",Value="Attending Phy"},new SelectListItem{Text="Comments",Value="Comments"},
                new SelectListItem{Text="CPT",Value="CPT"},new SelectListItem{Text="Disposition",Value="Disposition"},
                new SelectListItem{Text="DownCoding",Value="DownCoding"},new SelectListItem{Text="Error Category",Value="Error Category"},
                new SelectListItem{Text="Modifier",Value="Modifier"},new SelectListItem{Text="Other CPT",Value="Other CPT"},
                new SelectListItem{Text="Scribe",Value="Scribe"}
            };
            model.MasterDropdownList = listIt;
            model.FacilityList = managerObj.GetFacilityNames();
            return View(model);
        }

        [HttpPost]
        public JsonResult MasterData(PerimeterMasterModel MasterModel)
        {
            managerObj.SaveMasterData(MasterModel);
            return Json("",JsonRequestBehavior.AllowGet);
        }
    }
}