﻿using CBIplus.BAL.Managers;
using CBIplus.BAL.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace CBIplus.Controllers
{
    public class QcTransactionController : Controller
    {
         IMedDataQcTransactionService managerObj=new MedDataQcTransactionManager();
       
        //
        // GET: /QcTransaction/
        public ActionResult Transaction()
        {
            return View(managerObj.GetQcTransactionDetails());
        }
        public ActionResult LoadQcInboxGrid()
        {
            return PartialView("_QcInboxGrid",managerObj.GetCodedData());
        }
        public ActionResult ReleaseToClient()
        {
            return View();
        }
        public ActionResult LoadQcAddCPT(int transId,int tranDetaisId,string status)
        {
            MedDataQcTransactionModel model = new MedDataQcTransactionModel();
            model = managerObj.All(tranDetaisId);
            model.TRANS_ID = transId;
            model.PopUpStatus = status;
            model.TRANS_DETAIL_ID = tranDetaisId;
            //model.AnesthesiaStartTimeList = managerObj.GetStartTimeDropdown();
            //model.AnesthesiaEndTimeList = managerObj.GetEndTimeDropdown();
            return PartialView("_QcAddCPT",model);
        }
        [HttpPost]
        public ActionResult QCAddNewCPT(MedDataQcTransactionModel model,string asa)
        {
            model.AsaCross = asa;
            managerObj.QCAddNewCPT(model);
            return Json(model.PopUpStatus+"*"+model.TRANS_ID, JsonRequestBehavior.AllowGet);
        }
        public JsonResult GetErrorSubCategory(string errorType)
        {
            return Json(managerObj.GetErrorSubCategory(errorType), JsonRequestBehavior.AllowGet); 
        }
      
        public ActionResult ViewCPTGrid(int transId,string accountNumber)
        {
            return PartialView("_ViewCPTGrid", managerObj.GetCPTGridData(transId, accountNumber));
        }
        public ActionResult ViewAccount(MedDataQcTransactionModel model)
        {
            model.DOS = Convert.ToDateTime(model.DOS).ToShortDateString();
            model.PhysicalStatusList = managerObj.GetPhysacalStatus();
            return PartialView("_ViewAccount",model);
        }


        public ActionResult SubmitQcGrid(List<MedDataQcTransactionModel> errorModel,string selectedAccounts)
        {
            managerObj.FinalQcSubmit(errorModel, selectedAccounts);
            return Json("",JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public JsonResult UpdateAccountDetails(MedDataQcTransactionModel model)
        {
            managerObj.UpdateAccountDetails(model);
            return Json("",JsonRequestBehavior.AllowGet);
        }
        public ActionResult DeleteCPT(int transDetailsId)
        {
            managerObj.DeleteCPT(transDetailsId);
            return Json(transDetailsId, JsonRequestBehavior.AllowGet);
        }
	}
}