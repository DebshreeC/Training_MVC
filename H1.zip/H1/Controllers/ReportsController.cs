﻿using CBIplus.BAL.Generics;
using CBIplus.BAL.Managers;
using CBIplus.BAL.ViewModels;
using Microsoft.Reporting.WebForms;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace CBIplus.Controllers
{
    public class ReportsController : Controller
    {
        //
        // GET: /Reports/
       IReportManager managerObj=new ReportManager();    
     
        public ActionResult ErrorLog()
        {
           // ReportsViewModel model = new ReportsViewModel();
            ReportViewer reportViewer = new ReportViewer();
            reportViewer.ProcessingMode = ProcessingMode.Remote;
            reportViewer.SizeToReportContent = true;
            reportViewer.ShowParameterPrompts = false;
            //reportViewer.ServerReport.ReportPath = "/CBI_Reports/Reports/ErrorLog";
            reportViewer.ServerReport.ReportPath = Constants.ErrorLog;
            reportViewer.ServerReport.ReportServerUrl = new Uri(Constants.ReportIpAddress);

            ViewBag.ReportViewer = reportViewer;
            return View();
        }
        [HttpPost]
        public ActionResult ErrorLog(ReportsViewModel model)
        {

            ReportsViewModel para = new ReportsViewModel();
            para = managerObj.GetReportDetails("Error_Log");
            ReportViewer reportViewer = new ReportViewer();
            reportViewer.ProcessingMode = ProcessingMode.Remote;
            reportViewer.SizeToReportContent = true;
            reportViewer.ShowParameterPrompts = false;
            reportViewer.ServerReport.ReportPath = Constants.ErrorLog;
            reportViewer.ServerReport.ReportServerUrl = new Uri(Constants.ReportIpAddress);
            List<ReportParameter> reportParameter = new List<ReportParameter>();
            reportParameter.Add(new ReportParameter("Userntlg", para.UserName));
            reportParameter.Add(new ReportParameter("FromDate", Convert.ToDateTime(model.FromDate).ToString("yyyy-MM-dd")));
            reportParameter.Add(new ReportParameter("ToDate", Convert.ToDateTime(model.ToDate).ToString("yyyy-MM-dd")));
            reportParameter.Add(new ReportParameter("ProjectId", para.ProjectId));
            reportParameter.Add(new ReportParameter("PracticeId", para.PracticeID));
            //reportParameter.Add(new ReportParameter("TASK_ID", para.TaskId));
            //reportParameter.Add(new ReportParameter("TASK_ID", para.TaskId));

            reportParameter.Add(new ReportParameter("status", model.ErrorStatus));
           
            if (model.Location == "0")
            {
                string Value = null;
                reportParameter.Add(new ReportParameter("Location", Value));
            }
            else
            {
                reportParameter.Add(new ReportParameter("Location", model.Location));
            }

           
        
            reportViewer.ServerReport.SetParameters(reportParameter);
            reportViewer.ServerReport.Refresh();
            ViewBag.ReportViewer = reportViewer;
           // return View();
            return PartialView("_ReportViewer");
        }

        public ActionResult ErrorCommentLog()
        {
            // ReportsViewModel model = new ReportsViewModel();
            ReportViewer reportViewer = new ReportViewer();
            reportViewer.ProcessingMode = ProcessingMode.Remote;
            reportViewer.SizeToReportContent = true;
            reportViewer.ShowParameterPrompts = false;
            //reportViewer.ServerReport.ReportPath = "/CBI_Reports/Reports/ErrorLog";
            reportViewer.ServerReport.ReportPath = Constants.ErrorCommentLog;
            reportViewer.ServerReport.ReportServerUrl = new Uri(Constants.ReportIpAddress);

            ViewBag.ReportViewer = reportViewer;
            return View();
        }
        [HttpPost]
        public ActionResult ErrorCommentLog(ReportsViewModel model)
        {

            ReportsViewModel para = new ReportsViewModel();
            para = managerObj.GetReportDetails("ErrorCommentLog");
            ReportViewer reportViewer = new ReportViewer();
            reportViewer.ProcessingMode = ProcessingMode.Remote;
            reportViewer.SizeToReportContent = true;
            reportViewer.ShowParameterPrompts = false;
            reportViewer.ServerReport.ReportPath = Constants.ErrorCommentLog;
            reportViewer.ServerReport.ReportServerUrl = new Uri(Constants.ReportIpAddress);
            List<ReportParameter> reportParameter = new List<ReportParameter>();
            reportParameter.Add(new ReportParameter("Userntlg", para.UserName));
            reportParameter.Add(new ReportParameter("fromdate", Convert.ToDateTime(model.FromDate).ToString("yyyy-MM-dd")));
            reportParameter.Add(new ReportParameter("todate", Convert.ToDateTime(model.ToDate).ToString("yyyy-MM-dd")));
            reportParameter.Add(new ReportParameter("project_id", para.ProjectId));
            reportParameter.Add(new ReportParameter("task_id", para.TaskId));

            //reportParameter.Add(new ReportParameter("status", model.ErrorStatus));

            //if (model.Location == "0")
            //{
            //    string Value = null;
            //    reportParameter.Add(new ReportParameter("Location", Value));

            //}
            //else
            //{
            //    reportParameter.Add(new ReportParameter("Location", model.Location));
            //}

            reportViewer.ServerReport.SetParameters(reportParameter);
            reportViewer.ServerReport.Refresh();
            ViewBag.ReportViewer = reportViewer;
            // return View();
            return PartialView("_ReportViewer");
        }

        public JsonResult GetFacilityNames(string fromDate, string toDate)
        {
            return Json(managerObj.GetFacilityNames(fromDate, toDate), JsonRequestBehavior.AllowGet);
        }

        public JsonResult GetFacilityCode(string BatchName)
        {
            return Json(managerObj.GetFacilityCode(BatchName), JsonRequestBehavior.AllowGet);
        }

        public JsonResult GetBatchNames(string fromDate, string toDate)
        {
            return Json(managerObj.GetBatchNames(fromDate, toDate), JsonRequestBehavior.AllowGet);
        }

        public JsonResult GetBatches(string fromDate, string toDate)
        {
            return Json(managerObj.GetBatches(fromDate, toDate), JsonRequestBehavior.AllowGet);
        }

        public JsonResult GetPracticeName(string fromDate, string toDate)
        {
            return Json(managerObj.GetPracticeName(fromDate, toDate), JsonRequestBehavior.AllowGet);
        }
        public JsonResult GetCodingStatus()
        {
            return Json(managerObj.GetCodingStatus(), JsonRequestBehavior.AllowGet);
        }

        public JsonResult GetCoderNames()
        {
            return Json(managerObj.GetCoderNames(),JsonRequestBehavior.AllowGet);
        }
        public JsonResult GetStatusForQC()
        {
            return Json(managerObj.GetStatusForQC(), JsonRequestBehavior.AllowGet);
        }
        public JsonResult GetBatchName1(string Facility)
        {
            return Json(managerObj.GetBatchName1(Facility), JsonRequestBehavior.AllowGet);
        }

        public JsonResult GetEncounterType()
        {
            return Json(managerObj.GetEncounterType(), JsonRequestBehavior.AllowGet);
        }
        public JsonResult GetLocation()
        {
            return Json(managerObj.GetLocation(), JsonRequestBehavior.AllowGet);
        }


        public JsonResult AuditCategoryList()
        {
            return Json(managerObj.AuditCategoryList(), JsonRequestBehavior.AllowGet);
        }

        public ActionResult ProductionReport()
        {
            //ReportsViewModel model = new ReportsViewModel();
            ReportViewer reportViewer = new ReportViewer();
            reportViewer.ProcessingMode = ProcessingMode.Remote;
            reportViewer.SizeToReportContent = true;
            reportViewer.ShowParameterPrompts = false;
            reportViewer.ServerReport.ReportPath =Constants.ProductionReport;
            reportViewer.ServerReport.ReportServerUrl = new Uri(Constants.ReportIpAddress);

            ViewBag.ReportViewer = reportViewer;
            return View();
        }
        [HttpPost]
        public ActionResult ProductionReport(ReportsViewModel model)
        {
            ReportsViewModel newModel = new ReportsViewModel();

            newModel = managerObj.GetReportDetails("Coding_Production_Report");
            ReportViewer reportViewer = new ReportViewer();
            reportViewer.ProcessingMode = ProcessingMode.Remote;
            reportViewer.SizeToReportContent = true;
            reportViewer.ShowParameterPrompts = false;
            reportViewer.ServerReport.ReportPath = Constants.ProductionReport;
            reportViewer.ServerReport.ReportServerUrl = new Uri(Constants.ReportIpAddress);


            List<ReportParameter> reportParameter = new List<ReportParameter>();

            reportParameter.Add(new ReportParameter("Userntlg", newModel.UserName));
            reportParameter.Add(new ReportParameter("project_id", newModel.ProjectId));
            reportParameter.Add(new ReportParameter("task_id", newModel.TaskId));

            //reportParameter.Add(new ReportParameter("fromdate", model.FromDate == null ? "null" : Convert.ToDateTime(model.FromDate).ToString("yyyy-MM-dd", CultureInfo.InvariantCulture)));
            //reportParameter.Add(new ReportParameter("todate", model.ToDate == null ? "null" : Convert.ToDateTime(model.ToDate).ToString("yyyy-MM-dd", CultureInfo.InvariantCulture)));
            reportParameter.Add(new ReportParameter("fromdate", model.FromDate == null ? null : model.FromDate));
            reportParameter.Add(new ReportParameter("todate", model.ToDate == null ? null : model.ToDate));

            if (model.BatchName == "0")
            {
                model.BatchName = null;
            }
            if (model.EncounterType == "0")
            {
                model.EncounterType = null;
            }
            if (model.CodingStatus == "0")
            {
                model.CodingStatus = null;
            }
            if (model.Location == "0")
            {
                model.Location = null;
            }

            reportParameter.Add(new ReportParameter("batchname", model.BatchName == null ? null : CryptoGraphy.Encrypt(model.BatchName)));
            reportParameter.Add(new ReportParameter("encountertype", model.EncounterType == null ? null : model.EncounterType));

            //if (model.Facility == "0")
            //{
            //    model.Facility = null;
            //}

            //reportParameter.Add(new ReportParameter("facility", model.Facility == null ? null : model.Facility));
            //if (model.CodingStatus == "0")
            //{
            //    model.CodingStatus = null;
            //}

            reportParameter.Add(new ReportParameter("Status", model.CodingStatus == null ? null : model.CodingStatus));
           
            reportParameter.Add(new ReportParameter("Location", model.Location == null ? null : model.Location));
            reportParameter.Add(new ReportParameter("PracticeId", newModel.PracticeID));
           
            reportViewer.ServerReport.SetParameters(reportParameter);
            reportViewer.ServerReport.Refresh();
            ViewBag.ReportViewer = reportViewer;
            return PartialView("_ReportViewer");
        }
       
        public ActionResult QCProductionReport()
        {
          //  ReportsViewModel model = new ReportsViewModel();
            ReportViewer reportViewer = new ReportViewer();
            reportViewer.ProcessingMode = ProcessingMode.Remote;
            reportViewer.SizeToReportContent = true;
            reportViewer.ShowParameterPrompts = false;
            reportViewer.ServerReport.ReportPath = Constants.QCProductionReport;
            reportViewer.ServerReport.ReportServerUrl = new Uri(Constants.ReportIpAddress);

            ViewBag.ReportViewer = reportViewer;
            return View();
        }
        [HttpPost]
        public ActionResult QCProductionReport(ReportsViewModel model)
        {
            ReportsViewModel newModel = new ReportsViewModel();
            newModel = managerObj.GetReportDetails("QC_Production_Report");
            ReportViewer reportViewer = new ReportViewer();
            reportViewer.ProcessingMode = ProcessingMode.Remote;
            reportViewer.SizeToReportContent = true;
            reportViewer.ShowParameterPrompts = false;
            reportViewer.ServerReport.ReportPath = Constants.QCProductionReport;
            reportViewer.ServerReport.ReportServerUrl = new Uri(Constants.ReportIpAddress);
            List<ReportParameter> reportParameter = new List<ReportParameter>();


            
             reportParameter.Add(new ReportParameter("Userntlg", newModel.UserName));
            reportParameter.Add(new ReportParameter("project_id", newModel.ProjectId));
            reportParameter.Add(new ReportParameter("task_id", newModel.TaskId));
          //  reportParameter.Add(new ReportParameter("codername", model.CoderNames == null ? null : model.CoderNames));
          //  reportParameter.Add(new ReportParameter("fromdate", Convert.ToDateTime(model.FromDate).ToString("yyyy-MM-dd", CultureInfo.InvariantCulture)));
           // reportParameter.Add(new ReportParameter("todate", Convert.ToDateTime(model.ToDate).ToString("yyyy-MM-dd", CultureInfo.InvariantCulture)));
            reportParameter.Add(new ReportParameter("fromdate", model.FromDate == null ? null : model.FromDate));
            reportParameter.Add(new ReportParameter("todate", model.ToDate == null ? null : model.ToDate));

           
            if (model.BatchName == "0")
            {
                model.BatchName = null;
            }
            if (model.CodingStatusQC == "0")
            {
                model.CodingStatusQC = null;
            }
            if (model.Location == "0")
            {
                model.Location = null;
            }

            reportParameter.Add(new ReportParameter("batchname", model.BatchName == null ? null : CryptoGraphy.Encrypt(model.BatchName)));
            reportParameter.Add(new ReportParameter("Status", model.CodingStatusQC == null ? null : model.CodingStatusQC));
          
            reportParameter.Add(new ReportParameter("Location", model.Location == null ? null : model.Location));
            reportParameter.Add(new ReportParameter("PracticeId", newModel.PracticeID));
        
            reportViewer.ServerReport.SetParameters(reportParameter);
            reportViewer.ServerReport.Refresh();
            ViewBag.ReportViewer = reportViewer;
            return PartialView("_ReportViewer");
        }

        public ActionResult ReleasedReport()
        {
            //ReportsViewModel model = new ReportsViewModel();
            ReportViewer reportViewer = new ReportViewer();
            reportViewer.ProcessingMode = ProcessingMode.Remote;
            reportViewer.SizeToReportContent = true;
            reportViewer.ShowParameterPrompts = false;
            reportViewer.ServerReport.ReportPath = Constants.ReleasedReport;
            reportViewer.ServerReport.ReportServerUrl = new Uri(Constants.ReportIpAddress);

            ViewBag.ReportViewer = reportViewer;
            return View();
        }
        [HttpPost]
        public ActionResult ReleasedReport(ReportsViewModel model)
        {
            ReportsViewModel newModel = new ReportsViewModel();
            newModel = managerObj.GetReportDetails("Released_Report");
            ReportViewer reportViewer = new ReportViewer();
            reportViewer.ProcessingMode = ProcessingMode.Remote;
            reportViewer.SizeToReportContent = true;
            reportViewer.ShowParameterPrompts = false;
            reportViewer.ServerReport.ReportPath = Constants.ReleasedReport;
            reportViewer.ServerReport.ReportServerUrl = new Uri(Constants.ReportIpAddress);
            List<ReportParameter> reportParameter = new List<ReportParameter>();

            if (model.BatchName == "0")
            {
                model.BatchName = null;
            }
            if (model.EncounterType == "0")
            {
                model.EncounterType = null;
            }
            if (model.Location == "0")
            {
                model.Location = null;
            }
            if (model.Facility == "0")
            {
                model.Facility = null;
            }
            if (model.PracticeName == "0")
            {
                model.PracticeName = null;
            }

            reportParameter.Add(new ReportParameter("projectid", newModel.ProjectId));
            //reportParameter.Add(new ReportParameter("taskid", newModel.TaskId));
            //reportParameter.Add(new ReportParameter("fromdate", model.FromDate == null ? null : Convert.ToDateTime(model.FromDate).ToString("MM/dd/yyyy", CultureInfo.InvariantCulture)));
            //reportParameter.Add(new ReportParameter("todate", model.ToDate == null ? null : Convert.ToDateTime(model.ToDate).ToString("MM/dd/yyyy", CultureInfo.InvariantCulture)));
            string nullValue = null;
            DateTime from = Convert.ToDateTime(model.FromDate);
            DateTime to = Convert.ToDateTime(model.ToDate);
            reportParameter.Add(new ReportParameter("fromdate", model.FromDate == null ? nullValue : from.ToString("yyyy-MM-dd", CultureInfo.InvariantCulture)));
            reportParameter.Add(new ReportParameter("todate", model.ToDate == null ? nullValue : to.ToString("yyyy-MM-dd", CultureInfo.InvariantCulture)));
            reportParameter.Add(new ReportParameter("batchname", model.BatchName == null ? nullValue : model.BatchName.Trim()));
            reportParameter.Add(new ReportParameter("PracticeName", model.PracticeName == null ? nullValue : model.PracticeName.Trim()));
           // reportParameter.Add(new ReportParameter("encountertype", model.EncounterType == null ? nullValue : model.EncounterType));
            reportParameter.Add(new ReportParameter("facility", model.Facility == null ? nullValue : model.Facility.Trim()));
            reportParameter.Add(new ReportParameter("location", model.Location == null ? nullValue : model.Location.Trim()));
           // reportParameter.Add(new ReportParameter("CodedDate", model.CodedDate == null ? null : model.CodedDate));
            reportParameter.Add(new ReportParameter("PracticeId", newModel.PracticeID));
            reportViewer.ServerReport.SetParameters(reportParameter);
            reportViewer.ServerReport.Refresh();
            ViewBag.ReportViewer = reportViewer;
            return PartialView("_ReportViewer");
        }


        //////////////////////////


        public ActionResult AccurcyReport()
        {
            //ReportsViewModel model = new ReportsViewModel();
            ReportViewer reportViewer = new ReportViewer();
            reportViewer.ProcessingMode = ProcessingMode.Remote;
            reportViewer.SizeToReportContent = true;
            reportViewer.ShowParameterPrompts = false;
            reportViewer.ServerReport.ReportPath = Constants.AccurcyReport;
            reportViewer.ServerReport.ReportServerUrl = new Uri(Constants.ReportIpAddress);

            ViewBag.ReportViewer = reportViewer;
            return View();
        }

        [HttpPost]
        public ActionResult AccurcyReport(ReportsViewModel model)
        { 
            ReportViewer reportViewer = new ReportViewer();
            ReportsViewModel newModel = new ReportsViewModel();
            newModel = managerObj.GetReportDetails("sp_Get_Data_AccuracyReport");
            reportViewer.ProcessingMode = ProcessingMode.Remote;
            reportViewer.SizeToReportContent = true;
            reportViewer.ShowParameterPrompts = false;
            reportViewer.ServerReport.ReportPath = Constants.AccurcyReportPerimeter;
            reportViewer.ServerReport.ReportServerUrl = new Uri(Constants.ReportIpAddress);
            List<ReportParameter> reportParameter = new List<ReportParameter>();

            reportParameter.Add(new ReportParameter("fromdate", Convert.ToDateTime(model.FromDate).ToString("yyyy-MM-dd")));
            reportParameter.Add(new ReportParameter("todate", Convert.ToDateTime(model.ToDate).ToString("yyyy-MM-dd")));
            reportParameter.Add(new ReportParameter("project_id", newModel.ProjectId));
            reportParameter.Add(new ReportParameter("practice_id", newModel.PracticeID));
            //reportParameter.Add(new ReportParameter("Userntlg", model.CoderNames));
            reportParameter.Add(new ReportParameter("Userntlg", newModel.UserName));
           
            reportViewer.ServerReport.SetParameters(reportParameter);
            reportViewer.ServerReport.Refresh();
            ViewBag.ReportViewer = reportViewer;
            return PartialView("_ReportViewer");
        }


        //////////////////////////


        public ActionResult AccurcyReportHighMark()
        {
            //ReportsViewModel model = new ReportsViewModel();
            ReportViewer reportViewer = new ReportViewer();
            reportViewer.ProcessingMode = ProcessingMode.Remote;
            reportViewer.SizeToReportContent = true;
            reportViewer.ShowParameterPrompts = false;
            reportViewer.ServerReport.ReportPath = Constants.AccurcyReport;
            reportViewer.ServerReport.ReportServerUrl = new Uri(Constants.ReportIpAddress);

            ViewBag.ReportViewer = reportViewer;
            return View();
        }

        [HttpPost]
        public ActionResult AccurcyReportHighMark(ReportsViewModel model)
        {
            ReportViewer reportViewer = new ReportViewer();
            ReportsViewModel newModel = new ReportsViewModel();
            newModel = managerObj.GetReportDetails("sp_Get_Data_AccuracyReportHighMark");

            reportViewer.ProcessingMode = ProcessingMode.Remote;
            reportViewer.SizeToReportContent = true;
            reportViewer.ShowParameterPrompts = false;
            reportViewer.ServerReport.ReportPath = Constants.AccurcyReport;
            reportViewer.ServerReport.ReportServerUrl = new Uri(Constants.ReportIpAddress);
            List<ReportParameter> reportParameter = new List<ReportParameter>();

            reportParameter.Add(new ReportParameter("Userntlg", newModel.UserName));
            reportParameter.Add(new ReportParameter("project_id", newModel.ProjectId));
            reportParameter.Add(new ReportParameter("practice_id", newModel.PracticeID));
            reportParameter.Add(new ReportParameter("task_id", newModel.PracticeID));
            reportParameter.Add(new ReportParameter("fromdate", model.FromDate == null ? null : model.FromDate));
            reportParameter.Add(new ReportParameter("todate", model.ToDate == null ? null : model.ToDate));
           // reportParameter.Add(new ReportParameter("fromdate", Convert.ToDateTime(model.FromDate).ToString("yyyy-MM-dd")));
           // reportParameter.Add(new ReportParameter("todate", Convert.ToDateTime(model.ToDate).ToString("yyyy-MM-dd")));
            //reportParameter.Add(new ReportParameter("ProjectId", newModel.ProjectId));

           // reportParameter.Add(new ReportParameter("Userntlg", model.CoderNames));

            //if (model.CoderNames == "0")
            //{
            //    string value = null;
            //    reportParameter.Add(new ReportParameter("Userntlg", value));
            //}
            //else
            //{
            //    reportParameter.Add(new ReportParameter("Userntlg", model.CoderNames));
            //}


            //if (model.AuditCategory == "0")
            //{
            //    string value = null;
            //    reportParameter.Add(new ReportParameter("AuditCategory", value));
            //}
            //else
            //{
            //    reportParameter.Add(new ReportParameter("AuditCategory", model.AuditCategory));
            //}

            if (model.Location == "0")
            {
                string Value = null;
                reportParameter.Add(new ReportParameter("Location", Value));

            }
            else
            {
                reportParameter.Add(new ReportParameter("Location", model.Location));
            }
            reportViewer.ServerReport.SetParameters(reportParameter);
            reportViewer.ServerReport.Refresh();
            ViewBag.ReportViewer = reportViewer;
          //  return View();
            return PartialView("_ReportViewer");
        }

        public ActionResult PeriProductionReport()
        {
            return View();
        }

        public ActionResult PeriCoderProductionReport()
        {
            return View();
        }

        public ActionResult GetReportDetails(string fromDos, string toDos, string batchName, string facility, string status)
        {
            return PartialView("_PeriReport", managerObj.GetProductionReportDetails(fromDos, toDos, batchName, facility, status));
        }
        public ActionResult GetReportDetails1(string fromDos, string toDos, string batchName, string facility, string status)
        {
            return PartialView("_RptBatchDetails", Session["SecondTabale"] as ReportsViewModel);
        }

        public ActionResult GetBatchCount()
        {
            return PartialView("_RptBatchCount", Session["ThirdTabale"] as ReportsViewModel);
        }

        public JsonResult GetStatus()
        {
            return Json(managerObj.GetStatus(), JsonRequestBehavior.AllowGet);
        }

        public JsonResult ProductionReportExport()
        {
            managerObj.GetProductionReport();
            return Json("", JsonRequestBehavior.AllowGet);
        }

        public ActionResult HighMarkProductionReport()
        {
            //ReportsViewModel model = new ReportsViewModel();
            ReportViewer reportViewer = new ReportViewer();
            reportViewer.ProcessingMode = ProcessingMode.Remote;
            reportViewer.SizeToReportContent = true;
            reportViewer.ShowParameterPrompts = false;
            reportViewer.ServerReport.ReportPath = Constants.HighMarkReleasedReport;
            reportViewer.ServerReport.ReportServerUrl = new Uri(Constants.ReportIpAddress);
            ViewBag.ReportViewer = reportViewer;
            return View();
        }
        [HttpPost]
        public ActionResult HighMarkReleasedReport(ReportsViewModel model)
        {
            ReportsViewModel newModel = new ReportsViewModel();
            newModel = managerObj.GetReportDetails("usp_HighMark_ProductionReport");
            ReportViewer reportViewer = new ReportViewer();
            reportViewer.ProcessingMode = ProcessingMode.Remote;
            reportViewer.SizeToReportContent = true;
            reportViewer.ShowParameterPrompts = false;
            reportViewer.ServerReport.ReportPath = Constants.HighMarkReleasedReport;
            reportViewer.ServerReport.ReportServerUrl = new Uri(Constants.ReportIpAddress);
            List<ReportParameter> reportParameter = new List<ReportParameter>();
            if (model.Location == "0")
            {
                model.Location = null;
            }
            string nullValue = null;    
             DateTime from = Convert.ToDateTime(model.FromDate);
             DateTime to = Convert.ToDateTime(model.ToDate);
           reportParameter.Add(new ReportParameter("Fromdate", model.FromDate == null ? nullValue : from.ToString("MM/dd/yyyy", CultureInfo.InvariantCulture)));
           reportParameter.Add(new ReportParameter("Todate", model.ToDate == null ? nullValue : to.ToString("MM/dd/yyyy", CultureInfo.InvariantCulture)));
         //  reportParameter.Add(new ReportParameter("Fromdate", model.FromDate == null ? null : model.FromDate));
         //  reportParameter.Add(new ReportParameter("Todate", model.ToDate == null ? null : model.ToDate));
            reportParameter.Add(new ReportParameter("Location", model.Location == null ? nullValue : model.Location.Trim()));
            reportParameter.Add(new ReportParameter("PracticeId", newModel.PracticeID));
            reportViewer.ServerReport.SetParameters(reportParameter);
            reportViewer.ServerReport.Refresh();
            ViewBag.ReportViewer = reportViewer;
            return PartialView("_ReportViewer");
        }

        public ActionResult HighMarkAccountTrackerReport()
        {
            ReportViewer reportViewer = new ReportViewer();
            reportViewer.ProcessingMode = ProcessingMode.Remote;
            reportViewer.SizeToReportContent = true;
            reportViewer.ShowParameterPrompts = false;
            reportViewer.ServerReport.ReportPath = Constants.HighMarkAccountTrackerReport;
            reportViewer.ServerReport.ReportServerUrl = new Uri(Constants.ReportIpAddress);
            ViewBag.ReportViewer = reportViewer;
            return View();
        }
        [HttpPost]
        public ActionResult HighMarkAccountTrackerReport(ReportsViewModel model)
        {
            ReportsViewModel newModel = new ReportsViewModel();
            newModel = managerObj.GetReportDetails("USP_Get_Account_Details");
            ReportViewer reportViewer = new ReportViewer();
            reportViewer.ProcessingMode = ProcessingMode.Remote;
            reportViewer.SizeToReportContent = true;
            reportViewer.ShowParameterPrompts = false;
            reportViewer.ServerReport.ReportPath = Constants.HighMarkAccountTrackerReport;
            reportViewer.ServerReport.ReportServerUrl = new Uri(Constants.ReportIpAddress);
            List<ReportParameter> reportParameter = new List<ReportParameter>();
            if (model.BatchName == "0")
            {
                model.BatchName = "";
            }
            else
            {
                model.BatchName = CryptoGraphy.Encrypt(model.BatchName);
            }
            if (model.Location == "0")
            {
                model.Location = "";
            }
            string emptyValue = ""; 
            DateTime from = Convert.ToDateTime(model.FromDate);
            DateTime to = Convert.ToDateTime(model.ToDate);
            reportParameter.Add(new ReportParameter("ProjectID", newModel.ProjectId));
            reportParameter.Add(new ReportParameter("PracticeID", newModel.PracticeID));
            reportParameter.Add(new ReportParameter("FromDate", model.FromDate == null ? emptyValue : from.ToString("MM/dd/yyyy", CultureInfo.InvariantCulture)));
            reportParameter.Add(new ReportParameter("ToDate", model.ToDate == null ? emptyValue : to.ToString("MM/dd/yyyy", CultureInfo.InvariantCulture)));
            reportParameter.Add(new ReportParameter("BatchName", model.BatchName == "" ? "" : model.BatchName.Trim()));
            reportParameter.Add(new ReportParameter("Location", model.Location == "" ? "" : model.Location.Trim()));
            reportParameter.Add(new ReportParameter("Type", model.Type));
            
            reportViewer.ServerReport.SetParameters(reportParameter);
            reportViewer.ServerReport.Refresh();
            ViewBag.ReportViewer = reportViewer;
            return PartialView("_ReportViewer");
        }
    }
}