﻿using CBIplus.BAL.Managers;
using CBIplus.BAL.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace CBIplus.Controllers
{
    public class PerimeterQCTransactionController : Controller
    {
         IPerimeterQCService managerObj=new PerimeterQCManager();
       
        // GET: /QCPerimeter/
         public ActionResult QcPerimeterTransaction()
         {
             PerimeterQCTransactionModel model = new PerimeterQCTransactionModel();
             model.CoderList = managerObj.getCoderNames("Coder-TL", "Coder").OrderBy(x => x.Text).ToList();
             model.ErrorList = managerObj.GetErrorDataDetails();
             model.ErrorParameterList = managerObj.GetErrorParameter();  
             return View(model);
         }

        public ActionResult LoadQcInboxGrid(string selecetedText)
        {
            return PartialView("_QCPrimeterInbox", managerObj.GetCodedData(selecetedText));
        }

        public ActionResult LoadQcAddCPT(int transId, int tranDetaisId, string status)
        {
            PerimeterQCTransactionModel model = new PerimeterQCTransactionModel();
            model = managerObj.All(tranDetaisId, transId);
            model.TRANS_ID = transId;
            model.PopUpStatus = status;
            model.TRANS_DETAIL_ID = tranDetaisId;           
            return PartialView("_QCPerimeterAddCPT", model);
        }

        public ActionResult ViewCPTGrid(int transId, string accountNumber)
        {
            return PartialView("_QCPerimeterCPTGrid", managerObj.GetPerimeterCPTGridData(transId, accountNumber));
        }

        public ActionResult MarkError(List<MedDataQcTransactionModel> errorModel, string listofErrors)
        {
            managerObj.UpdateErrorList(errorModel, listofErrors);
            return Json("",JsonRequestBehavior.AllowGet);
        }

        public JsonResult ChangeSelectedCPT(string CPT)
        {
            return Json(managerObj.GetSelectedCPT(CPT), JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public ActionResult QCAddNewCPT(PerimeterQCTransactionModel model)
        { 
            managerObj.PerimeterQCAddNewCPT(model);
            return Json(model.PopUpStatus + "*" + model.TRANS_ID, JsonRequestBehavior.AllowGet);
        }

        public JsonResult GetErrorSubCategory(string errorType)
        {
            return Json(managerObj.GetErrorSubCategory(errorType), JsonRequestBehavior.AllowGet);
        }
        /************************SUBHAJA******************new fileds aaded**************/
        public JsonResult GetErrorSubParameter(string errorType)
        {
            return Json(managerObj.GetErrorSubParameter(errorType), JsonRequestBehavior.AllowGet);
        }
        public JsonResult GetErrorMicroCategory(string errorType)
        {
            return Json(managerObj.GetErrorMicroCategory(errorType), JsonRequestBehavior.AllowGet);
        }
        /************************SUBHAJA******************new fileds aaded**************/


        public ActionResult LoadPDF(string accNumber)
        {
            return Json(managerObj.LoadPDF(accNumber), JsonRequestBehavior.AllowGet);
        }
	}
}