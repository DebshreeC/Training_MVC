﻿using CBIplus.BAL.Managers;
using CBIplus.BAL.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace CBIplus.Controllers
{
    public class HighMarkCoderTransactionController : Controller
    {
        //
        // GET: /HighMarkCoderTransaction/

         IHighMarkCoderTransactionService managerObj =new HighMarkCoderTransactionManager();
        
        public ActionResult HighMarkCoderTransaction()   
        {
            return View(managerObj.HighMarkCoderTransaction());
        }
        [HttpPost]
        public ActionResult HighMarkCoderTransaction(HighMarkCoderTransactionModel model, string eodList, string screenName)
        {
            managerObj.SaveHighMarkCoderTransaction(model, eodList, screenName);
            return Json("Success",JsonRequestBehavior.AllowGet);
        }
        public ActionResult CoderInboxGrid(string selecetedText)
        {
            List<HighMarkCoderTransactionModel> model = new List<HighMarkCoderTransactionModel>();
            model = managerObj.HighMarkCoderInbox(selecetedText);
            if (model.Count > 0)
            {
                model[0].EncounterTypeList = managerObj.GetEncounterType();
                if (!string.IsNullOrEmpty(selecetedText))
                {
                    model[0].EncounterType = selecetedText.Split('*')[0];
                }
            }
            else
            {
                HighMarkCoderTransactionModel newModel = new HighMarkCoderTransactionModel();
                newModel.EncounterTypeList = managerObj.GetEncounterType();
                if (!string.IsNullOrEmpty(selecetedText))
                {
                    newModel.EncounterType = selecetedText.Split('*')[0];
                }
                model.Add(newModel);
            }
          
            return PartialView("_HMCoderGridPartial", model);
 
        }


        public ActionResult LoadEncounter()
        { 
            HighMarkCoderTransactionModel objModel = new HighMarkCoderTransactionModel();
            objModel.EncounterTypeList = managerObj.GetEncounterType();
            return View(objModel);
        }
        public ActionResult LoadDXGrid(int batchId)
        {
            return PartialView("_DxGrid", managerObj.LoadDXGrid(batchId));
        }
        public ActionResult LoadTrackingGrid()
        {
            return PartialView("_TrackingGrid", managerObj.GetTrackingGridData());
        }

        public ActionResult SaveFinalStatus(int batchId, string status, string coderComment, string Gender, int totalPages)
        {
            managerObj.SaveFinalStatus(batchId, status, coderComment, Gender, totalPages);
            return Json("",JsonRequestBehavior.AllowGet);
        }
        public JsonResult DeleteDXRow(int tdId, string screenName)
        {
            managerObj.DeleteDXRow(tdId, screenName);
            return Json("Success",JsonRequestBehavior.AllowGet);
        }
        public ActionResult UpdateTracking(HighMarkCoderTransactionModel model)
        {
            return PartialView("_UpdateTrackingData",model);
        }
        [HttpPost]
        public JsonResult UpdateTrackingGridData(HighMarkCoderTransactionModel model)
        {
            managerObj.UpdateTrackingGridData(model);
            return Json("",JsonRequestBehavior.AllowGet);
        }

        public ActionResult CheckDXCode(string dxvalue, string dxTp, string memberDOB, string endingDOS)
        {
            return Json(managerObj.CheckDXCode(dxvalue, dxTp, memberDOB, endingDOS), JsonRequestBehavior.AllowGet);
        }

        public ActionResult CheckDuplicateRecords(string Beginning_DOS, string Ending_DOS, string Dx_Type, string DXCode, string PageNo, int Batch_Id)
        {
            return Json(managerObj.CheckDuplicateRecords(Beginning_DOS, Ending_DOS, Dx_Type, DXCode, PageNo, Batch_Id), JsonRequestBehavior.AllowGet);
        }

        public ActionResult CheckErrorAccounts()
        {
            return Json(managerObj.CheckErrorAccounts(), JsonRequestBehavior.AllowGet); 
        }

        public ActionResult ICDCodeValidation(string dxCode, string EndingDOS, int batchId, string buttonName, int transDetailsID)
        {
            return Json(managerObj.ICDCodeValidation(dxCode, EndingDOS, batchId, buttonName, transDetailsID), JsonRequestBehavior.AllowGet); 
        }
	}
}