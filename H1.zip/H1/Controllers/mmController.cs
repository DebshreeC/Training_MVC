﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace CBIplus.Controllers
{
    public class mmController : Controller
    {
        //
        // GET: /mm/
        public ActionResult Index()
        {
            return View();
        }
	}
}