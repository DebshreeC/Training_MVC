﻿using CBIplus.BAL.Managers;
using CBIplus.BAL.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace CBIplus.Controllers
{
    public class QCClarificationController : Controller
    {

        IHighMarkCoderTransactionService managerObj=new HighMarkCoderTransactionManager();

        public ActionResult QCClarification()
        {
            return View();
        }

        public ActionResult QCClarificationGrid()
        {
            //return PartialView("_QCClarificationGrid", managerObj.QCClarificationGrid());
            return PartialView("_QCClarificationAccountList", managerObj.QCClarificationAccounts());
        }
        public JsonResult SaveQcClarification(List<QCClarificationModel> model)
        {
            managerObj.SaveQcClarification(model);
            return Json("",JsonRequestBehavior.AllowGet);
        }
        public JsonResult SaveQcAcknowledge(List<QCClarificationModel> model)
        {
            managerObj.SaveQcAcknowledge(model);
            return Json("", JsonRequestBehavior.AllowGet);
        }

        public ActionResult HighMarkQCClarification(string transId, string AccNo, string FName, string Lname, string MemberDOB, string MemberGender, string EncounterType, string CodedBy, string PDFpath)
        {
            @ViewBag.trackingId = transId;
            return View("QCClarificationTransaction", managerObj.QCClarificationTransaction(transId, AccNo, FName, Lname, MemberDOB, MemberGender, EncounterType, CodedBy,PDFpath));
        }

        public ActionResult LoadQCClarificationAccDetails(int trackingId)
        {
            return PartialView("_ClarificationDxGrid", managerObj.ClarificationDXGrid(trackingId));
        }

        public ActionResult SaveQCClarificationDetails(string transId)
        {
            managerObj.SaveQCClarificationDetails(transId);
            return Json("Success", JsonRequestBehavior.AllowGet);
        }

        public ActionResult AddDXCode(int transId)
        {
            return PartialView("_AddClarificationDXCode", managerObj.GetOldComment(transId));
        }
	}
}