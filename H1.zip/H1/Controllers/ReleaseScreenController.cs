﻿using CBIplus.BAL.Managers;
using CBIplus.BAL.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace CBIplus.Controllers
{
    public class ReleaseScreenController : Controller
    {
        //
        // GET: /ReleaseScreen/
        IMedDataAllotmentManager managerObj=new MedDataAllotmentManager();
        IReportManager managerObjRpt = new ReportManager();   

        public ActionResult ReleaseScreen()
        {
            return View();
        }
        public ActionResult ReleaseGrid(string fromDate, string toDate, int Auditstatus)
        {
            if (Auditstatus==1)
            {
                return PartialView("_ReleaseGrid", managerObj.ReleaseScreenData(fromDate, toDate, Auditstatus));
            }
            else
            {
                return PartialView("_SkipGrid", managerObj.ReleaseScreenData(fromDate, toDate, Auditstatus));
            }            
        }
        public ActionResult ReleaseGridWithBatchName(string fromDate, string toDate,string batchName, int Auditstatus)
        {
             if (Auditstatus==1)
            {
                return PartialView("_ReleaseGrid", managerObj.ReleaseGridWithBatchName(fromDate, toDate, batchName, Auditstatus));
            }
            else
            {
                return PartialView("_SkipGrid", managerObj.ReleaseGridWithBatchName(fromDate, toDate, batchName, Auditstatus));
            }            
        }
        public JsonResult ReleaseAccounts(List<ReleaseAccountModel> model)
        {
            managerObj.ReleaseAccounts(model);
            return Json("",JsonRequestBehavior.AllowGet);
        }
        public JsonResult GetBatchNames(string fromDate, string toDate)
        {
            return Json(managerObjRpt.GetBatchNames(fromDate, toDate), JsonRequestBehavior.AllowGet);
        }
        public ActionResult ChangeAccess()
        {
            AllotmentModel model = new AllotmentModel();
            model = managerObj.All();
            return PartialView("_ChangeAccess",model);
        }

        public ActionResult GetTLList(string Location)
        {
            return Json(managerObj.getTLNames(Location).ToList(), JsonRequestBehavior.AllowGet);
        }

        public JsonResult GetCoderforSelectedTL(string tl, string location,string access_type)
        {
            return Json(managerObj.GetCoderforSelectedTL(tl, location,access_type), JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public JsonResult ChangeCoderAccess(string NoofCoder, string location, string access_type)
        {
            managerObj.ChangeCoderAccess(NoofCoder,location,access_type);
            return Json("", JsonRequestBehavior.AllowGet);
        }

	}
}