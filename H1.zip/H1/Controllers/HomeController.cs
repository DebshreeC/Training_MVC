﻿using CBIplus.BAL.Generics;
using CBIplus.BAL.Managers;
using CBIplus.BAL.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.Mvc;
using System.Web.Security;

namespace CBIplus.Controllers
{
    public class HomeController : Controller
    {
        IUserMenuService managerObj =new UserMenuManager();
        UserMenuModel model = new UserMenuModel();

        public ActionResult Index()
        {
            return View();
        }

        public ActionResult About()
        { 
            ViewBag.Message = "Your application description page.";
            return View();
        }

        public ActionResult Contact()
        {
            ViewBag.Message = "Your contact page.";
            return View();
        }
        public ActionResult Home()
        {
            model = managerObj.GetClietList();
            model = managerObj.GetPractices();
            return View(model);
        }
       
        [HttpPost]
        public ActionResult LoadClientMenu(UserMenuModel model)
        {
            string PracStatus=managerObj.GetPractice(model);
            System.Web.HttpContext.Current.Session["PracID"] = model.SelectedPractice;
            if (PracStatus=="")
            {
                Session[Constants.UserName] = null;
                Session.Clear();
                Session.Abandon();
                FormsAuthentication.SignOut();
                return RedirectToAction("Home");
            }
            return RedirectToAction("Index", "Import", model);
        }
        #region SignOut

        /// <summary>
        ///     This function used to logout from application and kill all the sessions
        /// </summary>
        /// <returns></returns>
        public ActionResult SignOut()
        {
            Session[Constants.UserName] = null;
            Session.Clear();
            Session.Abandon();
            FormsAuthentication.SignOut();
            return RedirectToAction("Home");
        }

        #endregion
    }
}