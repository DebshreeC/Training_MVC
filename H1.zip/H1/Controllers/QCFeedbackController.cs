﻿using CBIplus.BAL.Managers;
using CBIplus.BAL.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace CBIplus.Controllers
{
    public class QCFeedbackController : Controller
    {

        IHighMarkCoderTransactionService managerObj=new HighMarkCoderTransactionManager();
      

        public ActionResult QCFeedBack()
        {
            return View(managerObj.QCFeedBack());
        }

        public ActionResult QCFeedBackGrid(string status)
        {
            ViewBag.ProjectId = Session["ProjectId"];
            return PartialView("_QCFeedBackGrid", managerObj.QCFeedBackGrid(status));
        }

        public ActionResult AddDXCode(int transId)
        {
            return PartialView("_AddDXCode", managerObj.GetOldComment(transId));
        }
        
        //[HttpPost]
        public ActionResult SaveComment(QCFeedBackModel model, string screenName)
        {
            return Json(managerObj.SaveComment(model,screenName), JsonRequestBehavior.AllowGet);
        }
        public ActionResult HighMarkCoderTransaction(string trackingId)
        {
            @ViewBag.trackingId = trackingId.Split('¥')[0].ToString();
            return View(managerObj.HighMarkCoderTransaction(trackingId.Split('¥')[1].ToString()));
        }

        public ActionResult LoadTrackingGridForTrackingId(string TrackingId)
        {
            string[] charSet = TrackingId.Split('¥');
            TrackingId = charSet[0].Replace(" ", "+");
            return PartialView("_TrackingGrid", managerObj.GetTrackingGridDataBytrackingID(TrackingId));
        }

        public ActionResult CheckDXCode(string dxvalue, string dxTp, string memberDOB,string endingDOS)
        {
            return Json(managerObj.CheckDXCode(dxvalue, dxTp, memberDOB,endingDOS), JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public ActionResult HighMarkCoderTransaction(HighMarkCoderTransactionModel model, string eodList, string screenName)
        {
          //  model.EDos = model.EndingDOS;
            managerObj.SaveHighMarkCoderTransaction(model, eodList, screenName);
            return Json("Success", JsonRequestBehavior.AllowGet);
        }

        public ActionResult LoadDXGrid(int batchId)
        {
            return PartialView("_DxGrid", managerObj.LoadDXGrid(batchId));
        }

        public ActionResult UpdateQCAck(string TID)
        {
            managerObj.UpdateQCAck(TID);
            return Json("", JsonRequestBehavior.AllowGet);
        }

        public ActionResult UpdateQCAckByICD(string TID, string screenName)
        {
            return Json(managerObj.UpdateQCAckByICD(TID, screenName), JsonRequestBehavior.AllowGet);
        }

        public JsonResult DeleteDXRow(int tdId, string screenName)
        {
            managerObj.DeleteDXRow(tdId, screenName);
            return Json("Success", JsonRequestBehavior.AllowGet);
        }

        public ActionResult GetErrorDetails(string transId)
        {
            return PartialView("_ErrorDetails", managerObj.GetErrorDetails(transId));
        }

        public ActionResult SaveQCFeedbackDetails(string transId)
        {
            return Json(managerObj.SaveQCFeedbackDetails(transId), JsonRequestBehavior.AllowGet);
        }
	}
}