﻿using CBIplus.BAL.Managers;
using CBIplus.BAL.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace CBIplus.Controllers
{
    public class TransactionController : Controller
    {
        //
        // GET: /Transaction/
         ITransactionService managerObj=new TransactionManager();
      

        public ActionResult CodingTransaction(string accountNumber=null)
        {
            ViewBag.AccountNum = accountNumber;
           return View(managerObj.All());
        }
        public ActionResult LoadCoderGrid()
        {
            List<CoderTransactionModel> model = new List<CoderTransactionModel>();
            model = managerObj.GetFacilityForTransaction();
            if (model.Count > 0)
            {
                model[0].FacilityList = managerObj.GetFacilityNames();
            }
            else
            {
                CoderTransactionModel newModel = new CoderTransactionModel();
                newModel.FacilityList = managerObj.GetFacilityNames();
                model.Add(newModel);
            }
            return PartialView("_CoderInboxGrid", model);
        }

        public JsonResult LoadAsaCross(string cptCode)
        {
          //  string description = managerObj.getAsaCross(cptCode);
            return Json(managerObj.getAsaCross(cptCode), JsonRequestBehavior.AllowGet);
        }

        public JsonResult SaveChartChanges(List<CoderTransactionModel> model, string status)
        {
            managerObj.InsertOrUpdateChartDetails(model, status);
            return Json("",JsonRequestBehavior.AllowGet);
        }

        public JsonResult SaveBatchStatus(List<CoderTransactionModel> model)
        {
            managerObj.SaveBatchStatus(model);
            return Json("", JsonRequestBehavior.AllowGet);
        }

        public ActionResult AccountDetailsGrid(string accountNumber)
        {
            return PartialView("_AccountDetails", managerObj.GetCodedData(accountNumber));
        }

        public ActionResult ViewAccountDetails(CoderTransactionModel model)
        {
            model.PhysicalStatus = managerObj.GetPhysacalStatus();
            return PartialView("_ViewAccount",model);
        }
        [HttpPost]
        public ActionResult UpdateAccountDetails(CoderTransactionModel model)
        {
            managerObj.UpdateAccountDetails(model);
            return Json("Success",JsonRequestBehavior.AllowGet);
        }
        public ActionResult AddCPT(int transId, int transDetailsId, string status)
        {
            CoderTransactionModel model = new CoderTransactionModel();
            model = managerObj.All(transDetailsId);
            model.TRANS_ID = transId;
            model.TRANS_DETAIL_ID = transDetailsId;
            model.PopupStatus = status;
            //model.AnesthesiaStartTimeList = managerObj.GetStartTimeDropdown();
            //model.AnesthesiaEndTimeList = managerObj.GetEndTimeDropdown();
            return PartialView("_AddCPT",model);
        }
        [HttpPost]
        public ActionResult AddNewCPT(CoderTransactionModel model,string asa)
        {
            model.AsaCross = asa;
            managerObj.AddNewCPT(model);
            return Json(model.PopupStatus+"*"+model.TRANS_ID, JsonRequestBehavior.AllowGet);
        }

        public ActionResult ViewCPTGrid(int transId, string accountNumber)
        {
            return PartialView("_ViewCPTGrid", managerObj.GetCPTGridData(transId, accountNumber));
        }
        public ActionResult DeleteCPT(int transDetailsId)
        {
            managerObj.DeleteCPT(transDetailsId);
            return Json(transDetailsId, JsonRequestBehavior.AllowGet);
        }
        [HttpPost]
        public JsonResult GetAutoProviderNames(string Prefix)
        {
            var list = managerObj.GetAutoProviderNames(Prefix);
            var CityName = (from N in list
                            where N.Name.StartsWith(Prefix)
                            select new { N.Name });
            return Json(CityName, JsonRequestBehavior.AllowGet);
        }
        public JsonResult CheckIcdCode(string enteredIcd)
        {
            return Json(managerObj.CheckIcd(enteredIcd),JsonRequestBehavior.AllowGet);
        }

	}
}