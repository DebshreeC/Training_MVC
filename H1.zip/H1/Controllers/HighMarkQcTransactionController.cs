﻿using CBIplus.BAL.Managers;
using CBIplus.BAL.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace CBIplus.Controllers
{
    public class HighMarkQcTransactionController : Controller
    {
         IHighMarkQCTransactionService objIHighMarkQCTransactionService=new HighMarkQCTransactionManager();

      
        public ActionResult Transaction()
        {
            return View(objIHighMarkQCTransactionService.HighMarkQCTransactionModel());
            //return View();
        }
        public ActionResult ReleaseToClient()
        {
            return View();
        }

        public ActionResult QCTrackingGridForACA()
        {
            return PartialView("_QCTrackingGrid", objIHighMarkQCTransactionService.GetTrackingGridDataRegularAuditForACA());
        }
        
        public ActionResult QCTrackingGrid()
        {
            return PartialView("_QCTrackingGrid",objIHighMarkQCTransactionService.GetTrackingGridDataRegularAudit());            
        }
        
        public ActionResult QCTrackingGridIncrementalHCC()
        {
            return PartialView("_QCTrackingGridIncrementalHCC", objIHighMarkQCTransactionService.GetTrackingGridDataIncrementalHCC());
        }
        
        public ActionResult QCTrackingGridBlindAudit()
        {
            return PartialView("_QCTrackingGridBlindAudit", objIHighMarkQCTransactionService.GetTrackingGridDataBlind());
        }

        public ActionResult UpdateQCTracking(string transId, string transDetailsId, string batchId, string firstName, string lastName, string memberDOB, string codedDate, string codedBy)
        {
            return PartialView("_QCUpdateTrackingData", objIHighMarkQCTransactionService.GetTrackingPopupData(Convert.ToInt32(transId), Convert.ToInt32(transDetailsId), Convert.ToInt32(batchId), firstName, lastName, memberDOB, codedDate, codedBy));
        }
 
        public JsonResult GetErrorSubCategory(string errorType)
        {
            return Json(objIHighMarkQCTransactionService.GetErrorSubCategory(errorType), JsonRequestBehavior.AllowGet);
        }

        public JsonResult GetErrorSubCategoryWeightage(string errorType, string SubCategory)
        {
            return Json(objIHighMarkQCTransactionService.GetErrorSubCategoryWeightage(errorType, SubCategory), JsonRequestBehavior.AllowGet);
        }

        public JsonResult FinalQcSubmit(string TabText, string selectedAccounts)
        {
            objIHighMarkQCTransactionService.FinalQcSubmit(selectedAccounts, TabText);
            return Json(string.Empty, JsonRequestBehavior.AllowGet);
        }

        public ActionResult LoadEncounter()
        {
            HighMarkQCTransactionModel objModel = new HighMarkQCTransactionModel();
            objModel.EncounterTypeList = objIHighMarkQCTransactionService.GetEncounterType();
            return View(objModel);
        }
        public ActionResult LoadQCDXGrid(int batchId)
        {
            return PartialView("_QCDxTrackingGrid", objIHighMarkQCTransactionService.LoadQCDXGrid(batchId));
        }
        
        public ActionResult SaveFinalStatus(int batchId, string status, string coderComment, string Gender)
        {
            objIHighMarkQCTransactionService.SaveFinalStatus(batchId, status, coderComment, Gender);
            return Json("", JsonRequestBehavior.AllowGet);
        }
        public JsonResult DeleteDXRow(int tdId)
        {
            objIHighMarkQCTransactionService.DeleteDXRow(tdId);
            return Json("Success", JsonRequestBehavior.AllowGet);
        }
      
        [HttpPost]
        public JsonResult UpdateTrackingGridData(HighMarkQCTransactionModel model)
        {
            objIHighMarkQCTransactionService.UpdateTrackingGridData(model);
            return Json("", JsonRequestBehavior.AllowGet);
        }       

        [HttpPost]
        public ActionResult HighMarkQCTransactionSubmit(HighMarkQCTransactionModel model, string eodList)
        {
            objIHighMarkQCTransactionService.SaveHighMarkQCTransaction(model, eodList);
            return Json("Success", JsonRequestBehavior.AllowGet);
        }

        public ActionResult CheckDXCode(string dxvalue, string dxTp, string memberDOB, string endingDOS)
        {
            return Json(objIHighMarkQCTransactionService.CheckDXCode(dxvalue, dxTp, memberDOB, endingDOS), JsonRequestBehavior.AllowGet);

        }
        public ActionResult MarkError(int transdetaisId)
        {
            return PartialView("_ErrorMark", objIHighMarkQCTransactionService.QcErrorMarking(transdetaisId));
        }
        public ActionResult ErrorGrid(int transDetailsId)
        {
          return PartialView("_ErrorGrid",objIHighMarkQCTransactionService.GetErrorGridData(transDetailsId));
        }
        [HttpPost]
        public JsonResult SaveMarkError(ErrorGridModel model, string arrayOfIds)
        {
            objIHighMarkQCTransactionService.SaveMarkErrorDetails(model, arrayOfIds);
            return Json("", JsonRequestBehavior.AllowGet);
        }
        public JsonResult DeleteMarkedError(string errorCat,string subCate,string comments,int trandetaislId)
        {
            objIHighMarkQCTransactionService.DeleteMarkedError(errorCat,subCate, comments, trandetaislId);
            return Json("", JsonRequestBehavior.AllowGet);
        }

        public ActionResult ICDCodeValidation(string dxCode, string endingDOS, int batchId, string buttonName, int transDetailsID)
        {
            return Json(objIHighMarkQCTransactionService.ICDCodeValidation(dxCode, endingDOS, batchId, buttonName, transDetailsID), JsonRequestBehavior.AllowGet);
        }

       
	}
}