﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.Mvc;
using System.ComponentModel.DataAnnotations;

namespace AT.BAL.ViewModel
{
   public class InsertProjectModel
    {
        
            public int Project_Unique_ID { get; set; }
            [Required]
            public string Client { get; set; }
            [Required]
            public string Project_Name { get; set; }
            [Required]
            public string Process { get; set; }
            [Required]
            public string Description { get; set; }
            [Required]
            public string Type { get; set; }
            public List<SelectListItem> TypeList { get; set; }
            [Required]
            public string Status { get; set; }
            public List<SelectListItem> StatusList { get; set; }
            [Required]
            public string Project_Status { get; set; }
            //public List<SelectListItem> Project_Status_List { get; set; }
            [Required]
            public string InProgress_Status { get; set; }
            public List<SelectListItem> InProgress_StatusList { get; set; }


            [Required]
            [DataType(DataType.Date)]
            [DisplayFormat(DataFormatString = "{0:mm/dd/yyyy}", ApplyFormatInEditMode = true)]
            public DateTime? Request_Received_Date { get; set; }
            // public DateTime? Request_Received_Date1 { get; set; }

            public string Request_ReceivedDate { get; set; }

            [Required]
            [DataType(DataType.Date)]
            public DateTime? Approved_Rejected_Date { get; set; }
            [Required]
            public string Location { get; set; }
            public List<SelectListItem> LocationList { get; set; }
            [Required]
            public string Vertical { get; set; }
            public List<SelectListItem> VerticalList { get; set; }
            [Required]
            public string Fully_Loaded_FTE_Cost_dollar { get; set; }
            [Required]
            public string Est_dollar_savings { get; set; }
            [Required]
            public string Est_Effort_Cost_dollar { get; set; }
            [Required]
            public string Manager { get; set; }
            [Required]
            public string SPOC { get; set; }
            [Required]
            public string Remarks { get; set; }
            [Required]
            public string EXT { get; set; }
            [Required]
            public string Priority { get; set; }
            public List<SelectListItem> PriorityList { get; set; }
            [Required]
            [DataType(DataType.Date)]
            public DateTime? Project_Start_Date { get; set; }
            [Required]
            [DataType(DataType.Date)]
            public DateTime? Planned_Completion_Date { get; set; }
            [Required]
            [DataType(DataType.Date)]
            public DateTime? Actual_Completion_Date { get; set; }
            [Required]
            public string Resources_Involved { get; set; }
            [Required]
            public string Hash_Resources_Required { get; set; }
            [Required]
            [DataType(DataType.Date)]
            public DateTime? UAT_Release_Date { get; set; }
            [Required]
            [DataType(DataType.Date)]
            public DateTime? LIVE_Release_Date { get; set; }
            [Required]
            public string UAT_Remarks { get; set; }
            [Required]
            public string LIVE_Remarks { get; set; }
            [Required]
            [DataType(DataType.Date)]
            public DateTime? Release_Date { get; set; }
            [Required]
            public string Release_Type { get; set; }
            [Required]
            [DataType(DataType.Date)]
            public DateTime? Benefit_Sign_off_Date { get; set; }
            [Required]
            public string Process_Re_engineering { get; set; }
            public List<SelectListItem> Process_Re_engineeringList { get; set; }
            [Required]
            public string Effort_Man_days { get; set; }
            [Required]
            public string No_FTEs_Involved { get; set; }
            [Required]
            public string Est_Prod_Impv_percent { get; set; }
            [Required]
            public string Act_Prod_Impv_percent { get; set; }
            [Required]
            public string Est_Quality_Impv_percent { get; set; }
            [Required]
            public string Act_Quality_Impv_percent { get; set; }
            [Required]
            public string Est_FTE_Saving { get; set; }
            [Required]
            public string Revised_Est_FTE_Saving { get; set; }
            [Required]
            public string Act_FTE_Saving { get; set; }
            [Required]
            public string Est_Hours_saved_FTE { get; set; }
            [Required]
            public string Act_Hours_saved_FTE { get; set; }
            [Required]
            public string Comments { get; set; }
            [Required]
            public string Application { get; set; }
            [Required]
            public string Enter_By { get; set; }

            public string Selectedvalue { get; set; }
            public List<SelectListItem> LoadStatusList { get; set; }

            [Required]
            public string Est_dollar_saving { get; set; }
            [Required]
            public string Act_dollar_saving { get; set; }

            [Required]
            public string Category { get; set; }
            public List<SelectListItem> CategoryList { get; set; }

            [Required]
            public string Est_Excel_saving { get; set; }
       
            public string strBuhname { get; set; }
            public List<SelectListItem> BuhnameList { get; set; }
            public List<SelectListItem> clientList { get; set; }
            public List<SelectListItem> ProcessList { get; set; }

            public string SDHname { get; set; }
            public List<SelectListItem> SDHList { get; set; }
            public List<SelectListItem> ManagerList { get; set; }
            public List<SelectListItem> SPOCList { get; set; }
             
    }
}
