﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AT.BAL.ViewModel
{
    public class EstDetails
    {
        public string strResourecename { get; set; }
        public string strEst_hours { get; set; }
        public string strEst_Prod { get; set; }
        public string strEst_Quality { get; set; }
        public string strEst_FTE { get; set; }
        public string strEst_Excel { get; set; }
        public string strEst_dollar { get; set; }
        public string Est_Saving_Desc { get; set; }
        public string Emp_name { get; set; }
        public string emp_id { get; set; }
    }

    public class ACTDetails
    {
       
        public string strACT_hours { get; set; }
        public string strACT_Prod { get; set; }
        public string strACT_Quality { get; set; }
        public string strACT_FTE { get; set; }
        public string strACT_Excel { get; set; }
        public string strACT_dollar { get; set; }
        public string ACT_Saving_Desc { get; set; }
         
         
    }
}
