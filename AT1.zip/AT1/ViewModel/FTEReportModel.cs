﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.Mvc;

namespace AT.BAL.ViewModel
{
    public class FTEReportModel
    {
       
        public string  strStatus { get; set; }
        public string strLocation { get; set; }
        public string strfromDate { get; set; }
        public string strTodate { get; set; }
    }
}
