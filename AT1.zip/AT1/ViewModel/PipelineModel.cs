﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
namespace AT.BAL.ViewModel
{
   public class PipelineModel
    {
       public DataTable dtATtracker { get; set; }
       public string strProjectID { get; set; }
       public string strRemarks { get; set; }
       public string strStatus { get; set; }
       public string strResourceName { get; set; }
       public string strRequiredResource { get; set; }
       public string strPriority { get; set; }
       public string strProjectStartDate { get; set; }
       public string RejectedReason { get; set; }
       public string strProcessstudy { get; set; }
       public string strfeasibilitystatus { get; set; }

    }
}
