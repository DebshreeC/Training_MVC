﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AT.BAL.ViewModel
{
    public class DevCostModel
    {
        public decimal dev_cost { get; set; }
        public string strfromDate { get; set; }
       

    }
}
