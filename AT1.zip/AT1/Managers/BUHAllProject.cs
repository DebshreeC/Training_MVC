﻿using AT.BAL.Generics;
using AT.DAL;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Runtime.ExceptionServices;
using System.Text;
using System.Threading.Tasks;
using System.Web;

namespace AT.BAL.Managers
{
    public class BUHAllProject
    {
        public DataTable getBUHAllProjectDetails( string dtFromdate, string dtTodate)
        {
            DataTable dt = new DataTable();
            using (Automation_TrackerEntities _context = new Automation_TrackerEntities())
            {
                string strUsername = Convert.ToString(HttpContext.Current.Session["UserName"]);

                try
                {

                    SqlConnection conObj = new SqlConnection(Constants.ConnectionString);
                    conObj.Open();
                    SqlCommand cmdObj = new SqlCommand(Constants.sp_BUHAllProject, conObj);
                    cmdObj.CommandType = CommandType.StoredProcedure;
                    cmdObj.Parameters.AddWithValue("@fromdate", dtFromdate != "" ? Convert.ToDateTime(dtFromdate) : Convert.ToDateTime("1/1/1900"));
                    cmdObj.Parameters.AddWithValue("@todate", dtTodate != "" ? Convert.ToDateTime(dtTodate) : Convert.ToDateTime("1/1/1900"));
                    SqlDataAdapter adapter1 = new SqlDataAdapter(cmdObj);
                    adapter1.Fill(dt);
                    conObj.Close();

                }
                catch (Exception e)
                {
                    ExceptionDispatchInfo.Capture(e).Throw();
                }
                return dt;
            }
        }

    }
}
