﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;

namespace AT.BAL.Managers
{
    public interface IinProgresServices
    {
        DataTable getInprogressProjectDetails(string strStatus, string strFntype);
        DataTable getOpenProject(string strStatus, string strFntype);
        void InprogressSave(string listOfAccounts, string strStatus, string strReason);
        DataTable getCompletedProjectDetails(string strStatus, string strFntype);
        void OnHoldDataSave(string listOfAccounts, string strStatus, string strReasontoRevert);
    }
}
