﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AT.BAL.Managers
{
    public interface IUserMenuService
    {
        void GetSideMenu();
        string GetSideMenustring();
        void saveSessiondetails();
    }
}
