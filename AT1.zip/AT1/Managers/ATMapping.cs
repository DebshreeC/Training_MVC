﻿using AT.DAL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AT.BAL.ViewModel;
using System.Data;
using System.Reflection;
using System.Web.Mvc;
using System.Data.SqlClient;
using AT.BAL.Generics;
using System.Web;
using System.Runtime.ExceptionServices;

namespace AT.BAL.Managers
{
    public class ATMapping
    {
        public List<ColumnListModel> GetListofColumns(string DbCondition)
        {

            using (Automation_TrackerEntities _context = new Automation_TrackerEntities())
            {

                if (DbCondition == "S")
                {
                    //   var liCol = _context.Column_List.Where(t => t.Column_Id != 0).ToList();
                    var licol = (from cl in _context.Column_List
                                 where cl.Column_Id != 0 && cl.Screen_Required == "Y"
                                 select new ColumnListModel
                                 {
                                     Column_Id = cl.Column_Id,
                                     Column_Name = cl.Column_Name,
                                     Display_Name = cl.Display_Name,
                                     Enter_By = cl.Enter_By,
                                     Enter_Date = cl.Enter_Date
                                 }).ToList();
                    return licol;
                }
                else
                {
                    var licol = (from cl in _context.Column_List
                                 where cl.Column_Id != 0 && cl.Report_Required == "Y"
                                 select new ColumnListModel
                                 {
                                     Column_Id = cl.Column_Id,
                                     Column_Name = cl.Column_Name,
                                     Display_Name = cl.Display_Name,
                                     Enter_By = cl.Enter_By,
                                     Enter_Date = cl.Enter_Date
                                 }).ToList();
                    return licol;
                }
            }
        }


        public void InsertProject(List<ViewModel.InsertProjectModel> mod)
        {
            using (Automation_TrackerEntities _context = new Automation_TrackerEntities())
            {
                Track_Details tr = new Track_Details();
                if (mod != null)
                {
                    foreach (var item in mod)
                    {
                        tr.category = item.Category;
                        tr.Client = item.Client;
                        tr.Client = item.Client;
                        tr.Project_Name = item.Project_Name;
                        tr.Process = item.Process;
                        tr.Description = item.Description;
                        tr.Location = item.Location;
                        tr.Vertical = item.Vertical;
                        tr.Type = item.Type;
                        tr.Manager = item.Manager;
                        tr.SPOC = item.SPOC;
                        tr.Remarks = item.Remarks;
                        tr.Req_Received_Date = Convert.ToDateTime(item.Request_ReceivedDate);
                        tr.Est_Prod_Impv_percent = item.Est_Prod_Impv_percent;
                        tr.Est_Quality_Impv_percent = item.Est_Quality_Impv_percent;
                        tr.Est_FTE_Saving = 0;
                        tr.Est_Hours_saved_FTE = item.Est_Hours_saved_FTE;
                        tr.Enter_By = System.Environment.UserName;
                        tr.Enter_Date = DateTime.Now;
                        tr.Status = "PipelineOpen";
                        tr.Est_Dollar_Saving = item.Est_dollar_saving;
                        tr.Est_Excel_Saving = item.Est_Excel_saving;
                        tr.buhname = item.strBuhname;
                        tr.sdhname = item.SDHname;
                        _context.Track_Details.Add(tr);
                        _context.SaveChanges();

                    }
                }
            }

        }


        public void EditGridRecord(int ProjectId, string Client, string ProjectName)
        {
            using (Automation_TrackerEntities _context = new Automation_TrackerEntities())
            {


                foreach (var liIcd in _context.Track_Details.Where(x => x.Project_Unique_ID == ProjectId).ToList())
                {
                    liIcd.Client = Client;
                    liIcd.Project_Name = ProjectName;
                }
                _context.SaveChanges();

                //var liIcd = _context.Track_Details.Where(x => x.Project_Unique_ID == ProjectId).FirstOrDefault();
                //liIcd.Client = Client;
                //liIcd.Project_Name = ProjectName;
                //liIcd.Enter_Date = DateTime.Now.ToString();
                //_context.SaveChanges();

            }
        }


        public void UpdateProjectRecord(FormCollection frm, int Project_Unique_ID, string strStatus = null, string strAddstatus = null)
        {
            using (Automation_TrackerEntities _context = new Automation_TrackerEntities())
            {
                var _tr = _context.Track_Details.Where(x => x.Project_Unique_ID == Project_Unique_ID).SingleOrDefault();

                if (_tr != null)
                {

                    foreach (var key in frm.AllKeys)
                    {
                        if (key == "Client")
                        {
                            _tr.Client = frm[key];
                        }
                        else if (key == "Project_Name")
                        {
                            _tr.Project_Name = frm[key];
                        }
                        else if (key == "Process")
                        {
                            _tr.Process = frm[key];
                        }
                        else if (key == "Description")
                        {
                            _tr.Description = frm[key];
                        }
                        else if (key == "Type")
                        {
                            _tr.Type = frm[key];
                        }
                        else if (key == "Status")
                        {
                            _tr.Status = frm[key];
                        }
                        else if (key == "Project_Status")
                        {
                            _tr.Project_Status = frm[key];
                        }
                        else if (key == "InProgress_Status")
                        {
                            _tr.InProgress_Status = frm[key];
                        }
                        else if (key == "Req_Received_Date")
                        {
                            if (Convert.ToString(frm[key]) != "")
                            {
                                _tr.Req_Received_Date = Convert.ToDateTime(frm[key]);
                            }
                        }
                        else if (key == "Approved_Rejected_Date")
                        {
                            if (Convert.ToString(frm[key]) != "")
                            {
                                _tr.Approved_Rejected_Date = Convert.ToDateTime(frm[key]);
                            }
                        }
                        else if (key == "Location")
                        {
                            _tr.Location = frm[key];
                        }
                        else if (key == "Vertical")
                        {
                            _tr.Vertical = frm[key];
                        }
                        else if (key == "Fully_Loaded_FTE_Cost_dollar")
                        {
                            _tr.Fully_Loaded_FTE_Cost_dollar = frm[key].ToString() != "" ? Convert.ToDecimal(frm[key]) : 0;
                        }
                        else if (key == "Payroll_FTE_Cost")
                        {

                            _tr.Payroll_FTE_Cost = frm[key].ToString() != "" ? Convert.ToDecimal(frm[key]) : 0;

                        }
                        else if (key == "Est_Dollar_Saving")
                        {

                            if (strAddstatus == "add")
                            {
                                if (strStatus == "PipelineOpen")
                                {
                                    _tr.Est_Dollar_Saving = frm[key];
                                }
                            }
                            else
                            {
                                _tr.Est_Dollar_Saving = frm[key];
                            }
                        }

                        else if (key == "Act_Dollar_Saving")
                        {
                            _tr.Act_Dollar_Saving = frm[key];
                        }

                        else if (key == "Est_Effort_Cost_dollar")
                        {
                            if (strAddstatus == "add")
                            {
                                if (strStatus == "PipelineOpen")
                                {
                                    _tr.Est_Effort_Cost_dollar = frm[key];
                                }
                            }
                            else
                            {
                                _tr.Est_Effort_Cost_dollar = frm[key];
                            }

                        }
                        else if (key == "Manager")
                        {
                            _tr.Manager = frm[key];
                        }
                        else if (key == "SPOC")
                        {
                            _tr.SPOC = frm[key];
                        }
                        else if (key == "Remarks")
                        {
                            _tr.Remarks = frm[key];
                        }
                        else if (key == "EXT")
                        {
                            _tr.EXT = frm[key];
                        }
                        else if (key == "Priority")
                        {
                            _tr.Priority = frm[key];
                        }
                        else if (key == "Project_Start_Date")
                        {
                            if (Convert.ToString(frm[key]) != "")
                            {
                                _tr.Project_Start_Date = Convert.ToDateTime(frm[key]);
                            }
                        }

                        else if (key == "Planned_Completion_Date")
                        {
                            if (Convert.ToString(frm[key]) != "")
                            {
                                _tr.Planned_Completion_Date = Convert.ToDateTime(frm[key]);
                            }
                        }
                        else if (key == "Actual_Completion_Date")
                        {
                            if (Convert.ToString(frm[key]) != "")
                            {
                                _tr.Actual_Completion_Date = Convert.ToDateTime(frm[key]);
                            }
                        }
                        else if (key == "Resources_Involved")
                        {
                            _tr.Resources_Involved = frm[key];
                        }
                        else if (key == "Hash_Resources_Required")
                        {
                            _tr.Hash_Resources_Required = frm[key];
                        }
                        else if (key == "UAT_Release_Date")
                        {
                            if (Convert.ToString(frm[key]) != "")
                            {
                                _tr.UAT_Release_Date = Convert.ToDateTime(frm[key]);
                            }
                        }
                        else if (key == "LIVE_Release_Date")
                        {
                            if (Convert.ToString(frm[key]) != "")
                            {
                                _tr.LIVE_Release_Date = Convert.ToDateTime(frm[key]);
                            }
                        }
                        else if (key == "UAT_Remarks")
                        {
                            _tr.UAT_Remarks = frm[key];
                        }
                        else if (key == "LIVE_Remarks")
                        {
                            _tr.LIVE_Remarks = frm[key];

                        }
                        else if (key == "Release_Date")
                        {
                            if (Convert.ToString(frm[key]) != "")
                            {
                                _tr.Release_Date = Convert.ToDateTime(frm[key]);
                            }
                        }
                        else if (key == "Release_Type")
                        {
                            _tr.Release_Type = frm[key];
                        }
                        else if (key == "Benefit_Sign_off_Date")
                        {
                            if (Convert.ToString(frm[key]) != "")
                            {
                                _tr.Benefit_Sign_off_Date = Convert.ToDateTime(frm[key]);
                            }
                        }
                        else if (key == "UAT_Sign_off_Date")
                        {
                            if (Convert.ToString(frm[key]) != "")
                            {
                                _tr.UAT_Sign_off_Date = Convert.ToDateTime(frm[key]);
                            }
                        }
                        else if (key == "Benefit_Signedby")
                        {
                            _tr.Benefit_Signedby = frm[key];
                        }

                        else if (key == "Process_Re_engineering")
                        {
                            _tr.Process_Re_engineering = frm[key];
                        }
                        else if (key == "Effort_Man_days")
                        {
                            _tr.Effort_Man_days = frm[key];
                        }
                        else if (key == "No_FTEs_Involved")
                        {
                            _tr.No_FTEs_Involved = frm[key];
                        }
                        else if (key == "Est_Prod_Impv_percent")
                        {
                            if (strAddstatus == "add")
                            {
                                if (strStatus == "PipelineOpen")
                                {

                                    _tr.Est_Prod_Impv_percent = frm[key];
                                }
                            }
                            else
                            {
                                _tr.Est_Prod_Impv_percent = frm[key];
                            }
                        }

                        else if (key == "Act_Prod_Impv_percent")
                        {
                            _tr.Act_Prod_Impv_percent = frm[key];
                        }
                        else if (key == "Est_Quality_Impv_percent")
                        {
                            if (strAddstatus == "add")
                            {
                                if (strStatus == "PipelineOpen")
                                {

                                    _tr.Est_Quality_Impv_percent = frm[key];
                                }
                            }
                            else
                            {
                                _tr.Est_Quality_Impv_percent = frm[key];
                            }


                        }
                        else if (key == "Act_Quality_Impv_percent")
                        {
                            _tr.Act_Quality_Impv_percent = frm[key];
                        }
                        else if (key == "Est_FTE_Saving")
                        {
                            if (strAddstatus == "add")
                            {
                                if (strStatus == "PipelineOpen")
                                {

                                    _tr.Est_FTE_Saving = frm[key].ToString() != "" ? Convert.ToDecimal(frm[key]) : 0;
                                }
                            }
                            else
                            {
                                _tr.Est_FTE_Saving = frm[key].ToString() != "" ? Convert.ToDecimal(frm[key]) : 0;
                            }
                        }

                        else if (key == "Act_FTE_Saving")
                        {
                            _tr.Act_FTE_Saving = frm[key].ToString() != "" ? Convert.ToDecimal(frm[key]) : 0;
                        }




                        else if (key == "Est_Excel_Saving")
                        {
                            if (strAddstatus == "add")
                            {
                                if (strStatus == "PipelineOpen")
                                {

                                    _tr.Est_Excel_Saving = frm[key];
                                }
                            }
                            else
                            {
                                _tr.Est_Excel_Saving = frm[key];
                            }
                        }

                        else if (key == "Act_Excel_Saving")
                        {
                            _tr.Act_Excel_Saving = frm[key];
                        }

                        else if (key == "Revised_Est_FTE_Saving")
                        {
                            _tr.Revised_Est_FTE_Saving = frm[key];
                        }
                        else if (key == "Est_Hours_saved_FTE")
                        {

                            if (strAddstatus == "add")
                            {
                                if (strStatus == "PipelineOpen")
                                {

                                    _tr.Est_Hours_saved_FTE = frm[key];
                                }
                            }
                            else
                            {
                                _tr.Est_Hours_saved_FTE = frm[key];
                            }
                        }
                        else if (key == "Act_Hours_saved_FTE")
                        {
                            _tr.Act_Hours_saved_FTE = frm[key];
                        }
                        else if (key == "Comments")
                        {
                            _tr.Comments = frm[key];
                        }
                        else if (key == "Application")
                        {
                            _tr.Application = frm[key];
                        }
                        else if (key == "Total_FTEs_inthe_project")
                        {
                            _tr.Total_FTEs_inthe_project = frm[key].ToString() != "" ? Convert.ToDecimal(frm[key]) : 0;
                        }
                        else if (key == "Est_Effort_Needed")
                        {
                            _tr.Est_Effort_Needed = frm[key].ToString() != "" ? Convert.ToDecimal(frm[key]) : 0;
                        }


                        else if (key == "Requiredresource")
                        {
                            _tr.Requiredresource = frm[key].ToString() != "" ? Convert.ToInt32(frm[key]) : 0;
                        }
                        else if (key == "Resname_hidden")
                        {
                            _tr.Resource_Name = frm[key];
                        }
                        else if (key == "Resourceid")
                        {
                            _tr.Resource_id = frm[key];
                        }

                        else if (key == "Act_Effort")
                        {
                            _tr.Act_Effort = frm[key].ToString() != "" ? Convert.ToInt32(frm[key]) : 0;
                        }
                        else if (key == "reason_for_delay")
                        {
                            if (strStatus == "In-Progress" && Convert.ToString(frm[key]) != "")
                            {
                                _tr.reason_for_delay = Convert.ToString(frm[key]);
                            }

                        }
                        else if (key == "reason_for_effort_variation")
                        {
                            if (strStatus == "In-Progress" && Convert.ToString(frm[key]) != "")
                            {
                                _tr.reason_for_effort_variation = Convert.ToString(frm[key]);
                            }

                        }

                        else if (key == "processstudy")
                        {
                            if (Convert.ToString(frm[key]) != "---Select---")
                            {
                                _tr.processstudy = Convert.ToString(frm[key]);
                            }

                        }
                        else if (key == "tech_feasibility")
                        {
                            if (Convert.ToString(frm[key]) != "---Select---")
                            {
                                _tr.tech_feasibility = Convert.ToString(frm[key]);
                            }

                        }

                        else if (key == "est_Saving_hidden")
                        {
                            if (strAddstatus == "add")
                            {
                                if (strStatus == "PipelineOpen")
                                {
                                    string strAdd = frm[key].ToString();
                                    if (strAdd.Contains("est_TBD_Saving"))
                                    {
                                        _tr.est_TBD_Saving = "TBD";
                                    }
                                }
                                //if (frm[key].ToString() == "PipelineOpen")
                                //{
                                //    _tr.Status = "Open";
                                //}
                                //if (frm[key].ToString() == "Approved")
                                //{
                                //    _tr.Status = "In-Progress";
                                //}
                                //if (frm[key].ToString() == "TentativelyApproved")
                                //{
                                //    _tr.Status = "In-Progress";
                                //}
                                //if (frm[key].ToString() == "InprogressUAT")
                                //{
                                //    _tr.Status = "InprogressLive";
                                //}
                                //if (frm[key].ToString() == "InprogressLive")
                                //{
                                //    _tr.Status = "Completed";
                                //}
                            }
                        }

                    }

                }

                _context.SaveChanges();
            }

            if (strAddstatus == "add")
            {
                if (strStatus == "PipelineOpen")
                {
                    using (Automation_TrackerEntities _context = new Automation_TrackerEntities())
                    {

                        _context.AT_EST_Saving_Details.RemoveRange(_context.AT_EST_Saving_Details.Where(x => x.Project_Unique_ID == Project_Unique_ID));
                        _context.SaveChanges();
                        foreach (var key in frm.AllKeys)
                        {
                            if (key == "est_Saving_hidden")
                            {
                                string[] array = frm[key].Split(',').Select(x => x.Trim()).ToArray();

                                foreach (var index in array)
                                {
                                    if (!string.IsNullOrEmpty(index))
                                    {
                                        AT_EST_Saving_Details ObjAT = new AT_EST_Saving_Details();
                                        ObjAT.Project_Unique_ID = Project_Unique_ID;
                                        ObjAT.Est_Saving_Desc = index.ToString();
                                        _context.AT_EST_Saving_Details.Add(ObjAT);

                                    }
                                }
                            }
                        }

                        _context.SaveChanges();
                    }
                }

                if (strStatus == "InprogressLive")
                {
                    using (Automation_TrackerEntities _context = new Automation_TrackerEntities())
                    {

                        _context.AT_ACT_Saving_Details.RemoveRange(_context.AT_ACT_Saving_Details.Where(x => x.Project_Unique_ID == Project_Unique_ID));
                        _context.SaveChanges();
                        foreach (var key in frm.AllKeys)
                        {
                            if (key == "act_Saving_hidden")
                            {
                                string[] array = frm[key].Split(',').Select(x => x.Trim()).ToArray();

                                foreach (var index in array)
                                {
                                    if (!string.IsNullOrEmpty(index))
                                    {
                                        AT_ACT_Saving_Details ObjAT = new AT_ACT_Saving_Details();
                                        ObjAT.Project_Unique_ID = Project_Unique_ID;
                                        ObjAT.ACT_Saving_Desc = index.ToString();
                                        _context.AT_ACT_Saving_Details.Add(ObjAT);

                                    }
                                }
                            }
                        }

                        _context.SaveChanges();
                    }
                }

            }

            //var liIcd = _context.Track_Details.Where(x => x.Project_Unique_ID == ProjectId).FirstOrDefault();
            //liIcd.Client = Client;
            //liIcd.Project_Name = ProjectName;
            //liIcd.Enter_Date = DateTime.Now.ToString();
            //_context.SaveChanges();
        }


        public void RejectProject(FormCollection frm, int Project_Unique_ID, string strStatus = null, string strAddstatus = null)
        {
            using (Automation_TrackerEntities _context = new Automation_TrackerEntities())
            {
                var _tr = _context.Track_Details.Where(x => x.Project_Unique_ID == Project_Unique_ID).SingleOrDefault();

                if (_tr != null)
                {
                    foreach (var key in frm.AllKeys)
                    {
                        if (key == "Client")
                        {
                            _tr.Client = frm[key];
                        }
                        else if (key == "Project_Name")
                        {
                            _tr.Project_Name = frm[key];
                        }
                        else if (key == "Process")
                        {
                            _tr.Process = frm[key];
                        }
                        else if (key == "Description")
                        {
                            _tr.Description = frm[key];
                        }
                        else if (key == "Type")
                        {
                            _tr.Type = frm[key];
                        }
                        else if (key == "Status")
                        {
                            _tr.Status = frm[key];
                        }
                        else if (key == "Project_Status")
                        {
                            _tr.Project_Status = frm[key];
                        }
                        else if (key == "InProgress_Status")
                        {
                            _tr.InProgress_Status = frm[key];
                        }
                        else if (key == "Req_Received_Date")
                        {
                            if (Convert.ToString(frm[key]) != "")
                            {
                                _tr.Req_Received_Date = Convert.ToDateTime(frm[key]);
                            }
                        }
                        else if (key == "Approved_Rejected_Date")
                        {
                            if (Convert.ToString(frm[key]) != "")
                            {
                                _tr.Approved_Rejected_Date = Convert.ToDateTime(frm[key]);
                            }
                        }
                        else if (key == "Location")
                        {
                            _tr.Location = frm[key];
                        }
                        else if (key == "Vertical")
                        {
                            _tr.Vertical = frm[key];
                        }
                        else if (key == "Fully_Loaded_FTE_Cost_dollar")
                        {
                            _tr.Fully_Loaded_FTE_Cost_dollar = frm[key].ToString() != "" ? Convert.ToDecimal(frm[key]) : 0;
                        }
                        else if (key == "Payroll_FTE_Cost")
                        {

                            _tr.Payroll_FTE_Cost = frm[key].ToString() != "" ? Convert.ToDecimal(frm[key]) : 0;

                        }

                        else if (key == "Est_Dollar_Saving")
                        {
                            _tr.Est_Dollar_Saving = frm[key];
                        }
                        else if (key == "Act_Dollar_Saving")
                        {
                            _tr.Act_Dollar_Saving = frm[key];
                        }

                        else if (key == "Est_Effort_Cost_dollar")
                        {
                            _tr.Est_Effort_Cost_dollar = frm[key];
                        }
                        else if (key == "Manager")
                        {
                            _tr.Manager = frm[key];
                        }
                        else if (key == "SPOC")
                        {
                            _tr.SPOC = frm[key];
                        }
                        else if (key == "Remarks")
                        {
                            _tr.Remarks = frm[key];
                        }
                        else if (key == "EXT")
                        {
                            _tr.EXT = frm[key];
                        }
                        else if (key == "Priority")
                        {
                            _tr.Priority = frm[key];
                        }
                        else if (key == "Project_Start_Date")
                        {
                            if (Convert.ToString(frm[key]) != "")
                            {
                                _tr.Project_Start_Date = Convert.ToDateTime(frm[key]);
                            }
                        }

                        else if (key == "Planned_Completion_Date")
                        {
                            if (Convert.ToString(frm[key]) != "")
                            {
                                _tr.Planned_Completion_Date = Convert.ToDateTime(frm[key]);
                            }
                        }
                        else if (key == "Actual_Completion_Date")
                        {
                            if (Convert.ToString(frm[key]) != "")
                            {
                                _tr.Actual_Completion_Date = Convert.ToDateTime(frm[key]);
                            }
                        }
                        else if (key == "Resources_Involved")
                        {
                            _tr.Resources_Involved = frm[key];
                        }
                        else if (key == "Hash_Resources_Required")
                        {
                            _tr.Hash_Resources_Required = frm[key];
                        }
                        else if (key == "UAT_Release_Date")
                        {
                            if (Convert.ToString(frm[key]) != "")
                            {
                                _tr.UAT_Release_Date = Convert.ToDateTime(frm[key]);
                            }
                        }
                        else if (key == "LIVE_Release_Date")
                        {
                            if (Convert.ToString(frm[key]) != "")
                            {
                                _tr.LIVE_Release_Date = Convert.ToDateTime(frm[key]);
                            }
                        }
                        else if (key == "UAT_Remarks")
                        {
                            _tr.UAT_Remarks = frm[key];
                        }
                        else if (key == "LIVE_Remarks")
                        {
                            _tr.LIVE_Remarks = frm[key];

                        }
                        else if (key == "Release_Date")
                        {
                            if (Convert.ToString(frm[key]) != "")
                            {
                                _tr.Release_Date = Convert.ToDateTime(frm[key]);
                            }
                        }
                        else if (key == "Release_Type")
                        {
                            _tr.Release_Type = frm[key];
                        }
                        else if (key == "Benefit_Sign_off_Date")
                        {
                            if (Convert.ToString(frm[key]) != "")
                            {
                                _tr.Benefit_Sign_off_Date = Convert.ToDateTime(frm[key]);
                            }
                        }
                        else if (key == "Benefit_Signedby")
                        {
                            _tr.Benefit_Signedby = frm[key];
                        }
                        else if (key == "Process_Re_engineering")
                        {
                            _tr.Process_Re_engineering = frm[key];
                        }
                        else if (key == "Effort_Man_days")
                        {
                            _tr.Effort_Man_days = frm[key];
                        }
                        else if (key == "No_FTEs_Involved")
                        {
                            _tr.No_FTEs_Involved = frm[key];
                        }
                        else if (key == "Est_Prod_Impv_percent")
                        {
                            _tr.No_FTEs_Involved = frm[key];
                        }

                        else if (key == "Act_Prod_Impv_percent")
                        {
                            _tr.Act_Prod_Impv_percent = frm[key];
                        }
                        else if (key == "Est_Quality_Impv_percent")
                        {
                            _tr.Est_Quality_Impv_percent = frm[key];
                        }
                        else if (key == "Act_Quality_Impv_percent")
                        {
                            _tr.Act_Quality_Impv_percent = frm[key];
                        }
                        else if (key == "Est_FTE_Saving")
                        {
                            _tr.Est_FTE_Saving = frm[key].ToString() != "" ? Convert.ToDecimal(frm[key]) : 0;
                        }
                        else if (key == "Revised_Est_FTE_Saving")
                        {
                            _tr.Revised_Est_FTE_Saving = frm[key];
                        }
                        else if (key == "Act_FTE_Saving")
                        {
                            _tr.Act_FTE_Saving = frm[key].ToString() != "" ? Convert.ToDecimal(frm[key]) : 0;
                        }
                        else if (key == "Est_Hours_saved_FTE")
                        {
                            _tr.Est_Hours_saved_FTE = frm[key];
                        }
                        else if (key == "Act_Hours_saved_FTE")
                        {
                            _tr.Act_Hours_saved_FTE = frm[key];
                        }
                        else if (key == "Comments")
                        {
                            _tr.Comments = frm[key];
                        }
                        else if (key == "Application")
                        {
                            _tr.Application = frm[key];
                        }
                        else if (key == "Total_FTEs_inthe_project")
                        {
                            _tr.Total_FTEs_inthe_project = frm[key].ToString() != "" ? Convert.ToDecimal(frm[key]) : 0;
                        }
                        else if (key == "Est_Effort_Needed")
                        {
                            _tr.Est_Effort_Needed = frm[key].ToString() != "" ? Convert.ToDecimal(frm[key]) : 0;
                        }


                        else if (key == "Requiredresource")
                        {
                            _tr.Requiredresource = frm[key].ToString() != "" ? Convert.ToInt32(frm[key]) : 0;
                        }
                        else if (key == "Resname_hidden")
                        {
                            _tr.Resource_Name = frm[key];
                        }
                        else if (key == "Resourceid")
                        {
                            _tr.Resource_id = frm[key];
                        }
                        else if (key == "Act_Effort")
                        {
                            _tr.Act_Effort = frm[key].ToString() != "" ? Convert.ToInt32(frm[key]) : 0;
                        }
                        else if (key == "reason_for_delay")
                        {
                            if (strStatus == "Inprogress" && Convert.ToString(frm[key]) != "")
                            {
                                _tr.reason_for_delay = Convert.ToString(frm[key]);
                            }

                        }
                        else if (key == "Reason_for_Rejection")
                        {
                            _tr.Reason_for_Rejection = Convert.ToString(frm[key]);
                        }
                        else if (key == "status")
                        {
                            if (strAddstatus == "add")
                            {
                                if (frm[key].ToString() == "PipelineOpen")
                                {
                                    _tr.Status = "Rejected";
                                }
                            }
                        }



                    }

                }

                _context.SaveChanges();

            }
        }

        public DataTable ATEditProject(int strProjectID, string strStatus = null)
        {
            DataTable dt = new DataTable();
            using (Automation_TrackerEntities _context = new Automation_TrackerEntities())
            {
                //if (strStatus == "PipelineOpen" || strStatus == "PipelineApproved")
                //{
                PipelineManager objP = new PipelineManager();
                SqlConnection conObj = new SqlConnection(Constants.ConnectionString);
                conObj.Open();
                SqlCommand cmdObj = new SqlCommand(Constants.sp_getdatabyProjectid, conObj);
                cmdObj.CommandType = CommandType.StoredProcedure;
                cmdObj.Parameters.AddWithValue("@status", strStatus);
                cmdObj.Parameters.AddWithValue("@Project_Unique_ID", strProjectID);
                SqlDataAdapter adapter1 = new SqlDataAdapter(cmdObj);
                adapter1.Fill(dt);
                conObj.Close();

                //}

                //else
                //{


                //    var lis = (from l in _context.Track_Details where l.Project_Unique_ID == strProjectID select l).ToList();
                //    dt = ToDataTable(lis);
                //}
            }

            return dt;

        }

        public DataTable ATADDProject(int strProjectID, string strStatus = null)
        {
            DataTable dt = new DataTable();
            using (Automation_TrackerEntities _context = new Automation_TrackerEntities())
            {

                PipelineManager objP = new PipelineManager();
                SqlConnection conObj = new SqlConnection(Constants.ConnectionString);
                conObj.Open();
                SqlCommand cmdObj = new SqlCommand(Constants.sp_ADDProjectid, conObj);
                cmdObj.CommandType = CommandType.StoredProcedure;
                cmdObj.Parameters.AddWithValue("@status", strStatus);
                cmdObj.Parameters.AddWithValue("@Project_Unique_ID", strProjectID);
                SqlDataAdapter adapter1 = new SqlDataAdapter(cmdObj);
                adapter1.Fill(dt);
                conObj.Close();




            }

            return dt;

        }

        public DataTable ATADDEditProject(int strProjectID, string strStatus = null, string DbCondition = null)
        {
            DataTable dt = new DataTable();
            using (Automation_TrackerEntities _context = new Automation_TrackerEntities())
            {
                PipelineManager objP = new PipelineManager();
                SqlConnection conObj = new SqlConnection(Constants.ConnectionString);
                conObj.Open();
                SqlCommand cmdObj = new SqlCommand(Constants.sp_DynamicADDEdit, conObj);
                cmdObj.CommandType = CommandType.StoredProcedure;
                cmdObj.Parameters.AddWithValue("@status", strStatus);
                cmdObj.Parameters.AddWithValue("@Project_Unique_ID", strProjectID);
                cmdObj.Parameters.AddWithValue("@DBCondition", DbCondition);
                SqlDataAdapter adapter1 = new SqlDataAdapter(cmdObj);
                adapter1.Fill(dt);
                conObj.Close();
            }
            return dt;
        }



        public static DataTable ToDataTable<T>(List<T> items)
        {
            DataTable dataTable = new DataTable(typeof(T).Name);

            //Get all the properties
            PropertyInfo[] Props = typeof(T).GetProperties(BindingFlags.Public | BindingFlags.Instance);
            foreach (PropertyInfo prop in Props)
            {
                //Setting column names as Property names
                dataTable.Columns.Add(prop.Name);
            }
            foreach (T item in items)
            {
                var values = new object[Props.Length];
                for (int i = 0; i < Props.Length; i++)
                {
                    //inserting property values to datatable rows
                    values[i] = Props[i].GetValue(item, null);
                }
                dataTable.Rows.Add(values);
            }
            //put a breakpoint here and check datatable
            return dataTable;
        }


        public void EditDynamicColumn(string ProjectHeader, string SubMenu, string MappingList, string Dbcondition)
        {
            using (Automation_TrackerEntities _context = new Automation_TrackerEntities())
            {
                int SId = Convert.ToInt32(SubMenu);
                _context.Mapping_Column_List.RemoveRange(_context.Mapping_Column_List.Where(x => x.Project_Status_Id == SId && x.additionrequired == Dbcondition));
                _context.SaveChanges();
                int MappingColumn = 0;
                var array = MappingList.Split(',');
                for (int i = 0; i <= array.Count() - 1; i++)
                {
                    MappingColumn = Convert.ToInt32(array[i]);
                    var MappingEdit = _context.Set<Mapping_Column_List>();
                    MappingEdit.Add(new Mapping_Column_List
                    {
                        Column_Id = MappingColumn,
                        Project_Status_Id = SId,
                        additionrequired = Dbcondition
                    });
                    _context.SaveChanges();
                }

            }
        }

        public List<int> getEditDynamicColumn(int SubMenuId, string DbCondition)
        {
            //using (Automation_TrackerEntities _context = new Automation_TrackerEntities())
            //{
            //    List<int> EL = new List<int>();
            //    EL = _context.MappingEdit_Column_List.Where(x => x.Project_Status_Id == SubMenuId).Select(x => x.Column_Id).Cast<int>().ToList();
            //    return EL;
            //}

            using (Automation_TrackerEntities _context = new Automation_TrackerEntities())
            {
                //Select * from Mapping_Column_List where Project_Status_Id=7 and additionrequired='Y'
                List<int> EL = new List<int>();
                EL = _context.Mapping_Column_List.Where(x => x.Project_Status_Id == SubMenuId && x.additionrequired == DbCondition).Select(x => x.Column_Id).Cast<int>().ToList();
                return EL;
            }
        }

        #region Get BUH Names
        public List<SelectListItem> GetBUHNames(string strFntype = "BU_HEADS", string strBUH = null, string StrClient = null)
        {
            using (Automation_TrackerEntities _context = new Automation_TrackerEntities())
            {
                DataTable dt = new DataTable();

                SqlConnection conObj = new SqlConnection(Constants.ConnectionString);
                conObj.Open();
                SqlCommand cmdObj = new SqlCommand();
                cmdObj = new SqlCommand(Constants.sp_BUHname, conObj);
                cmdObj.CommandType = CommandType.StoredProcedure;
                cmdObj.Parameters.AddWithValue("@fntype", strFntype);
                cmdObj.Parameters.AddWithValue("@BU_HEADS", strBUH);
                cmdObj.Parameters.AddWithValue("@Client", StrClient);
                SqlDataAdapter adapter1 = new SqlDataAdapter(cmdObj);

                adapter1.Fill(dt);
                conObj.Close();



                var list_BUH = (from DataRow row in dt.Rows

                                select new SelectListItem
                                {
                                    Text = row["text"].ToString(),
                                    Value = row["id"].ToString()
                                }).ToList();
                return list_BUH;
            }

        }
        #endregion



        public List<SelectListItem> GetEMPNames(string fntype, string project_unique_id, string emp_id)
        {
            using (Automation_TrackerEntities _context = new Automation_TrackerEntities())
            {
                DataTable dt = new DataTable();

                SqlConnection conObj = new SqlConnection(Constants.ConnectionString);
                conObj.Open();
                SqlCommand cmdObj = new SqlCommand();
                cmdObj = new SqlCommand(Constants.sp_getempName, conObj);
                cmdObj.CommandType = CommandType.StoredProcedure;
                cmdObj.Parameters.AddWithValue("@fntype", fntype);
                cmdObj.Parameters.AddWithValue("@project_unique_id", project_unique_id);
                cmdObj.Parameters.AddWithValue("@emp_id", emp_id);

                SqlDataAdapter adapter1 = new SqlDataAdapter(cmdObj);

                adapter1.Fill(dt);
                conObj.Close();



                var list_BUH = (from DataRow row in dt.Rows

                                select new SelectListItem
                                {
                                    Text = row["text"].ToString(),
                                    Value = row["id"].ToString()
                                }).ToList();
                return list_BUH;
            }

        }



        #region Get BUH Names
        public List<SelectListItem> GetManagerNames(string strFntype = "BU_HEADS", string strBUH = null, string StrClient = null, string strProcess = null,
            string strLocation = null, string strVertical = null, string strManager = null)
        {
            using (Automation_TrackerEntities _context = new Automation_TrackerEntities())
            {
                DataTable dt = new DataTable();

                SqlConnection conObj = new SqlConnection(Constants.ConnectionString);
                conObj.Open();
                SqlCommand cmdObj = new SqlCommand();
                cmdObj = new SqlCommand(Constants.sp_Manager, conObj);
                cmdObj.CommandType = CommandType.StoredProcedure;
                cmdObj.Parameters.AddWithValue("@fntype", strFntype);
                cmdObj.Parameters.AddWithValue("@BU_HEADS", strBUH);
                cmdObj.Parameters.AddWithValue("@Client", StrClient);
                cmdObj.Parameters.AddWithValue("@process", strProcess);
                cmdObj.Parameters.AddWithValue("@location", strLocation);
                cmdObj.Parameters.AddWithValue("@Vertical", strVertical);
                cmdObj.Parameters.AddWithValue("@Manager", strManager);

                SqlDataAdapter adapter1 = new SqlDataAdapter(cmdObj);

                adapter1.Fill(dt);
                conObj.Close();



                var list_BUH = (from DataRow row in dt.Rows

                                select new SelectListItem
                                {
                                    Text = row["desc"].ToString(),
                                    Value = row["id"].ToString()
                                }).ToList();
                return list_BUH;
            }

        }
        #endregion

        #region Get BUH Names
        public List<SelectListItem> GetBenefitsignedoffbyNames(string strFntype = "BU_HEADS", string strBUH = null, string strProjectid = null,
            string strLocation = null, string strVertical = null, string strManager = null)
        {
            using (Automation_TrackerEntities _context = new Automation_TrackerEntities())
            {
                DataTable dt = new DataTable();

                SqlConnection conObj = new SqlConnection(Constants.ConnectionString);
                conObj.Open();
                SqlCommand cmdObj = new SqlCommand();
                cmdObj = new SqlCommand(Constants.sp_Benifitsignedby, conObj);
                cmdObj.CommandType = CommandType.StoredProcedure;
                cmdObj.Parameters.AddWithValue("@fntype", strFntype);
                cmdObj.Parameters.AddWithValue("@BU_HEADS", strBUH);
                cmdObj.Parameters.AddWithValue("@projectid", strProjectid);


                SqlDataAdapter adapter1 = new SqlDataAdapter(cmdObj);

                adapter1.Fill(dt);
                conObj.Close();



                var list_BUH = (from DataRow row in dt.Rows

                                select new SelectListItem
                                {
                                    Text = row["desc"].ToString(),
                                    Value = row["id"].ToString()
                                }).ToList();
                return list_BUH;
            }

        }
        #endregion



        #region Get Resource Names
        public List<SelectListItem> GetResourceNames(string strFntype = "BU_HEADS")
        {
            using (Automation_TrackerEntities _context = new Automation_TrackerEntities())
            {
                DataTable dt = new DataTable();

                SqlConnection conObj = new SqlConnection(Constants.ConnectionString);
                conObj.Open();
                SqlCommand cmdObj = new SqlCommand();
                cmdObj = new SqlCommand(Constants.sp_Resourcename, conObj);
                cmdObj.CommandType = CommandType.StoredProcedure;
                cmdObj.Parameters.AddWithValue("@fntype", strFntype);

                SqlDataAdapter adapter1 = new SqlDataAdapter(cmdObj);

                adapter1.Fill(dt);
                conObj.Close();



                var list_BUH = (from DataRow row in dt.Rows

                                select new SelectListItem
                                {
                                    Text = row["EMP_NAME"].ToString(),
                                    Value = row["EMP_ID"].ToString()
                                }).ToList();
                return list_BUH;
            }

        }
        #endregion

        public DataTable GetDeveloperNames(string strFntype = "BU_HEADS")
        {
            using (Automation_TrackerEntities _context = new Automation_TrackerEntities())
            {
                DataTable dt = new DataTable();

                SqlConnection conObj = new SqlConnection(Constants.ConnectionString);
                conObj.Open();
                SqlCommand cmdObj = new SqlCommand();
                cmdObj = new SqlCommand(Constants.sp_Resourcename, conObj);
                cmdObj.CommandType = CommandType.StoredProcedure;
                cmdObj.Parameters.AddWithValue("@fntype", strFntype);

                SqlDataAdapter adapter1 = new SqlDataAdapter(cmdObj);

                adapter1.Fill(dt);
                conObj.Close();


                return dt;

            }

        }



        public string CheckAdditionfunction(string strStatus, string strProjectid)
        {
            DataTable dt = new DataTable();
            string strRes = string.Empty;
            using (Automation_TrackerEntities _context = new Automation_TrackerEntities())
            {
                string strUsername = Convert.ToString(HttpContext.Current.Session["UserName"]);

                try
                {
                    SqlDataReader reader;
                    SqlConnection conObj = new SqlConnection(Constants.ConnectionString);
                    conObj.Open();
                    SqlCommand cmdObj = new SqlCommand(Constants.sp_ChkAddition, conObj);
                    cmdObj.CommandType = CommandType.StoredProcedure;

                    cmdObj.Parameters.AddWithValue("@status", strStatus);
                    cmdObj.Parameters.AddWithValue("@project_id", strProjectid);

                    reader = cmdObj.ExecuteReader();
                    while (reader.Read())
                    {
                        strRes = reader.GetValue(0).ToString();
                    }
                }
                catch (Exception e)
                {
                    ExceptionDispatchInfo.Capture(e).Throw();
                }
                return strRes;
            }
        }

    }
}
