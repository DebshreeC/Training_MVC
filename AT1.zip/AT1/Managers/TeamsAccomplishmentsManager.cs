﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using AT.BAL.Generics;
using AT.DAL;
using System.Data.SqlClient;
using System.Web;
using System.Runtime.ExceptionServices;

namespace AT.BAL.Managers
{
    public class TeamsAccomplishmentsManager
    {
        public DataTable getOpenProject(string strStatus, string strFntype)
        {
            DataTable dt = new DataTable();
            using (Automation_TrackerEntities _context = new Automation_TrackerEntities())
            {
                string strUsername = Convert.ToString(HttpContext.Current.Session["UserName"]);

                try
                {

                    SqlConnection conObj = new SqlConnection(Constants.ConnectionString);
                    conObj.Open();
                    SqlCommand cmdObj = new SqlCommand(Constants.sp_openprojectdetails, conObj);
                    cmdObj.CommandType = CommandType.StoredProcedure;
                    cmdObj.Parameters.AddWithValue("@status", strStatus);
                    cmdObj.Parameters.AddWithValue("@fntype", strFntype);
                    cmdObj.Parameters.AddWithValue("@userid", strUsername);

                    SqlDataAdapter adapter1 = new SqlDataAdapter(cmdObj);
                    adapter1.Fill(dt);
                    conObj.Close();

                }
                catch (Exception e)
                {
                    ExceptionDispatchInfo.Capture(e).Throw();
                }
                return dt;
            }
        }



        public DataTable ATADDEditProject(int strProjectID, string strStatus, string DbCondition)
        {
            DataTable dt = new DataTable();
            using (Automation_TrackerEntities _context = new Automation_TrackerEntities())
            {
                PipelineManager objP = new PipelineManager();
                SqlConnection conObj = new SqlConnection(Constants.ConnectionString);
                conObj.Open();
                SqlCommand cmdObj = new SqlCommand(Constants.sp_DynamicADDEdit, conObj);
                cmdObj.CommandType = CommandType.StoredProcedure;
                cmdObj.Parameters.AddWithValue("@status", strStatus);
                cmdObj.Parameters.AddWithValue("@Project_Unique_ID", strProjectID);
                cmdObj.Parameters.AddWithValue("@DBCondition", DbCondition);
                SqlDataAdapter adapter1 = new SqlDataAdapter(cmdObj);
                adapter1.Fill(dt);
                conObj.Close();
            }
            return dt;
        }
       
    }
}
