﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using AT.DAL;
using System.Data.SqlClient;
using AT.BAL.Generics;
using System.Web;
using System.Runtime.ExceptionServices;

namespace AT.BAL.Managers
{
    public class InProgressManager : IinProgresServices
    {
        
        public DataTable getInprogressProjectDetails(string strStatus,string strFntype)
        {
            PipelineManager objP = new PipelineManager();
            return (objP.getOpenProject(strStatus, strFntype));
        }

        public DataTable getOpenProject(string strStatus, string strFntype)
        {
            DataTable dt = new DataTable();
            using (Automation_TrackerEntities _context = new Automation_TrackerEntities())
            {
                string strUsername = Convert.ToString(HttpContext.Current.Session["UserName"]);

                try
                {

                    SqlConnection conObj = new SqlConnection(Constants.ConnectionString);
                    conObj.Open();
                    SqlCommand cmdObj = new SqlCommand(Constants.sp_openprojectdetails, conObj);
                    cmdObj.CommandType = CommandType.StoredProcedure;
                    cmdObj.Parameters.AddWithValue("@status", strStatus);
                    cmdObj.Parameters.AddWithValue("@fntype", strFntype);
                    cmdObj.Parameters.AddWithValue("@userid", strUsername);

                    SqlDataAdapter adapter1 = new SqlDataAdapter(cmdObj);
                    adapter1.Fill(dt);
                    conObj.Close();

                }
                catch (Exception e)
                {
                    ExceptionDispatchInfo.Capture(e).Throw();
                }
                return dt;
            }
        }


        public DataTable ATADDEditProject(int strProjectID, string strStatus, string DbCondition)
        {
            DataTable dt = new DataTable();
            using (Automation_TrackerEntities _context = new Automation_TrackerEntities())
            {
                PipelineManager objP = new PipelineManager();
                SqlConnection conObj = new SqlConnection(Constants.ConnectionString);
                conObj.Open();
                SqlCommand cmdObj = new SqlCommand(Constants.sp_DynamicADDEdit, conObj);
                cmdObj.CommandType = CommandType.StoredProcedure;
                cmdObj.Parameters.AddWithValue("@status", strStatus);
                cmdObj.Parameters.AddWithValue("@Project_Unique_ID", strProjectID);
                cmdObj.Parameters.AddWithValue("@DBCondition", DbCondition);
                SqlDataAdapter adapter1 = new SqlDataAdapter(cmdObj);
                adapter1.Fill(dt);
                conObj.Close();
            }
            return dt;
        }
       


        #region AllotToCoder
        public void InprogressSave(string listOfAccounts, string strStatus,string strReason)
        {
            string[] array = listOfAccounts.Split(',').Select(x => x.Trim()).ToArray();
            using (Automation_TrackerEntities _context = new Automation_TrackerEntities())
            {
                string userName = HttpContext.Current.Session["UserName"].ToString();
                _context.Track_Details.Where(x => array.Contains(x.Project_Unique_ID.ToString())).ToList().ForEach(x =>
                { x.Status = array[0]; x.inprogress_to_uat_date = DateTime.Now; x.UAT_Release_Date = DateTime.Now; x.onhold_reason = strReason; });
                _context.SaveChanges();
            }
        }
        #endregion


        public DataTable getCompletedProjectDetails(string strStatus, string strFntype)
        {
            PipelineManager objP = new PipelineManager();
             return (objP.getOpenProject(strStatus, strFntype));
        }

        public void OnHoldDataSave(string listOfAccounts, string strStatus,string strReasontoRevert)
        {
            string[] array = listOfAccounts.Split(',').Select(x => x.Trim()).ToArray();
            using (Automation_TrackerEntities _context = new Automation_TrackerEntities())
            {
                string userName = HttpContext.Current.Session["UserName"].ToString();
                _context.Track_Details.Where(x => array.Contains(x.Project_Unique_ID.ToString())).ToList().ForEach(x =>
                { x.Status = array[0]; x.Reason_for_Revert = strReasontoRevert; x.onhold_to_revertdate = DateTime.Now; });
                _context.SaveChanges();
            }
        }

        public List<string> getESTProjectDetails(int strProjectUniqueID)
        { 
            using (Automation_TrackerEntities _context = new Automation_TrackerEntities())
            {
                //Select * from Mapping_Column_List where Project_Status_Id=7 and additionrequired='Y'
                List<string> EL = new List<string>();
                //EL = _context.Mapping_Column_List.Where(x => x.Project_Status_Id == SubMenuId && x.additionrequired == DbCondition).Select(x => x.Column_Id).Cast<int>().ToList();

                EL = _context.AT_EST_Saving_Details.Where(x => x.Project_Unique_ID == strProjectUniqueID).Select(x => x.Est_Saving_Desc).Cast<string>().ToList();
                return EL;
            }
        } 
        
    }
}
