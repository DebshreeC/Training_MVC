﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AT.DAL;
using System.Data.SqlClient;
using AT.BAL.Generics;
using System.Data;
using System.Web;
using System.Runtime.ExceptionServices;

namespace AT.BAL.Managers
{
    public class SummaryManager
    {
        public DataTable getsummaryData( string strFntype)
        {
            DataTable dt = new DataTable();
            using (Automation_TrackerEntities _context = new Automation_TrackerEntities())
            {
               
                try
                {
                    SqlConnection conObj = new SqlConnection(Constants.ConnectionString);
                    conObj.Open();
                    SqlCommand cmdObj = new SqlCommand(Constants.sp_Summary, conObj);
                    cmdObj.CommandType = CommandType.StoredProcedure;
                    cmdObj.Parameters.AddWithValue("@fntype", strFntype);
                    SqlDataAdapter adapter1 = new SqlDataAdapter(cmdObj);
                    adapter1.Fill(dt);
                    conObj.Close();

                }
                catch (Exception e)
                {
                    ExceptionDispatchInfo.Capture(e).Throw();
                }
                return dt;
            }
        }
    }
}
