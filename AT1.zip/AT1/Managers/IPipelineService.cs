﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data ;

namespace AT.BAL.Managers
{
    public interface IPipelineService
    {
        DataTable getOpenProject(string strStatus,string strFntype);
        void TechCouncilapproval(string listOfAccounts, string strStatus,string strReason);
        void PipelineEditApproval(int Project_Unique_ID , string strResourceName, string strRequiredResource, string strPriority, string strProjectStartDate);
    }
}
