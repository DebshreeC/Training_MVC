﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.Mvc;
using System.Data.SqlClient;
using AT.BAL.Generics;
using System.Data;
using AT.DAL;
using System.Web;
using System.Runtime.ExceptionServices;

namespace AT.BAL.Managers
{
    public class FTEReportManager
    {
        public DataTable getFTEProjectDetails(string strStatus, string dtFromdate, string dtTodate)
        {
            DataTable dt = new DataTable();
            using (Automation_TrackerEntities _context = new Automation_TrackerEntities())
            {
                string strUsername = Convert.ToString(HttpContext.Current.Session["UserName"]);

                try
                {

                    SqlConnection conObj = new SqlConnection(Constants.ConnectionString);
                    conObj.Open();
                    SqlCommand cmdObj = new SqlCommand(Constants.sp_FTEReport, conObj);
                    cmdObj.CommandType = CommandType.StoredProcedure;
                    cmdObj.Parameters.AddWithValue("@status", strStatus);
                    cmdObj.Parameters.AddWithValue("@userid", strUsername);
                    cmdObj.Parameters.AddWithValue("@fromdate", dtFromdate != "" ? Convert.ToDateTime(dtFromdate) : Convert.ToDateTime("1/1/1900"));
                    cmdObj.Parameters.AddWithValue("@todate", dtTodate != "" ? Convert.ToDateTime(dtTodate) : Convert.ToDateTime("1/1/1900"));
                    SqlDataAdapter adapter1 = new SqlDataAdapter(cmdObj);
                    adapter1.Fill(dt);
                    conObj.Close();

                }
                catch (Exception e)
                {
                    ExceptionDispatchInfo.Capture(e).Throw();
                }
                return dt;
            }
        }


          public DataTable OverallSaving(  string dtFromdate, string dtTodate)
        {
            DataTable dt = new DataTable();
            using (Automation_TrackerEntities _context = new Automation_TrackerEntities())
            {
                string strUsername = Convert.ToString(HttpContext.Current.Session["UserName"]);

                try
                {

                    SqlConnection conObj = new SqlConnection(Constants.ConnectionString);
                    conObj.Open();
                    SqlCommand cmdObj = new SqlCommand(Constants.sp_Overallsaving, conObj);
                    cmdObj.CommandType = CommandType.StoredProcedure;
                    cmdObj.Parameters.AddWithValue("@fromdate", dtFromdate != "" ? Convert.ToDateTime(dtFromdate) : Convert.ToDateTime("1/1/1900"));
                    cmdObj.Parameters.AddWithValue("@todate", dtTodate != "" ? Convert.ToDateTime(dtTodate) : Convert.ToDateTime("1/1/1900"));
                    SqlDataAdapter adapter1 = new SqlDataAdapter(cmdObj);
                    adapter1.Fill(dt);
                    conObj.Close();

                }
                catch (Exception e)
                {
                    ExceptionDispatchInfo.Capture(e).Throw();
                }
                return dt;
            }
        }
        

        public DataTable getFinalReport(string dtFromdate, string dtTodate)
        {
            DataTable dt = new DataTable();
            using (Automation_TrackerEntities _context = new Automation_TrackerEntities())
            {
                string strUsername = Convert.ToString(HttpContext.Current.Session["UserName"]);

                try
                {

                    SqlConnection conObj = new SqlConnection(Constants.ConnectionString);
                    conObj.Open();
                    SqlCommand cmdObj = new SqlCommand(Constants.sp_FinalReport, conObj);
                    cmdObj.CommandType = CommandType.StoredProcedure;

                    cmdObj.Parameters.AddWithValue("@fromdate", dtFromdate != "" ? Convert.ToDateTime(dtFromdate) : Convert.ToDateTime("1/1/1900"));
                    cmdObj.Parameters.AddWithValue("@todate", dtTodate != "" ? Convert.ToDateTime(dtTodate) : Convert.ToDateTime("1/1/1900"));
                    SqlDataAdapter adapter1 = new SqlDataAdapter(cmdObj);
                    adapter1.Fill(dt);
                    conObj.Close();

                }
                catch (Exception e)
                {
                    ExceptionDispatchInfo.Capture(e).Throw();
                }
                return dt;
            }
        }

        public string  CheckFinyear(string dtFromdate, string dtTodate)
        {
            DataTable dt = new DataTable();
            string strRes = string.Empty;
            using (Automation_TrackerEntities _context = new Automation_TrackerEntities())
            {
                string strUsername = Convert.ToString(HttpContext.Current.Session["UserName"]);

                try
                {
                    SqlDataReader reader;
                    SqlConnection conObj = new SqlConnection(Constants.ConnectionString);
                    conObj.Open();
                    SqlCommand cmdObj = new SqlCommand(Constants.sp_Chkfinyear, conObj);
                    cmdObj.CommandType = CommandType.StoredProcedure;

                    cmdObj.Parameters.AddWithValue("@fromdate", dtFromdate != "" ? Convert.ToDateTime(dtFromdate) : Convert.ToDateTime("1/1/1900"));
                    cmdObj.Parameters.AddWithValue("@todate", dtTodate != "" ? Convert.ToDateTime(dtTodate) : Convert.ToDateTime("1/1/1900"));

                    reader = cmdObj.ExecuteReader();
                    while (reader.Read())
                    {
                        strRes = reader.GetValue(0).ToString();
                    }
                }
                catch (Exception e)
                {
                    ExceptionDispatchInfo.Capture(e).Throw();
                }
                return strRes;
            }
        }

        #region Get BUH Names
        public List<SelectListItem> LoadFiscalYear(string strFntype = "FiscalYear")
        {
            using (Automation_TrackerEntities _context = new Automation_TrackerEntities())
            {
                DataTable dt = new DataTable();

                SqlConnection conObj = new SqlConnection(Constants.ConnectionString);
                conObj.Open();
                SqlCommand cmdObj = new SqlCommand();
                cmdObj = new SqlCommand(Constants.sp_fiscalYear, conObj);
                cmdObj.CommandType = CommandType.StoredProcedure;
                cmdObj.Parameters.AddWithValue("@fntype", strFntype);
                SqlDataAdapter adapter1 = new SqlDataAdapter(cmdObj);

                adapter1.Fill(dt);
                conObj.Close();



                var list_BUH = (from DataRow row in dt.Rows

                                select new SelectListItem
                                {
                                    Text = row["text"].ToString(),
                                    Value = row["Value"].ToString()
                                }).ToList();
                return list_BUH;
            }

        }
        #endregion


        public DataTable SearchPage()
        {
            DataTable dt = new DataTable();
            using (Automation_TrackerEntities _context = new Automation_TrackerEntities())
            {
                string strUsername = Convert.ToString(HttpContext.Current.Session["UserName"]);

                try
                {

                    SqlConnection conObj = new SqlConnection(Constants.ConnectionString);
                    conObj.Open();
                    SqlCommand cmdObj = new SqlCommand(Constants.sp_SearchPage, conObj);
                    cmdObj.CommandType = CommandType.StoredProcedure;
                   
                    SqlDataAdapter adapter1 = new SqlDataAdapter(cmdObj);
                    adapter1.Fill(dt);
                    conObj.Close();

                }
                catch (Exception e)
                {
                    ExceptionDispatchInfo.Capture(e).Throw();
                }
                return dt;
            }
        }
        

    }
}
