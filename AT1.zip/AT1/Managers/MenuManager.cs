﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AT.DAL;
using System.Web;
using System.Web.Mvc;
using System.Web.Routing;

namespace AT.BAL.Managers
{
    public class MenuManager : IUserMenuService
    {
        public void GetSideMenu()
        {

            using (Automation_TrackerEntities _context = new Automation_TrackerEntities())
            {

                string menuName = string.Empty;
                string subMenu = string.Empty;
                string oldMenuName = string.Empty;
                string menuDiv = string.Empty;

                int count = 0;
                int menuCount = 0;
                var httpContext = new HttpContextWrapper(System.Web.HttpContext.Current);
                var menuList = _context.SP_Get_Menu_Details(HttpContext.Current.Session["UserName"].ToString()).ToList();
                var urlHelper = new UrlHelper(new RequestContext(httpContext, new RouteData()));
                for (int i = 0; i < menuList.Count; i++)
                {
                    string url = string.Empty;
                    menuName = menuList[i].MENU_NAME;
                    if (menuList[i].URL.ToString().Contains("/"))
                    {
                        string[] arry = menuList[i].URL.Split('/'); ;
                        url = urlHelper.Action(arry[1], arry[0], new RouteValueDictionary());
                    }

                    if (count == 0)
                    {
                        menuCount = menuList.Where(x => x.MENU_NAME == menuName).Select(x => x.MENU_NAME).Count();
                        menuDiv += "<li class='treeview'>";
                    }
                    subMenu = menuList[i].SUB_MENU_NAME;
                    if (menuName != oldMenuName)
                    {
                        count = menuCount;
                        menuDiv += "<a href='#'><i class='fa fa-dashboard'></i> <span style='color:#5bc0de;'>" + menuName + "</span> <span class='pull-right-container'>   <i class='fa fa-angle-left pull-right'></i> </span> </a>";
                        menuDiv += "<ul class='treeview-menu' >";
                    }
                    if (subMenu != null && subMenu != string.Empty)
                    {
                        menuDiv += "<li><a href=" + url + "><i class='fa fa-circle-o'></i>" + subMenu + "</a></li>";
                    }
                    count = count - 1;
                    if (count == 0)
                    {
                        menuDiv += "</ul>";
                        menuDiv += "</li>";
                    }
                    oldMenuName = menuName;
                }
                HttpContext.Current.Session["UserMenu"] = menuDiv;

            }
        }



        public string GetSideMenustring()
        {

            using (Automation_TrackerEntities _context = new Automation_TrackerEntities())
            {

                string menuName = string.Empty;
                string subMenu = string.Empty;
                string oldMenuName = string.Empty;
                string menuDiv = string.Empty;

                int count = 0;
                int menuCount = 0;
                var httpContext = new HttpContextWrapper(System.Web.HttpContext.Current);
                var menuList = _context.SP_Get_Menu_Details(System.Environment.UserName.ToString()).ToList();
                var urlHelper = new UrlHelper(new RequestContext(httpContext, new RouteData()));
                for (int i = 0; i < menuList.Count; i++)
                {
                    string url = string.Empty;
                    menuName = menuList[i].MENU_NAME;
                    if (menuList[i].URL.ToString().Contains("/"))
                    {
                        string[] arry = menuList[i].URL.Split('/'); ;
                        url = urlHelper.Action(arry[1], arry[0], new RouteValueDictionary());
                    }

                    if (count == 0)
                    {
                        menuCount = menuList.Where(x => x.MENU_NAME == menuName).Select(x => x.MENU_NAME).Count();
                        menuDiv += "<li class='treeview'>";
                    }
                    subMenu = menuList[i].SUB_MENU_NAME;
                    if (menuName != oldMenuName)
                    {
                        count = menuCount;
                        menuDiv += "<a href='#'><i class='fa fa-dashboard'></i> <span style='color:#5bc0de;'>" + menuName + "</span> <span class='pull-right-container'>   <i class='fa fa-angle-left pull-right'></i> </span> </a>";
                        menuDiv += "<ul class='treeview-menu' >";
                    }
                    if (subMenu != null && subMenu != string.Empty)
                    {
                        menuDiv += "<li><a href=" + url + "><i class='fa fa-circle-o'></i>" + subMenu + "</a></li>";
                    }
                    count = count - 1;
                    if (count == 0)
                    {
                        menuDiv += "</ul>";
                        menuDiv += "</li>";
                    }
                    oldMenuName = menuName;
                }
                HttpContext.Current.Session["UserMenu"] = menuDiv;
                return menuDiv;

            }
        }


        public void saveSessiondetails()
        
        {

            using (Automation_TrackerEntities _context = new Automation_TrackerEntities())
            {
                 
                 
                var ACCESS_TYPE = (from user in _context.AT_USER_ACCESS
                               where user.USER_NTLG == System.Environment.UserName.ToString()
                               select new
                               {
                                   user.ACCESS_TYPE
                               }
                                                           ).FirstOrDefault();


                HttpContext.Current.Session["ACCESS_TYPE"] = ACCESS_TYPE.ACCESS_TYPE; 
            }
        }

    }
}
