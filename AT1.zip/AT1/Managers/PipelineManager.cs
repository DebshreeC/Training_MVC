﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using AT.DAL;
using System.Data.SqlClient;
using AT.BAL.Generics;
using System.Web;
using System.Runtime.ExceptionServices;
using AT.BAL.ViewModel;

namespace AT.BAL.Managers
{
    public class PipelineManager : IPipelineService
    {
        InProgressManager objI = new InProgressManager();
        public DataTable getOpenProject(string strStatus, string strFntype)
        {
            DataTable dt = new DataTable();
            using (Automation_TrackerEntities _context = new Automation_TrackerEntities())
            {
                string strUsername = Convert.ToString(HttpContext.Current.Session["UserName"]);

                try
                {

                    SqlConnection conObj = new SqlConnection(Constants.ConnectionString);
                    conObj.Open();
                    SqlCommand cmdObj = new SqlCommand(Constants.sp_openprojectdetails, conObj);
                    cmdObj.CommandType = CommandType.StoredProcedure;
                    cmdObj.Parameters.AddWithValue("@status", strStatus);
                    cmdObj.Parameters.AddWithValue("@fntype", strFntype);
                    cmdObj.Parameters.AddWithValue("@userid", strUsername);

                    SqlDataAdapter adapter1 = new SqlDataAdapter(cmdObj);
                    adapter1.Fill(dt);
                    conObj.Close();

                }
                catch (Exception e)
                {
                    ExceptionDispatchInfo.Capture(e).Throw();
                }
                return dt;
            }
        }

        public DataTable ATADDEditProject(int strProjectID, string strStatus, string DbCondition)
        {
            return (objI.ATADDEditProject(strProjectID, strStatus, DbCondition));
        }

        #region AllotToCoder
        public void TechCouncilapproval(string listOfAccounts, string strStatus, string strReason)
        {
            string[] array = listOfAccounts.Split(',').Select(x => x.Trim()).ToArray();
            using (Automation_TrackerEntities _context = new Automation_TrackerEntities())
            {
                if (array[0].ToString() == "Rejected")
                {
                    string userName = HttpContext.Current.Session["UserName"].ToString();
                    _context.Track_Details.Where(x => array.Contains(x.Project_Unique_ID.ToString())).ToList().ForEach(x =>
                    { x.Status = array[0]; x.Reason_for_Rejection = strReason; x.rejectedby = userName; x.Rejected_Date = DateTime.Now; });
                    _context.SaveChanges();

                }
                else
                {
                    string userName = HttpContext.Current.Session["UserName"].ToString();
                    _context.Track_Details.Where(x => array.Contains(x.Project_Unique_ID.ToString())).ToList().ForEach(x =>
                    { x.Status = array[0]; x.Approved_BY = userName; x.Approved_Rejected_Date = DateTime.Now; });
                    _context.SaveChanges();
                }
            }
        }
        #endregion

        #region AllotToCoder
        public void PipelineEditApproval(int Project_Unique_ID, string strResourceName, string strRequiredResource, string strPriority, string strProjectStartDate)
        {

            using (Automation_TrackerEntities _context = new Automation_TrackerEntities())
            {

                string userName = HttpContext.Current.Session["UserName"].ToString();
                var _tr = _context.Track_Details.Where(x => x.Project_Unique_ID == Project_Unique_ID).SingleOrDefault();
                if (_tr != null)
                {
                    _tr.Priority = strPriority;
                    _tr.Project_Start_Date = Convert.ToDateTime(strProjectStartDate);
                    _tr.Resource_Name = strResourceName;
                    _tr.Requiredresource = Convert.ToInt32(strRequiredResource);
                    _tr.Status = "In-Progress";
                }
                _context.SaveChanges();

            }
        }
        #endregion


        #region Pipeline OpenSave

        public void PipeLineSave(string listOfAccounts, string strStatus, string strReason)
        {
            string[] array = listOfAccounts.Split(',').Select(x => x.Trim()).ToArray();
            using (Automation_TrackerEntities _context = new Automation_TrackerEntities())
            {
                if (array[0].ToString() == "Open")
                {
                    string userName = HttpContext.Current.Session["UserName"].ToString();
                    _context.Track_Details.Where(x => array.Contains(x.Project_Unique_ID.ToString())).ToList().ForEach(x =>
                    { x.Status = array[0]; });
                    _context.SaveChanges();
                }
                else
                {
                    string userName = HttpContext.Current.Session["UserName"].ToString();
                    _context.Track_Details.Where(x => array.Contains(x.Project_Unique_ID.ToString())).ToList().ForEach(x =>
                    { x.Status = array[0]; x.Reason_for_Rejection = strReason; x.rejectedby = userName; x.Rejected_Date = DateTime.Now; });
                    _context.SaveChanges();
                }

            }
        }
        #endregion

        #region Pipeline OpenSave

        public void PipeLineApprovedSave(string listOfAccounts, string strStatus)
        {
            string[] array = listOfAccounts.Split(',').Select(x => x.Trim()).ToArray();
            using (Automation_TrackerEntities _context = new Automation_TrackerEntities())
            {

                string userName = HttpContext.Current.Session["UserName"].ToString();
                _context.Track_Details.Where(x => array.Contains(x.Project_Unique_ID.ToString())).ToList().ForEach(x =>
                { x.Status = array[0]; });
                _context.SaveChanges();

            }
        }
        #endregion


        #region Pipeline OpenSave

        public void TentativeApprovedSave(string listOfAccounts, string strStatus)
        {
            string[] array = listOfAccounts.Split(',').Select(x => x.Trim()).ToArray();
            using (Automation_TrackerEntities _context = new Automation_TrackerEntities())
            {

                string userName = HttpContext.Current.Session["UserName"].ToString();
                _context.Track_Details.Where(x => array.Contains(x.Project_Unique_ID.ToString())).ToList().ForEach(x =>
                { x.Status = array[0]; });
                _context.SaveChanges();

            }
        }
        #endregion

        #region Inprogress UATSave

        public void inprogressSave(string listOfAccounts, string strStatus)
        {
            string[] array = listOfAccounts.Split(',').Select(x => x.Trim()).ToArray();
            using (Automation_TrackerEntities _context = new Automation_TrackerEntities())
            {

                string userName = HttpContext.Current.Session["UserName"].ToString();
                _context.Track_Details.Where(x => array.Contains(x.Project_Unique_ID.ToString())).ToList().ForEach(x =>
                { x.Status = array[0]; x.LIVE_Release_Date = DateTime.Now; });
                _context.SaveChanges();

            }
        }
        #endregion

        #region Inprogress LiveSave

        public void inprogressLiveSave(string listOfAccounts, string strStatus)
        {
            string[] array = listOfAccounts.Split(',').Select(x => x.Trim()).ToArray();
            using (Automation_TrackerEntities _context = new Automation_TrackerEntities())
            {

                string userName = HttpContext.Current.Session["UserName"].ToString();
                _context.Track_Details.Where(x => array.Contains(x.Project_Unique_ID.ToString())).ToList().ForEach(x =>
                { x.Status = array[0]; });
                _context.SaveChanges();

            }
        }
        #endregion


        public List<ViewModel.EstDetails> getESTDetails(string Poject_id)
        {
            DataTable dt = new DataTable();
            using (Automation_TrackerEntities _context = new Automation_TrackerEntities())
            {

                SqlConnection conObj = new SqlConnection(Constants.ConnectionString);
                conObj.Open();
                SqlCommand cmdObj = new SqlCommand(Constants.sp_ESTDetails, conObj);
                cmdObj.CommandType = CommandType.StoredProcedure;

                cmdObj.Parameters.AddWithValue("@Project_Unique_ID", Poject_id);

                SqlDataAdapter adapter1 = new SqlDataAdapter(cmdObj);
                adapter1.Fill(dt);
                conObj.Close();

                return (from DataRow row in dt.Rows

                        select new EstDetails
                        {
                            strResourecename = Convert.ToString(row["Resource_Name"]),
                            Est_Saving_Desc = Convert.ToString(row["Est_Saving_Desc"]),
                            strEst_dollar = Convert.ToString(row["Est_Dollar_Saving"]),
                            strEst_Quality = Convert.ToString(row["Est_Quality_Impv_percent"]),
                            strEst_Prod = Convert.ToString(row["Est_Prod_Impv_percent"]),
                            strEst_hours = Convert.ToString(row["Est_Hours_saved_FTE"]),
                            strEst_FTE = Convert.ToString(row["Est_FTE_Saving"]),
                            strEst_Excel = Convert.ToString(row["Est_Excel_Saving"])

                        }).ToList();

            }
        }


        public List<ViewModel.ACTDetails> getACTDetails(string Poject_id)
        {
            DataTable dt = new DataTable();
            using (Automation_TrackerEntities _context = new Automation_TrackerEntities())
            {

                SqlConnection conObj = new SqlConnection(Constants.ConnectionString);
                conObj.Open();
                SqlCommand cmdObj = new SqlCommand(Constants.sp_ACTProject, conObj);
                cmdObj.CommandType = CommandType.StoredProcedure;
                cmdObj.Parameters.AddWithValue("@Project_Unique_ID", Poject_id);
                SqlDataAdapter adapter1 = new SqlDataAdapter(cmdObj);
                adapter1.Fill(dt);
                conObj.Close();

                return (from DataRow row in dt.Rows

                        select new ACTDetails
                        {
                            ACT_Saving_Desc = Convert.ToString(row["Act_Saving_Desc"]),
                            strACT_dollar = Convert.ToString(row["Act_Dollar_Saving"]),
                            strACT_Quality = Convert.ToString(row["Act_Quality_Impv_percent"]),
                            strACT_Prod = Convert.ToString(row["Act_Prod_Impv_percent"]),
                            strACT_hours = Convert.ToString(row["Act_Hours_saved_FTE"]),
                            strACT_FTE = Convert.ToString(row["Act_FTE_Saving"]),
                            strACT_Excel = Convert.ToString(row["Act_Excel_Saving"])

                        }).ToList();

            }
        }

        public List<ViewModel.EstDetails> getResourceUpdatedata(string Poject_id)
        {
            DataTable dt = new DataTable();
            using (Automation_TrackerEntities _context = new Automation_TrackerEntities())
            {

                SqlConnection conObj = new SqlConnection(Constants.ConnectionString);
                conObj.Open();
                SqlCommand cmdObj = new SqlCommand(Constants.sp_UpdateEmpname, conObj);
                cmdObj.CommandType = CommandType.StoredProcedure;

                cmdObj.Parameters.AddWithValue("@Project_Unique_ID", Poject_id);

                SqlDataAdapter adapter1 = new SqlDataAdapter(cmdObj);
                adapter1.Fill(dt);
                conObj.Close();

                return (from DataRow row in dt.Rows

                        select new EstDetails
                        {
                            emp_id = Convert.ToString(row["emp_id"]),
                            Emp_name = Convert.ToString(row["name"]),
                            

                        }).ToList();

            }
        }

    }
}
