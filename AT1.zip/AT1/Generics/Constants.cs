﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AT.BAL.Generics
{
    public class Constants
    { 
        public const string sp_openprojectdetails = "usp_get_projectdetails";
        public static string ConnectionString = System.Configuration.ConfigurationSettings.AppSettings["Con"].ToString();
        public const string sp_Inporgress = "usp_get_Inprogressprojdetails";
        public const string sp_getdatabyProjectid = "usp_get_projectIDdetails";
        public const string sp_ADDProjectid = "usp_get_projectIDADDdetails"; 
        public const string sp_DynamicADDEdit = "usp_get_Dynamicproject";
        public const string sp_Summary = "usp_get_Summary";
        public const string sp_FTEReport = "usp_get_FTEProjectDetails";
        public const string sp_FinalReport = "usp_get_Finalsheet";
        public const string sp_Resourcename = "usp_get_Resourcename";
        public const string sp_BUHname = "usp_get_BUHname";
        public const string sp_BUHname1 = "usp_get_BUHname1";
        public const string sp_Manager = "usp_get_ManagerName";
        public const string sp_Manager1 = "usp_get_ManagerName1";
        public const string sp_Benifitsignedby = "usp_get_Signoffby";
        public const string sp_Chkfinyear = "usp_chk_financialyear";
        public const string sp_Overallsaving= "usp_get_overallSaving";
        public const string sp_BUHAllProject = "usp_get_BUHAllproject";
        public const string sp_ESTDetails = "usp_get_projestdetails";
        public const string sp_UpdateEmpname = "usp_get_updateResource";
        public const string sp_ChkAddition = "usp_chk_alladdition";
        public const string sp_getempName = "usp_get_empname";
        public const string sp_fiscalYear = "usp_get_fiscalYear";
        public const string sp_SearchPage = "usp_get_SearchProject";
        public const string sp_ACTProject = "usp_get_ACTprojestdetails";
        
        
    }
}
