﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AT.DAL;

namespace AT.BAL.Generics
{
    public class DynamicColumn
    {
        public static string getColname(string strColname)
        {
            string strRes = string.Empty;
            using (Automation_TrackerEntities _context = new Automation_TrackerEntities())
            {
                var s = (from r in _context.Column_List where r.Column_Name == strColname select new {r.Display_Name }).FirstOrDefault();
                if (s != null)
                {
                    strRes = s.Display_Name;
                }
            }
            return strRes;
        }
    }
}
