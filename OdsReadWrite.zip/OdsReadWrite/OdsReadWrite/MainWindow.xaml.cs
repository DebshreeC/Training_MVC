﻿using System.Windows;

namespace OdsReadWrite
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
    }
}
