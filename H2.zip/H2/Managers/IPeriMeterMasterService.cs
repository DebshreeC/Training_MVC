﻿using CBIplus.BAL.Managers;
using CBIplus.BAL.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.Mvc;

namespace CBIplus.BAL.Managers
{
    public interface IPeriMeterMasterService
    {
        void SaveMasterData(PerimeterMasterModel MasterModel);
        List<SelectListItem> GetFacilityNames();
    }
}
