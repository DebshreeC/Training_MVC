﻿using CBIplus.BAL.Generics;
using CBIplus.BAL.ViewModels;
using CBIplus.DAL;
using Microsoft.Win32.SafeHandles;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using System.Web.Mvc;
using System.IO;
using System.Globalization;


namespace CBIplus.BAL.Managers
{
    public class MedDataAllotmentManager : IMedDataAllotmentManager
    {
        
        #region Coder Details

       

        #region Get status Names

        public List<SelectListItem> getStatusNames(string taskName)
        {
            using (CBI_Anes_HighEntities _context = new CBI_Anes_HighEntities())
            {
                //string a = CryptoGraphy.Encrypt("MA006370066");
                int projectId = Convert.ToInt32(HttpContext.Current.Session[Constants.ProjectId]);
                int taskId = _context.tbl_TASK_TABLE.Where(x => x.TASK_NAME == taskName && x.PROJECT_ID == projectId).Select(x => x.TASK_ID).FirstOrDefault();
                var list = (from status in _context.tbl_STATUS_MASTER
                            join task in _context.tbl_TASK_TABLE on status.TASK_ID equals task.TASK_ID
                            where status.PROJECT_ID == projectId && task.TASK_ID == taskId
                            select new SelectListItem
                            {
                                Text = status.STATUS_TYPE,
                                Value = status.STATUS_ID.ToString()
                            }).ToList();
                return list;
            }
        }
        #endregion

        #region Get Facility Names
        public List<SelectListItem> getFacilityNames(string status)
        {
            using (CBI_Anes_HighEntities _context = new CBI_Anes_HighEntities())
            {
                int projectId = Convert.ToInt32(HttpContext.Current.Session[Constants.ProjectId]);
                return (from facility in _context.tbl_IMPORT_TABLE
                        where facility.BATCH_STATUS == status && facility.PROJECT_ID == projectId
                        select new SelectListItem
                        {
                            Text = facility.First_Name,
                            Value = facility.FACILITY
                        }).ToList();
            }
        }
        #endregion

        //Auto allotment-- by subhaja 23/05/2017
        #region Get Locations

        public List<SelectListItem> getLocationNames()
        {
            using (CBI_Anes_HighEntities _context = new CBI_Anes_HighEntities())
            {
                int projectId = Convert.ToInt32(HttpContext.Current.Session[Constants.ProjectId]);
                return (from location in _context.tbl_LOCATION
                        where location.PROJECT_ID == projectId
                        select new SelectListItem
                        {
                            Text = location.LOCATION,
                            Value = location.LOCATION
                        }).ToList();
            }
        }
        #endregion

        #region Get Batch Names
        public List<SelectListItem> getBatchNamesBULK(string location, string fromDate, string toDate)
        {
            using (CBI_Anes_HighEntities _context = new CBI_Anes_HighEntities())
            {
                DateTime fupdate = Convert.ToDateTime(fromDate);
                DateTime ttupdate = Convert.ToDateTime(toDate);
                DateTime tupdate = ttupdate.AddDays(1);

                int projectId = Convert.ToInt32(HttpContext.Current.Session[Constants.ProjectId]);
                int practiceid = Convert.ToInt32(HttpContext.Current.Session[Constants.PracticeID]); 
                var cc=(from batName in _context.tbl_IMPORT_TABLE
                        where batName.PROJECT_ID == projectId && batName.BATCH_STATUS == "Fresh" && batName.LOCATION == location && batName.PRACTICE_ID == practiceid && (batName.UPLOAD_DATE >= fupdate && batName.UPLOAD_DATE <= tupdate)
                        select new SelectListItem
                        {
                            Text = batName.BATCH_NAME,
                            Value = batName.BATCH_NAME
                        }).Distinct().ToList();
                foreach (var item in cc)
                {
                    item.Text = CryptoGraphy.Decrypt(item.Text);
                }
                var uniqueItems = cc.GroupBy(s => s.Value, i => i, (k, item) => new SelectListItem
                {
                    Text = item.First().Text,
                    Value = k,
                }).ToList();
                return uniqueItems;
            }
        }
        #endregion
        //Auto allotment-- by subhaja 23/05/2017
        #region Get Batch Names
        public List<SelectListItem> getBatchNames(string facility)
        {
            using (CBI_Anes_HighEntities _context = new CBI_Anes_HighEntities())
            {
                int projectId = Convert.ToInt32(HttpContext.Current.Session[Constants.ProjectId]);
                return (from batName in _context.tbl_IMPORT_TABLE
                        where batName.FACILITY == facility && batName.PROJECT_ID == projectId
                        select new SelectListItem 
                        {
                            Text =batName.BATCH_NAME,
                            Value = batName.BATCH_ID.ToString()
                        }).ToList();
            }
        }
        #endregion

        #region Get Coder Names
        public List<SelectListItem> getCoderNames(string tl, string user,string location)
        {
            int projectId = Convert.ToInt32(HttpContext.Current.Session[Constants.ProjectId]);
            string userName = Convert.ToString(HttpContext.Current.Session[Constants.UserName]);
            int practiceId = Convert.ToInt32(HttpContext.Current.Session[Constants.PracticeID]);
           
            using (CBI_Anes_HighEntities _context = new CBI_Anes_HighEntities())
            {
                var userLocation = (from userAccess in _context.tbl_USER_ACCESS
                                    where userAccess.PRACTICE_ID == practiceId && userAccess.PROJECT_ID == projectId && userAccess.USER_NTLG == userName
                                    select new AllotmentModel
                                    {
                                        Location=userAccess.Location

                                    }).FirstOrDefault();

                if (userLocation.Location.Contains(location))
                {
                    var data = (from coder in _context.tbl_USER_ACCESS
                                where coder.PROJECT_ID == projectId && (coder.ACCESS_TYPE == tl || coder.ACCESS_TYPE == user) && coder.Location == location && coder.PRACTICE_ID == practiceId && coder.TL_NTLG == userName
                                select new SelectListItem { Text = coder.USER_NTLG, Value = coder.USER_NTLG }).Distinct().ToList();
                    var uniqueItems = data.GroupBy(s => s.Value, i => i, (k, item) => new SelectListItem
                    {
                        Text = item.First().Text,
                        Value = k,
                    }).ToList();
                    return uniqueItems;
                }
                else
                {
                    var data = (from coder in _context.tbl_USER_ACCESS
                                where coder.PROJECT_ID == projectId && (coder.ACCESS_TYPE == tl || coder.ACCESS_TYPE == user) && coder.Location == location && coder.PRACTICE_ID == practiceId
                                select new SelectListItem { Text = coder.USER_NTLG, Value = coder.USER_NTLG }).Distinct().ToList();
                    var uniqueItems = data.GroupBy(s => s.Value, i => i, (k, item) => new SelectListItem
                    {
                        Text = item.First().Text,
                        Value = k,
                    }).ToList();
                    return uniqueItems;
                }
            }
        }
        #endregion
        //Auto allotment-- by subhaja 23/05/2017
        #region get TL names
        public int availableCount(string encounter, string batch, string loc)
        {
            using (CBI_Anes_HighEntities _context = new CBI_Anes_HighEntities())
            {
                int projectId = Convert.ToInt32(HttpContext.Current.Session[Constants.ProjectId]);
                string userNtlg = HttpContext.Current.Session[Constants.UserName].ToString();
                string Location = HttpContext.Current.Session[Constants.LocationName].ToString();
                int practiceId = Convert.ToInt32(HttpContext.Current.Session[Constants.PracticeID]);
                if (loc == "" || loc == null)
                {
                    loc = Location;
                }                
                int AvilableCount = 0;
                if (batch == ""||batch==null)
                {
                    var importCount = _context.tbl_IMPORT_TABLE.Where(x => x.PROJECT_ID == projectId && x.BATCH_STATUS == "fresh" && x.ENCOUNTER_TYPE == encounter && x.PRACTICE_ID == practiceId && x.LOCATION == loc).ToList();
                    AvilableCount = importCount.Count().ToString() == "0" ? 0 : importCount.Count();
                }
                else
                {
                    batch = CryptoGraphy.Encrypt(batch);
                    var importCount = _context.tbl_IMPORT_TABLE.Where(x => x.PROJECT_ID == projectId && x.BATCH_STATUS == "fresh" && x.ENCOUNTER_TYPE == encounter && x.PRACTICE_ID == practiceId && x.LOCATION == loc && x.BATCH_NAME==batch).ToList();
                    AvilableCount = importCount.Count().ToString() == "0" ? 0 : importCount.Count();
                }
                
                return AvilableCount;
            }
        }
        public List<SelectListItem> getTLNames(string location)
        {
            int projectId = Convert.ToInt32(HttpContext.Current.Session[Constants.ProjectId]);
            string userName = Convert.ToString(HttpContext.Current.Session[Constants.UserName]);
            int practiceId = Convert.ToInt32(HttpContext.Current.Session[Constants.PracticeID]);

            using (CBI_Anes_HighEntities _context = new CBI_Anes_HighEntities())
            {
                var userLocation = (from userAccess in _context.tbl_USER_ACCESS
                                    where userAccess.PRACTICE_ID == practiceId && userAccess.PROJECT_ID == projectId && userAccess.USER_NTLG == userName
                                    select new AllotmentModel
                                    {
                                        Location = userAccess.Location

                                    }).FirstOrDefault();

                if (userLocation.Location.Contains(location))
                {
                    var data = (from coder in _context.tbl_USER_ACCESS
                                where coder.PROJECT_ID == projectId && coder.Location == location && coder.PRACTICE_ID == practiceId && coder.ACCESS_TYPE=="Coder-TL"
                                select new SelectListItem { Text = coder.TL_NTLG, Value = coder.TL_NTLG }).Distinct().ToList();
                    var uniqueItems = data.GroupBy(s => s.Value, i => i, (k, item) => new SelectListItem
                    {
                        Text = item.First().Text,
                        Value = k,
                    }).ToList();
                    return uniqueItems;
                }
                else
                {
                    var data = (from coder in _context.tbl_USER_ACCESS
                                where coder.PROJECT_ID == projectId && coder.Location == location && coder.PRACTICE_ID == practiceId && coder.ACCESS_TYPE == "Coder-TL"
                                select new SelectListItem { Text = coder.TL_NTLG, Value = coder.TL_NTLG }).Distinct().ToList();
                    var uniqueItems = data.GroupBy(s => s.Value, i => i, (k, item) => new SelectListItem
                    {
                        Text = item.First().Text,
                        Value = k,
                    }).ToList();
                    return uniqueItems;
                }
            }
        }
        #endregion
        #region Get Codernames for the TL

        public List<SelectListItem> GetCoderforSelectedTL(string tl, string location)
        {
            int projectId = Convert.ToInt32(HttpContext.Current.Session[Constants.ProjectId]);
            string userName = Convert.ToString(HttpContext.Current.Session[Constants.UserName]);
            int practiceId = Convert.ToInt32(HttpContext.Current.Session[Constants.PracticeID]);
            string[] ACCESS_id = new string[] { "Coder-TL", "Coder" };

            using (CBI_Anes_HighEntities _context = new CBI_Anes_HighEntities())
            {
                //var userLocation = (from userAccess in _context.tbl_USER_ACCESS
                //                    where userAccess.PRACTICE_ID == practiceId && userAccess.PROJECT_ID == projectId && userAccess.USER_NTLG == userName
                //                    select new AllotmentModel
                //                    {
                //                        Location=userAccess.Location

                //                    }).FirstOrDefault();
                //string location = userLocation.Location;
                
               
                    var data = (from coder in _context.tbl_USER_ACCESS
                                where coder.PROJECT_ID == projectId && coder.Location == location && coder.PRACTICE_ID == practiceId && tl.Contains(coder.TL_NTLG) && ACCESS_id.Contains(coder.ACCESS_TYPE)
                                select new SelectListItem { Text = coder.USER_NTLG, Value = coder.USER_NTLG }).Distinct().ToList();
                    var uniqueItems = data.GroupBy(s => s.Value, i => i, (k, item) => new SelectListItem
                    {
                        Text = item.First().Text,
                        Value = k,
                    }).ToList();
                    return uniqueItems;               
            }
        }
        #endregion



        #region Get Codernames for the TL with access

        public List<SelectListItem> GetCoderforSelectedTL(string tl, string location, string ACCESS_id)
        {
            int projectId = Convert.ToInt32(HttpContext.Current.Session[Constants.ProjectId]);
            string userName = Convert.ToString(HttpContext.Current.Session[Constants.UserName]);
            int practiceId = Convert.ToInt32(HttpContext.Current.Session[Constants.PracticeID]);
            //string[] ACCESS_id = new string[] { "Coder-TL", "Coder" };

            using (CBI_Anes_HighEntities _context = new CBI_Anes_HighEntities())
            {
                //var userLocation = (from userAccess in _context.tbl_USER_ACCESS
                //                    where userAccess.PRACTICE_ID == practiceId && userAccess.PROJECT_ID == projectId && userAccess.USER_NTLG == userName
                //                    select new AllotmentModel
                //                    {
                //                        Location=userAccess.Location

                //                    }).FirstOrDefault();
                //string location = userLocation.Location;


                var data = (from coder in _context.tbl_USER_ACCESS
                            where coder.PROJECT_ID == projectId && coder.Location == location && coder.PRACTICE_ID == practiceId && coder.TL_NTLG == tl && coder.ACCESS_TYPE == ACCESS_id
                            select new SelectListItem { Text = coder.USER_NTLG, Value = coder.USER_NTLG }).Distinct().ToList();
                var uniqueItems = data.GroupBy(s => s.Value, i => i, (k, item) => new SelectListItem
                {
                    Text = item.First().Text,
                    Value = k,
                }).ToList();
                return uniqueItems;
            }
        }
        #endregion
        //Auto allotment-- by subhaja 23/05/2017
        #region BatchWiseFilterAccounts
        public DataTable BatchWiseFilterAccounts(string batchName, string status)
        {
            int projectId = Convert.ToInt32(HttpContext.Current.Session[Constants.ProjectId]);
            string userName = Convert.ToString(HttpContext.Current.Session[Constants.UserName]);
            int practiceId = Convert.ToInt32(HttpContext.Current.Session[Constants.PracticeID]);
            DataSet dsCommon = new DataSet();
            if (HttpContext.Current.Session["CodingAllotment"] == null)
            {
                try
                {
                    dsCommon.Clear();
                    SqlConnection conObj = new SqlConnection(Constants.ConnectionString);
                    conObj.Open();
                    SqlCommand cmdObj = new SqlCommand(Constants.SPCodingAllotment, conObj);
                    cmdObj.CommandType = CommandType.StoredProcedure;
                    cmdObj.Parameters.AddWithValue("@ProjectId", projectId);
                    cmdObj.Parameters.AddWithValue("@User_Ntlg", userName);
                    cmdObj.Parameters.AddWithValue("@PracticeId", practiceId);
                    SqlDataAdapter adapter1 = new SqlDataAdapter(cmdObj);
                    adapter1.Fill(dsCommon);
                    conObj.Close();
                    HttpContext.Current.Session["CodingAllotment"] = dsCommon;
                }
                catch (Exception e)
                {
                    throw e;
                }
            }
            else
            {
                dsCommon = (DataSet)HttpContext.Current.Session["CodingAllotment"];
            }
            if (status == "-- Select --")
            {
                return FilterWithBatchName(dsCommon.Tables[0], batchName);
            }

            return FilterWithBatchName(FilterWithText(dsCommon.Tables[0], status), batchName);
        }
        #endregion

        #region EncounterTypeWiseFilterAccounts
        public DataTable EncounterTypeWiseFilterAccounts(string status, string encounterType)
        {
            int projectId = Convert.ToInt32(HttpContext.Current.Session[Constants.ProjectId]);
            string userName = Convert.ToString(HttpContext.Current.Session[Constants.UserName]);
            int practiceId = Convert.ToInt32(HttpContext.Current.Session[Constants.PracticeID]);
            DataSet dsCommon = new DataSet();
            if (HttpContext.Current.Session["CodingAllotment"] == null)
            {
                try
                {
                    dsCommon.Clear();
                    SqlConnection conObj = new SqlConnection(Constants.ConnectionString);
                    conObj.Open();
                    SqlCommand cmdObj = new SqlCommand(Constants.SPCodingAllotment, conObj);
                    cmdObj.CommandType = CommandType.StoredProcedure;
                    cmdObj.Parameters.AddWithValue("@ProjectId", projectId);
                    cmdObj.Parameters.AddWithValue("@User_Ntlg", userName);
                    cmdObj.Parameters.AddWithValue("@PracticeId", practiceId);
                    SqlDataAdapter adapter1 = new SqlDataAdapter(cmdObj);
                    adapter1.Fill(dsCommon);
                    conObj.Close();
                    HttpContext.Current.Session["CodingAllotment"] = dsCommon;
                }
                catch (Exception e)
                {
                    throw e;
                }
            }
            else
            {
                dsCommon = (DataSet)HttpContext.Current.Session["CodingAllotment"];
            }
            if (status == "-- Select --")
            {
                DataTable DTCodingAlloted = FilterWithEncounterType(dsCommon.Tables[0], encounterType);
                foreach (DataRow row in DTCodingAlloted.Rows)
                {
                    row[2] = CryptoGraphy.Decrypt(row[2].ToString()).ToString();
                    row[4] = CryptoGraphy.Decrypt(row[4].ToString()).ToString();
                    row[5] = CryptoGraphy.Decrypt(row[5].ToString()).ToString();
                    row[6] = CryptoGraphy.Decrypt(row[6].ToString()).ToString();
                    row[7] = CryptoGraphy.Decrypt(row[7].ToString()).ToString();
                    row[8] = CryptoGraphy.Decrypt(row[8].ToString()).ToString();
                    row[9] = CryptoGraphy.Decrypt(row[9].ToString()).ToString();
                    row[10] = CryptoGraphy.Decrypt(row[10].ToString()).ToString();
                    row[12] = CryptoGraphy.Decrypt(row[12].ToString()).ToString();
                }
                return DTCodingAlloted;
            }

            DataTable DTCodingAllotedd = FilterWithEncounterType(FilterWithText(dsCommon.Tables[0], status), encounterType);
            foreach (DataRow row in DTCodingAllotedd.Rows)
            {
                row[2] = CryptoGraphy.Decrypt(row[2].ToString()).ToString();
                row[4] = CryptoGraphy.Decrypt(row[4].ToString()).ToString();
                row[5] = CryptoGraphy.Decrypt(row[5].ToString()).ToString();
                row[6] = CryptoGraphy.Decrypt(row[6].ToString()).ToString();
                row[7] = CryptoGraphy.Decrypt(row[7].ToString()).ToString();
                row[8] = CryptoGraphy.Decrypt(row[8].ToString()).ToString();
                row[9] = CryptoGraphy.Decrypt(row[9].ToString()).ToString();
                row[10] = CryptoGraphy.Decrypt(row[10].ToString()).ToString();
                row[12] = CryptoGraphy.Decrypt(row[12].ToString()).ToString();
            }
            return DTCodingAllotedd;
        }
        #endregion


        #region Get Accoun tDetails
        public DataTable GetAccountDetails(string status, string fromDos, string toDos, string encounterType)
        {
            int projectId = Convert.ToInt32(HttpContext.Current.Session[Constants.ProjectId]);
            string userName = Convert.ToString(HttpContext.Current.Session[Constants.UserName]);
            int practiceId = Convert.ToInt32(HttpContext.Current.Session[Constants.PracticeID]);
            DataSet dsCommon = new DataSet();

            #region "Entiry Framework"
            if (fromDos == "")
            {
                fromDos = null;
            }
            if (toDos == "")
            {
                toDos = null;
            }
            CBI_Anes_HighEntities dbObj = Singleton.Instance;

            List<SqlParameter> Parameter = new List<SqlParameter>();
            dsCommon.Clear();
            Parameter.Add(new SqlParameter("@ProjectId", projectId));
            Parameter.Add(new SqlParameter("@User_Ntlg", userName));
            Parameter.Add(new SqlParameter("@PracticeId", practiceId));
            Parameter.Add(new SqlParameter("@Status", status));
            Parameter.Add(new SqlParameter("@FromDate", fromDos));
            Parameter.Add(new SqlParameter("@ToDate", toDos));
            Parameter.Add(new SqlParameter("@encounterType", encounterType));
            dsCommon = DBExtension.ExecuteDataset(dbObj.Database, Constants.SPCodingAllotment, Parameter);
            HttpContext.Current.Session["CodingAllotment"] = dsCommon;
            #endregion "Entiry Framework"

            //using (CBI_Anes_HighEntities _context = new CBI_Anes_HighEntities())
            //{
            //    try
            //    {
            //        if (fromDos == "")
            //        {
            //            fromDos = null;
            //        }
            //        if (toDos == "")
            //        {
            //            toDos = null;
            //        }

            //        dsCommon.Clear();
            //        SqlConnection conObj = new SqlConnection(Constants.ConnectionString);
            //        conObj.Open();
            //        SqlCommand cmdObj = new SqlCommand(Constants.SPCodingAllotment, conObj);
            //        cmdObj.CommandType = CommandType.StoredProcedure;
            //        cmdObj.Parameters.AddWithValue("@ProjectId", projectId);
            //        cmdObj.Parameters.AddWithValue("@User_Ntlg", userName);
            //        cmdObj.Parameters.AddWithValue("@PracticeId", practiceId);
            //        cmdObj.Parameters.AddWithValue("@Status", status);
            //        cmdObj.Parameters.AddWithValue("@FromDate", fromDos);
            //        cmdObj.Parameters.AddWithValue("@ToDate", toDos);
            //        cmdObj.Parameters.AddWithValue("@encounterType", encounterType);
            //        SqlDataAdapter adapter1 = new SqlDataAdapter(cmdObj);
            //        adapter1.Fill(dsCommon);
            //        conObj.Close();
            //        HttpContext.Current.Session["CodingAllotment"] = dsCommon;
            //    }
            //    catch (Exception e)
            //    {
            //        throw e;
            //    }

            if (dsCommon.Tables[0] != null)
            {
                foreach (DataRow row in dsCommon.Tables[0].Rows)
                {
                    row[2] = CryptoGraphy.Decrypt(row[2].ToString()).ToString();
                    row[4] = CryptoGraphy.Decrypt(row[4].ToString()).ToString();
                    row[5] = CryptoGraphy.Decrypt(row[5].ToString()).ToString();
                    row[6] = CryptoGraphy.Decrypt(row[6].ToString()).ToString();
                    row[7] = CryptoGraphy.Decrypt(row[7].ToString()).ToString();
                    row[8] = CryptoGraphy.Decrypt(row[8].ToString()).ToString();
                    row[9] = CryptoGraphy.Decrypt(row[9].ToString()).ToString();
                    row[10] = CryptoGraphy.Decrypt(row[10].ToString()).ToString();
                    row[12] = CryptoGraphy.Decrypt(row[12].ToString()).ToString();
                }
                return dsCommon.Tables[0];
            }
            else
            {
                return null;
            }
        }
        #endregion

        private DataTable FilterTable(DataTable table, DateTime startDate, DateTime endDate)
        {
            CBI_Anes_HighEntities _context = new CBI_Anes_HighEntities();
            string userName = Convert.ToString(HttpContext.Current.Session[Constants.UserName]);

            int projectId = Convert.ToInt32(HttpContext.Current.Session[Constants.ProjectId]);
            if (projectId==16)
            {
                var Role = _context.tbl_USER_ACCESS.Where(x => x.PROJECT_ID == projectId && x.USER_NTLG == userName).Select(x => x.ACCESS_TYPE).FirstOrDefault();
                if (Role.ToUpper() == "CODER" || Role.ToUpper() == "CODER-TL")
                {
                    var filteredRows =
               from row in table.Rows.OfType<DataRow>()
               where (DateTime)row[5] >= startDate
               where (DateTime)row[5] <= endDate
               select row;
                    var filteredTable = table.Clone();

                    filteredRows.ToList().ForEach(r => filteredTable.ImportRow(r));
                    return filteredTable;
                }
                else
                {
                    var filteredRows =
               from row in table.Rows.OfType<DataRow>()
               where (DateTime)row[4] >= startDate
               where (DateTime)row[4] <= endDate
               select row;
                    var filteredTable = table.Clone();

                    filteredRows.ToList().ForEach(r => filteredTable.ImportRow(r));
                    return filteredTable;
                }
               
            }
            else
            {
                var filteredRows =
                    from row in table.Rows.OfType<DataRow>()
                    where (DateTime)row[3] >= startDate
                    where (DateTime)row[3] <= endDate
                    select row;
                var filteredTable = table.Clone();

                filteredRows.ToList().ForEach(r => filteredTable.ImportRow(r));
                return filteredTable;
            }
        }
        private DataTable FilterWithText(DataTable table, string searchText)
        {
            var filteredRows =
               from row in table.Rows.OfType<DataRow>()
               where (string)row[1] != null && (string)row[1] == searchText

               select row;

            var filteredTable = table.Clone();

            filteredRows.ToList().ForEach(r => filteredTable.ImportRow(r));

            return filteredTable;
        }
        private DataTable FilterWithBatchName(DataTable table, string batchname)
        {
            var filteredRows = from row in table.Rows.OfType<DataRow>() where (string)row[7] != null && (string)row[7] == batchname select row;

            var filteredTable = table.Clone();

            filteredRows.ToList().ForEach(r => filteredTable.ImportRow(r));

            return filteredTable;
        }

        private DataTable FilterWithEncounterType(DataTable table, string encounterType)
        {
            var filteredRows = from row in table.Rows.OfType<DataRow>() where (string)row[11] != null && (string)row[11] == encounterType select row;

            var filteredTable = table.Clone();

            filteredRows.ToList().ForEach(r => filteredTable.ImportRow(r));

            return filteredTable;
        }

        //private DataTable FilterWithTextQCEncType(DataTable table, string encounterType)
        //{
        //    var filteredRows = from row in table.Rows.OfType<DataRow>() where (string)row[10] != null && (string)row[10] == encounterType select row;

        //    var filteredTable = table.Clone();

        //    filteredRows.ToList().ForEach(r => filteredTable.ImportRow(r));

        //    return filteredTable;
        //}

        private DataTable FilterWithTextQC(DataTable table, string searchText)
        {
            IEnumerable<DataRow> filteredRows;
            //if (searchText == "QC Allotted")
            //{
            //    filteredRows =
            // from row in table.Rows.OfType<DataRow>()
            // where (string)row[0] == searchText 

            // select row;
            //}
            //else
            //{
            filteredRows =
         from row in table.Rows.OfType<DataRow>()
         where (string)row[0] == searchText

         select row;
            //}
            var filteredTable = table.Clone();
            filteredRows.ToList().ForEach(r => filteredTable.ImportRow(r));
            return filteredTable;
        }

        public AllotmentModel All(string status = null, string facility = null, string fromDos = null, string toDos = null)
        {
            AllotmentModel model = new AllotmentModel();
            string Locationb = HttpContext.Current.Session[Constants.LocationName].ToString();
            //  model.Status = getStatusNames("Coding_Allotment");
            model.FacilityList = getFacilityNames(status);
            model.LocationList = getLocationNames();
            model.BatchList = getBatchNames(facility);
            model.ProjectId = Convert.ToString(HttpContext.Current.Session[Constants.ProjectId]);

            //Auto allotment-- by subhaja 23/05/2017
            model.BatchListBulk = getBatchNamesBULK(Locationb, fromDos, toDos);
            //Auto allotment-- by subhaja 23/05/2017
            model.AccessType = getAccessType();
            //model.CoderList = getCoderNames();
            // model.QCStatusList = getStatusNames("QC_Allotment");
            model.QCList = getQCNames();
            return model;
        }

        #region
        public string AllotToCoderBulk(AllotmentModel model, string listOfCoders, int ToBeAllocateCount, string location, int NOOFUSERS, string ENCOUNTERTYPE, string BATCHNAME)
        {

            string status = "";
            string modifiedString = listOfCoders.Replace("checkbox,", "");
            string[] array = modifiedString.Split(',').Select(x => x.Trim()).ToArray();
            int arrayLength = array.Length;

            int projectId = Convert.ToInt32(HttpContext.Current.Session[Constants.ProjectId]);
            string userName = Convert.ToString(HttpContext.Current.Session[Constants.UserName]);
            int practiceId = Convert.ToInt32(HttpContext.Current.Session[Constants.PracticeID]);
            DataSet dsCommon = new DataSet();
            if (BATCHNAME == "" || BATCHNAME == null || BATCHNAME == "0")
            {
                BATCHNAME = null;
            }
            else
            {
                BATCHNAME = CryptoGraphy.Encrypt(BATCHNAME);
            }
            if (arrayLength != 0)
            {
                CBI_Anes_HighEntities dbObj = Singleton.Instance;
                List<SqlParameter> Parameter = new List<SqlParameter>();
                dsCommon.Clear();
                Parameter.Add(new SqlParameter("@PROJECTID", projectId));
                Parameter.Add(new SqlParameter("@USERNTLG", userName));
                Parameter.Add(new SqlParameter("@PRACTICEID", practiceId));
                Parameter.Add(new SqlParameter("@USERNTLGS", modifiedString));
                Parameter.Add(new SqlParameter("@NOOFRECORDS", ToBeAllocateCount));
                Parameter.Add(new SqlParameter("@LOCATION", location));
                Parameter.Add(new SqlParameter("@NOOFUSERS", NOOFUSERS));
                Parameter.Add(new SqlParameter("@ENCOUNTERTYPE", ENCOUNTERTYPE));
                Parameter.Add(new SqlParameter("@BATCHNAME", BATCHNAME));
                dsCommon = DBExtension.ExecuteDataset(dbObj.Database, Constants.spBulkCodingAllotment, Parameter);
                if (dsCommon.Tables[0].Rows[0][0].ToString() == "SUCCESS")
                {
                    status = "Success";
                }
                else
                {
                    status = "Fail";
                }

                //try
                //{
                //    dsCommon.Clear();
                //    SqlConnection conObj = new SqlConnection(Constants.ConnectionString);
                //    conObj.Open();
                //    SqlCommand cmdObj = new SqlCommand(Constants.spBulkCodingAllotment, conObj);
                //    cmdObj.CommandType = CommandType.StoredProcedure;
                //    cmdObj.Parameters.AddWithValue("@PROJECTID", projectId);
                //    cmdObj.Parameters.AddWithValue("@USERNTLG", userName);
                //    cmdObj.Parameters.AddWithValue("@PRACTICEID", practiceId);
                //    cmdObj.Parameters.AddWithValue("@USERNTLGS", modifiedString);
                //    cmdObj.Parameters.AddWithValue("@NOOFRECORDS", ToBeAllocateCount);
                //    cmdObj.Parameters.AddWithValue("@LOCATION", location);
                //    cmdObj.Parameters.AddWithValue("@NOOFUSERS", NOOFUSERS);
                //    cmdObj.Parameters.AddWithValue("@ENCOUNTERTYPE", ENCOUNTERTYPE);
                //    cmdObj.Parameters.AddWithValue("@BATCHNAME", BATCHNAME);
                //    SqlDataAdapter adapter1 = new SqlDataAdapter(cmdObj);
                //    adapter1.Fill(dsCommon);
                //    if (dsCommon.Tables[0].Rows[0][0].ToString() == "SUCCESS")
                //    {
                //        //HttpContext.Current.Session[Constants.Records] = dsCommon.Tables[0].Rows[0][0].ToString();
                //        status="Success";
                //    }
                //    else
                //    {
                //        //HttpContext.Current.Session[Constants.Records] = "FAIL";
                //        status = "Fail";
                //    }

                //    conObj.Close();

                //}
                //catch (Exception e)
                //{
                //    throw e;
                //}
            }
            return status;
        }
        #endregion

        public string getAccessType()
        {
            CBI_Anes_HighEntities _context = new CBI_Anes_HighEntities();
            int projectId = Convert.ToInt32(HttpContext.Current.Session[Constants.ProjectId]);
            int practiceId = Convert.ToInt32(HttpContext.Current.Session[Constants.PracticeID]);
            string userName = HttpContext.Current.Session[Constants.UserName].ToString();
            var role = _context.tbl_USER_ACCESS.Where(x => x.PROJECT_ID == projectId && x.PRACTICE_ID==practiceId && x.USER_NTLG == userName && x.TL_NTLG==userName && x.OM_NTLG==userName).Select(x => x.ACCESS_TYPE).FirstOrDefault();
            return role;
        }

        #region AllotToCoder
        public void AllotToCoder(AllotmentModel model, string listOfAccounts)
        {
            string[] array = listOfAccounts.Split(',').Select(x => x.Trim()).ToArray();     
            using (CBI_Anes_HighEntities _context = new CBI_Anes_HighEntities())
            {
                int projectId = Convert.ToInt32(HttpContext.Current.Session[Constants.ProjectId]);
                string userName = HttpContext.Current.Session[Constants.UserName].ToString();

                if (projectId != 17)
                {
                    string[] newArray = array.Select(x => CryptoGraphy.Encrypt(x)).ToArray();
                    _context.tbl_IMPORT_TABLE.Where(x => newArray.Contains(x.ACCOUNT_NO) && x.PROJECT_ID == projectId).ToList().ForEach(x =>
                    { x.ALLOTTED_TO = array[0]; x.BATCH_STATUS = "Coding Allotted"; x.ALLOTTED_BY = userName; x.ALLOTTED_DATE = DateTime.Now; x.LOCATION = array[1]; });
                }
                else
                {
                    _context.tbl_IMPORT_TABLE.Where(x => array.Contains(x.ACCOUNT_NO) && x.PROJECT_ID == projectId).ToList().ForEach(x =>
                    { x.ALLOTTED_TO = array[0]; x.BATCH_STATUS = "Coding Allotted"; x.ALLOTTED_BY = userName;  x.ALLOTTED_DATE = DateTime.Now; });
                }

                _context.SaveChanges();


            }
        }
        #endregion

        #region SubmitAllotment
        public void SubmitAllotment(AllotmentModel model, string listOfAccounts)
        {
            string[] array = listOfAccounts.Split(',');
            int projectId = Convert.ToInt32(HttpContext.Current.Session[Constants.ProjectId]);
            using (CBI_Anes_HighEntities _context = new CBI_Anes_HighEntities())
            {
                for (int i = 0; i < array.Count(); i++)
                {
                    string accountNumber = "";
                    if (projectId == 16)
                    {
                        accountNumber = !array[i].EndsWith("=") ? CryptoGraphy.Encrypt(array[i].Trim()) : array[i];
                    }
                    else
                    {
                        accountNumber = array[i];
                    }

                    var import = _context.tbl_IMPORT_TABLE.Where(x => x.ACCOUNT_NO == accountNumber && x.PROJECT_ID == projectId).FirstOrDefault();
                    if (import != null)
                    {
                        import.BATCH_STATUS = "Coding Allotted";
                        import.ALLOTTED_BY = HttpContext.Current.Session[Constants.UserName].ToString();
                        import.ALLOTTED_DATE = DateTime.Now;

                    }
                }
                _context.SaveChanges();
            }
        }
        #endregion
        #endregion

        #region Re-assigning
        public void Reassign(AllotmentModel model, string listOfAccounts)
        {
            string[] array = listOfAccounts.Split(',').Select(x => x.Trim()).ToArray();
            using (CBI_Anes_HighEntities _context = new CBI_Anes_HighEntities())
            {
                int projectId = Convert.ToInt32(HttpContext.Current.Session[Constants.ProjectId]);
                string[] newArray = array.Select(x => CryptoGraphy.Encrypt(x)).ToArray();
                _context.tbl_IMPORT_TABLE.Where(x => newArray.Contains(x.ACCOUNT_NO) && x.PROJECT_ID == projectId).ToList().ForEach(x =>
                { x.ALLOTTED_TO = null; x.BATCH_STATUS = "FRESH"; x.TL_NAME = array[0]; x.ALLOTTED_BY = null; x.ALLOTTED_DATE = null; x.LOCATION = array[1]; });
                _context.SaveChanges();
            }
        }
        #endregion
        #region GetQcAccountDetailsHighMark

        public DataTable GetQcAccountDetailsHighMark(string status, string fromDos, string toDos, string auditType, string encounterType)
        {
            int projectId = Convert.ToInt32(HttpContext.Current.Session[Constants.ProjectId]);
            string userName = HttpContext.Current.Session[Constants.UserName].ToString();
            int practiceId = Convert.ToInt32(HttpContext.Current.Session[Constants.PracticeID]);
            DataSet dsCommon = new DataSet();
            using (CBI_Anes_HighEntities _context = new CBI_Anes_HighEntities())
            {
                CBI_Anes_HighEntities dbObj = Singleton.Instance;
                List<SqlParameter> Parameter = new List<SqlParameter>();
                dsCommon.Clear();
                Parameter.Add(new SqlParameter("@ProjectId", projectId));
                Parameter.Add(new SqlParameter("@practiceId", practiceId));
                Parameter.Add(new SqlParameter("@Status", status));
                Parameter.Add(new SqlParameter("@CodedFromDate", fromDos));
                Parameter.Add(new SqlParameter("@CodedToDate", toDos));
                Parameter.Add(new SqlParameter("@UserNtlg", userName));
                Parameter.Add(new SqlParameter("@encounterType", encounterType == "--Select--" ? " " : encounterType));
                dsCommon = DBExtension.ExecuteDataset(dbObj.Database, Constants.SpQcAllotmentHighMark, Parameter);
                var tt = dsCommon;

                //try
                //{
                //dsCommon.Clear();
                //SqlConnection conObj = new SqlConnection(Constants.ConnectionString);
                //conObj.Open();
                //SqlCommand cmdObj = new SqlCommand(Constants.SpQcAllotmentHighMark, conObj);
                //cmdObj.CommandType = CommandType.StoredProcedure;
                //cmdObj.Parameters.AddWithValue("@ProjectId", projectId);
                //cmdObj.Parameters.AddWithValue("@practiceId", practiceId);
                //cmdObj.Parameters.AddWithValue("@Status", status);
                //cmdObj.Parameters.AddWithValue("@CodedFromDate", fromDos);
                //cmdObj.Parameters.AddWithValue("@CodedToDate", toDos);
                //cmdObj.Parameters.AddWithValue("@UserNtlg", userName);
                //cmdObj.Parameters.AddWithValue("@encounterType", encounterType == "--Select--" ?" ":encounterType);

                //SqlDataAdapter adapter1 = new SqlDataAdapter(cmdObj);
                //adapter1.Fill(dsCommon);
                //conObj.Close();
                //var tt = dsCommon;



                //DataSet dsBlind = new DataSet();
                ////var Res = listResult.ToList();
                //if (auditType == "Blind Audit")
                //{
                //    if (dsCommon.Tables[0].Rows.Count > 0)
                //    {
                //        string webKey = ConfigurationSettings.AppSettings["SkippedPercentage"].ToString();
                //        Decimal value = Convert.ToDecimal((Convert.ToDecimal(ConfigurationSettings.AppSettings["SkippedPercentage"].ToString()) * dsCommon.Tables[0].Rows.Count) / 100);
                //        //dsCommon = dsCommon.Tables[0].Rows.Cast<System.Data.DataRow>().Take(Convert.ToInt32(value));
                //        DataTable dt = SelectTopDataRow(dsCommon.Tables[0], Convert.ToInt32(value));
                //        dsCommon = null;
                //        dsCommon = new DataSet();
                //        dsCommon.Tables.Add(dt);
                //        //var records = dsCommon.Tables[0].Rows.Cast<System.Data.DataRow>().Take(10);
                //    }
                //}
                //return dsBlind.Tables[0];
                //}
                //catch (Exception e)
                //{
                //    throw e;
                //}

                if (dsCommon.Tables[0] != null)
                {
                    foreach (DataRow row in dsCommon.Tables[0].Rows)
                    {
                        row[2] = CryptoGraphy.Decrypt(row[2].ToString()).ToString();
                        row[4] = CryptoGraphy.Decrypt(row[4].ToString()).ToString();
                        row[5] = CryptoGraphy.Decrypt(row[5].ToString()).ToString();
                        row[6] = CryptoGraphy.Decrypt(row[6].ToString()).ToString();
                        row[7] = CryptoGraphy.Decrypt(row[7].ToString()).ToString();
                        row[8] = CryptoGraphy.Decrypt(row[8].ToString()).ToString();
                        row[9] = CryptoGraphy.Decrypt(row[9].ToString()).ToString();
                        row[10] = CryptoGraphy.Decrypt(row[10].ToString()).ToString();
                        row[12] = CryptoGraphy.Decrypt(row[12].ToString()).ToString();
                        row[13] = CryptoGraphy.Decrypt(row[13].ToString()).ToString();

                    }
                    return dsCommon.Tables[0];
                }
                else
                {
                    return null;
                }
            }
        }

        #endregion

        #region Get Allotment Details

        public void GetAllotmentDetails()
        {
            DataSet dsCommon = new DataSet();
            using (CBI_Anes_HighEntities _context = new CBI_Anes_HighEntities())
            {
                try
                {
                    dsCommon.Clear();
                    SqlConnection conObj = new SqlConnection(Constants.ConnectionString);
                    conObj.Open();
                    SqlCommand cmdObj = new SqlCommand(Constants.AllotedDetails, conObj);
                    cmdObj.CommandType = CommandType.StoredProcedure;
                    cmdObj.Parameters.AddWithValue("@Role", "Coder");
                    SqlDataAdapter adapter1 = new SqlDataAdapter(cmdObj);
                    adapter1.Fill(dsCommon);
                    HttpContext.Current.Response.ClearContent();
                    HttpContext.Current.Response.AddHeader("content-disposition", "attachment;filename=Coding_Allotted_Details.csv");
                    HttpContext.Current.Response.ContentType = "text/csv";
                    StringWriter activityStringWriter = new StringWriter();
                    activityStringWriter.WriteLine("\"Batch Name\",\"Coder Name\",\"No of Acc#' s\"");
                    foreach (DataRow DRow in dsCommon.Tables[0].Rows)
                    {
                        activityStringWriter.WriteLine(string.Format("\"{0}\",\"{1}\",\"{2}\"",CryptoGraphy.Decrypt(DRow[0].ToString()), DRow[1].ToString(), DRow[2].ToString()));
                    }
                    HttpContext.Current.Response.Write(activityStringWriter.ToString());
                    HttpContext.Current.Response.End();
                    conObj.Close();
                }
                catch (Exception e)
                {
                    throw e;
                }
            }
        }
        #endregion

        #region Get QCAllotment Details

        public void GetQCAllotmentDetails()
        {
            DataSet dsCommon = new DataSet();
            using (CBI_Anes_HighEntities _context = new CBI_Anes_HighEntities())
            {
                try
                {
                    dsCommon.Clear();
                    SqlConnection conObj = new SqlConnection(Constants.ConnectionString);
                    conObj.Open();
                    SqlCommand cmdObj = new SqlCommand(Constants.AllotedDetails, conObj);
                    cmdObj.CommandType = CommandType.StoredProcedure;
                    cmdObj.Parameters.AddWithValue("@Role", "QC");
                    SqlDataAdapter adapter1 = new SqlDataAdapter(cmdObj);
                    adapter1.Fill(dsCommon);

                    conObj.Close();
                }
                catch (Exception e)
                {
                    throw e;
                }
            }
        }
        #endregion

        public DataTable SelectTopDataRow(DataTable dt, int count)
        {
            DataTable dtn = dt.Clone();
            for (int i = 0; i < count; i++)
            {
                dtn.ImportRow(dt.Rows[i]);
            }
            return dtn;
        }

        #region  Get QC Details
        public DataTable GetQCAccountDetails(string status, string fromDos, string toDos)
        {
            int projectId = Convert.ToInt32(HttpContext.Current.Session[Constants.ProjectId]);
            string userName = Convert.ToString(HttpContext.Current.Session[Constants.UserName]);
            DataSet dsCommon = new DataSet();
            using (CBI_Anes_HighEntities _context = new CBI_Anes_HighEntities())
            {
                try
                {
                    dsCommon.Clear();
                    SqlConnection conObj = new SqlConnection(Constants.ConnectionString);
                    conObj.Open();
                    SqlCommand cmdObj = new SqlCommand(Constants.SpQcAllotment, conObj);
                    cmdObj.CommandType = CommandType.StoredProcedure;
                    cmdObj.Parameters.AddWithValue("@ProjectId", projectId);
                    cmdObj.Parameters.AddWithValue("@UserNTLG", userName);
                    SqlDataAdapter adapter1 = new SqlDataAdapter(cmdObj);
                    adapter1.Fill(dsCommon);
                    conObj.Close();
                    var tt = dsCommon;
                }
                catch (Exception e)
                {
                    throw e;
                }

                if ((string.IsNullOrEmpty(status) || (status == "-- Select --")) && string.IsNullOrEmpty(fromDos) && string.IsNullOrEmpty(toDos))
                {
                    //return dsCommon.Tables[0];
                    if (dsCommon.Tables[0] != null)
                    {
                        return FilterWithTextQC(dsCommon.Tables[0], "Coded");
                    }
                    else
                    {
                        return null;
                    }
                }
                else if (!string.IsNullOrEmpty(status) && string.IsNullOrEmpty(fromDos) && string.IsNullOrEmpty(toDos))
                {

                    return FilterWithTextQC(dsCommon.Tables[0], status);
                }
                else if (!string.IsNullOrEmpty(status) && !string.IsNullOrEmpty(fromDos) && !string.IsNullOrEmpty(toDos))
                {
                    DateTime fDos = Convert.ToDateTime(fromDos);
                    DateTime tDos = Convert.ToDateTime(toDos);
                    return FilterTable(FilterWithTextQC(dsCommon.Tables[0], status), fDos, tDos);
                }
                else
                {
                    return null;
                }
            }
        }

        #region Get QC status Names

        //public List<SelectListItem> getQCStatusNames()
        //{
        //    using (CBI_Anes_HighEntities _context = new CBI_Anes_HighEntities())
        //    {
        //        int projectId = Convert.ToInt32(HttpContext.Current.Session[Constants.ProjectId]);
        //        string userName=HttpContext.Current.Session[Constants.UserName].ToString();
        //        var list = (from status in _context.tbl_STATUS_MASTER
        //                    join task in _context.tbl_TASK_TABLE on status.TASK_ID equals task.TASK_ID
        //                    where status.PROJECT_ID == projectId && task.TASK_ID == 118
        //                    select new SelectListItem
        //                    {
        //                        Text = status.STATUS_TYPE,
        //                        Value = status.STATUS_ID.ToString()
        //                    }).ToList();
        //        return list;
        //    }
        //}
        #endregion

        #region Allot To QC
        public void AllotToQC(AllotmentModel model, string listOfAccounts)
        {
           
            string[] array = listOfAccounts.Split(',').Select(x => x.Trim()).ToArray();
            int projectId = Convert.ToInt32(HttpContext.Current.Session[Constants.ProjectId]);
            using (CBI_Anes_HighEntities _context = new CBI_Anes_HighEntities())
            {
                string userName = HttpContext.Current.Session[Constants.UserName].ToString();

                if (projectId != 17)
                {
                    string[] newArray = array.Select(x => CryptoGraphy.Encrypt(x)).ToArray();
                    var myList = _context.tbl_IMPORT_TABLE.Where(x => newArray.Contains(x.ACCOUNT_NO) && x.PROJECT_ID == projectId).ToList();
                    var bathIds = myList.Select(x => x.BATCH_ID).ToList();
                    _context.tbl_TRANSACTION.Where(x => bathIds.Contains(x.BATCH_ID) && x.PROJECT_ID == projectId).ToList().ForEach(x => x.QC_BY = userName);
                    myList.ForEach(x =>{ x.QC_ALLOTTED_BY = array[0]; x.BATCH_STATUS = "QC Allotted"; x.QC_ALLOTTED_DATE = DateTime.Now; });
                }
                else
                {
                    var myList = _context.tbl_IMPORT_TABLE.Where(x => array.Contains(x.ACCOUNT_NO) && x.PROJECT_ID == projectId).ToList();
                    var bathIds = myList.Select(x=>x.BATCH_ID).ToList();
                    _context.tbl_TRANSACTION.Where(x => bathIds.Contains(x.BATCH_ID) && x.PROJECT_ID == projectId).ToList().ForEach(x => x.QC_BY = userName);
                    myList.ForEach(x =>{ x.QC_ALLOTTED_BY = array[0]; x.BATCH_STATUS = "QC Allotted";  x.QC_ALLOTTED_DATE = DateTime.Now; });
                }

                _context.SaveChanges();
            }
        }
        #endregion

        #region Get QC Names
        public List<SelectListItem> getQCNames()
        {
            using (CBI_Anes_HighEntities _context = new CBI_Anes_HighEntities())
            {
                int projectId = Convert.ToInt32(HttpContext.Current.Session[Constants.ProjectId]);
                return (from coder in _context.tbl_USER_ACCESS
                        where coder.PROJECT_ID == projectId && (coder.ACCESS_TYPE == "CODER-QC-TL" || coder.ACCESS_TYPE == "CODER-QC")
                        select new SelectListItem
                        {
                            Text = coder.USER_NTLG,
                            Value = coder.USER_ID.ToString()
                        }).ToList();
            }
        }
        #endregion

        #region Submit QC Allotment
        public void SubmitQCAllotment(AllotmentModel model, string listOfAccounts, string auditType = null)
        {
            string[] array = listOfAccounts.Split(',');
            int projectId = Convert.ToInt32(HttpContext.Current.Session[Constants.ProjectId]);
            using (CBI_Anes_HighEntities _context = new CBI_Anes_HighEntities())
            {
                for (int i = 0; i < array.Count(); i++)
                {
                    string accountNumber = "";
                    if (projectId == 16)
                    {
                        accountNumber = !array[i].EndsWith("=") ? CryptoGraphy.Encrypt(array[i].Trim()) : array[i];
                    }
                    else
                    {
                        accountNumber = array[i];
                    }
                    var import = _context.tbl_IMPORT_TABLE.Where(x => x.ACCOUNT_NO == accountNumber && x.PROJECT_ID == projectId).FirstOrDefault();

                    if (import != null)
                    {
                        var transaction = _context.tbl_TRANSACTION.Where(x => x.BATCH_ID == import.BATCH_ID && x.PROJECT_ID == projectId).FirstOrDefault();
                        import.BATCH_STATUS = "QC Allotted";
                        transaction.QC_BY = HttpContext.Current.Session[Constants.UserName].ToString();
                        import.QC_ALLOTTED_BY = array[0];
                        import.QC_ALLOTTED_DATE = DateTime.Now;
                        //transaction.AUDIT_CATEGORY = auditType;

                    }
                }
                _context.SaveChanges();
            }
        }
        #endregion

        #endregion

        #region  ReleaseScreenData
        public DataTable ReleaseScreenData(string fromDate, string toDate, int Auditstatus)
        {
            int projectId = Convert.ToInt32(HttpContext.Current.Session[Constants.ProjectId]);
            string userName = Convert.ToString(HttpContext.Current.Session[Constants.UserName]);
            int practiceId = Convert.ToInt32(HttpContext.Current.Session[Constants.PracticeID]);
            DataSet dsCommon = new DataSet();
            CBI_Anes_HighEntities dbObj = Singleton.Instance;
            List<SqlParameter> Parameter = new List<SqlParameter>();
            dsCommon.Clear();
            Parameter.Add(new SqlParameter("@ProjectId", projectId));
            Parameter.Add(new SqlParameter("@UserNTLG", userName));
            Parameter.Add(new SqlParameter("@practiceId", practiceId));
            Parameter.Add(new SqlParameter("@fromDate", fromDate));
            Parameter.Add(new SqlParameter("@toDate", toDate));
            Parameter.Add(new SqlParameter("@Auditstatus", Auditstatus));

            dsCommon = DBExtension.ExecuteDataset(dbObj.Database, Constants.SpReleaseScreen, Parameter);
            //using (CBI_Anes_HighEntities _context = new CBI_Anes_HighEntities())
            //{
            //    try
            //    {
            //        dsCommon.Clear();
            //        SqlConnection conObj = new SqlConnection(Constants.ConnectionString);
            //        conObj.Open();
            //        SqlCommand cmdObj = new SqlCommand(Constants.SpReleaseScreen, conObj);
            //        cmdObj.CommandType = CommandType.StoredProcedure;
            //        cmdObj.Parameters.AddWithValue("@ProjectId", projectId);
            //        cmdObj.Parameters.AddWithValue("@UserNTLG", userName);
            //        cmdObj.Parameters.AddWithValue("@practiceId", practiceId);
            //        cmdObj.Parameters.AddWithValue("@fromDate", fromDate);
            //        cmdObj.Parameters.AddWithValue("@toDate", toDate);

            //        SqlDataAdapter adapter1 = new SqlDataAdapter(cmdObj);
            //        adapter1.Fill(dsCommon);
            //        conObj.Close();
            //        //var tt = dsCommon;
            //    }
            //    catch (Exception e)
            //    {
            //        throw e;
            //    }
            if (dsCommon.Tables[0] != null)
            {
                foreach (DataRow row in dsCommon.Tables[0].Rows)
                {
                    row[4] = CryptoGraphy.Decrypt(row[4].ToString());
                    row[5] = CryptoGraphy.Decrypt(row[5].ToString());
                    row[6] = CryptoGraphy.Decrypt(row[6].ToString());
                    row[7] = CryptoGraphy.Decrypt(row[7].ToString());
                    row[8] = CryptoGraphy.Decrypt(row[8].ToString());
                }
                return dsCommon.Tables[0];
            }
            else
            {
                return null;
            }
        }
        #endregion

        #region  ReleaseScreenDatawithbatchname
        public DataTable ReleaseGridWithBatchName(string fromDate, string toDate, string batchName, int Auditstatus)
        {
            int projectId = Convert.ToInt32(HttpContext.Current.Session[Constants.ProjectId]);
            string userName = Convert.ToString(HttpContext.Current.Session[Constants.UserName]);
            int practiceId = Convert.ToInt32(HttpContext.Current.Session[Constants.PracticeID]);
            if(batchName=="" || batchName=="0")
                batchName=null;
            DataSet dsCommon = new DataSet();
            CBI_Anes_HighEntities dbObj = Singleton.Instance;
            List<SqlParameter> Parameter = new List<SqlParameter>();
            dsCommon.Clear();
            Parameter.Add(new SqlParameter("@ProjectId", projectId));
            Parameter.Add(new SqlParameter("@UserNTLG", userName));
            Parameter.Add(new SqlParameter("@practiceId", practiceId));
            Parameter.Add(new SqlParameter("@fromDate", fromDate));
            Parameter.Add(new SqlParameter("@toDate", toDate));
            Parameter.Add(new SqlParameter("@Auditstatus", Auditstatus));
            Parameter.Add(new SqlParameter("@batchName", CryptoGraphy.Encrypt(batchName)));
            
            dsCommon = DBExtension.ExecuteDataset(dbObj.Database, Constants.SpReleaseScreenWithBatchName, Parameter);


            if (dsCommon.Tables[0] != null)
            {
                foreach (DataRow row in dsCommon.Tables[0].Rows)
                {
                    row[4] = CryptoGraphy.Decrypt(row[4].ToString());
                    row[5] = CryptoGraphy.Decrypt(row[5].ToString());
                    row[6] = CryptoGraphy.Decrypt(row[6].ToString());
                    row[7] = CryptoGraphy.Decrypt(row[7].ToString());
                    row[8] = CryptoGraphy.Decrypt(row[8].ToString());
                }
                return dsCommon.Tables[0];
            }
            else
            {
                return null;
            }
            
           // return dsCommon.Tables[0];
            //if (string.IsNullOrEmpty(fromDate) && string.IsNullOrEmpty(toDate))
            //{
            //    return dsCommon.Tables[0];
            //}
            //else
            //{
            //    return FilterTable(dsCommon.Tables[0], Convert.ToDateTime(fromDate), Convert.ToDateTime(toDate));
            //}
        }
        #endregion
        #region ReleaseAccounts

        public void ReleaseAccounts(List<ReleaseAccountModel> model)
        {
            using (CBI_Anes_HighEntities _context = new CBI_Anes_HighEntities())
            {
                int projectId = Convert.ToInt32(HttpContext.Current.Session[Constants.ProjectId]);
                string userName = HttpContext.Current.Session[Constants.UserName].ToString();
                try
                {
                    if (model.Count > 0)
                    {
                        var batchId = model.Select(y => y.BatchId).ToList();
                        var transId = model.Select(y => y.TransId).ToList();
                        if (model[0].ButtonText == "release")
                        {
                            _context.tbl_IMPORT_TABLE.Where(x => batchId.Contains(x.BATCH_ID)).ToList().ForEach(x => { x.RELEASED_DATE = DateTime.Now; x.RELEASED_BY = userName; x.BATCH_STATUS = Constants.Completed; });
                            _context.tbl_TRANSACTION.Where(x => transId.Contains(x.TRANS_ID)).ToList().ForEach(x => { x.CODING_STATUS = Constants.Completed; x.QC_STATUS = Constants.Completed; });
                        }
                        else
                        {
                            _context.tbl_IMPORT_TABLE.Where(x => batchId.Contains(x.BATCH_ID)).ToList().ForEach(x => { x.BATCH_STATUS = "QC Allotted"; });
                            _context.tbl_TRANSACTION.Where(x => transId.Contains(x.TRANS_ID)).ToList().ForEach(x => { x.QC_STATUS = "QC Allotted"; x.RELEASE_REAUDIT_BY = userName; x.RELEASE_REAUDIT_DATE = DateTime.Now; x.RELEASE_REAUDIT_STATUS = 1; x.IS_SKIPPED = 0; });
                        }

                        _context.SaveChanges();
                    }
                }
                catch (Exception ex)
                {

                }
            }
        }
        #endregion

        #region QC Skip

        public string QCSkip(AllotmentModel model, string listOfAccounts)
        {
            string Status = "";
            string[] array = listOfAccounts.Split(',').Select(x => x.Trim()).ToArray();
            int projectId = Convert.ToInt32(HttpContext.Current.Session[Constants.ProjectId]);
            string userName = HttpContext.Current.Session[Constants.UserName].ToString();
            using (CBI_Anes_HighEntities _context = new CBI_Anes_HighEntities())
            {
                string[] newArray = array.Select(x => CryptoGraphy.Encrypt(x)).ToArray();
                var myList = _context.tbl_IMPORT_TABLE.Where(x => newArray.Contains(x.ACCOUNT_NO) && x.PROJECT_ID == projectId).ToList();
                var bathIds = myList.Select(x => x.BATCH_ID).ToList();
                _context.tbl_TRANSACTION.Where(x => bathIds.Contains(x.BATCH_ID) && x.PROJECT_ID == projectId).ToList().ForEach(x => x.QC_BY = userName);
                myList.ForEach(x => { x.QC_ALLOTTED_BY = newArray[0]; x.BATCH_STATUS = "QC"; });
                var transList = _context.tbl_TRANSACTION.Where(x => bathIds.Contains(x.BATCH_ID) && x.PROJECT_ID == projectId).ToList();
                transList.ForEach(x => { x.IS_AUDITED = 0; x.IS_SKIPPED = 1; x.QC_BY = userName; x.QC_DATE = DateTime.Now; x.QC_STATUS = "Qced"; });
                _context.SaveChanges();
                Status = "Success";
            }
            return Status;
        }

        #endregion

        //Added by DebshreeC

        #region ChangeAccess
        public void ChangeCoderAccess(string NoofCoder, string location, string access_type)
        {
            int projectId = Convert.ToInt32(HttpContext.Current.Session[Constants.ProjectId]);
            string userName = Convert.ToString(HttpContext.Current.Session[Constants.UserName]);
            int practiceId = Convert.ToInt32(HttpContext.Current.Session[Constants.PracticeID]);
           
            using (CBI_Anes_HighEntities _context = new CBI_Anes_HighEntities())
            {
                try
                {
                    string str = NoofCoder.Substring(0, 8);
                    if (str == "checkbox")
                    {
                        NoofCoder = NoofCoder.Remove(0, 9);
                    }
                    _context.USP_CHANGE_ACCESS(projectId, userName, practiceId, NoofCoder, location, access_type);
                    _context.SaveChanges();
                }
                catch(Exception e)
                {
                    _context.USP_CHANGE_ACCESS(projectId, userName, practiceId, NoofCoder, location, access_type);
                    _context.SaveChanges();
                }
               
            }
        }
        #endregion

        #region SendBackAccountQC2CODER
        public void SendBackAccountQC2CODER(string selectedAccounts)
        {           
            int projectId = Convert.ToInt32(HttpContext.Current.Session[Constants.ProjectId]);
            using (CBI_Anes_HighEntities _context = new CBI_Anes_HighEntities())
            {
                string[] array = selectedAccounts.Split(',');
                string userName = HttpContext.Current.Session[Constants.UserName].ToString();

                //if ((selectedAccounts.Contains("Skip")))
                //{

                string[] newArray = array.Select(x => CryptoGraphy.Encrypt(x.Trim())).ToArray();
                var myList = _context.tbl_IMPORT_TABLE.Where(x => newArray.Contains(x.ACCOUNT_NO) && x.PROJECT_ID == projectId).ToList();

                var bathIds = myList.Select(x => x.BATCH_ID).ToList();
                foreach (var verObj in bathIds)
                {
                    var batch_id = verObj;
                    var _tr_id = (from sub in _context.tbl_TRANSACTION where sub.BATCH_ID == batch_id select new { sub.TRANS_ID }).Single();

                    int trans_id = Convert.ToInt32(_tr_id.TRANS_ID.ToString());

                    var qc_status = _context.tbl_TRANSACTION_DETAILS.Where(y => y.TRANS_ID == trans_id && y.Error_Count == "1").Select(z => z.Error_Count).ToList().Count > 0 ? "Error" : "Qced";

                    var modStatus = _context.tbl_TRANSACTION_DETAILS.Where(a => a.TRANS_ID == trans_id && (a.ICD_RESULT == "Q_INSERT" || a.ICD_RESULT == "Q_UPDATE" || a.Error_Correction == "Y"|| a.IS_ACKNOWLEDGE == "Y")).ToList().Count > 0 ? "N" : "Y";
                    if ((qc_status == "Error") || (modStatus == "N"))
                    {
                        HttpContext.Current.Session["QCED"] = "QCED";
                    }
                    else
                    {

                        var _tr_details = _context.tbl_IMPORT_TABLE.Where(m => m.BATCH_ID == batch_id).SingleOrDefault();

                        if (_tr_details != null)
                        {
                            _tr_details.BATCH_STATUS = "In Process";
                            _tr_details.MRN = "QC_Back";
                            _tr_details.QC_ALLOTTED_BY = null;
                            _tr_details.QC_ALLOTTED_DATE = null;
                        }
                    }    
                }
                _context.SaveChanges();

            }
        }
        #endregion

        //Added by DebshreeC
    }
}
