﻿using CBIplus.BAL.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.Mvc;

namespace CBIplus.BAL.Managers
{
   public interface IPeriMeterCoderService
    {
       List<CodingPeriModel> LoadCoderInboxData();
       CodingPeriModel LoadMasterDropdownData();
       List<CodingPeriModel> LoadCodedAccounts();
       CodingPeriModel LoadAccountDropdowns(string facilityNum, string accountNumber, string accountStatus = null);
       List<SelectListItem> GetSelectedCPT(string CPT);
       void SaveChartChanges(List<CodingPeriModel> model, string status);
       void SaveAndUpdateCPTChanges(CodingPeriModel model);
       List<CodingPeriModel> GetCPTGridData(int transId, string accountNumber, string Facility);
       CodingPeriModel GetCptICDDetails(int transId, int transDetailsId, string status, string accountNum, string facility);
       void DeleteAccountCPT(string cpt, int transId);
       void DeleteCPT(int transDetailsId);
       List<SelectListItem> GetValidCPTList(string CPTValue, int TRANSID);
       void UpdateAccountDetails(CodingPeriModel model);
       CodingPeriModel ConvertToPDF(string AccountNum);
    }
}
