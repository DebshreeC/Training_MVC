﻿using CBIplus.BAL.Generics;
using CBIplus.BAL.ViewModels;
using CBIplus.DAL;
using Microsoft.Win32.SafeHandles;
using System;
using System.Collections.Generic;
using System.Data.Entity.Validation;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using System.Web.Mvc;

namespace CBIplus.BAL.Managers
{
    public class TransactionManager : ITransactionService
    {

        
        static TransactionManager()
        {
             using (CBI_Anes_HighEntities _context = new CBI_Anes_HighEntities())
            {
                //HttpContext.Current.Session["ICD_CODES_LIST"] = _context.tbl_ICD_MASTER.Select(x=>x.ICD_CODE).ToList();
             }
        }

        #region Get Facility Names
        public List<SelectListItem> GetFacilityNames()
        {
            using (CBI_Anes_HighEntities _context = new CBI_Anes_HighEntities())
            {
                int projectId = Convert.ToInt32(HttpContext.Current.Session[Constants.ProjectId]);

                var list = (from facility in _context.tbl_FACILITY
                            where facility.PROJECT_ID == projectId
                            select new SelectListItem
                            {
                                Text = facility.DESCRIPTION,
                                Value = facility.F_Id.ToString()
                            }).ToList();
                return list;
            }
        }
        #endregion

        #region Get Status Nammes
        public List<SelectListItem> GetStatusNames()
        {
            using (CBI_Anes_HighEntities _context = new CBI_Anes_HighEntities())
            {
                int projectId = Convert.ToInt32(HttpContext.Current.Session[Constants.ProjectId]);
                var list = (from status in _context.TBL_CODING_STATUS_MASTER
                            where status.PROJECT_ID == projectId
                            select new SelectListItem
                            {
                                Text = status.CODING_STATUS,
                                Value = status.C_ID.ToString()
                            }).ToList();
                return list;
            }
        }
        #endregion

        #region Get Facility For Transaction
        public List<CoderTransactionModel> GetFacilityForTransaction()
        {
            using (CBI_Anes_HighEntities _context = new CBI_Anes_HighEntities())
            {
                int projectId = Convert.ToInt32(HttpContext.Current.Session[Constants.ProjectId]);
                string userName = HttpContext.Current.Session[Constants.UserName].ToString();
                //return (from data in _context.GetDataForTransaction(HttpContext.Current.Session[Constants.UserName].ToString(), HttpContext.Current.Session[Constants.ProjectId].ToString(), "Regular")
                return (from data in _context.tbl_IMPORT_TABLE
                        //join Trans in _context.tbl_TRANSACTION on data.BATCH_ID equals Trans.BATCH_ID
                        where data.PROJECT_ID == projectId && data.ALLOTTED_TO == userName //&& (data.BATCH_STATUS == 'Coding Allotted' || data.BATCH_STATUS == 'Pending')

                        select new CoderTransactionModel
                        {
                            JobName = data.JOB_NAME,
                            DOS = data.DOS.ToString(),
                            FacilityName = data.FACILITY,
                            AccountNumber = data.ACCOUNT_NO,
                            PageCount = data.PAGE_COUNT.ToString(),
                            BatchName = data.BATCH_NAME,
                            BatchStatus = data.BATCH_STATUS,
                            BatchId=data.BATCH_ID
                        }).Where(x => x.BatchStatus == "Coding Allotted" || x.BatchStatus == "Pending" || x.BatchStatus == "In Process").ToList();
            }
        }
        #endregion

        #region CheckIcd
        public string CheckIcd(string icd)
        {

            List<string> list;
            if (HttpContext.Current.Session["ICD_CODES_LIST"]!=null)
            {
               list = (List<string>)HttpContext.Current.Session["ICD_CODES_LIST"];
               
            }
            else
            {
                using (CBI_Anes_HighEntities _context = new CBI_Anes_HighEntities())
                {
                    HttpContext.Current.Session["ICD_CODES_LIST"] = _context.tbl_ICD_MASTER.Select(x => x.ICD_CODE).ToList();
                    list = (List<string>)HttpContext.Current.Session["ICD_CODES_LIST"];
                }
           
            }
            if(!string.IsNullOrEmpty(icd)&&list.Any(x=>icd.Contains(x)))
            {
                return "Success";
            }
            else
            {
                return "Fail";
            }
        }
        #endregion


        #region Get Physacal Status

        public List<SelectListItem> GetPhysacalStatus()
        {
            using (CBI_Anes_HighEntities _context = new CBI_Anes_HighEntities())
            {
                int projectId = Convert.ToInt32(HttpContext.Current.Session[Constants.ProjectId]);

                var list = (from phyStatus in _context.PHYSICAL_STATUS_MODIFIER_MASTER
                            select new SelectListItem
                            {
                                Text = phyStatus.PSM_Id.ToString() + "-" + phyStatus.Discription,
                                Value = phyStatus.PSM_Id.ToString()
                            }).ToList();
                return list;
            }
        }
        #endregion

        #region Get PQRS

        public List<SelectListItem> getPQRS()
        {
            using (CBI_Anes_HighEntities _context = new CBI_Anes_HighEntities())
            {
                int projectId = Convert.ToInt32(HttpContext.Current.Session[Constants.ProjectId]);
                var list = (from PQRS in _context.PQRS_MASTER
                            select new SelectListItem
                            {
                                Text = PQRS.Measure.ToString() + " - " + PQRS.Discription,
                                Value = PQRS.Measure.ToString()
                            }).ToList();
                return list;
            }
        }
        #endregion

        #region Get Qualifying Circumstance

        public List<SelectListItem> getQualifyingCircumstance()
        {
            using (CBI_Anes_HighEntities _context = new CBI_Anes_HighEntities())
            {
                int projectId = Convert.ToInt32(HttpContext.Current.Session[Constants.ProjectId]);
                var list = (from qualifyingCircumstance in _context.QUALIFYING_CIRCUMSTANCE_MASTER
                            select new SelectListItem
                            {
                                Text = qualifyingCircumstance.Codes + " - " + qualifyingCircumstance.Qualifying_Circumstance.ToString(),
                                Value = qualifyingCircumstance.Codes.ToString()
                            }).ToList();
                return list;
            }
        }
        #endregion

        #region Get AsaCross

        public List<SelectListItem> getAsaCross(string CPTCode)
        {
            using (CBI_Anes_HighEntities _context = new CBI_Anes_HighEntities())
            {
                int projectId = Convert.ToInt32(HttpContext.Current.Session[Constants.ProjectId]);
                var asaCross = (from cpt in _context.CPT_MASTER
                                where cpt.CPT == CPTCode
                                select new
                                {
                                    cpt.CPT_Ane_Code,
                                    cpt.CPT_Ane_Descriptor,
                                    cpt.Base_Unit_Modification
                                }).FirstOrDefault();
                //string asaCros = asaCross == null ? null : asaCross.CPT_Ane_Code + " - " + asaCross.CPT_Ane_Descriptor.ToString();

                var allData = _context.CPT_MASTER.ToList();
                List<SelectListItem> list = new List<SelectListItem>();
                if (asaCross != null)
                {
                    if (asaCross.CPT_Ane_Code.Contains(','))
                    {
                        for (int i = 0; i < asaCross.CPT_Ane_Code.Split(',').Length; i++)
                        {
                            string aneCode = asaCross.CPT_Ane_Code.Split(',')[i].ToString();
                            var descri = allData.Where(x => x.CPT_Ane_Code == aneCode).FirstOrDefault();
                            if (descri != null)
                            {
                                SelectListItem items = new SelectListItem { Text = asaCross.CPT_Ane_Code.Split(',')[i].ToString() + " - " + descri.CPT_Ane_Descriptor, Value = descri.Base_Unit_Modification };
                                list.Add(items);
                            }
                            else
                            {
                                SelectListItem items = new SelectListItem { Text = aneCode + " - No Description", Value = asaCross.Base_Unit_Modification };
                                list.Add(items);
                            }

                        }

                    }
                    else
                    {
                        string aneCode = asaCross.CPT_Ane_Code;
                        var descri = allData.Where(x => x.CPT_Ane_Code == aneCode).FirstOrDefault();
                        SelectListItem items = new SelectListItem { Text = asaCross.CPT_Ane_Code + " - " + descri.CPT_Ane_Descriptor, Value = descri.Base_Unit_Modification };
                        list.Add(items);
                    }
                }

                return list;
            }
        }
        #endregion

        #region GetStartTimeDropdown
        public List<SelectListItem> GetStartTimeDropdown()
        {
            List<SelectListItem> list = new List<SelectListItem>();
            for (int i = 0; i < 24; i++)
            {
                SelectListItem item = new SelectListItem { Text = i.ToString(), Value = i.ToString() };
                list.Add(item);
            }
            return list;
        }
        #endregion
        #region GetEndTimeDropdown
        public List<SelectListItem> GetEndTimeDropdown()
        {
            List<SelectListItem> list = new List<SelectListItem>();
            for (int i = 0; i < 60; i++)
            {
                SelectListItem item = new SelectListItem { Text = i.ToString(), Value = i.ToString() };
                list.Add(item);
            }
            return list;
        }
        #endregion

        public CoderTransactionModel All(int transDetailsId = 0)
        {
            CoderTransactionModel model = new CoderTransactionModel();
            using (CBI_Anes_HighEntities _context = new CBI_Anes_HighEntities())
            {
                var TD = _context.tbl_TRANSACTION_DETAILS.Where(x => x.TRANS_DETAIL_ID == transDetailsId).FirstOrDefault();
                if (TD != null)
                {
                    model.CPT = TD.CPT;
                    model.AcutePainPOS = TD.ACUTE_PAIN_POS;
                    model.AsaCross = TD.ASA_CROSS;
                    model.SelectPQRS = TD.PQRS;
                    model.Modifier = TD.MODIFIER;
                    model.AcutePainCPT = TD.ACUTE_PAIN_CPT;
                    model.AcutePainDX = TD.ACUTE_PAIN_DX;
                    model.BaseUnitModification = Convert.ToString(TD.UNITS);
                    model.Diagnosis = TD.ICD_CODE;
                    model.MedicalDirection = TD.MEDICAL_DIRECTION;
                    // model.DiadnosisResult = TD.ICD_RESULT;
                    model.AncillaryServiceProvider = TD.ANCILLARY_SERVICE_PROVIDERS;
                    model.AncillaryServices = TD.ANCILLARY_SERVICES;
                    model.SelectQualifyingCircumstances = TD.QUALIFYING_CIRCUMSTANCES;
                    model.AncillaryModifier = TD.ANCILLARY_MODIFIER;

                    model.ProviderName = TD.PROVIDER_MD;
                    model.CRNA = TD.CRNA;

                    model.AnesthesiaStartTimeFrom = string.IsNullOrEmpty(TD.Anesthesia_Start_time.ToString()) ? null : DateTime.Today.Add(TD.Anesthesia_Start_time.Value).ToString("hh:mm tt");
                    model.AnesthesiaEndTimeFrom = string.IsNullOrEmpty(TD.Anesthesia_End_time.ToString()) ? null : DateTime.Today.Add(TD.Anesthesia_End_time.Value).ToString("hh:mm tt");



                    model.TimeDifference = string.IsNullOrEmpty(TD.Anesthesia_Time_Diff.ToString()) ? null : TD.Anesthesia_Time_Diff.ToString();

                    model.Comments = TD.COMMENTS;

                }
            }
            //model.AnesthesiaStartTimeList = GetStartTimeDropdown();
            //model.AnesthesiaEndTimeList = GetEndTimeDropdown();
            model.PhysicalStatus = GetPhysacalStatus();
            model.PQRS = getPQRS();
            model.QualifyingCircumstances = getQualifyingCircumstance();
            model.StatusNames = GetStatusNames();
            return model;
        }

        #region Insert Or Update Chart Details
        public void InsertOrUpdateChartDetails(List<CoderTransactionModel> coder, string status)
        {
            using (CBI_Anes_HighEntities _context = new CBI_Anes_HighEntities())
            {
                string accountNumber = coder[0].AccountNumber;
                var import = _context.tbl_IMPORT_TABLE.Where(x => x.ACCOUNT_NO == accountNumber).FirstOrDefault();
                int i = 0;
                int transId = 0;
                try
                {
                    if (status == "Pending")
                    {
                        tbl_TRANSACTION transaction = new tbl_TRANSACTION();
                        tbl_IMPORT_TABLE tblImport = new tbl_IMPORT_TABLE();
                        transaction.CODING_STATUS = status;
                        import.BATCH_STATUS = status;
                        _context.SaveChanges();
                    }
                    else
                    {
                        foreach (var item in coder)
                        {
                            tbl_TRANSACTION transaction = new tbl_TRANSACTION();
                           
                            var trans = _context.tbl_TRANSACTION.Where(x => x.BATCH_ID == item.BatchId).FirstOrDefault();
                            if (trans == null)
                            {
                                if (!string.IsNullOrEmpty(item.ProviderName))
                                {
                                    string[] array = item.ProviderName.TrimEnd(';').Split(';');
                                    if (array.Length == 1)
                                    {
                                        item.ProviderName1 = array[0];
                                    }
                                    if (array.Length == 2)
                                    {
                                        item.ProviderName1 = array[0];
                                        item.ProviderName2 = array[1];
                                    }
                                    if (array.Length == 3)
                                    {
                                        item.ProviderName1 = array[0];
                                        item.ProviderName2 = array[1];
                                        item.ProviderName3 = array[2];
                                    }
                                    if (array.Length == 4)
                                    {
                                        item.ProviderName1 = array[0];
                                        item.ProviderName2 = array[1];
                                        item.ProviderName3 = array[2];
                                        item.ProviderName4 = array[3];
                                    }
                                    if (array.Length == 5)
                                    {
                                        item.ProviderName1 = array[0];
                                        item.ProviderName2 = array[1];
                                        item.ProviderName3 = array[2];
                                        item.ProviderName4 = array[3];
                                        item.ProviderName5 = array[4];
                                    }
                                }
                                if (!string.IsNullOrEmpty(item.CRNA))
                                {
                                    string[] array = item.CRNA.TrimEnd(';').Split(';');
                                    if (array.Length == 1)
                                    {
                                        item.CRNA1 = array[0];
                                    }
                                    if (array.Length == 2)
                                    {
                                        item.CRNA1 = array[0];
                                        item.CRNA2 = array[1];
                                    }
                                    if (array.Length == 3)
                                    {
                                        item.CRNA1 = array[0];
                                        item.CRNA2 = array[1];
                                        item.CRNA3 = array[2];
                                    }
                                    if (array.Length == 4)
                                    {
                                        item.CRNA1 = array[0];
                                        item.CRNA2 = array[1];
                                        item.CRNA3 = array[2];
                                        item.CRNA4 = array[3];
                                    }
                                    if (array.Length == 5)
                                    {
                                        item.CRNA1 = array[0];
                                        item.CRNA2 = array[1];
                                        item.CRNA3 = array[2];
                                        item.CRNA4 = array[3];
                                        item.CRNA5 = array[4];
                                    }
                                }

                                transaction.BATCH_ID = import.BATCH_ID;
                                transaction.ANES_TYPE = item.AnesType;
                                transaction.PHYSICAL_STATUS = item.SelectedPhysicalStatus;
                                transaction.PATIENT_NAME = item.PatName;
                                //transaction.CODING_STATUS = item.CodingStatus;
                                //transaction.ACCOUNT_STATUS = item.CodingStatus;
                                transaction.CODED_DATE = DateTime.Now;
                                transaction.CODED_BY = HttpContext.Current.Session[Constants.UserName].ToString();
                                transaction.PROJECT_ID = Convert.ToInt32(HttpContext.Current.Session[Constants.ProjectId]);
                                import.BATCH_STATUS = status;
                                transaction.CODING_STATUS = status;
                                transaction.START_TIME = Convert.ToDateTime(item.StartDateTime).TimeOfDay;
                                transaction.END_TIME = DateTime.Now.TimeOfDay;
                                transaction.PROVIDER_NAME1 = item.ProviderName1;
                                transaction.PROVIDER_NAME2 = item.ProviderName2;
                                transaction.PROVIDER_NAME3 = item.ProviderName3;
                                transaction.PROVIDER_NAME4 = item.ProviderName4;
                                transaction.PROVIDER_NAME5 = item.ProviderName5;
                                transaction.CRNA1 = item.CRNA1;
                                transaction.CRNA2 = item.CRNA2;
                                transaction.CRNA3 = item.CRNA3;
                                transaction.CRNA4 = item.CRNA4;
                                transaction.CRNA5 = item.CRNA5;
                                i = i + 1;
                                _context.tbl_TRANSACTION.Add(transaction);
                                _context.SaveChanges();
                                transId = Convert.ToInt32(_context.tbl_TRANSACTION.Where(x => x.BATCH_ID == import.BATCH_ID).Select(x => x.TRANS_ID).FirstOrDefault());
                            }

                            string icdres = item.DiadnosisResult.Trim(';');
                            string[] icdArray = icdres.Split(';');
                            for (int j = 0; j < icdArray.Length; j++)
                            {
                                tbl_TRANSACTION_DETAILS transDetails = new tbl_TRANSACTION_DETAILS();
                                string[] AST = item.AnesthesiaStartTimeFrom.Split(':');
                                string[] EST = item.AnesthesiaEndTimeFrom.Split(':');
                                transDetails.TRANS_ID = transId;
                                transDetails.CPT = item.CPT;
                                transDetails.ASA_CROSS = item.AsaCross;
                                transDetails.MODIFIER = item.Modifier == null ? "" : item.Modifier;
                                transDetails.ICD_CODE = icdArray[j];
                                transDetails.ICD_RESULT = item.DiadnosisResult;
                                //transDetails.ICD = item.DiadnosisResult;
                                transDetails.ANCILLARY_SERVICES = item.AncillaryServices == null ? "" : item.AncillaryServices;
                                transDetails.ANCILLARY_MODIFIER = item.AncillaryModifier == null ? "" : item.AncillaryModifier;
                                transDetails.ACUTE_PAIN_CPT = item.AcutePainCPT == null ? "" : item.AcutePainCPT;
                                transDetails.ACUTE_PAIN_DX = item.AcutePainDX == null ? "" : item.AcutePainDX;
                                transDetails.ACUTE_PAIN_POS = item.AcutePainPOS == null ? "" : item.AcutePainPOS;
                                transDetails.PQRS = ((item.SelectPQRS == null) || (item.SelectPQRS == "-- Select --")) ? "" : item.SelectPQRS;
                                transDetails.UNITS = Convert.ToInt32(item.BaseUnitModification);
                                transDetails.MEDICAL_DIRECTION = item.MedicalDirection == null ? "" : item.MedicalDirection;
                                transDetails.ANCILLARY_SERVICE_PROVIDERS = item.AncillaryServiceProvider;
                                transDetails.QUALIFYING_CIRCUMSTANCES = ((item.SelectQualifyingCircumstances == null) || (item.SelectQualifyingCircumstances == "-- Select --")) ? "" : item.SelectQualifyingCircumstances;
                                transDetails.COMMENTS = item.Comments;
                                transaction.START_TIME = Convert.ToDateTime(item.StartDateTime).TimeOfDay;
                                transaction.END_TIME = DateTime.Now.TimeOfDay;
                                //transDetails.PROVIDER_MD = item.ProviderName;
                                //transDetails.CRNA = item.CRNA;
                                transDetails.Anesthesia_Start_time = Convert.ToDateTime(AST[0] + ":" + AST[1]).TimeOfDay;
                                transDetails.Anesthesia_End_time = Convert.ToDateTime(EST[0] + ":" + EST[1]).TimeOfDay;
                                transDetails.Anesthesia_Time_Diff = Convert.ToDateTime(item.TimeDifference).TimeOfDay;
                                _context.tbl_TRANSACTION_DETAILS.Add(transDetails);
                                //  _context.tbl_TRANSACTION.Add(transaction);
                            }
                        }
                        _context.SaveChanges();
                    }
                }

                catch (DbEntityValidationException ex)
                {
                    var errorMessages = ex.EntityValidationErrors.SelectMany(x => x.ValidationErrors).Select(x => x.ErrorMessage);
                    var fullErrorMessage = string.Join(Constants.CommaSpace, errorMessages);
                    var exceptionMessage = string.Concat(ex.Message, Constants.ValidationError, fullErrorMessage);
                    throw new DbEntityValidationException(exceptionMessage, ex.EntityValidationErrors);
                }
                catch(Exception e)
                {
                    e.Message.ToString();
                }
            }
        }
        #endregion

        #region Save Batch Status
        public void SaveBatchStatus(List<CoderTransactionModel> coder)
        {
            //tbl_IMPORT_TABLE import = new tbl_IMPORT_TABLE();
            using (CBI_Anes_HighEntities _context = new CBI_Anes_HighEntities())
            {
                string accountNumber = coder[0].AccountNumber;
                var import = _context.tbl_IMPORT_TABLE.Where(x => x.ACCOUNT_NO == accountNumber).FirstOrDefault();
                try
                {
                    foreach (var item in coder)
                    {
                        import.BATCH_STATUS = "In Process";
                        _context.SaveChanges();
                    }
                }

                catch (DbEntityValidationException ex)
                {
                    var errorMessages = ex.EntityValidationErrors.SelectMany(x => x.ValidationErrors).Select(x => x.ErrorMessage);
                    var fullErrorMessage = string.Join(Constants.CommaSpace, errorMessages);
                    var exceptionMessage = string.Concat(ex.Message, Constants.ValidationError, fullErrorMessage);
                    throw new DbEntityValidationException(exceptionMessage, ex.EntityValidationErrors);
                }
            }
        }
        #endregion

        #region GetCPTGridData
        public List<CoderTransactionModel> GetCPTGridData(int transId, string accountNumber)
        {
            using (CBI_Anes_HighEntities _context = new CBI_Anes_HighEntities())
            {
                int projectId = Convert.ToInt32(HttpContext.Current.Session[Constants.ProjectId]);

                return (from TD in _context.tbl_TRANSACTION_DETAILS
                        where TD.TRANS_ID == transId
                        select new CoderTransactionModel
                        {
                            AccountNumber = accountNumber,
                            TRANS_ID = TD.TRANS_ID,
                            CPT = TD.CPT,
                            AsaCross = TD.ASA_CROSS,
                            Modifier = TD.MODIFIER,

                            DiadnosisResult = TD.ICD_RESULT,
                            AncillaryServices = TD.ANCILLARY_SERVICES,
                            AncillaryModifier = TD.ANCILLARY_MODIFIER,
                            AcutePainCPT = TD.ACUTE_PAIN_CPT,
                            AcutePainDX = TD.ACUTE_PAIN_DX,
                            AcutePainPOS = TD.ACUTE_PAIN_POS,
                            SelectPQRS = TD.PQRS,
                            BaseUnitModification = TD.UNITS.ToString(),
                            MedicalDirection = TD.MEDICAL_DIRECTION,
                            AncillaryServiceProvider = TD.ANCILLARY_SERVICE_PROVIDERS,
                            SelectQualifyingCircumstances = TD.QUALIFYING_CIRCUMSTANCES,

                            Comments = TD.COMMENTS,
                            IcdCode = TD.ICD_CODE,
                            TRANS_DETAIL_ID = TD.TRANS_DETAIL_ID
                        }).ToList();
            }
        }
        #endregion

        #region Get Coded Details

        public List<CoderTransactionModel> GetCodedData(string accountNumber)
        {
            using (CBI_Anes_HighEntities _context = new CBI_Anes_HighEntities())
            {
                int projectId = Convert.ToInt32(HttpContext.Current.Session[Constants.ProjectId]);
                string userName = HttpContext.Current.Session[Constants.UserName].ToString().ToUpper().Trim();
                if (string.IsNullOrEmpty(accountNumber))
                {
                    return (from I in _context.tbl_IMPORT_TABLE
                            join T in _context.tbl_TRANSACTION on I.BATCH_ID equals T.BATCH_ID
                            join TD in _context.tbl_TRANSACTION_DETAILS on T.TRANS_ID equals TD.TRANS_ID
                            where T.CODED_BY.ToUpper() == userName && I.PROJECT_ID == projectId && T.CODING_STATUS == "Coded" && T.QC_STATUS == null
                            orderby T.TRANS_ID
                            select new CoderTransactionModel
                            {
                                AccountNumber = I.ACCOUNT_NO,
                                FacilityName = I.FACILITY,
                                DOS = I.DOS.ToString(),
                                PatName = T.PATIENT_NAME,
                                BatchName = I.BATCH_NAME,
                                BatchId = I.BATCH_ID,
                                JobName = I.JOB_NAME,
                                PageCount = I.PAGE_COUNT.ToString(),
                                AnesType = T.ANES_TYPE,
                                TRANS_ID = T.TRANS_ID,
                                SelectedPhysicalStatus = T.PHYSICAL_STATUS,
                                TRANS_DETAIL_ID = TD.TRANS_DETAIL_ID,
                                ProviderName1 = T.PROVIDER_NAME1,
                                ProviderName2 = T.PROVIDER_NAME2,
                                ProviderName3 = T.PROVIDER_NAME3,
                                ProviderName4 = T.PROVIDER_NAME4,
                                ProviderName5 = T.PROVIDER_NAME5,
                                CRNA1 = T.CRNA1,
                                CRNA2 = T.CRNA2,
                                CRNA3 = T.CRNA3,
                                CRNA4 = T.CRNA4,
                                CRNA5 = T.CRNA5,
                            }).GroupBy(x => x.AccountNumber).Select(x => x.FirstOrDefault()).OrderByDescending(x => x.TRANS_ID).Take(10).ToList();
                }
                else
                {
                    return (from I in _context.tbl_IMPORT_TABLE
                            join T in _context.tbl_TRANSACTION on I.BATCH_ID equals T.BATCH_ID
                            join TD in _context.tbl_TRANSACTION_DETAILS on T.TRANS_ID equals TD.TRANS_ID
                            where T.PROJECT_ID == projectId && I.ACCOUNT_NO == accountNumber
                            orderby T.TRANS_ID
                            select new CoderTransactionModel
                            {
                                AccountNumber = I.ACCOUNT_NO,
                                FacilityName = I.FACILITY,
                                DOS = I.DOS.ToString(),
                                PatName = T.PATIENT_NAME,
                                BatchName = I.BATCH_NAME,
                                BatchId = I.BATCH_ID,
                                JobName = I.JOB_NAME,
                                PageCount = I.PAGE_COUNT.ToString(),
                                AnesType = T.ANES_TYPE,
                                TRANS_ID = T.TRANS_ID,
                                SelectedPhysicalStatus = T.PHYSICAL_STATUS,
                                TRANS_DETAIL_ID = TD.TRANS_DETAIL_ID
                            }).GroupBy(x => x.AccountNumber).Select(x => x.FirstOrDefault()).Take(10).ToList();
                }
            }
        }

        #endregion

        #region UpdateAccountDetails
        public void UpdateAccountDetails(CoderTransactionModel model)
        {
            using (CBI_Anes_HighEntities _context = new CBI_Anes_HighEntities())
            {
                var trans = _context.tbl_TRANSACTION.Where(x => x.BATCH_ID == model.BatchId).FirstOrDefault();
                var import = _context.tbl_IMPORT_TABLE.Where(x => x.BATCH_ID == model.BatchId).FirstOrDefault();
                if (trans != null)
                {
                    import.FACILITY = model.FacilityName;
                    import.DOS = Convert.ToDateTime(model.DOS);
                    trans.DOS = Convert.ToDateTime(model.DOS);
                    trans.PATIENT_NAME = model.PatName;
                    import.BATCH_NAME = model.BatchName;
                    import.JOB_NAME = model.JobName;
                    import.PAGE_COUNT = Convert.ToInt32(model.PageCount);
                    trans.ANES_TYPE = model.AnesType;
                    trans.PHYSICAL_STATUS = model.SelectedPhysicalStatus;
                    trans.PROVIDER_NAME1 = model.ProviderName1;
                    trans.PROVIDER_NAME2 = model.ProviderName2;
                    trans.PROVIDER_NAME3 = model.ProviderName3;
                    trans.PROVIDER_NAME4 = model.ProviderName4;
                    trans.PROVIDER_NAME5 = model.ProviderName5;
                    trans.CRNA1 = model.CRNA1;
                    trans.CRNA2 = model.CRNA2;
                    trans.CRNA3 = model.CRNA3;
                    trans.CRNA4 = model.CRNA4;
                    trans.CRNA5 = model.CRNA5;
                    _context.SaveChanges();
                }
            }
        }
        #endregion

        #region AddNewCPT
        public void AddNewCPT(CoderTransactionModel model)
        {
            using (CBI_Anes_HighEntities _context = new CBI_Anes_HighEntities())
            {
                var TD = _context.tbl_TRANSACTION_DETAILS.Where(x => x.TRANS_DETAIL_ID == model.TRANS_DETAIL_ID).FirstOrDefault();
                string[] AST = model.AnesthesiaStartTimeFrom.Split(':');
                string[] EST = model.AnesthesiaEndTimeFrom.Split(':');
                if (TD == null)
                {
                    string icdres = model.DiadnosisResult.Trim(';');
                    string[] icdArray = icdres.Split(';');
                    for (int i = 0; i < icdArray.Length; i++)
                    {


                        tbl_TRANSACTION_DETAILS transDetails = new tbl_TRANSACTION_DETAILS();
                        transDetails.TRANS_ID = model.TRANS_ID;
                        transDetails.CPT = model.CPT;
                        transDetails.ASA_CROSS = model.AsaCross;
                        transDetails.MODIFIER = model.Modifier;
                        transDetails.ICD_CODE = icdArray[i];
                        transDetails.ICD_RESULT = model.DiadnosisResult;
                        transDetails.ANCILLARY_SERVICES = model.AncillaryServices;
                        transDetails.ANCILLARY_MODIFIER = model.AncillaryModifier;
                        transDetails.ACUTE_PAIN_POS = model.AcutePainPOS;
                        transDetails.PQRS = model.SelectPQRS;
                        transDetails.UNITS = Convert.ToInt32(model.BaseUnitModification);
                        transDetails.MEDICAL_DIRECTION = model.MedicalDirection;
                        transDetails.ANCILLARY_SERVICE_PROVIDERS = model.AncillaryServiceProvider;
                        transDetails.QUALIFYING_CIRCUMSTANCES = model.SelectQualifyingCircumstances;
                        transDetails.COMMENTS = model.Comments;
                        transDetails.ACUTE_PAIN_CPT = model.AcutePainCPT;
                        transDetails.ACUTE_PAIN_DX = model.AcutePainDX;
                        transDetails.PROVIDER_MD = model.ProviderName;
                        transDetails.CRNA = model.CRNA;

                        transDetails.Anesthesia_Start_time = Convert.ToDateTime(AST[0] + ":" + AST[1]).TimeOfDay;
                        transDetails.Anesthesia_End_time = Convert.ToDateTime(EST[0] + ":" + EST[1]).TimeOfDay;

                        transDetails.Anesthesia_Time_Diff = Convert.ToDateTime(model.TimeDifference).TimeOfDay;
                        _context.tbl_TRANSACTION_DETAILS.Add(transDetails);
                    }

                }
                else
                {

                    TD.TRANS_ID = model.TRANS_ID;
                    TD.CPT = model.CPT;
                    TD.ASA_CROSS = model.AsaCross;
                    TD.MODIFIER = model.Modifier;
                    TD.ICD_CODE = model.DiadnosisResult.TrimEnd(';');
                    TD.ICD_RESULT = TD.ICD_RESULT+";"+ model.DiadnosisResult;

                    //TD.ICD_CODE = model.Diagnosis;
                    //TD.ICD_RESULT = model.DiadnosisResult;
                    TD.ANCILLARY_SERVICES = model.AncillaryServices;
                    TD.ANCILLARY_MODIFIER = model.AncillaryModifier;
                    TD.ACUTE_PAIN_POS = model.AcutePainPOS;
                    TD.PQRS = model.SelectPQRS;
                    TD.UNITS = Convert.ToInt32(model.BaseUnitModification);
                    TD.MEDICAL_DIRECTION = model.MedicalDirection;
                    TD.ANCILLARY_SERVICE_PROVIDERS = model.AncillaryServiceProvider;
                    TD.QUALIFYING_CIRCUMSTANCES = model.SelectQualifyingCircumstances;
                    TD.COMMENTS = model.Comments;
                    TD.ACUTE_PAIN_CPT = model.AcutePainCPT;
                    TD.ACUTE_PAIN_DX = model.AcutePainDX;

                    TD.PROVIDER_MD = model.ProviderName;
                    TD.CRNA = model.CRNA;

                    TD.Anesthesia_Start_time = Convert.ToDateTime(AST[0] + ":" + AST[1]).TimeOfDay;
                    TD.Anesthesia_End_time = Convert.ToDateTime(EST[0] + ":" + EST[1]).TimeOfDay;

                    TD.Anesthesia_Time_Diff = Convert.ToDateTime(model.TimeDifference).TimeOfDay;

                    var icdRes = _context.tbl_TRANSACTION_DETAILS.Where(x => x.CPT == TD.CPT && x.TRANS_ID == model.TRANS_ID).ToList();

                    string icdcodeResult = string.Empty;

                    icdcodeResult = icdRes.Select(query => query.ICD_CODE).Aggregate((a, b) => a + ";" + b);

                    foreach (var item in icdRes)
                    {
                        item.ICD_RESULT = icdcodeResult;
                        _context.SaveChanges();
                    }


                }
                _context.SaveChanges();
            }
        }
        #endregion

        #region DeleteCPT
        public void DeleteCPT(int transDetailsId)
        {
            using (CBI_Anes_HighEntities _context = new CBI_Anes_HighEntities())
            {
                int projectId = Convert.ToInt32(HttpContext.Current.Session[Constants.ProjectId]);
                string icdcodeResult = "";
                var transDetails = _context.tbl_TRANSACTION_DETAILS.Where(x => x.TRANS_DETAIL_ID == transDetailsId).FirstOrDefault();
                _context.tbl_TRANSACTION_DETAILS.Remove(transDetails);
                _context.SaveChanges();
                var updateTransDetails = _context.tbl_TRANSACTION_DETAILS.Where(x => x.CPT == transDetails.CPT).ToList();

                if (updateTransDetails != null && updateTransDetails.Count > 0)
                {

                    icdcodeResult = projectId == 16 ? updateTransDetails.Select(query => query.ICD).Aggregate((a, b) => a + ";" + b) : updateTransDetails.Select(query => query.ICD_CODE).Aggregate((a, b) => a + ";" + b);

                    foreach (var item in updateTransDetails)
                    {
                        item.ICD_RESULT = icdcodeResult;
                        _context.SaveChanges();
                    }
                }

            }
        }
        #endregion
        #region GetAutoProviderNames
        public List<ProviderCRNAModel> GetAutoProviderNames(string Prefix)
        {
            List<ProviderCRNAModel> ObjList = new List<ProviderCRNAModel>()  
            {  
  
                new ProviderCRNAModel {Id=1,Name="Latur" },  
                new ProviderCRNAModel {Id=2,Name="Mumbai" },  
                new ProviderCRNAModel {Id=3,Name="Pune" },  
                new ProviderCRNAModel {Id=4,Name="Delhi" },  
                new ProviderCRNAModel {Id=5,Name="Dehradun" },  
                new ProviderCRNAModel {Id=6,Name="Noida" },  
                new ProviderCRNAModel {Id=7,Name="New Delhi" }  
  
        };
            //Searching records from list using LINQ query  

            return ObjList;
        }
        #endregion
    }
}
                            

                                                                                                





