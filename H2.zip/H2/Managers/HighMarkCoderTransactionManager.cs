﻿using CBIplus.BAL.Generics;
using CBIplus.BAL.ViewModels;
using CBIplus.DAL;
using Microsoft.Win32.SafeHandles;
using System;
using System.Globalization;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Web;

using System.Web.Mvc;
using System.Data.Entity;

namespace CBIplus.BAL.Managers
{
    public class HighMarkCoderTransactionManager : IHighMarkCoderTransactionService
    {

        int practiceId = Convert.ToInt32(HttpContext.Current.Session[Constants.PracticeID]);
        string USERNTLG_g = HttpContext.Current.Session[Constants.UserName].ToString();
        int PROJECTID_g = Convert.ToInt32(HttpContext.Current.Session[Constants.ProjectId]);
        string LOCATION_g = HttpContext.Current.Session[Constants.LocationName].ToString();
       // var UserLocation = _context.tbl_USER_ACCESS.Where(x => x.PROJECT_ID == projectId && x.PRACTICE_ID == practiceId && x.USER_NTLG == userNtlg).ToList();

        #region HighMarkCoderInbox
        public List<HighMarkCoderTransactionModel> HighMarkCoderInbox(string selecetedText)
        {
            using (CBI_Anes_HighEntities _context = new CBI_Anes_HighEntities())
            {
                string userNtlg = HttpContext.Current.Session[Constants.UserName].ToString();
                int projectId = Convert.ToInt32(HttpContext.Current.Session[Constants.ProjectId]);
                int practiceId = Convert.ToInt32(HttpContext.Current.Session[Constants.PracticeID]);
                var coderInbox = (from import in _context.tbl_IMPORT_TABLE
                                  where import.ALLOTTED_TO == userNtlg && (import.BATCH_STATUS == "Coding Allotted" ||import.BATCH_STATUS=="In Process") && import.PROJECT_ID == projectId && import.PRACTICE_ID == practiceId
                                  select new HighMarkCoderTransactionModel
                                  {
                                      ReceivedDate = import.ALLOTTED_DATE.ToString(),
                                      TrackingCode = import.ACCOUNT_NO,
                                      Status = import.BATCH_STATUS,
                                      MemberFirstName = import.First_Name,
                                      MemberLastName = import.Last_Name,
                                      MemberDOB = import.MEMBER_DOB.ToString(),
                                      MemberGender = import.MEMBER_GENDER,
                                      SelectedEncounter = import.ENCOUNTER_TYPE,
                                      BatchId = import.BATCH_ID,
                                      EncounterType = import.ENCOUNTER_TYPE,
                                      InvReceivedDate = import.ALLOTTED_DATE,
                                      BatchName=import.BATCH_NAME,
                                      BatchStatus=import.BATCH_STATUS,
                                      MRN=import.MRN,
                                      PDFpath=import.PDF_Path
                                  }).OrderByDescending(x => x.BatchStatus).ToList();
                var finalList = (from import in coderInbox

                                 select new HighMarkCoderTransactionModel
                                 {
                                     ReceivedDate = import.ReceivedDate,
                                     TrackingCode = CryptoGraphy.Decrypt(import.TrackingCode),
                                     Status = import.Status,
                                     MemberFirstName = CryptoGraphy.Decrypt(import.MemberFirstName),
                                     MemberLastName = CryptoGraphy.Decrypt(import.MemberLastName),
                                     MemberDOB = CryptoGraphy.Decrypt(import.MemberDOB),
                                     MemberGender = CryptoGraphy.Decrypt(import.MemberGender),
                                     SelectedEncounter = import.SelectedEncounter,
                                     BatchId = import.BatchId,
                                     EncounterType = import.EncounterType,
                                     InvReceivedDate = import.InvReceivedDate,
                                     BatchName=CryptoGraphy.Decrypt(import.BatchName),
                                     MRN=import.MRN,
                                     AllottedDate = import.AllottedDate,
                                     PDFpath = import.PDFpath
                                 }).OrderBy(x => x.AllottedDate).ToList();

                if (selecetedText.Contains("EType"))
                {
                    string[] array = selecetedText.Split('*');
                    string ENCOUNTER_TYPE = array[0].ToString();
                    return finalList.Where(x => x.EncounterType == ENCOUNTER_TYPE).ToList();

                }
                else if (selecetedText.Contains("DOS"))
                {
                    string[] array = selecetedText.Split('*');
                    DateTime receivedDate = Convert.ToDateTime(array[0].ToString());
                    return finalList.Where(x => x.InvReceivedDate == receivedDate).ToList();
                }
                else
                {
                    return finalList;
                }
            }
        }
        #endregion

        #region GetEncounter Type
        public List<SelectListItem> GetEncounterType()
        {
            using (CBI_Anes_HighEntities _context = new CBI_Anes_HighEntities())
            {
                int projectId = Convert.ToInt32(HttpContext.Current.Session[Constants.ProjectId]);

                var list = (from encounterType in _context.TBL_ENCOUNTER_TYPE_MASTER
                            where encounterType.PROJECT_ID == projectId
                            select new SelectListItem
                            {
                                Text = encounterType.ENCOUNTER_TYPE,
                                Value = encounterType.EN_ID.ToString()
                            }).ToList();
                return list;
            }
        }
        #endregion

        #region GetEcodeList
        public List<SelectListItem> GetEcodeList(string defaultvalue = "")
        {
            int projectId = Convert.ToInt32(HttpContext.Current.Session[Constants.ProjectId]);
            using (CBI_Anes_HighEntities _context = new CBI_Anes_HighEntities())
            {
                return (from E in _context.TBL_EO_CODE_MASTER where E.PROJECT_ID == projectId && E.DELETE_FLAG =="N" select new SelectListItem { Text = E.EO_CODE, Value = E.EO_COMMENT, Selected = defaultvalue.Contains(E.EO_CODE) }).ToList();
            }
        }
        #endregion

        #region HighMarkCoderTransaction
        public HighMarkCoderTransactionModel HighMarkCoderTransaction()
        {
            HighMarkCoderTransactionModel model = new HighMarkCoderTransactionModel();
            using (CBI_Anes_HighEntities _context = new CBI_Anes_HighEntities())
            {
                model.EOCodeList = GetEcodeList();
                model.StatusList = StaticStatusList();
                model.GenderList = StaticGenderList();
                model.DXTypeList = StaticDXTypeList();
                model.Practice_Id = practiceId;              
                model.CommentsList = CommentList();
                return model;
            }
        }
        public HighMarkCoderTransactionModel HighMarkCoderTransaction(string whoCorrected)
        {
            HighMarkCoderTransactionModel model = new HighMarkCoderTransactionModel();
            using (CBI_Anes_HighEntities _context = new CBI_Anes_HighEntities())
            {
                model.EOCodeList = GetEcodeList();
                model.StatusList = StaticStatusList();
                model.GenderList = StaticGenderList();
                model.DXTypeList = StaticDXTypeList();
                model.Practice_Id = practiceId;
                model.QACorrected = whoCorrected;
                model.CommentsList = CommentList();
                return model;
            }
        }
        #endregion

        public HighMarkCoderTransactionModel QCClarificationTransaction( string transId, string AccNo, string FName, string Lname, string MemberDOB, string MemberGender, string EncounterType, string CodedBy,string pdfPath)
        {
            HighMarkCoderTransactionModel model = new HighMarkCoderTransactionModel();
            using (CBI_Anes_HighEntities _context = new CBI_Anes_HighEntities())
            {
                int transid=Convert.ToInt32(transId);
                var batchDetails = _context.tbl_TRANSACTION.Where(x => x.TRANS_ID == transid).FirstOrDefault();
                var batch = _context.tbl_IMPORT_TABLE.Where(x => x.BATCH_ID == batchDetails.BATCH_ID).FirstOrDefault();
                model.BatchId = Convert.ToInt32(batchDetails.BATCH_ID);
                model.TrackingCode = CryptoGraphy.Decrypt(batch.ACCOUNT_NO);
                model.MemberFirstName = CryptoGraphy.Decrypt(batch.First_Name);
                model.MemberLastName = CryptoGraphy.Decrypt(batch.Last_Name);
                model.MBRDOB = CryptoGraphy.Decrypt(batch.MEMBER_DOB);
                model.MGender = CryptoGraphy.Decrypt(batch.MEMBER_GENDER);
                model.EncounterType = EncounterType;
                model.CodedBy = CodedBy;
                model.EOCodeList = GetEcodeList();
                model.StatusList = StaticStatusList();
                model.GenderList = StaticGenderList();
                model.DXTypeList = StaticDXTypeList();
                model.Practice_Id = practiceId;
                model.CommentsList = CommentList();
                model.PDFpath = pdfPath;
                return model;
            }
        }

        #region StaticStatusList
        private List<SelectListItem> StaticStatusList()
        {
            List<SelectListItem> listItems = new List<SelectListItem>();
            listItems.Add(new SelectListItem { Text = "Completed", Value = "Completed" });
            return listItems;
        }
        #endregion

        #region StaticGenderList
        private List<SelectListItem> StaticGenderList()
        {
            List<SelectListItem> listItems = new List<SelectListItem>();
            listItems.Add(new SelectListItem { Text = "F", Value = "F" });
            listItems.Add(new SelectListItem { Text = "M", Value = "M" });
            listItems.Add(new SelectListItem { Text = " ", Value = " " });

            return listItems;
        }
        #endregion

        #region StaticDXTypeList
        private List<SelectListItem> StaticDXTypeList()
        {
            List<SelectListItem> listItems = new List<SelectListItem>();

            listItems.Add(new SelectListItem { Text = "0", Value = "0" });
            listItems.Add(new SelectListItem { Text = "9", Value = "9" });
            listItems.Add(new SelectListItem { Text = "", Value = "" });


            return listItems;
        }
        #endregion

        #region CommentList
        private static List<SelectListItem> CommentList()
        {
            using (CBI_Anes_HighEntities _context = new CBI_Anes_HighEntities())
            {
                int projectId = Convert.ToInt32(HttpContext.Current.Session[Constants.ProjectId]);

                var list = (from comments in _context.tbl_COMMENT_MASTER
                            where comments.PROJECT_ID == projectId.ToString()
                            select new SelectListItem
                            {
                                Text = comments.COMMENT_NAME,
                                Value = comments.COMMENT_NAME
                            }).ToList();
                return list;
            }
        }
        #endregion

        #region LoadDXGrid
        public List<HighMarkCoderTransactionModel> LoadDXGrid(int batchId)
        {
            using (CBI_Anes_HighEntities _context = new CBI_Anes_HighEntities())
            {
                HttpContext.Current.Session["BatchID"] = batchId;

                string[] status = { "Completed", "Pending", "Clarifications" };
                int projectId = Convert.ToInt32(HttpContext.Current.Session[Constants.ProjectId]);
                var list = (from TD in _context.tbl_TRANSACTION_DETAILS
                            join T in _context.tbl_TRANSACTION on TD.TRANS_ID equals T.TRANS_ID
                            join I in _context.tbl_IMPORT_TABLE on T.BATCH_ID equals I.BATCH_ID
                            where T.PROJECT_ID == projectId && ((I.BATCH_STATUS == "Coding Allotted" || I.BATCH_STATUS == "In Process") || I.BATCH_STATUS == "Coded" || I.BATCH_STATUS == "Pending" || I.BATCH_STATUS == "Clarifications" || I.BATCH_STATUS == "QC" || I.BATCH_STATUS == "QC Allotted") && T.BATCH_ID == batchId && T.PRACTICE_ID == practiceId
                            select new
                            {
                                TD.BEGINNING_DOS,
                                TD.ENDING_DOS,
                                TD.ICD_CODE,
                                TD.ICD,
                                TD.PAGE_NO,
                                TD.EO_CODE1,
                                TD.EO_CODE2,
                                TD.EO_CODE3,
                                TD.EO_CODE4,
                                TD.EO_CODE5,
                                TD.EO_CODE6,
                                TD.EO_COMMENT1,
                                TD.EO_COMMENT2,
                                TD.EO_COMMENT3,
                                TD.EO_COMMENT4,
                                TD.EO_COMMENT5,
                                TD.EO_COMMENT6,
                                TD.TRANS_DETAIL_ID,
                                TD.TRANS_ID,
                                I.ACCOUNT_NO,
                                I.MEMBER_GENDER,
                                I.BATCH_ID,
                                TD.Error_Correction,
                                TD.MODIFIER,
                                T.CODING_COMMENTS,
                                TD.COMMENTS,
                                TD.IS_ACKNOWLEDGE,
                                TD.ICD_RESULT
                            }).ToList();                
                return (from item in list
                        select new HighMarkCoderTransactionModel
                            {
                                BeginningDOS = CryptoGraphy.Decrypt(item.BEGINNING_DOS),
                                EndingDOS = CryptoGraphy.Decrypt(item.ENDING_DOS),
                                DxType = item.ICD_CODE,
                                DXCode = item.ICD,
                                Page = item.PAGE_NO,
                                EOCode1 = item.EO_CODE1,
                                EOCode2 = item.EO_CODE2,
                                EOCode3 = item.EO_CODE3,
                                EOCode4 = item.EO_CODE4,
                                EOCode5 = item.EO_CODE5,
                                EOCode6 = item.EO_CODE6,
                                EOComment1 = item.EO_COMMENT1,
                                EOComment2 = item.EO_COMMENT2,
                                EOComment3 = item.EO_COMMENT3,
                                EOComment4 = item.EO_COMMENT4,
                                EOComment5 = item.EO_COMMENT5,
                                EOComment6 = item.EO_COMMENT6,
                                TRANS_DETAIL_ID = item.TRANS_DETAIL_ID,
                                TRANS_ID = item.TRANS_ID.ToString(),
                                TrackingCode = CryptoGraphy.Decrypt(item.ACCOUNT_NO),
                                MemberGender = CryptoGraphy.Decrypt(item.MEMBER_GENDER),
                                BatchId = item.BATCH_ID,
                                ErrorCorrection = item.Error_Correction,
                                Modifier=item.MODIFIER,
                                QCcomments = item.CODING_COMMENTS,
                                ICDComments=item.COMMENTS,
                                is_Acknowledge=item.IS_ACKNOWLEDGE,
                                ICDResult=item.ICD_RESULT
                            }).OrderByDescending(x => x.TRANS_DETAIL_ID).ToList();
            }
        }
        #endregion
        #region SaveHighMarkCoderTransaction
        public void SaveHighMarkCoderTransaction(HighMarkCoderTransactionModel model, string ecode, string screeenName)
        {
            if (model.BatchId == 0)
            {
                model.BatchId = Convert.ToInt32(HttpContext.Current.Session["BatchID"]);
            }
            if (!string.IsNullOrEmpty(ecode))
            {
                ecode = ecode.TrimEnd('%');
                string[] array = ecode.Split('%');

                if (array.Length == 1)
                {
                    model.EOCode1 = array[0].Split('*')[0];
                    model.EOComment1 = array[0].Split('*')[1];
                }
                else if (array.Length == 2)
                {
                    model.EOCode1 = array[0].Split('*')[0];
                    model.EOComment1 = array[0].Split('*')[1];
                    if (array[1]!=" ")
                    {
                        model.EOCode2 = array[1].Split('*')[0];
                        model.EOComment2 = array[1].Split('*')[1];
                    }
                }
                else if (array.Length == 3)
                {
                    model.EOCode1 = array[0].Split('*')[0];
                    model.EOComment1 = array[0].Split('*')[1];
                    model.EOCode2 = array[1].Split('*')[0];
                    model.EOComment2 = array[1].Split('*')[1];
                    model.EOCode3 = array[2].Split('*')[0];
                    model.EOComment3 = array[2].Split('*')[1];
                }
                else if (array.Length == 4)
                {
                    model.EOCode1 = array[0].Split('*')[0];
                    model.EOComment1 = array[0].Split('*')[1];
                    model.EOCode2 = array[1].Split('*')[0];
                    model.EOComment2 = array[1].Split('*')[1];
                    model.EOCode3 = array[2].Split('*')[0];
                    model.EOComment3 = array[2].Split('*')[1];
                    model.EOCode4 = array[3].Split('*')[0];
                    model.EOComment4 = array[3].Split('*')[1];
                }
                else if (array.Length == 5)
                {
                    model.EOCode1 = array[0].Split('*')[0];
                    model.EOComment1 = array[0].Split('*')[1];
                    model.EOCode2 = array[1].Split('*')[0];
                    model.EOComment2 = array[1].Split('*')[1];
                    model.EOCode3 = array[2].Split('*')[0];
                    model.EOComment3 = array[2].Split('*')[1];
                    model.EOCode4 = array[3].Split('*')[0];
                    model.EOComment4 = array[3].Split('*')[1];
                    model.EOCode5 = array[4].Split('*')[0];
                    model.EOComment5 = array[4].Split('*')[1];
                }

                else if (array.Length == 6)
                {
                    model.EOCode1 = array[0].Split('*')[0];
                    model.EOComment1 = array[0].Split('*')[1];
                    model.EOCode2 = array[1].Split('*')[0];
                    model.EOComment2 = array[1].Split('*')[1];
                    model.EOCode3 = array[2].Split('*')[0];
                    model.EOComment3 = array[2].Split('*')[1];
                    model.EOCode4 = array[3].Split('*')[0];
                    model.EOComment4 = array[3].Split('*')[1];
                    model.EOCode5 = array[4].Split('*')[0];
                    model.EOComment5 = array[4].Split('*')[1];
                    model.EOCode6 = array[5].Split('*')[0];
                    model.EOComment6 = array[5].Split('*')[1];
                }
            }

            string userNtlg = HttpContext.Current.Session[Constants.UserName].ToString();
            int projectId = Convert.ToInt32(HttpContext.Current.Session[Constants.ProjectId]);
           
            using (CBI_Anes_HighEntities _context = new CBI_Anes_HighEntities())
            {
                var TD = _context.tbl_TRANSACTION_DETAILS.Where(x => x.TRANS_DETAIL_ID == model.TRANS_DETAIL_ID).FirstOrDefault();
                var transactionExits = _context.tbl_TRANSACTION.Where(x => x.BATCH_ID == model.BatchId).FirstOrDefault();
                var batchDetails = _context.tbl_IMPORT_TABLE.Where(x => x.BATCH_ID == model.BatchId).FirstOrDefault();

                if (TD == null)
                {
                    if (transactionExits == null)
                    {
                        tbl_TRANSACTION transaction = new tbl_TRANSACTION();
                        transaction.PROJECT_ID = projectId;
                        transaction.BATCH_ID = model.BatchId;
                        transaction.PRACTICE_ID = practiceId;

                        transaction.CODED_DATE = System.DateTime.Now;
                        transaction.CODED_BY = userNtlg;
                        transaction.CODING_STARTTIME = System.DateTime.Now;
                        /*
                        DateTime dateValue;
                        foreach (CultureInfo ci in CultureInfo.GetCultures(CultureTypes.AllCultures))
                        {
                            string culture = ci.Name;
                            string culture1 = ci.EnglishName;
                        }                        
                        //--------------------------------SUBHAJA----------------------
                        CultureInfo culture12 = CultureInfo.CurrentCulture;
                        DateTimeStyles styles = DateTimeStyles.None;
                        DateTime.TryParse((System.DateTime.Now).ToString(), culture12, styles, out dateValue);
                        transaction.CODING_STARTTIME = dateValue;
                        //--------------------------------SUBHAJA----------------------
                          */
                        transaction.CODING_STATUS = Constants.CodingInProgress;
                        batchDetails.BATCH_STATUS = Constants.CodingInProgress;
                        _context.tbl_TRANSACTION.Add(transaction);
                        _context.SaveChanges();
                    }
                   
                    var trans = _context.tbl_TRANSACTION.Where(x => x.BATCH_ID == model.BatchId && x.PROJECT_ID == projectId).FirstOrDefault();
                    tbl_TRANSACTION_DETAILS transDetails = new tbl_TRANSACTION_DETAILS();
                    transDetails.TRANS_ID = trans.TRANS_ID;
                    transDetails.BEGINNING_DOS = CryptoGraphy.Encrypt(model.BeginningDOS);
                    transDetails.ENDING_DOS = CryptoGraphy.Encrypt(model.EDos);
                    transDetails.ICD_CODE = model.DxType;
                    transDetails.ICD = model.DXCode;
                    transDetails.PAGE_NO = model.Page;
                    if (screeenName == "Feedback" || screeenName=="QCClarification")
                    {
                        if (screeenName=="QCClarification")
                        {
                            transDetails.ASA_CROSS = "Y";
                        }
                        else if (screeenName == "Feedback")
                        {
                            HttpContext.Current.Session["bthID"] = model.BatchId;
                        }
                        transDetails.MODIFIER="Y";
                    }
                    transDetails.EO_CODE1 = model.EOCode1;
                    transDetails.EO_CODE2 = model.EOCode2;
                    transDetails.EO_CODE3 = model.EOCode3;
                    transDetails.EO_CODE4 = model.EOCode4;
                    transDetails.EO_CODE5 = model.EOCode5;
                    transDetails.EO_CODE6 = model.EOCode6;
                    transDetails.EO_COMMENT1 = model.EOComment1;
                    transDetails.EO_COMMENT2 = model.EOComment2;
                    transDetails.EO_COMMENT3 = model.EOComment3;
                    transDetails.EO_COMMENT4 = model.EOComment4;
                    transDetails.EO_COMMENT5 = model.EOComment5;
                    transDetails.EO_COMMENT6 = model.EOComment6;
                    transDetails.COMMENTS = model.ICDComments;
                    
                    _context.tbl_TRANSACTION_DETAILS.Add(transDetails);

                    HttpContext.Current.Session["_TempTransactionID"] = trans.TRANS_ID.ToString();
                }
                else
                {
                    TD.BEGINNING_DOS = CryptoGraphy.Encrypt(model.BeginningDOS);
                    TD.ENDING_DOS = CryptoGraphy.Encrypt(model.EDos);
                    TD.ICD_CODE = model.DxType;
                    TD.ICD = model.DXCode;
                    TD.PAGE_NO = model.Page;
                    //TD.EO_CODE1 = GetMultipleSelectedEoCode(model.EOCodeList);
                    //TD.EO_COMMENT1 = GetMultipleSelectedEoComment(model.EOCodeList);
                    TD.EO_CODE1 = model.EOCode1;
                    TD.EO_CODE2 = model.EOCode2;
                    TD.EO_CODE3 = model.EOCode3;
                    TD.EO_CODE4 = model.EOCode4;
                    TD.EO_CODE5 = model.EOCode5;
                    TD.EO_CODE6 = model.EOCode6;
                    TD.EO_COMMENT1 = model.EOComment1;
                    TD.EO_COMMENT2 = model.EOComment2;
                    TD.EO_COMMENT3 = model.EOComment3;
                    TD.EO_COMMENT4 = model.EOComment4;
                    TD.EO_COMMENT5 = model.EOComment5;
                    TD.EO_COMMENT6 = model.EOComment6;
                    TD.COMMENTS = model.ICDComments;
                    if (TD.Error_Correction == "N")
                    {
                        TD.Error_Correction = "Mod";
                    }
                }
                _context.SaveChanges();
                #region Insert Transaction details in tbl_TRANSACTION_DETAILS_BACKUP
                if (screeenName == "codingTransaction")
                { 
                    var TDB = _context.tbl_TRANSACTION_DETAILS_BACKUP.Where(x => x.TRANS_DETAILS_ID == model.TRANS_DETAIL_ID).FirstOrDefault();

                    if (TDB == null)
                    {
                        tbl_TRANSACTION_DETAILS_BACKUP transDetailsHistory = new tbl_TRANSACTION_DETAILS_BACKUP();
                        //var TDetails = _context.tbl_TRANSACTION_DETAILS.Where(x => x.TRANS_DETAIL_ID == model.TRANS_DETAIL_ID).FirstOrDefault();
                        var trans = _context.tbl_TRANSACTION.Where(x => x.BATCH_ID == model.BatchId && x.PROJECT_ID == projectId).FirstOrDefault();
                        var TDetails = _context.tbl_TRANSACTION_DETAILS.Where(x => x.TRANS_ID == trans.TRANS_ID).OrderByDescending(x => x.TRANS_DETAIL_ID).FirstOrDefault();

                        transDetailsHistory.TRANS_DETAILS_ID = TDetails.TRANS_DETAIL_ID;
                        transDetailsHistory.TRANS_ID = trans.TRANS_ID;
                        transDetailsHistory.BEGINNING_DOS = CryptoGraphy.Encrypt(model.BeginningDOS);
                        transDetailsHistory.ENDING_DOS = CryptoGraphy.Encrypt(model.EDos);
                        transDetailsHistory.Dx_TYPE = model.DxType;
                        transDetailsHistory.Dx_CODE = model.DXCode;
                        transDetailsHistory.PAGE_NO = model.Page;
                        transDetailsHistory.ICD_COMMENTS = model.ICDComments;
                        transDetailsHistory.EO_CODE1 = model.EOCode1;
                        transDetailsHistory.EO_COMMENT1 = model.EOComment1;
                        transDetailsHistory.EO_CODE2 = model.EOCode2;
                        transDetailsHistory.EO_COMMENT2 = model.EOComment2;
                        transDetailsHistory.EO_CODE3 = model.EOCode3;
                        transDetailsHistory.EO_COMMENT3 = model.EOComment3;
                        transDetailsHistory.EO_CODE4 = model.EOCode4;
                        transDetailsHistory.EO_COMMENT4 = model.EOComment4;
                        transDetailsHistory.EO_CODE5 = model.EOCode5;
                        transDetailsHistory.EO_COMMENT5 = model.EOComment5;
                        transDetailsHistory.EO_CODE6 = model.EOCode6;
                        transDetailsHistory.EO_COMMENT6 = model.EOComment6;
                        _context.tbl_TRANSACTION_DETAILS_BACKUP.Add(transDetailsHistory);
                    }
                    else
                    {
                        // TDB.TRANS_DETAILS_ID = TDetails.TRANS_DETAIL_ID;
                        TDB.BEGINNING_DOS = CryptoGraphy.Encrypt(model.BeginningDOS);
                        TDB.ENDING_DOS = CryptoGraphy.Encrypt(model.EDos);
                        TDB.Dx_TYPE = model.DxType;
                        TDB.Dx_CODE = model.DXCode;
                        TDB.PAGE_NO = model.Page;
                        TDB.ICD_COMMENTS = model.ICDComments;
                        TDB.EO_CODE1 = model.EOCode1;
                        TDB.EO_CODE2 = model.EOCode2;
                        TDB.EO_CODE3 = model.EOCode3;
                        TDB.EO_CODE4 = model.EOCode4;
                        TDB.EO_CODE5 = model.EOCode5;
                        TDB.EO_CODE6 = model.EOCode6;
                        TDB.EO_COMMENT1 = model.EOComment1;
                        TDB.EO_COMMENT2 = model.EOComment2;
                        TDB.EO_COMMENT3 = model.EOComment3;
                        TDB.EO_COMMENT4 = model.EOComment4;
                        TDB.EO_COMMENT5 = model.EOComment5;
                        TDB.EO_COMMENT6 = model.EOComment6;
                    }
                    #endregion
                    _context.SaveChanges();
                }

              
            }
        }
        #endregion

        #region GetTrackingGridData
        public List<HighMarkCoderTransactionModel> GetTrackingGridData()
        {
            using (CBI_Anes_HighEntities _context = new CBI_Anes_HighEntities())
            {
                int projectId = Convert.ToInt32(HttpContext.Current.Session[Constants.ProjectId]);
                string userNtlg = HttpContext.Current.Session[Constants.UserName].ToString();
                string[] status = { "Coded", "Pending", "Clarifications" };
                var list = (from I in _context.tbl_IMPORT_TABLE
                            join T in _context.tbl_TRANSACTION on I.BATCH_ID equals T.BATCH_ID
                            join TD in _context.tbl_TRANSACTION_DETAILS on T.TRANS_ID equals TD.TRANS_ID
                            where T.PROJECT_ID == projectId && status.Contains(T.CODING_STATUS) && (T.QC_STATUS == null) && I.ALLOTTED_TO == userNtlg && T.PRACTICE_ID==practiceId
                            select new
                            {
                                I.BATCH_ID,
                                I.First_Name,
                                I.Last_Name,
                                I.MEMBER_DOB,
                                I.ENCOUNTER_TYPE,
                                I.ACCOUNT_NO,
                                I.MEMBER_GENDER,
                                TD.BEGINNING_DOS,
                                TD.ENDING_DOS,
                                TD.ICD_CODE,
                                TD.ICD,
                                TD.PAGE_NO,
                                TD.EO_CODE1,
                                TD.EO_CODE2,
                                TD.EO_CODE3,
                                TD.EO_CODE4,
                                TD.EO_CODE5,
                                TD.EO_CODE6,
                                TD.EO_COMMENT1,
                                TD.EO_COMMENT2,
                                TD.EO_COMMENT3,
                                TD.EO_COMMENT4,
                                TD.EO_COMMENT5,
                                TD.EO_COMMENT6,
                                TD.TRANS_DETAIL_ID,
                                TD.TRANS_ID,
                                TD.COMMENTS
                            }).OrderBy(x => x.ACCOUNT_NO).ToList();
                return (from item in list
                        select new HighMarkCoderTransactionModel
                        {
                            BatchId = item.BATCH_ID,
                            MemberFirstName = CryptoGraphy.Decrypt(item.First_Name),
                            MemberLastName = CryptoGraphy.Decrypt(item.Last_Name),
                            MemberDOB = !string.IsNullOrEmpty(item.MEMBER_DOB.ToString()) ? CryptoGraphy.Decrypt(item.MEMBER_DOB) : "",
                            EncounterType = item.ENCOUNTER_TYPE,
                            TrackingCode = CryptoGraphy.Decrypt(item.ACCOUNT_NO),
                            MemberGender = CryptoGraphy.Decrypt(item.MEMBER_GENDER),
                            BeginningDOS = CryptoGraphy.Decrypt(item.BEGINNING_DOS),
                            EndingDOS = CryptoGraphy.Decrypt(item.ENDING_DOS),
                            DxType = item.ICD_CODE,
                            DXCode = item.ICD,
                            Page = item.PAGE_NO,
                            EOCode1 = item.EO_CODE1,
                            EOCode2 = item.EO_CODE2,
                            EOCode3 = item.EO_CODE3,
                            EOCode4 = item.EO_CODE4,
                            EOCode5 = item.EO_CODE5,
                            EOCode6 = item.EO_CODE6,
                            EOComment1 = item.EO_COMMENT1,
                            EOComment2 = item.EO_COMMENT2,
                            EOComment3 = item.EO_COMMENT3,
                            EOComment4 = item.EO_COMMENT4,
                            EOComment5 = item.EO_COMMENT5,
                            EOComment6 = item.EO_COMMENT6,
                            TRANS_DETAIL_ID = item.TRANS_DETAIL_ID,
                            TRANS_ID = item.TRANS_ID.ToString(),
                            ICDComments=item.COMMENTS
                        }).OrderBy(x => x.TrackingCode).ToList();
            }
        }
        #endregion

        #region SaveFinalStatus
        public void SaveFinalStatus(int batchId, string status, string coderComment, string Gender, int totalPages)
        {
            using (CBI_Anes_HighEntities _context = new CBI_Anes_HighEntities())
            {
                var import = _context.tbl_IMPORT_TABLE.Where(x => x.BATCH_ID == batchId).FirstOrDefault();
                var trans = _context.tbl_TRANSACTION.Where(x => x.BATCH_ID == batchId).FirstOrDefault();
                string userNtlg = HttpContext.Current.Session[Constants.UserName].ToString();
                if (import != null && trans != null)
                {
                    if (status == "Pending")
                    {
                        import.BATCH_STATUS = "Pending";
                    }
                    else if (status == "Clarifications")
                    {
                        import.BATCH_STATUS = "Clarifications";
                    }
                    else if (status == "Completed")
                    {
                        import.BATCH_STATUS = "Coded";
                    }

                    trans.QC_STATUS = null;
                    if (status == "Completed")
                    {
                        trans.CODING_STATUS = "Coded";
                    }
                    else
                    {
                        trans.CODING_STATUS = status;
                    }
                    //import.MEMBER_GENDER = !string.IsNullOrEmpty(Gender) ? CryptoGraphy.Encrypt(Gender) : CryptoGraphy.Encrypt(string.Empty);
                    trans.PRACTICE_ID = practiceId;
                    trans.CODING_COMMENTS = coderComment;
                    trans.CODING_ENDTIME = System.DateTime.Now;
                    trans.Total_Pages = totalPages;
                   /* //----timezone
                    var UserLocation = _context.tbl_USER_ACCESS.Where(x => x.PROJECT_ID == PROJECTID_g && x.PRACTICE_ID == practiceId && x.USER_NTLG == USERNTLG_g).ToList();
                    DateTime dateValue;
                    CultureInfo culture = CultureInfo.CurrentCulture;
                    DateTimeStyles styles = DateTimeStyles.None;
                    DateTime.TryParse((System.DateTime.Now).ToString(), culture, styles, out dateValue);
                    trans.CODING_ENDTIME = dateValue;//System.DateTime.Now;*/
                    trans.CODING_ENDTIME = System.DateTime.Now; 
                    trans.CODED_DATE = System.DateTime.Now;
                    trans.CODED_BY = userNtlg;
                    _context.SaveChanges();
                }
            }
        }
        #endregion

        #region DeleteDXRow

        public void DeleteDXRow(int transDetailsId, string ScreenName)
        {
            using (CBI_Anes_HighEntities _context = new CBI_Anes_HighEntities())
            {
                var transDetails = _context.tbl_TRANSACTION_DETAILS.Where(x => x.TRANS_DETAIL_ID == transDetailsId).FirstOrDefault();

                if (transDetails != null)
                {
                    if (ScreenName=="Coding")
                    {
                        _context.tbl_TRANSACTION_DETAILS.Remove(transDetails);
                    }
                    else
                    {
                        if (ScreenName=="QCFeedback")
                        {
                            var list = (from T in _context.tbl_TRANSACTION 
                                        join TD in _context.tbl_TRANSACTION_DETAILS on T.TRANS_ID equals TD.TRANS_ID
                                        where TD.TRANS_DETAIL_ID == transDetailsId
                                        select new SelectListItem
                                        {
                                            Text = T.BATCH_ID.ToString(),
                                            Value = T.BATCH_ID.ToString()
                                        }).ToList();

                            string value = list[0].Text;
                            HttpContext.Current.Session["bthID"] = list[0].Text;
                        }
                        var transDetailsCount = _context.tbl_TRANSACTION_DETAILS.Where(x => x.TRANS_ID == transDetails.TRANS_ID).Count();
                        if (transDetailsCount > 1)
                        {
                            _context.tbl_TRANSACTION_DETAILS.Remove(transDetails);
                        }
                    }
                    _context.SaveChanges();
                }

                if (ScreenName=="Coding")
	            {
                    var transDetailsBackup = _context.tbl_TRANSACTION_DETAILS_BACKUP.Where(x => x.TRANS_DETAILS_ID == transDetailsId).FirstOrDefault();
                    if (transDetailsBackup != null)
                    {
                        _context.tbl_TRANSACTION_DETAILS_BACKUP.Remove(transDetailsBackup);
                        _context.SaveChanges();
                    }
	            }
               
            }
        }
        #endregion

        #region UpdateTrackingGridData
        public void UpdateTrackingGridData(HighMarkCoderTransactionModel model)
        {
            using (CBI_Anes_HighEntities _context = new CBI_Anes_HighEntities())
            {
                var transDetails = _context.tbl_TRANSACTION_DETAILS.Where(x => x.TRANS_DETAIL_ID == model.TRANS_DETAIL_ID).FirstOrDefault();
                if (transDetails != null)
                {
                    transDetails.BEGINNING_DOS = CryptoGraphy.Encrypt(model.BeginningDOS);
                    transDetails.ENDING_DOS = CryptoGraphy.Encrypt(model.EndingDOS);
                    transDetails.ICD_CODE = model.DxType;
                    transDetails.ICD = model.DXCode;
                    transDetails.PAGE_NO = model.Page;
                    _context.SaveChanges();
                }
                var transDetailsBackup = _context.tbl_TRANSACTION_DETAILS_BACKUP.Where(x => x.TRANS_DETAILS_ID == model.TRANS_DETAIL_ID).FirstOrDefault();
                if (transDetailsBackup != null)
                {
                    transDetailsBackup.BEGINNING_DOS = CryptoGraphy.Encrypt(model.BeginningDOS);
                    transDetailsBackup.ENDING_DOS = CryptoGraphy.Encrypt(model.EndingDOS);
                    transDetailsBackup.Dx_TYPE = model.DxType;
                    transDetailsBackup.Dx_CODE = model.DXCode;
                    transDetailsBackup.PAGE_NO = model.Page;
                    _context.SaveChanges();
                }
            }
        }
        #endregion



        #region Check DXCode
        public List<HighMarkCoderTransactionModel> CheckDXCode(string dxvalue, string dxTp, string memberDOB, string endingDOS)
        {
            using (CBI_Anes_HighEntities _context = new CBI_Anes_HighEntities())
            {
                //int projectId = Convert.ToInt32(HttpContext.Current.Session[Constants.ProjectId]);
                
                //// int dxTpId =  int.Parse(dxTp);
                //string DxMatch = dxvalue.ToUpper();
                //var dxCode = _context.TBL_DX_CODE_MASTER.Where(x => x.PROJECT_ID == projectId && x.DX_CODE == DxMatch && x.DX_TYPE == dxTp && x.PRACTICE_ID==PracticeID).FirstOrDefault();
                //if (dxCode != null)
                //{
                //    return dxCode.DX_CODE.ToList();
                //}
                //else
                //{
                //    return "No matching found";
                //}
                List<HighMarkCoderTransactionModel> list = new List<HighMarkCoderTransactionModel>();
                HighMarkCoderTransactionModel model = new HighMarkCoderTransactionModel();
                int projectId = Convert.ToInt32(HttpContext.Current.Session[Constants.ProjectId]);
                int PracticeID = Convert.ToInt32(HttpContext.Current.Session[Constants.PracticeID]);
                if (PracticeID == 1)
                {
                    if (endingDOS.ToUpper().Contains("NO DOS"))
                    {
                        var dxCode = (from item in _context.TBL_DX_CODE_MASTER.Where(x => x.DX_CODE == dxvalue && x.DX_TYPE == dxTp && x.PRACTICE_ID == PracticeID && x.PROJECT_ID == projectId) select new { item.AGE_VALIDATION, item.ERROR_POPUP, item.DX_CODE, item.EO_Code, item.DOS, item.Gender }).FirstOrDefault();
                        if (dxCode != null)
                        {
                            model.DXCode = dxCode.DX_CODE;
                            model.AgeValidation = dxCode.AGE_VALIDATION;
                            model.ErrorPopup = dxCode.ERROR_POPUP;
                            model.EEocode = dxCode.EO_Code;
                            model.MemberDOB = memberDOB;
                            model.EndingDOS = dxCode.DOS.ToString();
                            model.Gender = dxCode.Gender;
                            list.Add(model);
                            return list;
                        }
                        else
                        {
                            model.DXCode = "";
                            model.AgeValidation = "";
                            model.ErrorPopup = "";
                            model.EEocode = "";
                            model.MemberDOB = memberDOB;
                            model.EndingDOS = "";
                            model.Gender = "";
                            list.Add(model);
                            return list;
                        }
                    }
                    else
                    {
                        DateTime Edos = Convert.ToDateTime(Constants.dateKey);
                        DateTime DOS = Convert.ToDateTime(endingDOS);

                        if (Edos > DOS)
                        {
                            var dxCode = (from item in _context.TBL_DX_CODE_MASTER.Where(x => x.DX_CODE == dxvalue && x.DX_TYPE == dxTp && x.PRACTICE_ID == PracticeID && x.PROJECT_ID == projectId && (x.DOS >= DOS && x.DOS < Edos)) select new { item.AGE_VALIDATION, item.ERROR_POPUP, item.DX_CODE, item.EO_Code, item.DOS, item.Gender }).FirstOrDefault();
                            if (dxCode != null)
                            {
                                model.DXCode = dxCode.DX_CODE;
                                model.AgeValidation = dxCode.AGE_VALIDATION;
                                model.ErrorPopup = dxCode.ERROR_POPUP;
                                model.EEocode = dxCode.EO_Code;
                                model.MemberDOB = memberDOB;
                                model.EndingDOS = dxCode.DOS.ToString();
                                model.Gender = dxCode.Gender;
                                list.Add(model);
                                return list;
                            }
                            else
                            {
                                model.DXCode = "";
                                model.AgeValidation = "";
                                model.ErrorPopup = "";
                                model.EEocode = "";
                                model.MemberDOB = memberDOB;
                                model.EndingDOS = "";
                                model.Gender = "";
                                list.Add(model);
                                return list;
                            }
                        }
                        else
                        {
                            var dxCode = (from item in _context.TBL_DX_CODE_MASTER.Where(x => x.DX_CODE == dxvalue && x.DX_TYPE == dxTp && x.PRACTICE_ID == PracticeID && x.PROJECT_ID == projectId && (x.DOS <= DOS && x.DOS >= Edos)) select new { item.AGE_VALIDATION, item.ERROR_POPUP, item.DX_CODE, item.EO_Code, item.DOS, item.Gender }).FirstOrDefault();
                            if (dxCode != null)
                            {
                                model.DXCode = dxCode.DX_CODE;
                                model.AgeValidation = dxCode.AGE_VALIDATION;
                                model.ErrorPopup = dxCode.ERROR_POPUP;
                                model.EEocode = dxCode.EO_Code;
                                model.MemberDOB = memberDOB;
                                model.EndingDOS = dxCode.DOS.ToString();
                                model.Gender = dxCode.Gender;
                                list.Add(model);
                                return list;
                            }
                            else
                            {
                                model.DXCode = "";
                                model.AgeValidation = "";
                                model.ErrorPopup = "";
                                model.EEocode = "";
                                model.MemberDOB = memberDOB;
                                model.EndingDOS = "";
                                model.Gender = "";
                                list.Add(model);
                                return list;
                            }
                        }
                    }
                }
                else
                {
                    if (endingDOS.ToUpper().Contains("NO DOS"))
                    {
                        var dxCode = (from item in _context.TBL_DX_CODE_MASTER.Where(x => x.DX_CODE == dxvalue && x.DX_TYPE == dxTp && x.PRACTICE_ID == PracticeID && x.PROJECT_ID == projectId) select new { item.AGE_VALIDATION, item.ERROR_POPUP, item.DX_CODE, item.EO_Code, item.DOS, item.Gender }).FirstOrDefault();
                        if (dxCode != null)
                        {
                            model.DXCode = dxCode.DX_CODE;
                            model.AgeValidation = dxCode.AGE_VALIDATION;
                            model.ErrorPopup = dxCode.ERROR_POPUP;
                            model.EEocode = dxCode.EO_Code;
                            model.MemberDOB = memberDOB;
                            model.EndingDOS = dxCode.DOS.ToString();
                            model.Gender = dxCode.Gender;
                            list.Add(model);
                            return list;
                        }
                        else
                        {
                            model.DXCode = "";
                            model.AgeValidation = "";
                            model.ErrorPopup = "";
                            model.EEocode = "";
                            model.MemberDOB = memberDOB;
                            model.EndingDOS = "";
                            model.Gender = "";
                            list.Add(model);
                            return list;
                        }
                    }
                    else
                    {
                        //DateTime Edos = Convert.ToDateTime(Constants.dateKey);
                        DateTime DOS = Convert.ToDateTime(endingDOS);

                        //if (Edos > DOS)
                        //{
                        var dxCode = (from item in _context.TBL_DX_CODE_MASTER.Where(x => x.DX_CODE == dxvalue && x.DX_TYPE == dxTp && x.PRACTICE_ID == PracticeID && x.PROJECT_ID == projectId) select new { item.AGE_VALIDATION, item.ERROR_POPUP, item.DX_CODE, item.EO_Code, item.DOS, item.Gender }).FirstOrDefault();
                        if (dxCode != null)
                        {
                            model.DXCode = dxCode.DX_CODE;
                            model.AgeValidation = dxCode.AGE_VALIDATION;
                            model.ErrorPopup = dxCode.ERROR_POPUP;
                            model.EEocode = dxCode.EO_Code;
                            model.MemberDOB = memberDOB;
                            model.EndingDOS = dxCode.DOS.ToString();
                            model.Gender = dxCode.Gender;
                            list.Add(model);
                            return list;
                        }
                        else
                        {
                            model.DXCode = "";
                            model.AgeValidation = "";
                            model.ErrorPopup = "";
                            model.EEocode = "";
                            model.MemberDOB = memberDOB;
                            model.EndingDOS = "";
                            model.Gender = "";
                            list.Add(model);
                            return list;
                        }
                        //}
                        //else
                        //{
                        //    var dxCode = (from item in _context.TBL_DX_CODE_MASTER.Where(x => x.DX_CODE == dxvalue && x.DX_TYPE == dxTp && x.PRACTICE_ID == PracticeID && x.PROJECT_ID == projectId && (x.DOS <= DOS && x.DOS >= Edos)) select new { item.AGE_VALIDATION, item.ERROR_POPUP, item.DX_CODE, item.EO_Code, item.DOS, item.Gender }).FirstOrDefault();
                        //    if (dxCode != null)
                        //    {
                        //        model.DXCode = dxCode.DX_CODE;
                        //        model.AgeValidation = dxCode.AGE_VALIDATION;
                        //        model.ErrorPopup = dxCode.ERROR_POPUP;
                        //        model.EEocode = dxCode.EO_Code;
                        //        model.MemberDOB = memberDOB;
                        //        model.EndingDOS = dxCode.DOS.ToString();
                        //        model.Gender = dxCode.Gender;
                        //        list.Add(model);
                        //        return list;
                        //    }
                        //    else
                        //    {
                        //        model.DXCode = "";
                        //        model.AgeValidation = "";
                        //        model.ErrorPopup = "";
                        //        model.EEocode = "";
                        //        model.MemberDOB = memberDOB;
                        //        model.EndingDOS = "";
                        //        model.Gender = "";
                        //        list.Add(model);
                        //        return list;
                        //    }
                        //}
                    }
                }
            }
        }

        #endregion
        #region GetMultipleSelectedItems
        private string GetMultipleSelectedEoComment(List<SelectListItem> selectedItems)
        {
            string selectedArrar = string.Empty;
            if (selectedItems != null)
            {
                foreach (var item in selectedItems)
                {
                    if (item.Selected == true)
                    {
                        selectedArrar = selectedArrar + "," + item.Value;
                    }
                }
                return selectedArrar.TrimStart(',');
            }
            else
            {
                return null;
            }
        }
        private string GetMultipleSelectedEoCode(List<SelectListItem> selectedItems)
        {
            string selectedArrar = string.Empty;
            if (selectedItems != null)
            {
                foreach (var item in selectedItems)
                {
                    if (item.Selected == true)
                    {
                        selectedArrar = selectedArrar + "," + item.Text;
                    }
                }
                return selectedArrar.TrimStart(',');
            }
            else
            {
                return null;
            }
        }
        #endregion

        //QC Feed Back Section

        #region HighMarkCoderTransaction
        public QCFeedBackModel QCFeedBack()
        {
            QCFeedBackModel model = new QCFeedBackModel();
            model.QCStatusList = GetQCStatusList();
            return model;
        }
        #endregion

        #region QCStatusList
        public List<SelectListItem> GetQCStatusList()
        {
            List<SelectListItem> listItems = new List<SelectListItem>();
            listItems.Add(new SelectListItem { Text = "No", Value = "No" });
            listItems.Add(new SelectListItem { Text = "Yes", Value = "Yes" });

            return listItems;
        }
        #endregion

        #region  Get QC Feed Back
        public DataTable QCFeedBackGrid(string status)
        {
            int projectId = Convert.ToInt32(HttpContext.Current.Session[Constants.ProjectId]);
            string userNtlg = HttpContext.Current.Session[Constants.UserName].ToString();
            int practiceId = Convert.ToInt32(HttpContext.Current.Session[Constants.PracticeID]);
            DataSet dsCommon = new DataSet();
            CBI_Anes_HighEntities dbObj = Singleton.Instance;
            List<SqlParameter> Parameter = new List<SqlParameter>();
            dsCommon.Clear();
            Parameter.Add(new SqlParameter("@ProjectId", projectId));
            Parameter.Add(new SqlParameter("@QCStatus", status));
            Parameter.Add(new SqlParameter("@Userntlg", userNtlg));
            Parameter.Add(new SqlParameter("@PracticeId", practiceId));
            dsCommon = DBExtension.ExecuteDataset(dbObj.Database, Constants.SPQcFeedBackData, Parameter);
            var tt = dsCommon;
            return dsCommon.Tables[0];

            //using (CBI_Anes_HighEntities _context = new CBI_Anes_HighEntities())
            //{
            //    try
            //    {
            //        dsCommon.Clear();
            //        SqlConnection conObj = new SqlConnection(Constants.ConnectionString);
            //        conObj.Open();
            //        SqlCommand cmdObj = new SqlCommand(Constants.SPQcFeedBackData, conObj);
            //        cmdObj.CommandType = CommandType.StoredProcedure;
            //        cmdObj.Parameters.AddWithValue("@ProjectId", projectId);
            //        cmdObj.Parameters.AddWithValue("@QCStatus", status);
            //        cmdObj.Parameters.AddWithValue("@Userntlg", userNtlg);
            //        cmdObj.Parameters.AddWithValue("@PracticeId", practiceId);
            //        SqlDataAdapter adapter1 = new SqlDataAdapter(cmdObj);
            //        adapter1.Fill(dsCommon);
            //        conObj.Close();
            //        var tt = dsCommon;

            //        return dsCommon.Tables[0];
            //    }
            //    catch (Exception e)
            //    {
            //        throw e;
            //    }
            //}
        }
        #endregion



        /////////////////// QC Feed Back
        #region GetTrackingGridData By trackingID
        public List<HighMarkCoderTransactionModel> GetTrackingGridDataBytrackingID(string trackingID)
        {
            using (CBI_Anes_HighEntities _context = new CBI_Anes_HighEntities())
            {
                int projectId = Convert.ToInt32(HttpContext.Current.Session[Constants.ProjectId]);
                string[] status = { "Completed", "Pending", "Clarifications" };
                var list = (from I in _context.tbl_IMPORT_TABLE
                            join T in _context.tbl_TRANSACTION on I.BATCH_ID equals T.BATCH_ID
                            join TD in _context.tbl_TRANSACTION_DETAILS on T.TRANS_ID equals TD.TRANS_ID
                            where T.PROJECT_ID == projectId && I.ACCOUNT_NO == trackingID && T.PRACTICE_ID==practiceId
                            select new
                            {
                                I.BATCH_ID,
                                I.First_Name,
                                I.Last_Name,
                                I.MEMBER_DOB,
                                I.ENCOUNTER_TYPE,
                                I.ACCOUNT_NO,
                                I.MEMBER_GENDER,
                                TD.BEGINNING_DOS,
                                TD.ENDING_DOS,
                                TD.ICD_CODE,
                                TD.ICD,
                                TD.PAGE_NO,
                                TD.EO_CODE1,
                                TD.EO_CODE2,
                                TD.EO_CODE3,
                                TD.EO_CODE4,
                                TD.EO_CODE5,
                                TD.EO_CODE6,
                                TD.EO_COMMENT1,
                                TD.EO_COMMENT2,
                                TD.EO_COMMENT3,
                                TD.EO_COMMENT4,
                                TD.EO_COMMENT5,
                                TD.EO_COMMENT6,
                                TD.TRANS_DETAIL_ID,
                                TD.TRANS_ID,
                                TD.COMMENTS,
                                I.PDF_Path
                            }).ToList();

                return (from item in list
                        select new HighMarkCoderTransactionModel
                        {
                            BatchId = item.BATCH_ID,
                            MemberFirstName = CryptoGraphy.Decrypt(item.First_Name),
                            MemberLastName = CryptoGraphy.Decrypt(item.Last_Name),
                            MemberDOB = !string.IsNullOrEmpty(item.MEMBER_DOB) ? CryptoGraphy.Decrypt(item.MEMBER_DOB) : "",
                            EncounterType = item.ENCOUNTER_TYPE,
                            TrackingCode = CryptoGraphy.Decrypt(item.ACCOUNT_NO),
                            MemberGender = CryptoGraphy.Decrypt(item.MEMBER_GENDER),
                            BeginningDOS = CryptoGraphy.Decrypt(item.BEGINNING_DOS),
                            EndingDOS = CryptoGraphy.Decrypt(item.ENDING_DOS),
                            DxType = item.ICD_CODE,
                            DXCode = item.ICD,
                            Page = item.PAGE_NO,
                            EOCode1 = item.EO_CODE1,
                            EOCode2 = item.EO_CODE2,
                            EOCode3 = item.EO_CODE3,
                            EOCode4 = item.EO_CODE4,
                            EOCode5 = item.EO_CODE5,
                            EOCode6 = item.EO_CODE6,
                            EOComment1 = item.EO_COMMENT1,
                            EOComment2 = item.EO_COMMENT2,
                            EOComment3 = item.EO_COMMENT3,
                            EOComment4 = item.EO_COMMENT4,
                            EOComment5 = item.EO_COMMENT5,
                            EOComment6 = item.EO_COMMENT6,
                            TRANS_DETAIL_ID = item.TRANS_DETAIL_ID,
                            TRANS_ID = item.TRANS_ID.ToString(),
                            ICDComments=item.COMMENTS,
                            PDFpath=item.PDF_Path
                        }).ToList();
            }
        }//&& (T.QC_STATUS==null)
        #endregion

        #region Save QCFeedback Details

        public string SaveQCFeedbackDetails(string transId)
        {
            string Status = "";

            using (CBI_Anes_HighEntities _context = new CBI_Anes_HighEntities())
            {
                int TID = Convert.ToInt32(transId);
                var transaction = _context.tbl_TRANSACTION.Where(x => x.TRANS_ID == TID).FirstOrDefault();
                var batchId = _context.tbl_IMPORT_TABLE.Where(x => x.BATCH_ID == transaction.BATCH_ID).FirstOrDefault();
                if (transaction != null)
                {
                    //var AcknowledgeData1 = (from TD in _context.tbl_TRANSACTION_DETAILS where TD.TRANS_ID == TID  && (TD.IS_ACKNOWLEDGE == "N" ||TD.IS_ACKNOWLEDGE=="Y")).Select().Count();
                    //var transDetailsCount = _context.tbl_TRANSACTION_DETAILS.Where(x => x.TRANS_ID == transDetails.TRANS_ID).Count();            
                    var AckAndClrCunt = _context.tbl_TRANSACTION_DETAILS.Where(x => (x.TRANS_ID == TID) && (x.IS_ACKNOWLEDGE == "N" || x.IS_ACKNOWLEDGE == "Y")).Count();
                    var ErrorCunt = _context.tbl_TRANSACTION_DETAILS.Where(x => (x.TRANS_ID == TID) && (x.Error_Correction == "N" || x.Error_Correction == "Y" || x.Error_Correction == "Mod" || x.ICD_RESULT!=null)).Count();
                    if (AckAndClrCunt==ErrorCunt)
                    {
                        var data = (from TD in _context.tbl_TRANSACTION_DETAILS
                                    where TD.TRANS_ID == TID && TD.Downcoded != null && TD.IS_ACKNOWLEDGE == "N"
                                    select new
                                    {
                                        ErrorCorrection = TD.Error_Correction
                                    }).ToList();

                        if (data.Count == 0)
                        {

                            if (transaction.QC_STATUS.ToUpper().Contains("ERROR"))
                            {
                                transaction.QC_STATUS = "QC Allotted";
                                transaction.IS_ACKNOWLEDGE = "Y";
                                //transaction.INSURANCE = "Y";
                                batchId.BATCH_STATUS = "QC Allotted";
                            }
                            else
                            {
                                transaction.QC_STATUS = "QCed";
                                transaction.IS_ACKNOWLEDGE = "Y";
                                batchId.BATCH_STATUS = "QCed";
                                transaction.QC_ERROR_CORRECTION = "Y";
                                transaction.QC_DATE = DateTime.Now;
                            }
                            transaction.IS_ACKNOWLEDGE_DATE = System.DateTime.Now;
                            transaction.REVIEW_REAUDIT = 1;
                        }
                        else
                        {
                            transaction.CODING_COMMENTS = "Coder Comments";
                            transaction.IS_ACKNOWLEDGE = "N";
                            transaction.RESIDENT = "1";
                            transaction.ACKNOWLEDGE_COMMENTS = "Y";
                        }
                        _context.SaveChanges();
                        Status = "Success";
                    }
                    else
                    {
                        Status = "Fail";
                    }
                }
                return Status;
            }
        }

        #endregion
        ///////////////////


        #region UpdateQCAck
        public void UpdateQCAck(string TID)
        {
            using (CBI_Anes_HighEntities _context = new CBI_Anes_HighEntities())
            {
                int transId = Convert.ToInt32(TID);
                var QCStatus = _context.tbl_TRANSACTION.Where(x => x.TRANS_ID == transId).FirstOrDefault();
                var transDetails = _context.tbl_TRANSACTION_DETAILS.Where(x => x.TRANS_ID == QCStatus.TRANS_ID).ToList();
                var import = _context.tbl_IMPORT_TABLE.Where(x => x.BATCH_ID == QCStatus.BATCH_ID).FirstOrDefault();
                if (QCStatus != null && import != null && QCStatus.QC_STATUS == "Error")//  && QCStatus.QC_ERROR_CORRECTION == "N"
                {
                    QCStatus.QC_STATUS = "QC Allotted";
                    QCStatus.IS_ACKNOWLEDGE = "Y";
                    import.BATCH_STATUS = "QC Allotted";
                    QCStatus.IS_ACKNOWLEDGE_DATE = System.DateTime.Now;

                    QCStatus.REVIEW_REAUDIT = 1;
                    for (int i = 0; i < transDetails.Count; i++)
                    {
                        transDetails[i].IS_ACKNOWLEDGE = "Y";
                    }
                    _context.SaveChanges();
                }
            }
        }
        #endregion

        #region UpdateQCAckByICD
        public string UpdateQCAckByICD(string TID, string screenName)
        {
            using (CBI_Anes_HighEntities _context = new CBI_Anes_HighEntities())
            {
                int transId = Convert.ToInt32(TID);
                _context.tbl_TRANSACTION_DETAILS.Where(x => x.TRANS_DETAIL_ID == transId).FirstOrDefault().IS_ACKNOWLEDGE = "Y";
                //_context.tbl_TRANSACTION_DETAILS.Where(x => x.TRANS_DETAIL_ID == transId).FirstOrDefault().COMMENTS = null;
               

                if (screenName=="QCClarification")
                {
                    _context.tbl_TRANSACTION_DETAILS.Where(x => x.TRANS_DETAIL_ID == transId).FirstOrDefault().Error_Count = null;
                    _context.SaveChanges();
                    var transID = (from TD in _context.tbl_TRANSACTION_DETAILS
                                   join T in _context.tbl_TRANSACTION on TD.TRANS_ID equals T.TRANS_ID
                                   where TD.TRANS_DETAIL_ID == transId
                                   select new
                                   {
                                       T.TRANS_ID
                                   }).FirstOrDefault().ToString();
                    return transID;
                }
                else {
                    _context.SaveChanges();
                    var batchID = (from TD in _context.tbl_TRANSACTION_DETAILS
                                   join T in _context.tbl_TRANSACTION on TD.TRANS_ID equals T.TRANS_ID
                                   where TD.TRANS_DETAIL_ID == transId
                                   select new
                                   {
                                       T.BATCH_ID
                                   }).FirstOrDefault().ToString();
                    return batchID;
                }
            }
        }
        #endregion

        // QC Clarification

        #region  Get QC Clarification
        public DataTable QCClarificationGrid()
        {
            int projectId = Convert.ToInt32(HttpContext.Current.Session[Constants.ProjectId]);
            string location = HttpContext.Current.Session[Constants.LocationName].ToString();
            string USERNTLG = HttpContext.Current.Session[Constants.UserName].ToString();
            DataSet dsCommon = new DataSet();

            CBI_Anes_HighEntities dbObj = Singleton.Instance;
            List<SqlParameter> Parameter = new List<SqlParameter>();
            dsCommon.Clear();
            Parameter.Add(new SqlParameter("@ProjectId", projectId));
            Parameter.Add(new SqlParameter("@PracticeId", practiceId));
            Parameter.Add(new SqlParameter("@Location", location));
            Parameter.Add(new SqlParameter("@NTLG", USERNTLG));
            dsCommon = DBExtension.ExecuteDataset(dbObj.Database, Constants.SPQcClarificationData, Parameter);
            var tt = dsCommon;
            return dsCommon.Tables[0];

            //using (CBI_Anes_HighEntities _context = new CBI_Anes_HighEntities())
            //{
            //    try
            //    {
            //        dsCommon.Clear();
            //        SqlConnection conObj = new SqlConnection(Constants.ConnectionString);
            //        conObj.Open();
            //        SqlCommand cmdObj = new SqlCommand(Constants.SPQcClarificationData, conObj);
            //        cmdObj.CommandType = CommandType.StoredProcedure;
            //        cmdObj.Parameters.AddWithValue("@ProjectId", projectId);
            //        cmdObj.Parameters.AddWithValue("@PracticeId", practiceId);
            //        cmdObj.Parameters.AddWithValue("@Location", location);
            //        cmdObj.Parameters.AddWithValue("@NTLG", USERNTLG);
            //        SqlDataAdapter adapter1 = new SqlDataAdapter(cmdObj);
            //        adapter1.Fill(dsCommon);
            //        conObj.Close();
            //        var tt = dsCommon;

            //        return dsCommon.Tables[0];
            //    }
            //    catch (Exception e)
            //    {
            //        throw e;
            //    }
            //}
        }
        #endregion

        #region GetOldComment
        public QCFeedBackModel GetOldComment(int transId)
        {
            using (CBI_Anes_HighEntities _context = new CBI_Anes_HighEntities())
            {
                //return (from T in _context.tbl_TRANSACTION where T.TRANS_ID == transId select new QCFeedBackModel { Comments = string.IsNullOrEmpty(T.CODING_COMMENTS) ? string.Empty : T.CODING_COMMENTS+"***",TransId=T.TRANS_ID }).FirstOrDefault();
                return (from T in _context.tbl_TRANSACTION_DETAILS where T.TRANS_DETAIL_ID == transId select new QCFeedBackModel { Comments = string.IsNullOrEmpty(T.Downcoded) ? string.Empty : T.Downcoded + "***", TransId = T.TRANS_DETAIL_ID }).FirstOrDefault();
            }
        }
        #endregion
        #region SaveComment
        public string SaveComment(QCFeedBackModel model, string screenName)
        {
            using (CBI_Anes_HighEntities _context = new CBI_Anes_HighEntities())
            {
                //var transaction = _context.tbl_TRANSACTION.Where(x => x.TRANS_ID == model.TransId).FirstOrDefault();
                //var transDetails = _context.tbl_TRANSACTION_DETAILS.Where(x => x.TRANS_ID == transaction.TRANS_ID).ToList();
                //if (transaction != null)
                //{
                //    transaction.CODING_COMMENTS = model.Comments;
                //    transaction.IS_ACKNOWLEDGE = "N";

                //    for (int i = 0; i < transDetails.Count; i++)
                //    {
                //        transDetails[i].IS_ACKNOWLEDGE = "Y";
                //    }
                //    _context.SaveChanges();
                //}

                _context.tbl_TRANSACTION_DETAILS.Where(x => x.TRANS_DETAIL_ID == model.TransId).FirstOrDefault().Downcoded = model.Comments;
                _context.tbl_TRANSACTION_DETAILS.Where(x => x.TRANS_DETAIL_ID == model.TransId).FirstOrDefault().IS_ACKNOWLEDGE = "N";
                if (screenName == "QCClarification")
                {
                    _context.tbl_TRANSACTION_DETAILS.Where(x => x.TRANS_DETAIL_ID == model.TransId).FirstOrDefault().Error_Count = "1";
                    _context.SaveChanges();
                    var transID = (from TD in _context.tbl_TRANSACTION_DETAILS
                                   join T in _context.tbl_TRANSACTION on TD.TRANS_ID equals T.TRANS_ID
                                   where TD.TRANS_DETAIL_ID == model.TransId
                                   select new
                                   {
                                       T.TRANS_ID
                                   }).FirstOrDefault().ToString();
                    return transID;
                }
                else
                {   
                    _context.SaveChanges();
                    var batchID = (from TD in _context.tbl_TRANSACTION_DETAILS
                                   join T in _context.tbl_TRANSACTION on TD.TRANS_ID equals T.TRANS_ID
                                   where TD.TRANS_DETAIL_ID == model.TransId
                                   select new
                                   {
                                       T.BATCH_ID
                                   }).FirstOrDefault().ToString();
                    return batchID;
                }
            }
        }
        #endregion

        #region SaveQcClarification

        public void SaveQcClarification(List<QCClarificationModel> model)
        {
            using (CBI_Anes_HighEntities _context = new CBI_Anes_HighEntities())
            {

                int transId = Convert.ToInt32(model[0].TransId);

                var transaction = _context.tbl_TRANSACTION.Where(x => x.TRANS_ID == transId).FirstOrDefault();

                foreach (var item in model)
                {

                    var trandetailsList = _context.tbl_TRANSACTION_DETAILS.Where(x => x.TRANS_DETAIL_ID == item.TransDetailsId).FirstOrDefault();
                    trandetailsList.QC_COMMENTS = !string.IsNullOrEmpty(trandetailsList.QC_COMMENTS) ? trandetailsList.QC_COMMENTS + "***" + item.QC_Comments : item.QC_Comments;
                    trandetailsList.IS_ACKNOWLEDGE = null;


                }

                transaction.QC_STATUS = "Error";
                transaction.QC_ERROR_CORRECTION = "N";
                transaction.IS_ACKNOWLEDGE = null;

                _context.SaveChanges();

            }
        }
        #endregion
        #region SaveQcAcknowledge

        public void SaveQcAcknowledge(List<QCClarificationModel> model)
        {
            using (CBI_Anes_HighEntities _context = new CBI_Anes_HighEntities())
            {
                int transId = Convert.ToInt32(model[0].TransId);

                var transaction = _context.tbl_TRANSACTION.Where(x => x.TRANS_ID == transId).FirstOrDefault();

                foreach (var item in model)
                {

                    var trandetailsList = _context.tbl_TRANSACTION_DETAILS.Where(x => x.TRANS_DETAIL_ID == item.TransDetailsId).FirstOrDefault();
                    trandetailsList.IS_ACKNOWLEDGE = "Y";
                }
                //transaction.IS_ACKNOWLEDGE_DATE = DateTime.Now;
                //transaction.QC_STATUS = "Qced";
                _context.SaveChanges();


                //******** Fist Phase Code***//
                //var transaction = _context.tbl_TRANSACTION.Where(x => x.TRANS_ID == transId).FirstOrDefault();
                //var transDetails = _context.tbl_TRANSACTION_DETAILS.Where(x => x.TRANS_ID == transaction.TRANS_ID).ToList();
                //if (transaction != null)
                //{
                //transaction.ERROR_WEIGHTAGE = errorWeight;
                //transaction.IS_ACKNOWLEDGE = "Y";
                //transaction.QC_STATUS = "Qced";
                //transaction.IS_ACKNOWLEDGE_DATE = DateTime.Now;
                //transaction.IS_AUDITED = 1;
                //transaction.IS_SKIPPED = 0;
                //for (int i = 0; i < transDetails.Count; i++)
                //{
                //    transDetails[i].IS_ACKNOWLEDGE = "Y";
                //}
                //_context.SaveChanges();
                // }
            }
        }
        #endregion

        #region Check Error Accounts
        public string CheckErrorAccounts()
        {
            int projectId = Convert.ToInt32(HttpContext.Current.Session[Constants.ProjectId]);
            int practiceId = Convert.ToInt32(HttpContext.Current.Session[Constants.PracticeID]);
            string userNtlg = HttpContext.Current.Session[Constants.UserName].ToString();
            DataSet dsCommon = new DataSet();

            CBI_Anes_HighEntities dbObj = Singleton.Instance;
            List<SqlParameter> Parameter = new List<SqlParameter>();
            dsCommon.Clear();
            Parameter.Add(new SqlParameter("@ProjectId", projectId));
            Parameter.Add(new SqlParameter("@Userntlg", userNtlg));
            Parameter.Add(new SqlParameter("@PracticeId", practiceId));
            dsCommon = DBExtension.ExecuteDataset(dbObj.Database, Constants.SPErrorAccoumts, Parameter);
            if (dsCommon.Tables[0].Rows.Count > 0)
            {
                return "Accounts Available";
            }
            else
            {
                return "No Accounts Found";
            }
            //using (CBI_Anes_HighEntities _context = new CBI_Anes_HighEntities())
            //{
            //try
            //{
            //    dsCommon.Clear();
            //    SqlConnection conObj = new SqlConnection(Constants.ConnectionString);
            //    conObj.Open();
            //    SqlCommand cmdObj = new SqlCommand(Constants.SPErrorAccoumts, conObj);
            //    cmdObj.CommandType = CommandType.StoredProcedure;
            //    cmdObj.Parameters.AddWithValue("@ProjectId", projectId);
            //    cmdObj.Parameters.AddWithValue("@Userntlg", userNtlg);
            //    cmdObj.Parameters.AddWithValue("@PracticeId", practiceId);
            //    SqlDataAdapter adapter1 = new SqlDataAdapter(cmdObj);
            //    adapter1.Fill(dsCommon);
            //    conObj.Close();
            //    if (dsCommon.Tables[0].Rows.Count > 0)
            //    {
            //        return "Accounts Available";
            //    }
            //    else
            //    {
            //        return "No Accounts Found";
            //    }
            //}
            //catch (Exception e)
            //{
            //    throw e;
            //}
            //}
        }
        #endregion

        #region Get Error Details

        public List<QCFeedBackModel> GetErrorDetails(string TDID)
        {
            using (CBI_Anes_HighEntities _context = new CBI_Anes_HighEntities())
            {
                List<QCFeedBackModel> Model = new List<QCFeedBackModel>();
                int transDetailsId = Convert.ToInt32(TDID);


                var data = (from TD in _context.tbl_TRANSACTION_DETAILS
                            where TD.TRANS_DETAIL_ID == transDetailsId
                            select new QCFeedBackModel
                            {
                                Error_Category = TD.ERROR_CATEGORY,
                                ERROR_SUBCATEGORY = TD.ERROR_SUBCATEGORY,
                                QC_Comments = TD.QC_COMMENTS
                            }).FirstOrDefault();
                if (data.Error_Category != null)
                {
                    string[] ErrorCategory = data.Error_Category.Split('*');
                    string[] ErrorSubcategory = data.ERROR_SUBCATEGORY.Split('*');
                    string[] QCComments = data.QC_Comments.Split('*');

                    for (int i = 0; i < ErrorCategory.Length; i++)
                    {
                        QCFeedBackModel item = new QCFeedBackModel();
                        item.Error_Category = ErrorCategory[i];
                        item.ERROR_SUBCATEGORY = ErrorSubcategory[i];
                        item.QC_Comments = QCComments[i];
                        Model.Add(item);
                    }
                }

                return Model;
            }
        }
        #endregion


        #region Check Duplicate Records
        public string CheckDuplicateRecords(string Beginning_DOS, string Ending_DOS, string Dx_Type, string DXCode, string PageNo, int Batch_Id)
        {
            using (CBI_Anes_HighEntities _context = new CBI_Anes_HighEntities())
            {
                int projectId = Convert.ToInt32(HttpContext.Current.Session[Constants.ProjectId]);
                var transactionExits = _context.tbl_TRANSACTION.Where(x => x.BATCH_ID == Batch_Id).FirstOrDefault();

                Beginning_DOS = CryptoGraphy.Encrypt(Beginning_DOS);
                Ending_DOS = CryptoGraphy.Encrypt(Ending_DOS);

                var CheckDuplicate = _context.tbl_TRANSACTION_DETAILS.Where(x => x.TRANS_ID == transactionExits.TRANS_ID && x.BEGINNING_DOS == Beginning_DOS && x.ENDING_DOS == Ending_DOS && x.ICD_CODE == Dx_Type && x.ICD == DXCode && x.PAGE_NO == PageNo).FirstOrDefault();
                if (CheckDuplicate == null)
                {
                    HttpContext.Current.Session["Value"] = "";
                    return "";
                }
                else
                {
                    HttpContext.Current.Session["Value"] = "matching found";
                    return "matching found";
                }
            }
        }
        #endregion


        public DataTable QCClarificationAccounts()
        {
            using (CBI_Anes_HighEntities _context = new CBI_Anes_HighEntities())
            {
                int projectId = Convert.ToInt32(HttpContext.Current.Session[Constants.ProjectId]);
                string location = HttpContext.Current.Session[Constants.LocationName].ToString();
                string USERNTLG = HttpContext.Current.Session[Constants.UserName].ToString();
                DataSet dsCommon = new DataSet();
                CBI_Anes_HighEntities dbObj = Singleton.Instance;
                List<SqlParameter> Parameter = new List<SqlParameter>();
                dsCommon.Clear();
                Parameter.Add(new SqlParameter("@ProjectId", projectId));
                Parameter.Add(new SqlParameter("@PracticeId", practiceId));
                Parameter.Add(new SqlParameter("@Location", location));
                Parameter.Add(new SqlParameter("@NTLG", USERNTLG));
                dsCommon = DBExtension.ExecuteDataset(dbObj.Database, Constants.SPQcClarificationData, Parameter);
                var tt = dsCommon;
                DataView view = new DataView(dsCommon.Tables[0]);
                DataTable distinctValues = view.ToTable(true, "ACCOUNT_NO", "TRANS_ID", "BATCH_NAME", "First_Name", "Last_Name", "MEMBER_DOB", "MEMBER_GENDER", "ENCOUNTER_TYPE", "CODED_BY","PDF_Path");
                return distinctValues;
                //try
                //{
                //    dsCommon.Clear();
                //    SqlConnection conObj = new SqlConnection(Constants.ConnectionString);
                //    conObj.Open();
                //    SqlCommand cmdObj = new SqlCommand(Constants.SPQcClarificationData, conObj);
                //    cmdObj.CommandType = CommandType.StoredProcedure;
                //    cmdObj.Parameters.AddWithValue("@ProjectId", projectId);
                //    cmdObj.Parameters.AddWithValue("@PracticeId", practiceId);
                //    cmdObj.Parameters.AddWithValue("@Location", location);
                //    cmdObj.Parameters.AddWithValue("@NTLG", USERNTLG);
                //    SqlDataAdapter adapter1 = new SqlDataAdapter(cmdObj);
                //    adapter1.Fill(dsCommon);
                //    conObj.Close();
                //    var tt = dsCommon;

                //    DataView view = new DataView(dsCommon.Tables[0]);
                //    DataTable distinctValues = view.ToTable(true, "ACCOUNT_NO", "TRANS_ID", "BATCH_NAME", "First_Name", "Last_Name", "MEMBER_DOB", "MEMBER_GENDER", "ENCOUNTER_TYPE", "CODED_BY");
                //    return distinctValues;
                //}
                //catch (Exception e)
                //{
                //    throw e;
                //}
            }
        }

        
        #region Clarification DXGrid
        public List<HighMarkCoderTransactionModel> ClarificationDXGrid(int trackingID)
        {
            using (CBI_Anes_HighEntities _context = new CBI_Anes_HighEntities())
            {
                int projectId = Convert.ToInt32(HttpContext.Current.Session[Constants.ProjectId]);
                string location = HttpContext.Current.Session[Constants.LocationName].ToString();

                HttpContext.Current.Session["TransID"] = trackingID;
                //var bID = _context.tbl_IMPORT_TABLE.Where(x => x.ACCOUNT_NO == trackingID).Select(x => x.BATCH_ID).FirstOrDefault();
                //var transID = _context.tbl_TRANSACTION.Where(x => x.BATCH_ID == bID).Select(x => x.TRANS_ID).FirstOrDefault();
                //int TID = Convert.ToInt32(trackingID);

                var list = (from TD in _context.tbl_TRANSACTION_DETAILS
                            join T in _context.tbl_TRANSACTION on TD.TRANS_ID equals T.TRANS_ID
                            join I in _context.tbl_IMPORT_TABLE on T.BATCH_ID equals I.BATCH_ID
                            where T.TRANS_ID == trackingID //T.PROJECT_ID == projectId && T.QC_STATUS.ToUpper() == "ERROR" && T.IS_ACKNOWLEDGE.ToUpper() == "N" && I.LOCATION == location && T.TRANS_ID == TID && T.PRACTICE_ID == practiceId
                            select new
                            {
                                TD.BEGINNING_DOS,
                                TD.ENDING_DOS,
                                TD.ICD_CODE,
                                TD.ICD,
                                TD.PAGE_NO,
                                TD.EO_CODE1,
                                TD.EO_CODE2,
                                TD.EO_CODE3,
                                TD.EO_CODE4,
                                TD.EO_CODE5,
                                TD.EO_CODE6,
                                TD.EO_COMMENT1,
                                TD.EO_COMMENT2,
                                TD.EO_COMMENT3,
                                TD.EO_COMMENT4,
                                TD.EO_COMMENT5,
                                TD.EO_COMMENT6,
                                TD.TRANS_DETAIL_ID,
                                TD.TRANS_ID,
                                I.ACCOUNT_NO,
                                I.MEMBER_GENDER,
                                I.BATCH_ID,
                                TD.Error_Correction,
                                TD.MODIFIER,
                                TD.Downcoded,
                                TD.COMMENTS,
                                TD.IS_ACKNOWLEDGE,
                                TD.ICD_RESULT
                            }).ToList();                
                return (from item in list
                        select new HighMarkCoderTransactionModel
                            {
                                BeginningDOS = CryptoGraphy.Decrypt(item.BEGINNING_DOS),
                                EndingDOS = CryptoGraphy.Decrypt(item.ENDING_DOS),
                                DxType = item.ICD_CODE,
                                DXCode = item.ICD,
                                Page = item.PAGE_NO,
                                EOCode1 = item.EO_CODE1,
                                EOCode2 = item.EO_CODE2,
                                EOCode3 = item.EO_CODE3,
                                EOCode4 = item.EO_CODE4,
                                EOCode5 = item.EO_CODE5,
                                EOCode6 = item.EO_CODE6,
                                EOComment1 = item.EO_COMMENT1,
                                EOComment2 = item.EO_COMMENT2,
                                EOComment3 = item.EO_COMMENT3,
                                EOComment4 = item.EO_COMMENT4,
                                EOComment5 = item.EO_COMMENT5,
                                EOComment6 = item.EO_COMMENT6,
                                TRANS_DETAIL_ID = item.TRANS_DETAIL_ID,
                                TRANS_ID = item.TRANS_ID.ToString(),
                                TrackingCode = CryptoGraphy.Decrypt(item.ACCOUNT_NO),
                                MemberGender = CryptoGraphy.Decrypt(item.MEMBER_GENDER),
                                BatchId = item.BATCH_ID,
                                ErrorCorrection = item.Error_Correction,
                                Modifier=item.MODIFIER,
                                QCcomments = item.Downcoded,
                                ICDComments=item.COMMENTS,
                                is_Acknowledge=item.IS_ACKNOWLEDGE,
                                ICDResult=item.ICD_RESULT
                            }).OrderByDescending(x => x.TRANS_DETAIL_ID).ToList();
            }
        }
        #endregion

        #region Save QCClarification Details

        public void SaveQCClarificationDetails(string transId)
        {
            using (CBI_Anes_HighEntities _context = new CBI_Anes_HighEntities())
            {
                int TID = Convert.ToInt32(transId);
                var transaction = _context.tbl_TRANSACTION.Where(x => x.TRANS_ID == TID).FirstOrDefault();
                var batchId = _context.tbl_IMPORT_TABLE.Where(x => x.BATCH_ID == transaction.BATCH_ID).FirstOrDefault();
                if (transaction != null)
                {
                    var data = (from TD in _context.tbl_TRANSACTION_DETAILS
                                where TD.TRANS_ID == TID &&  TD.IS_ACKNOWLEDGE== "N"&& TD.Downcoded != null//TD.Error_Correction
                                select new
                                {
                                    ErrorCorrection = TD.Error_Correction
                                }).ToList();

                    if (data.Count == 0)
                    {
                        transaction.QC_STATUS = "QCed";
                        transaction.IS_ACKNOWLEDGE = "Y";
                        transaction.QC_ERROR_CORRECTION = "Y";
                        batchId.BATCH_STATUS = "QCed";
                        transaction.IS_ACKNOWLEDGE_DATE = System.DateTime.Now;
                        transaction.REVIEW_REAUDIT = 1;
                        transaction.QC_DATE = DateTime.Now;
                    }
                    else
                    {
                        transaction.CODING_COMMENTS = "Coder Comments"; 
                        transaction.IS_ACKNOWLEDGE = "N";
                        transaction.RESIDENT = "1";
                        transaction.ACKNOWLEDGE_COMMENTS = "N";
                    }
                    _context.SaveChanges();
                }
            }
        }

        #endregion

        #region ICD Code Validation

        public string ICDCodeValidation(string dxCode, string EndingDOS, int batchId, string buttonName, int transDetailsID)
        {
            using (CBI_Anes_HighEntities _context = new CBI_Anes_HighEntities())
            {
                string DXCodeStatus = "";
                string Refernce = "";
                string eDOS = "";
                string EndDOS = EndingDOS;
                var transactionExits = _context.tbl_TRANSACTION.Where(x => x.BATCH_ID == batchId).FirstOrDefault();

                DateTime firstInterval = Convert.ToDateTime(Constants.FirstInterval);
                DateTime secondInterval = Convert.ToDateTime(Constants.SecondInterval);
                DateTime thirdInterval = Convert.ToDateTime(Constants.ThirdInterval);
                DateTime fifthInterval = Convert.ToDateTime(Constants.FifthInterval);
                DateTime sixthInterval = Convert.ToDateTime(Constants.SixthInterval);

                int practiceId = Convert.ToInt32(HttpContext.Current.Session[Constants.PracticeID]);
                if (practiceId==1)
                {
                    if (!EndingDOS.ToUpper().Contains("NO DOS"))
                    {
                        DateTime EDOS = Convert.ToDateTime(EndingDOS);
                        var list = (from TD in _context.tbl_TRANSACTION_DETAILS
                                    join T in _context.tbl_TRANSACTION on TD.TRANS_ID equals T.TRANS_ID
                                    join I in _context.tbl_IMPORT_TABLE on T.BATCH_ID equals I.BATCH_ID
                                    where T.BATCH_ID == batchId
                                    select new
                                    {
                                        transID = TD.TRANS_ID,
                                        dxCode = TD.ICD,
                                        EndingDOS = TD.ENDING_DOS,
                                        transDetailsID = TD.TRANS_DETAIL_ID
                                    }).ToList();

                        if (list != null)
                        {
                            var dcCodeList = (from item in list
                                              select new HighMarkCoderTransactionModel
                                              {
                                                  Tid = Convert.ToInt32(item.transID),
                                                  DXCode = item.dxCode,
                                                  DOS = CryptoGraphy.Decrypt(item.EndingDOS).ToString(),
                                                  TRANS_DETAIL_ID = item.transDetailsID
                                              }).ToList();
                            if (transDetailsID != 0)
                            {
                                var endingDOS = _context.tbl_TRANSACTION_DETAILS.Where(x => x.TRANS_DETAIL_ID == transDetailsID).FirstOrDefault();
                                eDOS = CryptoGraphy.Decrypt(endingDOS.ENDING_DOS.ToString());
                            }

                            foreach (var item in dcCodeList)
                            {
                                string EndingDOSS = CryptoGraphy.Encrypt(EndDOS).ToString();
                                if (item.DXCode == dxCode && !EndingDOS.ToUpper().Contains("NO DOS"))
                                {
                                    if (!eDOS.Contains("NO DOS"))
                                    {
                                        if (Convert.ToDateTime(item.DOS) < firstInterval && EDOS < firstInterval)
                                        {
                                            if (buttonName == "Update DX Code")
                                            {
                                                var Code = from listItem in dcCodeList.Where(x => (Convert.ToDateTime(x.DOS) < firstInterval) && x.DXCode == dxCode && x.TRANS_DETAIL_ID == transDetailsID) select new { listItem.DXCode };
                                                int count = Code.ToArray().Count();
                                                if (count != 0)
                                                {
                                                    DXCodeStatus = "";
                                                    Refernce = "Success";
                                                }
                                            }
                                            else
                                            {
                                                DXCodeStatus = "DX Code available";
                                            }
                                        }
                                        else if (EDOS >= firstInterval && EDOS < secondInterval && Convert.ToDateTime(item.DOS) >= firstInterval && Convert.ToDateTime(item.DOS) < secondInterval)
                                        {
                                            if (buttonName == "Update DX Code")
                                            {
                                                var Code = from listItem in dcCodeList.Where(x => (Convert.ToDateTime(x.DOS) >= firstInterval && Convert.ToDateTime(x.DOS) < secondInterval) && x.DXCode == dxCode && x.TRANS_DETAIL_ID == transDetailsID) select new { listItem.DXCode };
                                                int count = Code.ToArray().Count();
                                                if (count != 0)
                                                {
                                                    DXCodeStatus = "";
                                                    Refernce = "Success";
                                                }
                                            }
                                            else
                                            {
                                                DXCodeStatus = "DX Code available";
                                            }
                                        }
                                        else if (EDOS >= secondInterval && EDOS < thirdInterval && Convert.ToDateTime(item.DOS) >= secondInterval && Convert.ToDateTime(item.DOS) < thirdInterval)
                                        {
                                            if (buttonName == "Update DX Code")
                                            {
                                                var Code = from listItem in dcCodeList.Where(x => (Convert.ToDateTime(x.DOS) >= secondInterval && Convert.ToDateTime(x.DOS) < thirdInterval) && x.DXCode == dxCode && x.TRANS_DETAIL_ID == transDetailsID) select new { listItem.DXCode };
                                                int count = Code.ToArray().Count();
                                                if (count != 0)
                                                {
                                                    DXCodeStatus = "";
                                                    Refernce = "Success";
                                                }
                                            }
                                            else
                                            {
                                                DXCodeStatus = "DX Code available";
                                            }
                                        }
                                        else if (EDOS > thirdInterval && Convert.ToDateTime(item.DOS) > thirdInterval)
                                        {
                                            if (buttonName == "Update DX Code")
                                            {
                                                var Code = from listItem in dcCodeList.Where(x => (Convert.ToDateTime(x.DOS) > thirdInterval) && x.DXCode == dxCode && x.TRANS_DETAIL_ID == transDetailsID) select new { listItem.DXCode };
                                                int count = Code.ToArray().Count();
                                                if (count != 0)
                                                {
                                                    DXCodeStatus = "";
                                                    Refernce = "Success";
                                                }
                                            }
                                            else
                                            {
                                                DXCodeStatus = "DX Code available";
                                            }
                                        }
                                    }
                                }
                            }

                            if (buttonName == "Update DX Code")
                            {
                                if (!eDOS.Contains("NO DOS"))
                                {
                                    if (EDOS < firstInterval)
                                    {
                                        var Code = from item in dcCodeList.Where(x => (Convert.ToDateTime(x.DOS) < firstInterval) && x.DXCode == dxCode) select new { item.DXCode };
                                        int count = Code.ToArray().Count();
                                        if (count != 0 && Refernce != "Success")
                                        {
                                            DXCodeStatus = "DX Code available";
                                        }
                                    }
                                    else if (EDOS >= firstInterval && EDOS < secondInterval)
                                    {
                                        var Code = from item in dcCodeList.Where(x => (Convert.ToDateTime(x.DOS) >= firstInterval && Convert.ToDateTime(x.DOS) < secondInterval) && x.DXCode == dxCode) select new { item.DXCode };
                                        int count = Code.ToArray().Count();
                                        if (count != 0 && Refernce != "Success")
                                        {
                                            DXCodeStatus = "DX Code available";
                                        }
                                    }
                                    else if (EDOS >= secondInterval && EDOS < thirdInterval)
                                    {
                                        var Code = from item in dcCodeList.Where(x => (Convert.ToDateTime(x.DOS) >= secondInterval && Convert.ToDateTime(x.DOS) < thirdInterval) && x.DXCode == dxCode) select new { item.DXCode };
                                        int count = Code.ToArray().Count();
                                        if (count != 0 && Refernce != "Success")
                                        {
                                            DXCodeStatus = "DX Code available";
                                        }
                                    }
                                    else if (EDOS > thirdInterval)
                                    {
                                        var Code = from item in dcCodeList.Where(x => (Convert.ToDateTime(x.DOS) > thirdInterval) && x.DXCode == dxCode) select new { item.DXCode };
                                        int count = Code.ToArray().Count();
                                        if (count != 0 && Refernce != "Success")
                                        {
                                            DXCodeStatus = "DX Code available";
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                else
                {
                    if (!EndingDOS.ToUpper().Contains("NO DOS"))
                    {
                        DateTime EDOS = Convert.ToDateTime(EndingDOS);
                        var list = (from TD in _context.tbl_TRANSACTION_DETAILS
                                    join T in _context.tbl_TRANSACTION on TD.TRANS_ID equals T.TRANS_ID
                                    join I in _context.tbl_IMPORT_TABLE on T.BATCH_ID equals I.BATCH_ID
                                    where T.BATCH_ID == batchId
                                    select new
                                    {
                                        transID = TD.TRANS_ID,
                                        dxCode = TD.ICD,
                                        EndingDOS = TD.ENDING_DOS,
                                        transDetailsID = TD.TRANS_DETAIL_ID
                                    }).ToList();

                        if (list != null)
                        {
                            var dcCodeList = (from item in list
                                              select new HighMarkCoderTransactionModel
                                              {
                                                  Tid = Convert.ToInt32(item.transID),
                                                  DXCode = item.dxCode,
                                                  DOS = CryptoGraphy.Decrypt(item.EndingDOS).ToString(),
                                                  TRANS_DETAIL_ID = item.transDetailsID
                                              }).ToList();
                            if (transDetailsID != 0)
                            {
                                var endingDOS = _context.tbl_TRANSACTION_DETAILS.Where(x => x.TRANS_DETAIL_ID == transDetailsID).FirstOrDefault();
                                eDOS = CryptoGraphy.Decrypt(endingDOS.ENDING_DOS.ToString());
                            }

                            foreach (var item in dcCodeList)
                            {
                                string EndingDOSS = CryptoGraphy.Encrypt(EndDOS).ToString();
                                if (item.DXCode == dxCode && !EndingDOS.ToUpper().Contains("NO DOS"))
                                {
                                    if (!eDOS.Contains("NO DOS"))
                                    {
                                        if (Convert.ToDateTime(item.DOS) < thirdInterval && EDOS < thirdInterval)
                                        {
                                            if (buttonName == "Update DX Code")
                                            {
                                                var Code = from listItem in dcCodeList.Where(x => (Convert.ToDateTime(x.DOS) < thirdInterval) && x.DXCode == dxCode && x.TRANS_DETAIL_ID == transDetailsID) select new { listItem.DXCode };
                                                int count = Code.ToArray().Count();
                                                if (count != 0)
                                                {
                                                    DXCodeStatus = "";
                                                    Refernce = "Success";
                                                }
                                            }
                                            else
                                            {
                                                DXCodeStatus = "DX Code available";
                                            }
                                        }
                                        else if (EDOS >= thirdInterval && EDOS < fifthInterval && Convert.ToDateTime(item.DOS) >= thirdInterval && Convert.ToDateTime(item.DOS) < fifthInterval)
                                        {
                                            if (buttonName == "Update DX Code")
                                            {
                                                var Code = from listItem in dcCodeList.Where(x => (Convert.ToDateTime(x.DOS) >= thirdInterval && Convert.ToDateTime(x.DOS) < fifthInterval) && x.DXCode == dxCode && x.TRANS_DETAIL_ID == transDetailsID) select new { listItem.DXCode };
                                                int count = Code.ToArray().Count();
                                                if (count != 0)
                                                {
                                                    DXCodeStatus = "";
                                                    Refernce = "Success";
                                                }
                                            }
                                            else
                                            {
                                                DXCodeStatus = "DX Code available";
                                            }
                                        }
                                        else if (EDOS >= fifthInterval && EDOS < sixthInterval && Convert.ToDateTime(item.DOS) >= fifthInterval && Convert.ToDateTime(item.DOS) < sixthInterval)
                                        {
                                            if (buttonName == "Update DX Code")
                                            {
                                                var Code = from listItem in dcCodeList.Where(x => (Convert.ToDateTime(x.DOS) >= fifthInterval && Convert.ToDateTime(x.DOS) < sixthInterval) && x.DXCode == dxCode && x.TRANS_DETAIL_ID == transDetailsID) select new { listItem.DXCode };
                                                int count = Code.ToArray().Count();
                                                if (count != 0)
                                                {
                                                    DXCodeStatus = "";
                                                    Refernce = "Success";
                                                }
                                            }
                                            else
                                            {
                                                DXCodeStatus = "DX Code available";
                                            }
                                        }
                                        else if (EDOS > sixthInterval && Convert.ToDateTime(item.DOS) > sixthInterval)
                                        {
                                            if (buttonName == "Update DX Code")
                                            {
                                                var Code = from listItem in dcCodeList.Where(x => (Convert.ToDateTime(x.DOS) > sixthInterval) && x.DXCode == dxCode && x.TRANS_DETAIL_ID == transDetailsID) select new { listItem.DXCode };
                                                int count = Code.ToArray().Count();
                                                if (count != 0)
                                                {
                                                    DXCodeStatus = "";
                                                    Refernce = "Success";
                                                }
                                            }
                                            else
                                            {
                                                DXCodeStatus = "DX Code available";
                                            }
                                        }
                                    }
                                }
                            }

                            if (buttonName == "Update DX Code")
                            {
                                if (!eDOS.Contains("NO DOS"))
                                {
                                    if (EDOS < thirdInterval)
                                    {
                                        var Code = from item in dcCodeList.Where(x => (Convert.ToDateTime(x.DOS) < thirdInterval) && x.DXCode == dxCode) select new { item.DXCode };
                                        int count = Code.ToArray().Count();
                                        if (count != 0 && Refernce != "Success")
                                        {
                                            DXCodeStatus = "DX Code available";
                                        }
                                    }
                                    else if (EDOS >= thirdInterval && EDOS < fifthInterval)
                                    {
                                        var Code = from item in dcCodeList.Where(x => (Convert.ToDateTime(x.DOS) >= thirdInterval && Convert.ToDateTime(x.DOS) < fifthInterval) && x.DXCode == dxCode) select new { item.DXCode };
                                        int count = Code.ToArray().Count();
                                        if (count != 0 && Refernce != "Success")
                                        {
                                            DXCodeStatus = "DX Code available";
                                        }
                                    }
                                    else if (EDOS >= fifthInterval && EDOS < sixthInterval)
                                    {
                                        var Code = from item in dcCodeList.Where(x => (Convert.ToDateTime(x.DOS) >= fifthInterval && Convert.ToDateTime(x.DOS) < sixthInterval) && x.DXCode == dxCode) select new { item.DXCode };
                                        int count = Code.ToArray().Count();
                                        if (count != 0 && Refernce != "Success")
                                        {
                                            DXCodeStatus = "DX Code available";
                                        }
                                    }
                                    else if (EDOS > sixthInterval)
                                    {
                                        var Code = from item in dcCodeList.Where(x => (Convert.ToDateTime(x.DOS) > sixthInterval) && x.DXCode == dxCode) select new { item.DXCode };
                                        int count = Code.ToArray().Count();
                                        if (count != 0 && Refernce != "Success")
                                        {
                                            DXCodeStatus = "DX Code available";
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                return DXCodeStatus;
            }
        }
        #endregion
    }
}
