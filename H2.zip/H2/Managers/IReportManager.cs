﻿using CBIplus.BAL.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.Mvc;
using System.Data;

namespace CBIplus.BAL.Managers
{
    public interface IReportManager
    {
        ReportsViewModel GetReportDetails(string taskName);
        List<SelectListItem> GetFacilityNames(string fromDate, string toDate);
        List<SelectListItem> GetFacilityCode(string BatchName);
        List<SelectListItem> GetBatchNames(string fromDate, string toDate);
        List<SelectListItem> GetPracticeName(string fromDate, string toDate);
        List<SelectListItem> GetBatchName1(string Facility);
        List<SelectListItem> GetCodingStatus();
        List<SelectListItem> GetCoderNames();
        List<SelectListItem> GetStatusForQC();
        List<SelectListItem> GetEncounterType();
        List<SelectListItem> GetLocation();
        List<SelectListItem> AuditCategoryList();
        DataTable GetProductionReportDetails(string fromDos, string toDos, string batchName, string facility, string status);
        List<SelectListItem> GetStatus();
        List<SelectListItem> GetBatches(string fromDate, string toDate);
        void GetProductionReport();
    }
}
