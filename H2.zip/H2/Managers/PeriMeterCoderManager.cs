﻿using CBIplus.BAL.Generics;
using CBIplus.BAL.ViewModels;
using CBIplus.DAL;
using iTextSharp.text;
using Microsoft.Win32.SafeHandles;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity.Validation;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using System.Web.Mvc;
using System.Drawing.Imaging;

namespace CBIplus.BAL.Managers
{
    public class PeriMeterCoderManager : IPeriMeterCoderService
    {


        #region LoadCoderInboxData
        public List<CodingPeriModel> LoadCoderInboxData()
        {
            using (CBI_Anes_HighEntities _context = new CBI_Anes_HighEntities())
            {
                int projectId = Convert.ToInt32(HttpContext.Current.Session[Constants.ProjectId]);
                string userName = HttpContext.Current.Session[Constants.UserName].ToString();

                List<CodingPeriModel> list = (from data in _context.tbl_IMPORT_TABLE

                                              where data.PROJECT_ID == projectId && data.ALLOTTED_TO == userName && data.BATCH_STATUS == "Coding Allotted"

                                              select new CodingPeriModel
                                              {
                                                  DOS = data.DOS.ToString(),
                                                  Facility = data.FACILITY,
                                                  AccountNumber = data.ACCOUNT_NO,
                                                  BatchName = data.BATCH_NAME,
                                                  PayerClass = data.PAYER_CLASS,
                                                  PatientName = data.PATIENT_NAME,
                                                  ICD = data.ICD_CODE,
                                                  ReceivedDate = data.RECEIVED_DATE,
                                                  BatchId = data.BATCH_ID,

                                                  Status = data.BATCH_STATUS
                                              }).ToList();
                return (from item in list
                        select new CodingPeriModel
                        {
                            DOS = item.DOS,
                            Facility = item.Facility,
                            AccountNumber = CryptoGraphy.Decrypt(item.AccountNumber),
                            BatchName = CryptoGraphy.Decrypt(item.BatchName),
                            PayerClass = CryptoGraphy.Decrypt(item.PayerClass),
                            PatientName = CryptoGraphy.Decrypt(item.PatientName),
                            ICD = item.ICD,
                            ReceivedDate = item.ReceivedDate,
                            BatchId = item.BatchId,

                            Status = item.Status
                        }).ToList();

            }
        }
        #endregion

        #region LoadMasterDropdownData
        public CodingPeriModel LoadMasterDropdownData()
        {
            CodingPeriModel model = new CodingPeriModel();
            DataSet dsCommon = new DataSet();

            int projectId = Convert.ToInt32(HttpContext.Current.Session[Constants.ProjectId]);

            try
            {
                dsCommon.Clear();
                SqlConnection conObj = new SqlConnection(Constants.ConnectionString);
                conObj.Open();
                SqlCommand cmdObj = new SqlCommand(Constants.SPMasterList, conObj);
                cmdObj.CommandType = CommandType.StoredProcedure;
                cmdObj.Parameters.AddWithValue("@Proj", projectId);
                SqlDataAdapter adapter1 = new SqlDataAdapter(cmdObj);
                adapter1.Fill(dsCommon);
                conObj.Close();

            }
            catch (Exception e)
            {
                throw e;
            }
            if (dsCommon != null)
            {
                HttpContext.Current.Session["DataTable"] = dsCommon;
            }
            List<SelectListItem> items = new List<SelectListItem>();

            items.Add(new SelectListItem { Text = "0", Value = "0" });

            items.Add(new SelectListItem { Text = "1", Value = "1" });


            //model.AttendingPhyList = (from p in dsCommon.Tables[12].AsEnumerable() select new SelectListItem { Text = p.Field<string>("PHYSICIAN_NAME"), Value = p.Field<string>("PHYSICIAN_ID") }).ToList();
            //model.NPPAList = (from p in dsCommon.Tables[11].AsEnumerable() select new SelectListItem { Text = p.Field<string>("NP_PA_NAME"), Value = p.Field<string>("NP_PA_CODE") }).ToList();
            //model.ScribeList = (from p in dsCommon.Tables[10].AsEnumerable() select new SelectListItem { Text = p.Field<string>("SCRIBE_NAME"), Value = p.Field<string>("SCRIBE_ID") }).ToList();
            model.PatientStatusDCStatusList = (from p in dsCommon.Tables[9].AsEnumerable() select new SelectListItem { Text = p.Field<string>("PATIENT_STATUS"), Value = Convert.ToString(p.Field<int>("PATIENT_STATUS_ID")) }).ToList();
            model.CPTList = (from p in dsCommon.Tables[8].AsEnumerable() select new SelectListItem { Text = p.Field<string>("CPT1"), Value = Convert.ToString(p.Field<string>("CPT1")) }).ToList();
            //model.ModifierList = (from p in dsCommon.Tables[13].AsEnumerable() select new SelectListItem { Text = p.Field<string>("MODIFIERS"), Value = Convert.ToString(p.Field<int>("M_ID")) }).ToList();
            model.ModifierList = (from p in dsCommon.Tables[13].AsEnumerable() select new SelectListItem { Text = p.Field<string>("MODIFIERS"), Value = Convert.ToString(p.Field<string>("MODIFIERS")) }).ToList();
            model.StaticCommentsList = (from p in dsCommon.Tables[14].AsEnumerable() select new SelectListItem { Text = p.Field<string>("COMMENT_NAME"), Value = p.Field<string>("COMMENT_NAME") }).ToList();
            model.DowncodedFormList = (from p in dsCommon.Tables[8].AsEnumerable() select new SelectListItem { Text = p.Field<string>("CPT1"), Value = Convert.ToString(p.Field<string>("CPT1")) }).ToList();

            model.ResidentList = items;

            return model;

        }
        #endregion

        #region LoadCodedAccounts
        public List<CodingPeriModel> LoadCodedAccounts()
        {

            using (CBI_Anes_HighEntities _context = new CBI_Anes_HighEntities())
            {
                int projectId = Convert.ToInt32(HttpContext.Current.Session[Constants.ProjectId]);
                string userName = HttpContext.Current.Session[Constants.UserName].ToString().ToUpper().Trim();

                var list = (from I in _context.tbl_IMPORT_TABLE
                            join T in _context.tbl_TRANSACTION on I.BATCH_ID equals T.BATCH_ID
                            join TD in _context.tbl_TRANSACTION_DETAILS on T.TRANS_ID equals TD.TRANS_ID
                            where T.CODED_BY.ToUpper() == userName && I.PROJECT_ID == projectId && T.CODING_STATUS == "Coded" && T.QC_STATUS == null
                            orderby T.TRANS_ID
                            select new
                            {
                                I.ACCOUNT_NO,
                                I.DOS,
                                I.PATIENT_NAME,
                                I.BATCH_NAME,
                                I.BATCH_ID,
                                T.TRANS_ID,
                                TD.TRANS_DETAIL_ID,
                                I.FACILITY,
                                I.RECEIVED_DATE,
                                T.PATIENT_STATUS,
                                T.ATTENDING_PHY,
                                T.NPPA,
                                T.SCRIBE,
                                T.RESIDENT,
                                T.CODING_STATUS,
                                TD.COMMENTS,
                                T.IS_REOPENED,
                                TD.Downcoded,
                                TD.HPI,
                                TD.PFSH,
                                TD.ROS,
                                TD.EXAM,
                                I.PAYER_CLASS,
                                T.CODED_DATE
                            }).GroupBy(x => x.ACCOUNT_NO).Select(x => x.FirstOrDefault()).OrderByDescending(x => x.CODED_DATE).Take(5).ToList();
                return (from item in list
                        select new CodingPeriModel
                            {
                                CodedDate = Convert.ToString(item.CODED_DATE),
                                AccountNumber = CryptoGraphy.Decrypt(item.ACCOUNT_NO),
                                DOS = item.DOS.ToString(),
                                PatientName = CryptoGraphy.Decrypt(item.PATIENT_NAME),
                                BatchName = item.BATCH_NAME,
                                BatchId = item.BATCH_ID,
                                TRANS_ID = item.TRANS_ID,
                                TRANS_DETAIL_ID = item.TRANS_DETAIL_ID,
                                Facility = item.FACILITY,
                                ReceivedDate = item.RECEIVED_DATE,
                                PatientStatusDCStatus = item.PATIENT_STATUS,
                                AttendingPhy = item.ATTENDING_PHY,
                                NPPA = item.NPPA,
                                Scribe = item.SCRIBE,
                                Resident = item.RESIDENT,
                                Status = item.CODING_STATUS,
                                Comments = item.COMMENTS,
                                DowncodedForm = item.Downcoded,
                                HPI = item.HPI,
                                PFSH = item.PFSH,
                                ROS = item.ROS,
                                EXAM = item.EXAM,
                                PayerClass = CryptoGraphy.Decrypt(item.PAYER_CLASS),
                                Is_Reopened = string.IsNullOrEmpty(item.IS_REOPENED.ToString()) ? 0 : item.IS_REOPENED
                            }).Reverse().ToList();
            }

        }
        #endregion

        #region LoadAccountDropdowns
        public CodingPeriModel LoadAccountDropdowns(string facilityNum, string accountNumber, string accountStatus = null)
        {
            CodingPeriModel model = new CodingPeriModel();
            DataSet dataset;
            if (HttpContext.Current.Session["DataTable"] != null)
            {
                dataset = HttpContext.Current.Session["DataTable"] as DataSet;
            }
            else
            {
                LoadMasterDropdownData();
                dataset = HttpContext.Current.Session["DataTable"] as DataSet;


            }
            if (accountStatus == "updateAccount")
            {
                List<SelectListItem> items = new List<SelectListItem>();

                items.Add(new SelectListItem { Text = "0", Value = "0" });

                items.Add(new SelectListItem { Text = "1", Value = "1" });
                model.PatientStatusDCStatusList = (from p in dataset.Tables[9].AsEnumerable() select new SelectListItem { Text = p.Field<string>("PATIENT_STATUS"), Value = Convert.ToString(p.Field<int>("PATIENT_STATUS_ID")) }).ToList();
                // model.DowncodedFormList = (from p in dataset.Tables[8].AsEnumerable() select new SelectListItem { Text = p.Field<string>("CPT1"), Value = Convert.ToString(p.Field<int>("CPT1_ID")) }).ToList();
                model.ResidentList = items;
            }


            model.AttendingPhyList = (from p in dataset.Tables[12].AsEnumerable() where p.Field<string>("FACILITY_CODE") == facilityNum select new SelectListItem { Text = p.Field<string>("PHYSICIAN_NAME"), Value = p.Field<string>("PHYSICIAN_ID") }).ToList();
            model.NPPAList = (from p in dataset.Tables[11].AsEnumerable() where p.Field<string>("FACILITY_CODE") == facilityNum select new SelectListItem { Text = p.Field<string>("NP_PA_NAME"), Value = p.Field<string>("NP_PA_CODE") }).ToList();
            model.ScribeList = (from p in dataset.Tables[10].AsEnumerable() where p.Field<string>("FACILITY_CODE") == facilityNum select new SelectListItem { Text = p.Field<string>("SCRIBE_NAME"), Value = p.Field<string>("SCRIBE_ID") }).ToList();
            model.ListOfAccountPDF = ListOfAccountPDF(accountNumber);
            return model;
        }
        #endregion

        #region GetSelectedCPT
        public List<SelectListItem> GetSelectedCPT(string CPT)
        {
            DataSet dataset;
            if (HttpContext.Current.Session["DataTable"] != null)
            {
                dataset = HttpContext.Current.Session["DataTable"] as DataSet;
            }
            else
            {
                LoadMasterDropdownData();
                dataset = HttpContext.Current.Session["DataTable"] as DataSet;
            }
            if (CPT == "CPT1")
            {
                return (from p in dataset.Tables[8].AsEnumerable() select new SelectListItem { Text = p.Field<string>("CPT1"), Value = Convert.ToString(p.Field<int>("CPT1_ID")) }).ToList();
            }
            else
            {
                return (from p in dataset.Tables[15].AsEnumerable() select new SelectListItem { Text = p.Field<string>("OCPT"), Value = p.Field<string>("OCPT") }).ToList();
            }

        }
        #endregion

        #region SaveChartChanges
        public void SaveChartChanges(List<CodingPeriModel> model, string status)
        {
            using (CBI_Anes_HighEntities _context = new CBI_Anes_HighEntities())
            {
                string accountNumber = CryptoGraphy.Encrypt(model[0].AccountNumber.Trim());
                var import = _context.tbl_IMPORT_TABLE.Where(x => x.ACCOUNT_NO == accountNumber).FirstOrDefault();
                int i = 0;
                int transId = 0;
                try
                {
                    if (status == "Pending")
                    {
                        tbl_TRANSACTION transaction = new tbl_TRANSACTION();
                        tbl_IMPORT_TABLE tblImport = new tbl_IMPORT_TABLE();
                        transaction.CODING_STATUS = status;
                        import.BATCH_STATUS = status;
                        _context.SaveChanges();
                    }
                    else
                    {
                        foreach (var item in model)
                        {
                            tbl_TRANSACTION transaction = new tbl_TRANSACTION();
                            var trans = _context.tbl_TRANSACTION.Where(x => x.BATCH_ID == item.BatchId).FirstOrDefault();

                            if (trans == null)
                            {
                                transaction.BATCH_ID = import.BATCH_ID;//  == null ? "" : item.Modifier
                                transaction.PATIENT_NAME = item.PatientName == "--Select--" ? "" : item.PatientName;
                                transaction.ATTENDING_PHY = item.AttendingPhy == "--Select--" ? "" : item.AttendingPhy;
                                transaction.NPPA = item.NPPA == "--Select--" ? "" : item.NPPA;
                                transaction.SCRIBE = item.Scribe == "--Select--" ? "" : item.Scribe;
                                transaction.PATIENT_STATUS = item.PatientStatusDCStatus == "--Select--" ? "" : item.PatientStatusDCStatus;
                                transaction.RESIDENT = item.Resident == "--Select--" ? "" : item.Resident;
                                transaction.CODED_DATE = DateTime.Now;
                                transaction.CODED_BY = HttpContext.Current.Session[Constants.UserName].ToString();
                                transaction.PROJECT_ID = Convert.ToInt32(HttpContext.Current.Session[Constants.ProjectId]);
                                import.BATCH_STATUS = status;
                                transaction.CODING_STATUS = status;
                                transaction.START_TIME = Convert.ToDateTime(item.CodingStartTime).TimeOfDay;
                                transaction.END_TIME = DateTime.Now.TimeOfDay;

                                i = i + 1;
                                _context.tbl_TRANSACTION.Add(transaction);
                                _context.SaveChanges();
                                transId = Convert.ToInt32(_context.tbl_TRANSACTION.Where(x => x.BATCH_ID == import.BATCH_ID).Select(x => x.TRANS_ID).FirstOrDefault());
                            }

                            string icdres = item.ICD_Results.Trim(';');
                            string[] icdArray = icdres.Split(';');
                            string[] icdType = item.Type.Trim(';').Split(';');


                            for (int j = 0; j < icdArray.Length; j++)
                            {
                                tbl_TRANSACTION_DETAILS transDetails = new tbl_TRANSACTION_DETAILS();
                                transDetails.TRANS_ID = transId;
                                transDetails.CPT_LEVEL = item.CPTLevel;
                                transDetails.CPT = item.CPT;
                                transDetails.MODIFIER = item.Modifier == null ? "" : item.Modifier;
                                transDetails.ICD = icdArray[j];
                                transDetails.ICD_CODE = icdType[j];
                                transDetails.ICD_RESULT = item.ICD_Results;
                                transDetails.COMMENTS = item.Comments;
                                transDetails.HPI = item.HPI;
                                transDetails.PFSH = item.PFSH;
                                transDetails.ROS = item.ROS;
                                transDetails.EXAM = item.EXAM;
                                transDetails.Downcoded = item.DowncodedForm;
                                transaction.START_TIME = Convert.ToDateTime(item.CodingStartTime).TimeOfDay;
                                transaction.END_TIME = DateTime.Now.TimeOfDay;
                                transDetails.CPT_ORDER = item.CPTOrder;
                                _context.tbl_TRANSACTION_DETAILS.Add(transDetails);
                            }
                        }
                        _context.SaveChanges();
                    }
                }

                catch (DbEntityValidationException ex)
                {
                    var errorMessages = ex.EntityValidationErrors.SelectMany(x => x.ValidationErrors).Select(x => x.ErrorMessage);
                    var fullErrorMessage = string.Join(Constants.CommaSpace, errorMessages);
                    var exceptionMessage = string.Concat(ex.Message, Constants.ValidationError, fullErrorMessage);
                    throw new DbEntityValidationException(exceptionMessage, ex.EntityValidationErrors);
                }
            }
        }
        #endregion

        #region ListOfAccountPDF
        private List<string> ListOfAccountPDF(string accountNumber)
        {
            string[] filePaths;
            string PDFFileDestination;
            string[] filelist;

            int count = 0;
            int i = 0;

            //PDFFileDestination = Constants.PDFPath;
            //var Path = Constants.PDFPath;

            PDFFileDestination = HttpContext.Current.Server.MapPath(@"~/PeriMeter_PDF/");
            var Path = HttpContext.Current.Server.MapPath(@"~/PeriMeter_PDF/");
            filePaths = Directory.GetFiles(Path, "*" + accountNumber + "*.tif");
            i = filePaths.Count();
            if (i != 0)
            {
                for (i = 0; filePaths.Count() > i; i++)
                {
                    string directory = filePaths[i].Substring(0, filePaths[i].LastIndexOf('\\'));
                    filelist = Directory.GetFiles(directory,"*" +accountNumber+"*.TIF");

                    iTextSharp.text.Document document = new iTextSharp.text.Document(iTextSharp.text.PageSize.A1, 0, 50, 0, 2);
                    string file = filelist[i].Substring(filelist[i].LastIndexOf('\\') + 1);
                    string temp = (PDFFileDestination + file.Replace(".tif", ".pdf").Replace(".tif", ".pdf"));

                    if (!File.Exists(temp))
                    {
                        iTextSharp.text.pdf.PdfWriter writer = iTextSharp.text.pdf.PdfWriter.GetInstance(document, new System.IO.FileStream((PDFFileDestination + file.Replace(".tif", ".pdf")), System.IO.FileMode.Create));
                        //File Source
                        System.Drawing.Bitmap bm = new System.Drawing.Bitmap(filelist[i]);
                        //ImageLoad();
                        int total = bm.GetFrameCount(System.Drawing.Imaging.FrameDimension.Page);
                        document.Open();
                        iTextSharp.text.pdf.PdfContentByte cb = writer.DirectContent;
                        for (int k = 0; k < total; ++k)
                        {
                            bm.SelectActiveFrame(System.Drawing.Imaging.FrameDimension.Page, k);
                            iTextSharp.text.Image img = iTextSharp.text.Image.GetInstance(bm, System.Drawing.Imaging.ImageFormat.Bmp);

                            img.ScalePercent(72f / img.DpiX * 96);

                            img.SetAbsolutePosition(0, 0);
                            cb.AddImage(img);
                            document.NewPage();
                        }
                        document.Close();
                        count++;
                    }
                }
            }
            string[] dirs = Directory.GetFiles(Path, "*" + accountNumber + "*.pdf");
            List<string> listdropdown = new List<string>();
            foreach (string dir in dirs)
            {
                string[] value = dir.Split(new[] { "\\PeriMeter_PDF\\" }, StringSplitOptions.None);
                listdropdown.Add(value[1]);
            }
            return listdropdown;


            //var Path = HttpContext.Current.Server.MapPath(@"~/PeriMeter_PDF/");
            //string[] dirs = Directory.GetFiles(Path, "*" + accountNumber + "*");
            //List<string> listdropdown = new List<string>();
            //foreach (string dir in dirs)
            //{
            //    string[] value = dir.Split(new[] { "\\PeriMeter_PDF\\" }, StringSplitOptions.None);
            //    listdropdown.Add(value[1]);
            //}
            //return listdropdown;
        }
        #endregion
        public CodingPeriModel ConvertToPDF(string accNo)
        {
            CodingPeriModel model = new CodingPeriModel();
            model.ConvertToPDF = ConvertPDF(accNo);
            return model;
        }

        #region ConvertToPDF

        public List<string> ConvertPDF(string AccNo)
        {
            string[] filePaths;
            string PDFFileDestination;
            string[] filelist;

            int count = 0;
            int i = 0;
            try
            {
                //PDFFileDestination =Constants.PDFPath;
                //var Path = Constants.PDFPath;
                PDFFileDestination = HttpContext.Current.Server.MapPath(@"~/PeriMeter_PDF/");
                var Path = HttpContext.Current.Server.MapPath(@"~/PeriMeter_PDF/");
                filePaths = Directory.GetFiles(Path, "*" + AccNo + "*.tif");
                string directory = filePaths[i].Substring(0, filePaths[i].LastIndexOf('\\'));
                filelist = Directory.GetFiles(directory, "*.TIF");

                i = filePaths.Count();
                for (i = 0; filePaths.Count() > i; i++)
                {
                    iTextSharp.text.Document document = new iTextSharp.text.Document(iTextSharp.text.PageSize.A1, 0, 50, 0, 2);
                    string file = filelist[i].Substring(filelist[i].LastIndexOf('\\') + 1);
                    string temp = (PDFFileDestination + file.Replace(".tif", ".pdf").Replace(".tif", ".pdf"));

                    if (!File.Exists(temp))
                    {
                        iTextSharp.text.pdf.PdfWriter writer = iTextSharp.text.pdf.PdfWriter.GetInstance(document, new System.IO.FileStream((PDFFileDestination + file.Replace(".tif", ".pdf")), System.IO.FileMode.Create));
                        //File Source
                        System.Drawing.Bitmap bm = new System.Drawing.Bitmap(filelist[i]);
                        //ImageLoad();
                        int total = bm.GetFrameCount(System.Drawing.Imaging.FrameDimension.Page);
                        document.Open();
                        iTextSharp.text.pdf.PdfContentByte cb = writer.DirectContent;
                        for (int k = 0; k < total; ++k)
                        {
                            bm.SelectActiveFrame(System.Drawing.Imaging.FrameDimension.Page, k);
                            iTextSharp.text.Image img = iTextSharp.text.Image.GetInstance(bm, System.Drawing.Imaging.ImageFormat.Bmp);

                            img.ScalePercent(72f / img.DpiX * 96);

                            img.SetAbsolutePosition(0, 0);
                            cb.AddImage(img);
                            document.NewPage();
                        }
                        document.Close();
                        count++;
                    }
                }

                string[] dirs = Directory.GetFiles(Path, "*" + AccNo + "*.pdf");
                List<string> listdropdown = new List<string>();
                foreach (string dir in dirs)
                {
                    string[] value = dir.Split(new[] { "\\PeriMeter_PDF\\" }, StringSplitOptions.None);
                    listdropdown.Add(value[1]);
                }
                return listdropdown;
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }
        #endregion

        #region SaveCPTChanges
        public void SaveAndUpdateCPTChanges(CodingPeriModel model)
        {
            using (CBI_Anes_HighEntities _context = new CBI_Anes_HighEntities())
            {
                var transaction = _context.tbl_TRANSACTION.Where(x => x.TRANS_ID == model.TRANS_ID).FirstOrDefault();
                var tblTransDetails = _context.tbl_TRANSACTION_DETAILS.Where(x => x.TRANS_DETAIL_ID == model.TRANS_DETAIL_ID ).FirstOrDefault();
                string userName = HttpContext.Current.Session[Constants.UserName].ToString().ToUpper().Trim();
                if (tblTransDetails == null)
                {
                    var Max_TRANS_DETAIL_ID = (from x in _context.tbl_TRANSACTION_DETAILS where (x.TRANS_ID == model.TRANS_ID) select x.TRANS_DETAIL_ID).Max();//
                    var res = (from x in _context.tbl_TRANSACTION_DETAILS where (x.TRANS_DETAIL_ID == Max_TRANS_DETAIL_ID) select x.CPT_ORDER.Remove(0, 3)).FirstOrDefault();//


                    int value = 0;

                    try { value = int.Parse(res); }
                    catch { }


                    string icdres = model.ICD_Results.Trim(';');
                    string[] icdArray = icdres.Split(';');

                    for (int j = 0; j < icdArray.Length; j++)
                    {
                        tbl_TRANSACTION_DETAILS transDetails = new tbl_TRANSACTION_DETAILS();
                        transDetails.TRANS_ID = model.TRANS_ID;
                        transDetails.CPT_LEVEL = model.CPTLevel;
                        transDetails.CPT = model.CPT;
                        transDetails.MODIFIER = model.Modifier == null ? "" : model.Modifier;
                        transDetails.ICD = icdArray[j];
                        transDetails.ICD_CODE = model.Type;
                        transDetails.ICD_RESULT = model.ICD_Results;
                        transDetails.COMMENTS = model.Comments;
                        transDetails.HPI = model.HPI;
                        transDetails.PFSH = model.PFSH;
                        transDetails.ROS = model.ROS;
                        transDetails.EXAM = model.EXAM;
                        transDetails.Downcoded = model.DowncodedForm;
                        transDetails.CPT_ORDER = "CPT" + (value + 1).ToString();

                        _context.tbl_TRANSACTION_DETAILS.Add(transDetails);
                    }
                    transaction.START_TIME = Convert.ToDateTime(model.CodingStartTime).TimeOfDay;
                    transaction.END_TIME = DateTime.Now.TimeOfDay;
                }
                else
                {
                    if (model.Status == "Update ICD")
                    {
                        var tblTransactionDetails2 = _context.tbl_TRANSACTION_DETAILS.Where(x => x.TRANS_ID == model.TRANS_ID && x.CPT_ORDER == model.CPTOrder).ToList();
                        tblTransDetails.CPT_LEVEL = model.CPTLevel;
                        tblTransDetails.CPT = model.SelectedCPT;
                        tblTransDetails.ICD = model.ICD_Results == null ? model.ICD : model.ICD_Results;
                        tblTransDetails.UPDATED_BY = userName;
                        tblTransDetails.UPDATED_DATE = DateTime.Now;
                        foreach (var item in tblTransactionDetails2)
                        {
                            var tblTransactionDetails = _context.tbl_TRANSACTION_DETAILS.Where(x =>x.TRANS_DETAIL_ID==item.TRANS_DETAIL_ID && x.TRANS_ID == model.TRANS_ID && x.CPT_ORDER == model.CPTOrder).FirstOrDefault();

                            tblTransactionDetails.MODIFIER = model.Modifier == null ? "" : model.Modifier;
                            tblTransactionDetails.CPT = model.SelectedCPT;
                            //tblTransDetails.ICD_CODE = model.Type;
                            //tblTransDetails.ICD_RESULT = model.ICD_Results;
                            //tblTransDetails.ICD_RESULT = model.ICD_Results == null ? model.ICD : model.ICD_Results;
                            tblTransactionDetails.COMMENTS = model.Comments;
                            tblTransactionDetails.HPI = model.HPI;
                            tblTransactionDetails.PFSH = model.PFSH;
                            tblTransactionDetails.ROS = model.ROS;
                            tblTransactionDetails.EXAM = model.EXAM;
                            tblTransactionDetails.Downcoded = model.DowncodedForm;
                        }
                    }
                    else
                    {
                        tblTransDetails.CPT_LEVEL = model.CPTLevel;
                        tblTransDetails.CPT = model.SelectedCPT;
                        tblTransDetails.MODIFIER = model.Modifier == null ? "" : model.Modifier;
                        tblTransDetails.ICD = model.ICD_Results == null ? model.ICD : model.ICD_Results;
                        //tblTransDetails.ICD_CODE = model.Type;
                        //tblTransDetails.ICD_RESULT = model.ICD_Results;
                        //tblTransDetails.ICD_RESULT = model.ICD_Results == null ? model.ICD : model.ICD_Results;
                        tblTransDetails.COMMENTS = model.Comments;
                        tblTransDetails.HPI = model.HPI;
                        tblTransDetails.PFSH = model.PFSH;
                        tblTransDetails.ROS = model.ROS;
                        tblTransDetails.EXAM = model.EXAM;
                        tblTransDetails.UPDATED_BY = userName;
                        tblTransDetails.UPDATED_DATE = DateTime.Now;
                        tblTransDetails.Downcoded = model.DowncodedForm;
                    }
                    var icdRes = _context.tbl_TRANSACTION_DETAILS.Where(x => x.TRANS_DETAIL_ID == model.TRANS_DETAIL_ID && x.TRANS_ID == model.TRANS_ID).ToList();

                    string icdcodeResult = string.Empty;

                    icdcodeResult = icdRes.Select(query => query.ICD).Aggregate((a, b) => a + ";" + b);

                    foreach (var item in icdRes)
                    {
                        item.ICD_RESULT = icdcodeResult;
                        item.ICD_CODE = icdcodeResult;

                    }

                }


                _context.SaveChanges();
            }
        }
        #endregion
        #region GetCPTGridData
        public List<CodingPeriModel> GetCPTGridData(int transId, string accountNumber, string Facility)
        {
            using (CBI_Anes_HighEntities _context = new CBI_Anes_HighEntities())
            {
                int projectId = Convert.ToInt32(HttpContext.Current.Session[Constants.ProjectId]);

                return (from TD in _context.tbl_TRANSACTION_DETAILS
                        where TD.TRANS_ID == transId
                        select new CodingPeriModel
                        {
                            CPTOrder = TD.CPT_ORDER,
                            AccountNumber = accountNumber,
                            TRANS_ID = TD.TRANS_ID,
                            CPT = TD.CPT,
                            ICD = TD.ICD,
                            Modifier = TD.MODIFIER,
                            HPI = TD.HPI,
                            PFSH = TD.PFSH,
                            ROS = TD.ROS,
                            Facility = Facility,
                            DowncodedForm = TD.Downcoded,
                            EXAM = TD.EXAM,
                            Comments = TD.COMMENTS,

                            TRANS_DETAIL_ID = TD.TRANS_DETAIL_ID
                        }).OrderBy(x => x.CPTOrder).ToList();
            }
        }
        #endregion
        #region GetCptICDDetails
        public CodingPeriModel GetCptICDDetails(int transId, int transDetailsId, string status, string accountNum, string facility)
        {
            using (CBI_Anes_HighEntities _context = new CBI_Anes_HighEntities())
            {
                CodingPeriModel model = new CodingPeriModel();
                model = LoadMasterDropdownData();
                model.TRANS_ID = transId;
                model.TRANS_DETAIL_ID = transDetailsId;
                model.Status = status;
                model.AccountNumber = accountNum;
                model.Facility = facility;
                model.CodingStartTime = DateTime.Now.ToString();
                var data = (from I in _context.tbl_IMPORT_TABLE
                            join T in _context.tbl_TRANSACTION on I.BATCH_ID equals T.BATCH_ID
                            join TD in _context.tbl_TRANSACTION_DETAILS on T.TRANS_ID equals TD.TRANS_ID
                            where TD.TRANS_DETAIL_ID == transDetailsId
                            select new { TD.ICD, TD.CPT, TD.CPT_LEVEL, TD.MODIFIER, TD.Downcoded, TD.HPI, TD.PFSH, TD.ROS, TD.EXAM, TD.COMMENTS, TD.ICD_CODE, TD.CPT_ORDER ,I.PAYER_CLASS}).FirstOrDefault();
                if (data != null)
                {
                    model.ICD = data.ICD;
                    model.CPTLevel = data.CPT_LEVEL;
                    model.CPT = data.CPT;
                    model.Modifier = data.MODIFIER;
                    model.DowncodedForm = data.Downcoded;
                    model.HPI = data.HPI;
                    model.PFSH = data.PFSH;
                    model.ROS = data.ROS;
                    model.EXAM = data.EXAM;
                    model.Comments = data.COMMENTS;
                    model.SelectedICDType = data.ICD_CODE;
                    model.SelectedCPT = data.CPT;
                    model.CPTOrder = data.CPT_ORDER;
                    model.PyrClass = CryptoGraphy.Decrypt(data.PAYER_CLASS);
                }

                var primaryCPT=(from T in _context.tbl_TRANSACTION_DETAILS 
                            where T.TRANS_ID  == transId
                                    select new {
                                        T.CPT
                                    }).FirstOrDefault();

                model.PriCPT = primaryCPT.CPT.ToString();
                model.LoadIcdType = LIcdType(transId);

                return model;
            }
        }
        #endregion
        #region DeleteAccountCPT
        public void DeleteAccountCPT(string cpt, int transId)
        {
            using (CBI_Anes_HighEntities _context = new CBI_Anes_HighEntities())
            {

                List<CodingPeriModel> list = (from data in _context.tbl_TRANSACTION_DETAILS

                                              where data.TRANS_ID == transId

                                              select new CodingPeriModel
                                              {
                                                  CPT = data.CPT,
                                                  TRANS_DETAIL_ID = data.TRANS_DETAIL_ID,
                                                  CPTOrder = data.CPT_ORDER,
                                                  TRANS_ID = data.TRANS_ID
                                              }).ToList();


                // Deleteing CPT direct start
                _context.tbl_TRANSACTION_DETAILS.RemoveRange(_context.tbl_TRANSACTION_DETAILS.Where(x => x.CPT == cpt && x.TRANS_ID == transId));
                _context.SaveChanges();

                // Deleteing CPT End


                // Change CPT Order Start (Amit)

                string str = "", OldCPT = "";
                int CPTOrder = 0;
                string CurrCPT = "";
                foreach (var x in list)
                {
                    int TDId = x.TRANS_DETAIL_ID;
                    string CPO = x.CPTOrder.ToString();
                    string Cp = x.CPT.ToString();

                    if (Cp == cpt || str == "test")
                    {
                        if (str != "test")
                        {
                            var res = (from z in list where (z.CPT == cpt) select z.CPTOrder.Remove(0, 3)).FirstOrDefault();
                            str = "test";
                            CPTOrder = int.Parse(res.ToString());
                            OldCPT = cpt;
                        }
                        if (OldCPT != Cp)
                        {
                            var tblTransDetails = _context.tbl_TRANSACTION_DETAILS.Where(a => a.TRANS_DETAIL_ID == TDId).FirstOrDefault();
                            tblTransDetails.CPT_ORDER = "CPT" + CPTOrder;
                            _context.SaveChanges();

                            CurrCPT = (from z in list where (z.TRANS_DETAIL_ID == TDId + 1) select z.CPT).FirstOrDefault();

                            if (CurrCPT != Cp)
                            {
                                CPTOrder = CPTOrder + 1;
                            }
                        }
                    }
                }

                // Change CPT Order End

            }
        }
        #endregion

        #region DeleteCPT
        public void DeleteCPT(int transDetailsId)
        {
            using (CBI_Anes_HighEntities _context = new CBI_Anes_HighEntities())
            {
                int projectId = Convert.ToInt32(HttpContext.Current.Session[Constants.ProjectId]);
                string userName = HttpContext.Current.Session[Constants.UserName].ToString();

                var transDetails = _context.tbl_TRANSACTION_DETAILS.Where(x => x.TRANS_DETAIL_ID == transDetailsId).FirstOrDefault();

                List<CodingPeriModel> list = (from data in _context.tbl_TRANSACTION_DETAILS

                                              where data.TRANS_ID == transDetails.TRANS_ID

                                              select new CodingPeriModel
                                              {
                                                  CPT = data.CPT,
                                                  TRANS_DETAIL_ID = data.TRANS_DETAIL_ID,
                                                  CPTOrder = data.CPT_ORDER
                                              }).ToList();
                string icdcodeResult = "";
                // moved

                var CPTvalue = (from data in _context.tbl_TRANSACTION_DETAILS
                                where data.TRANS_DETAIL_ID == transDetailsId
                                select data.CPT).SingleOrDefault();

                var count = _context.tbl_TRANSACTION_DETAILS.Where(x => x.CPT == CPTvalue && x.TRANS_ID == transDetails.TRANS_ID).Count();

                int value = count;


                // Deleteing ICD direct start
                _context.tbl_TRANSACTION_DETAILS.Remove(transDetails);
                _context.SaveChanges();
                // Deleteing ICD End


                // Change CPT Order Start (Amit)
                if (value == 1)
                {
                    string str = "", OldCPT = "", currentTDId = "";
                    int CPTOrder = 0;
                    foreach (var x in list)
                    {
                        int TDId = x.TRANS_DETAIL_ID;
                        string CPO = x.CPTOrder.ToString();
                        string Cp = x.CPT.ToString();

                        if (TDId == transDetails.TRANS_DETAIL_ID || str == "test")
                        {
                            currentTDId = "";
                            if (str != "test")
                            {
                                var res = (from z in list where (z.TRANS_DETAIL_ID == TDId) select z.CPTOrder.Remove(0, 3)).FirstOrDefault();
                                str = "test";
                                currentTDId = "1";
                                CPTOrder = int.Parse(res.ToString());
                            }

                            if (OldCPT == Cp)
                            {
                                CPTOrder = CPTOrder - 1;

                                var tblTransDetails = _context.tbl_TRANSACTION_DETAILS.Where(a => a.TRANS_DETAIL_ID == TDId).FirstOrDefault();
                                tblTransDetails.CPT_ORDER = "CPT" + CPTOrder;
                                _context.SaveChanges();

                                CPTOrder = CPTOrder + 1;
                            }
                            else
                            {
                                if (currentTDId != "1")
                                {
                                    var tblTransDetails = _context.tbl_TRANSACTION_DETAILS.Where(a => a.TRANS_DETAIL_ID == TDId).FirstOrDefault();
                                    tblTransDetails.CPT_ORDER = "CPT" + CPTOrder;
                                    _context.SaveChanges();
                                    CPTOrder = CPTOrder + 1;
                                }
                                OldCPT = Cp;
                            }
                        }
                    }
                }
                // Change CPT Order End

                var updateTransDetails = _context.tbl_TRANSACTION_DETAILS.Where(x => x.CPT == transDetails.CPT).ToList();

                if (updateTransDetails != null && updateTransDetails.Count > 0)
                {

                    icdcodeResult = projectId == 16 ? updateTransDetails.Select(query => query.ICD).Aggregate((a, b) => a + ";" + b) : updateTransDetails.Select(query => query.ICD_CODE).Aggregate((a, b) => a + ";" + b);

                    foreach (var item in updateTransDetails)
                    {
                        item.ICD_RESULT = icdcodeResult;
                        _context.SaveChanges();
                    }
                }
            }
        }
        #endregion

        #region UpdateAccountDetails
        public void UpdateAccountDetails(CodingPeriModel model)
        {
            using (CBI_Anes_HighEntities _context = new CBI_Anes_HighEntities())
            {
                var trans = _context.tbl_TRANSACTION.Where(x => x.TRANS_ID == model.TRANS_ID).FirstOrDefault();

                if (trans != null)
                {
                    trans.ATTENDING_PHY = model.AttendingPhy;
                    trans.NPPA = model.NPPA;
                    trans.SCRIBE = model.Scribe;
                    trans.PATIENT_STATUS = model.PatientStatusDCStatus;
                    trans.RESIDENT = model.Resident;
                    _context.SaveChanges();
                }
            }
        }
        #endregion


        #region LIcdType
        private List<SelectListItem> LIcdType(int value)
        {
            List<SelectListItem> listItems = new List<SelectListItem>();
            using (CBI_Anes_HighEntities _context = new CBI_Anes_HighEntities())
            {
                var data = (from I in _context.tbl_IMPORT_TABLE
                            join T in _context.tbl_TRANSACTION on I.BATCH_ID equals T.BATCH_ID
                            where T.TRANS_ID == value
                            select I.ICD_CODE).FirstOrDefault();

                if (data == "Y")
                {
                    listItems.Add(new SelectListItem { Text = "ICD-9", Value = "ICD-9" });
                    listItems.Add(new SelectListItem { Text = "ICD-10", Value = "ICD-10" });
                }
                else
                {
                    listItems.Add(new SelectListItem { Text = "ICD-10", Value = "ICD-10" });
                }
                return listItems;
            }
        }
        #endregion

        #region GetValidCPTList
        public List<SelectListItem> GetValidCPTList(string CPTValue, int TRANSID)
        {
            DataSet dataset;
            if (HttpContext.Current.Session["DataTable"] != null)
            {
                dataset = HttpContext.Current.Session["DataTable"] as DataSet;
            }
            else
            {
                LoadMasterDropdownData();
                dataset = HttpContext.Current.Session["DataTable"] as DataSet;
            }
            if (CPTValue == "CPT1")    
            {
                return (from p in dataset.Tables[8].AsEnumerable() select new SelectListItem { Text = p.Field<string>("CPT1"), Value = Convert.ToString(p.Field<int>("CPT1_ID")) }).ToList();
            }
            else
            {
                return (from p in dataset.Tables[15].AsEnumerable() select new SelectListItem { Text = p.Field<string>("OCPT"), Value = p.Field<string>("OCPT") }).ToList();
            }
        }
        #endregion
    }
}
