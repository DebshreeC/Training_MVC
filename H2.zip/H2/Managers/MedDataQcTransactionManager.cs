﻿using CBIplus.BAL.Generics;
using CBIplus.BAL.ViewModels;
using CBIplus.DAL;

using Microsoft.Win32.SafeHandles;
using System;
using System.Collections.Generic;
using System.Data.Entity.Validation;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using System.Web.Mvc;

namespace CBIplus.BAL.Managers
{
    public class MedDataQcTransactionManager : IMedDataQcTransactionService
    {
        #region GetQcTransactionDetails
        public MedDataQcTransactionModel GetQcTransactionDetails()
        {
            MedDataQcTransactionModel model = new MedDataQcTransactionModel();
          //  model.CoderList = GetCoderList();
         //   model.PhysicalStatusList = GetPhysacalStatus();
            model.ErrorList = GetErrorDataDetails();
            //model.ProviderMdList = GetProviderList();
            //model.NPPAList = GetNPPAList();
            return model;
        }
        #endregion

        #region GetCoderDropdown
        private List<SelectListItem> GetCoderList()
        {
            using (CBI_Anes_HighEntities _context = new CBI_Anes_HighEntities())
            {
                string[] names = { "CODER", "IMPORT-CODER", "ADMIN", "CODER-TL", "Senior-Coder" };
                int projectId = Convert.ToInt32(HttpContext.Current.Session[Constants.ProjectId]);
                return (from UA in _context.tbl_USER_ACCESS
                        where names.Contains(UA.ACCESS_TYPE) && UA.PROJECT_ID == projectId
                        select new SelectListItem
                        {
                            Text = UA.USER_NAME,
                            Value = UA.USER_NTLG
                        }).ToList();
            }
        }
        #endregion

        #region GetStartTimeDropdown
        public List<SelectListItem> GetStartTimeDropdown()
        {
            List<SelectListItem> list = new List<SelectListItem>();
            for (int i = 0; i < 24;i++ )
            {
                SelectListItem item = new SelectListItem { Text=i.ToString(),Value=i.ToString()};
                list.Add(item);
            }
            return list;
        }
        #endregion

        #region GetEndTimeDropdown
        public List<SelectListItem> GetEndTimeDropdown()
        {
            List<SelectListItem> list = new List<SelectListItem>();
            for (int i = 0; i < 60; i++)
            {
                SelectListItem item = new SelectListItem{ Text=i.ToString(),Value=i.ToString()};
                list.Add(item);
            }
            return list;
        }
        #endregion

        #region GetProviderDropdown
        private List<SelectListItem> GetProviderList()
        {
            using (CBI_Anes_HighEntities _context = new CBI_Anes_HighEntities())
            {
                return (from AP in _context.tbl_ASSISTANT_PROVIDER_MASTER
                        select new SelectListItem
                            {
                                Text = AP.PROVIDER_ID + "-" + AP.FIRST_NAME + "," + AP.LAST_NAME,
                                Value = AP.A_ID.ToString()
                            }).OrderBy(x => x.Text).ToList();
            }
        }
        #endregion

        #region GetNPPA
        private List<SelectListItem> GetNPPAList()
        {
            int projectId = Convert.ToInt32(HttpContext.Current.Session[Constants.ProjectId]);
            using (CBI_Anes_HighEntities _context = new CBI_Anes_HighEntities())
            {
                return (from NPA in _context.tbl_NP_PA_MASTER where NPA.PROJECT_ID == projectId select new SelectListItem { Text = NPA.NP_PA_CODE + "-" + NPA.NP_PA_NAME, Value = NPA.NP_PA_CODE }).OrderBy(x => x.Text).ToList();
            }
        }
        #endregion

        #region GetCPTLevel    
        private List<SelectListItem> GetCptLevelList()
        {
            using (CBI_Anes_HighEntities _context = new CBI_Anes_HighEntities())
            {
                return (from CPT in _context.tbl_CPT1_MASTER select new SelectListItem { Text = CPT.CPT1, Value = CPT.CPT1_ID.ToString() }).OrderBy(x => x.Value).ToList();
            }
        }
        #endregion

        #region Get Physacal Status

        public List<SelectListItem> GetPhysacalStatus()
        {
            using (CBI_Anes_HighEntities _context = new CBI_Anes_HighEntities())
            {
                int projectId = Convert.ToInt32(HttpContext.Current.Session[Constants.ProjectId]);

                var list = (from phyStatus in _context.PHYSICAL_STATUS_MODIFIER_MASTER
                            select new SelectListItem
                            {
                                Text = phyStatus.PSM_Id.ToString() + "-" + phyStatus.Discription,
                                Value = phyStatus.PSM_Id.ToString()
                            }).ToList();
                return list;
            }
        }
        #endregion

        #region GetCPTGridData
        public List<MedDataQcTransactionModel> GetCPTGridData(int transId,string accountNumber)
        {
            using (CBI_Anes_HighEntities _context = new CBI_Anes_HighEntities())
            {
                int projectId = Convert.ToInt32(HttpContext.Current.Session[Constants.ProjectId]);

                return (from TD in _context.tbl_TRANSACTION_DETAILS
                        where TD.TRANS_ID == transId
                        select new MedDataQcTransactionModel
                        {
                            AccountNumber=accountNumber,
                            TRANS_ID = TD.TRANS_ID,
                            CPT = TD.CPT,
                            AsaCross = TD.ASA_CROSS,
                            Modifier = TD.MODIFIER,
                            DiadnosisResult = TD.ICD_RESULT,
                            AncillaryServices = TD.ANCILLARY_SERVICES,
                            AncillaryModifier = TD.ANCILLARY_MODIFIER,
                            AcutePainCPT = TD.ACUTE_PAIN_CPT,
                            AcutePainDX = TD.ACUTE_PAIN_DX,
                            AcutePainPOS = TD.ACUTE_PAIN_POS,
                            SelectPQRS = TD.PQRS,
                            MedicalDirection = TD.MEDICAL_DIRECTION,
                            AncillaryServiceProvider = TD.ANCILLARY_SERVICE_PROVIDERS,
                            SelectQualifyingCircumstances = TD.QUALIFYING_CIRCUMSTANCES,
                            Comments = TD.COMMENTS,
                            IcdCode=TD.ICD_CODE,
                            BaseUnitModification=TD.UNITS.ToString(),
                            TRANS_DETAIL_ID = TD.TRANS_DETAIL_ID,
                        }).ToList();
            }
        }
        #endregion

        #region Get Coded Details

        public List<MedDataQcTransactionModel> GetCodedData()
        {
            using (CBI_Anes_HighEntities _context = new CBI_Anes_HighEntities())
            {
                int projectId = Convert.ToInt32(HttpContext.Current.Session[Constants.ProjectId]);
                string useName = HttpContext.Current.Session[Constants.UserName].ToString();

                return (from I in _context.tbl_IMPORT_TABLE
                        join T in _context.tbl_TRANSACTION on I.BATCH_ID equals T.BATCH_ID
                        //join TD in _context.tbl_TRANSACTION_DETAILS on T.TRANS_ID equals TD.TRANS_ID
                        where I.BATCH_STATUS == "QC Allotted" && T.PROJECT_ID == projectId && I.QC_ALLOTTED_BY == useName
                        select new MedDataQcTransactionModel
                        {
                            AccountNumber = I.ACCOUNT_NO,
                            FacilityName = I.FACILITY,
                            DOS = I.DOS.ToString(),
                            BatchName = I.BATCH_NAME,
                            BatchId = I.BATCH_ID,
                            JobName = I.JOB_NAME,
                            PageCount = I.PAGE_COUNT.ToString(),
                            AnesType = T.ANES_TYPE,
                            TRANS_ID = T.TRANS_ID,
                            PhysicalStatus = T.PHYSICAL_STATUS,
                            PatientName = T.PATIENT_NAME,
                            ProviderName1=T.PROVIDER_NAME1,
                            ProviderName2=T.PROVIDER_NAME2,
                            ProviderName3=T.PROVIDER_NAME3,
                            ProviderName4=T.PROVIDER_NAME4,
                            ProviderName5=T.PROVIDER_NAME5,
                            CRNA1=T.CRNA1,
                            CRNA2=T.CRNA2,
                            CRNA3=T.CRNA3,
                            CRNA4=T.CRNA4,
                            CRNA5=T.CRNA5,
                           ReviewReAudit=T.REVIEW_REAUDIT==0?"NO":"YES",
                ReviewReAuditStatus=T.RELEASE_REAUDIT_STATUS==0?"NO":"YES",
                CodedBy=T.CODED_BY,
                CodedDate=T.CODED_DATE.ToString()
                        }).GroupBy(x=>x.AccountNumber).Select(x=>x.FirstOrDefault()).ToList();
            }
        }

        #endregion

        #region QCAddNewCPT
        public void QCAddNewCPT(MedDataQcTransactionModel model)
        {
            using (CBI_Anes_HighEntities _context = new CBI_Anes_HighEntities())
            {
                try
                {
                    var TD = _context.tbl_TRANSACTION_DETAILS.Where(x => x.TRANS_DETAIL_ID == model.TRANS_DETAIL_ID).FirstOrDefault();
                    var trans = _context.tbl_TRANSACTION.Where(x => x.TRANS_ID == model.TRANS_ID).FirstOrDefault();

                    string[] AST = model.AnesthesiaStartTimeFrom.Split(':');
                    string[] EST = model.AnesthesiaEndTimeFrom.Split(':');
                    if (TD == null)
                    {
                        string icdres=model.DiadnosisResult.Trim(';');
                        string[] icdArray = icdres.Split(';');
                       for(int i=0;i<icdArray.Length;i++)
                       {
                           tbl_TRANSACTION_DETAILS transDetails = new tbl_TRANSACTION_DETAILS();
                           string icdCode = icdArray[i];
                           transDetails.TRANS_ID = model.TRANS_ID;
                           transDetails.CPT = model.CPT;
                           transDetails.ASA_CROSS = model.AsaCross;
                           transDetails.MODIFIER = model.Modifier;
                           transDetails.ICD_CODE = icdCode;
                           transDetails.ICD_RESULT = model.DiadnosisResult;
                           transDetails.ANCILLARY_SERVICES = model.AncillaryServices;
                           transDetails.ANCILLARY_MODIFIER = model.AncillaryModifier;
                           transDetails.ACUTE_PAIN_POS = model.AcutePainPOS;
                           transDetails.PQRS = model.SelectPQRS;
                           transDetails.UNITS =model.BaseUnitModification==null? 0: Convert.ToInt32(model.BaseUnitModification);
                           transDetails.MEDICAL_DIRECTION = model.MedicalDirection;
                           transDetails.ANCILLARY_SERVICE_PROVIDERS = model.AncillaryServiceProvider;
                           transDetails.QUALIFYING_CIRCUMSTANCES = model.SelectQualifyingCircumstances;
                           transDetails.COMMENTS = model.Comments;
                           transDetails.ACUTE_PAIN_CPT = model.AcutePainCPT;
                           transDetails.ACUTE_PAIN_DX = model.AcutePainDX;
                           transDetails.PROVIDER_MD = model.ProviderName;
                           transDetails.CRNA = model.CRNA;
                           transDetails.Anesthesia_Start_time = Convert.ToDateTime(AST[0] + ":" + AST[1]).TimeOfDay;
                           transDetails.Anesthesia_End_time = Convert.ToDateTime(EST[0] + ":" + EST[1]).TimeOfDay;
                           transDetails.Anesthesia_Time_Diff = Convert.ToDateTime(model.TimeDifference).TimeOfDay;
                           _context.tbl_TRANSACTION_DETAILS.Add(transDetails);
                       }

                    }
                    else
                    {
                      
                        TD.TRANS_ID = model.TRANS_ID;
                        TD.CPT = model.CPT;
                        TD.ASA_CROSS = model.AsaCross;
                        TD.MODIFIER = model.Modifier;
                        TD.ICD_CODE = model.DiadnosisResult.TrimEnd(';');
                        TD.ICD_RESULT =TD.ICD_RESULT+";"+ model.DiadnosisResult;
                        TD.ANCILLARY_SERVICES = model.AncillaryServices;
                        TD.ANCILLARY_MODIFIER = model.AncillaryModifier;
                        TD.ACUTE_PAIN_POS = model.AcutePainPOS;
                        TD.PQRS = model.SelectPQRS;
                        TD.UNITS =model.BaseUnitModification==null? 0 : Convert.ToInt32(model.BaseUnitModification);
                        TD.MEDICAL_DIRECTION = model.MedicalDirection;
                        TD.ANCILLARY_SERVICE_PROVIDERS = model.AncillaryServiceProvider;
                        TD.QUALIFYING_CIRCUMSTANCES = model.SelectQualifyingCircumstances;
                        TD.COMMENTS = model.Comments;
                        TD.ACUTE_PAIN_CPT = model.AcutePainCPT;
                        TD.ACUTE_PAIN_DX = model.AcutePainDX;
                        TD.PROVIDER_MD = model.ProviderName;
                        TD.CRNA = model.CRNA;
                        TD.Anesthesia_Start_time = Convert.ToDateTime(AST[0] + ":" + AST[1]).TimeOfDay;
                        TD.Anesthesia_End_time = Convert.ToDateTime(EST[0] + ":" + EST[1]).TimeOfDay;
                        TD.Anesthesia_Time_Diff = Convert.ToDateTime(model.TimeDifference).TimeOfDay;
                     
                        _context.SaveChanges();
                        var icdRes = _context.tbl_TRANSACTION_DETAILS.Where(x => x.CPT == TD.CPT && x.TRANS_ID == model.TRANS_ID).ToList();
                        int i = 0;
                        string icdcodeResult = string.Empty;
                      
                        icdcodeResult = icdRes.Select(query => query.ICD_CODE).Aggregate((a, b) => a + ";" + b);
                      
                        foreach(var item in icdRes)
                        {
                            item.ICD_RESULT = icdcodeResult;
                            _context.SaveChanges();
                        }
                    }
                    trans.QC_DATE = DateTime.Now;

                }
                catch (DbEntityValidationException ex)
                {
                    var errorMessages = ex.EntityValidationErrors.SelectMany(x => x.ValidationErrors).Select(x => x.ErrorMessage);
                    var fullErrorMessage = string.Join(Constants.CommaSpace, errorMessages);
                    var exceptionMessage = string.Concat(ex.Message, Constants.ValidationError, fullErrorMessage);
                    throw new DbEntityValidationException(exceptionMessage, ex.EntityValidationErrors);
                }
                _context.SaveChanges();

            }
        }
        #endregion

        #region Get PQRS

        public List<SelectListItem> getPQRS()
        {
            using (CBI_Anes_HighEntities _context = new CBI_Anes_HighEntities())
            {
                int projectId = Convert.ToInt32(HttpContext.Current.Session[Constants.ProjectId]);
                var list = (from PQRS in _context.PQRS_MASTER
                            select new SelectListItem
                            {
                                Text = PQRS.Measure.ToString() + " - " + PQRS.Discription,
                                Value = PQRS.Measure.ToString()
                            }).ToList();
                return list;
            }
        }
        #endregion

        #region Get Qualifying Circumstance

        public List<SelectListItem> getQualifyingCircumstance()
        {
            using (CBI_Anes_HighEntities _context = new CBI_Anes_HighEntities())
            {
                int projectId = Convert.ToInt32(HttpContext.Current.Session[Constants.ProjectId]);
                var list = (from qualifyingCircumstance in _context.QUALIFYING_CIRCUMSTANCE_MASTER
                            select new SelectListItem
                            {
                                Text = qualifyingCircumstance.Codes + " - " + qualifyingCircumstance.Qualifying_Circumstance.ToString(),
                                Value = qualifyingCircumstance.Codes.ToString()
                            }).ToList();
                return list;
            }
        }
        #endregion

        #region Get AsaCross

        private string getAsaCross(string CPTCode)
        {
            using (CBI_Anes_HighEntities _context = new CBI_Anes_HighEntities())
            {
                int projectId = Convert.ToInt32(HttpContext.Current.Session[Constants.ProjectId]);
                var asaCross = (from cpt in _context.CPT_MASTER
                                where cpt.CPT == CPTCode
                                select new
                                {
                                    cpt.CPT_Ane_Code,
                                    cpt.CPT_Ane_Descriptor
                                }).FirstOrDefault();
                string asaCros = asaCross == null ? null : asaCross.CPT_Ane_Code + " - " + asaCross.CPT_Ane_Descriptor.ToString();
                return asaCros;
            }
        }
        #endregion

        public MedDataQcTransactionModel All(int transDetailsId = 0)
        {
            MedDataQcTransactionModel model = new MedDataQcTransactionModel();
            using (CBI_Anes_HighEntities _context = new CBI_Anes_HighEntities())
            {
                var TD = _context.tbl_TRANSACTION_DETAILS.Where(x => x.TRANS_DETAIL_ID == transDetailsId).FirstOrDefault();
                if (TD != null)
                {
                    model.CPT = TD.CPT;
                    model.AcutePainPOS = TD.ACUTE_PAIN_POS;
                    model.AsaCross = TD.ASA_CROSS;
                    model.SelectPQRS = TD.PQRS;
                    model.Modifier = TD.MODIFIER;
                    model.BaseUnitModification = TD.UNITS.ToString();
                    model.Diagnosis = TD.ICD_CODE;
                    model.MedicalDirection = TD.MEDICAL_DIRECTION;
                  //  model.DiadnosisResult = TD.ICD_RESULT;
                    model.AncillaryServiceProvider = TD.ANCILLARY_SERVICE_PROVIDERS;
                    model.AncillaryServices = TD.ANCILLARY_SERVICES;
                    model.SelectQualifyingCircumstances = TD.QUALIFYING_CIRCUMSTANCES;
                    model.AncillaryModifier = TD.ANCILLARY_MODIFIER;
                    model.AcutePainCPT = TD.ACUTE_PAIN_CPT;
                    model.AcutePainDX = TD.ACUTE_PAIN_DX;
                    model.ProviderName = TD.PROVIDER_MD;
                    model.CRNA = TD.CRNA;
                    model.AnesthesiaStartTimeFrom = string.IsNullOrEmpty(TD.Anesthesia_Start_time.ToString()) ? null : DateTime.Today.Add(TD.Anesthesia_Start_time.Value).ToString("hh:mm tt");
                    model.AnesthesiaEndTimeFrom = string.IsNullOrEmpty(TD.Anesthesia_End_time.ToString()) ? null : DateTime.Today.Add(TD.Anesthesia_End_time.Value).ToString("hh:mm tt");

                    //model.AnesthesiaStartTimeFrom = string.IsNullOrEmpty(TD.Anesthesia_Start_time.ToString()) ? null : TD.Anesthesia_Start_time.ToString().Split(':')[0].Length > 1 ? TD.Anesthesia_Start_time.ToString().Split(':')[0].TrimStart('0') : TD.Anesthesia_Start_time.ToString().Split(':')[0];
                    //model.AnesthesiaStartTimeTo = string.IsNullOrEmpty(TD.Anesthesia_Start_time.ToString()) ? null : TD.Anesthesia_Start_time.ToString().Split(':')[1].Length > 1 ? TD.Anesthesia_Start_time.ToString().Split(':')[1].TrimStart('0') : TD.Anesthesia_Start_time.ToString().Split(':')[1];
                    //model.AnesthesiaEndTimeFrom = string.IsNullOrEmpty(TD.Anesthesia_End_time.ToString()) ? null : TD.Anesthesia_End_time.ToString().Split(':')[0].Length > 1 ? TD.Anesthesia_End_time.ToString().Split(':')[0].TrimStart('0') : TD.Anesthesia_End_time.ToString().Split(':')[0];
                    //model.AnesthesiaEndTimeTo = string.IsNullOrEmpty(TD.Anesthesia_End_time.ToString()) ? null : TD.Anesthesia_End_time.ToString().Split(':')[1].Length > 1 ? TD.Anesthesia_End_time.ToString().Split(':')[1].TrimStart('0') : TD.Anesthesia_End_time.ToString().Split(':')[1];
                   
                    model.TimeDifference = string.IsNullOrEmpty(TD.Anesthesia_Time_Diff.ToString()) ? null : TD.Anesthesia_Time_Diff.ToString();
                    model.Comments = TD.COMMENTS;
                }
            }

            model.PhysicalStatusList = GetPhysacalStatus();
            model.PQRS = getPQRS();
            model.QualifyingCircumstances = getQualifyingCircumstance();
            model.StatusNames = GetStatusNames();
            return model;
        }

        #region Get Status Nammes
        public List<SelectListItem> GetStatusNames()
        {
            using (CBI_Anes_HighEntities _context = new CBI_Anes_HighEntities())
            {
                var list = (from status in _context.tbl_STATUS_MASTER
                            select new SelectListItem
                            {
                                Text = status.STATUS_TYPE,
                                Value = status.STATUS_ID.ToString()
                            }).ToList();
                return list;
            }
        }
        #endregion

        #region GetErrorDataDetails
        public List<SelectListItem> GetErrorDataDetails()
        {
            int projectId = Convert.ToInt32(HttpContext.Current.Session[Constants.ProjectId]);
            using (CBI_Anes_HighEntities _context = new CBI_Anes_HighEntities())
            {
                var data = (from E in _context.tbl_ERROR_CATEGORY where E.PROJECT_ID == projectId select new SelectListItem { Text = E.ERROR_CATEGORY, Value = E.ERROR_CATEGORY }).Distinct().ToList();
                var uniqueItems = data.GroupBy(s => s.Value, i => i, (k, item) => new SelectListItem
                {
                    Text = item.First().Text,
                    Value = k,

                }).ToList();
                return uniqueItems;
            }
        }
        #endregion

        #region GetErrorSubCategory

        public List<SelectListItem> GetErrorSubCategory(string errorType)
        {
            int projectId = Convert.ToInt32(HttpContext.Current.Session[Constants.ProjectId]);
            using (CBI_Anes_HighEntities _context = new CBI_Anes_HighEntities())
            {
                return (from E in _context.tbl_ERROR_CATEGORY where E.PROJECT_ID == projectId && E.ERROR_CATEGORY == errorType select new SelectListItem { Text = E.SUB_CATEGORY1, Value = E.E_ID.ToString() }).ToList();

            }
        }
        #endregion

        #region UpdateAccountDetails
        public void UpdateAccountDetails(MedDataQcTransactionModel model)
        {
            using (CBI_Anes_HighEntities _context = new CBI_Anes_HighEntities())
            {
                var trans = _context.tbl_TRANSACTION.Where(x => x.BATCH_ID == model.BatchId).FirstOrDefault();
                var import = _context.tbl_IMPORT_TABLE.Where(x => x.BATCH_ID == model.BatchId).FirstOrDefault();
                if (trans != null)
                {
                    import.FACILITY = model.FacilityName;
                    import.DOS = Convert.ToDateTime(model.DOS);
                    trans.DOS = Convert.ToDateTime(model.DOS);
                    import.BATCH_NAME = model.BatchName;
                    import.JOB_NAME = model.JobName;
                    import.PAGE_COUNT = Convert.ToInt32(model.PageCount);
                    trans.ANES_TYPE = model.AnesType;
                    trans.PHYSICAL_STATUS = model.PhysicalStatus;
                    trans.PATIENT_NAME = model.PatientName;
                    trans.PROVIDER_NAME1 = model.ProviderName1;
                    trans.PROVIDER_NAME2 = model.ProviderName2;
                    trans.PROVIDER_NAME3 = model.ProviderName3;
                    trans.PROVIDER_NAME4 = model.ProviderName4;
                    trans.PROVIDER_NAME5 = model.ProviderName5;
                    trans.CRNA1 = model.CRNA1;
                    trans.CRNA2 = model.CRNA2;
                    trans.CRNA3 = model.CRNA3;
                    trans.CRNA4 = model.CRNA4;
                    trans.CRNA5 = model.CRNA5;
                 
                    _context.SaveChanges();
                }
            }
        }
        #endregion

        #region FinalQcSubmit
        public void FinalQcSubmit(List<MedDataQcTransactionModel> model, string selectedAccounts)
        {
            int projectId = Convert.ToInt32(HttpContext.Current.Session[Constants.ProjectId]);
            using (CBI_Anes_HighEntities _context = new CBI_Anes_HighEntities())
            {
                string[] array = selectedAccounts.Split(',').Select(x => x.Trim()).ToArray();
                string errorCategory = string.Empty;
                string errorSubCategory = string.Empty;
                string errorCorrection = string.Empty;
                string errorSeverity = string.Empty;
                string errorBehaviour= string.Empty;
                string errorFinancialImpact= string.Empty;
                string errorMicroCategory = string.Empty;
                int errorCount = 0;
                string userName = HttpContext.Current.Session[Constants.UserName].ToString();
                if (selectedAccounts.Contains("Skip"))
                {
                    if (projectId == 16)
                    {
                        string[] newArray = array.Select(x => CryptoGraphy.Encrypt(x)).ToArray();
                        var myList = _context.tbl_IMPORT_TABLE.Where(x => newArray.Contains(x.ACCOUNT_NO) && x.PROJECT_ID == projectId).ToList();

                        var bathIds = myList.Select(x => x.BATCH_ID).ToList();
                        _context.tbl_TRANSACTION.Where(x => bathIds.Contains(x.BATCH_ID) && x.PROJECT_ID == projectId).ToList().ForEach(x => { x.QC_BY = userName; x.QC_DATE = DateTime.Now; x.QC_STATUS = "QC"; x.IS_SKIPPED = 1; x.IS_AUDITED = 0; });
                        myList.ForEach(x => {x.BATCH_STATUS = "QC"; });

                    }
                    else
                    {
                        var myList = _context.tbl_IMPORT_TABLE.Where(x => array.Contains(x.ACCOUNT_NO) && x.PROJECT_ID == projectId).ToList();

                        var bathIds = myList.Select(x => x.BATCH_ID).ToList();
                        _context.tbl_TRANSACTION.Where(x => bathIds.Contains(x.BATCH_ID) && x.PROJECT_ID == projectId).ToList().ForEach(x => { x.QC_BY = userName; x.QC_DATE = DateTime.Now; x.QC_STATUS = "Qced"; x.IS_SKIPPED = 1; x.IS_AUDITED = 0; });
                        myList.ForEach(x => { x.BATCH_STATUS = "QC"; });
                    }
                    
                        HttpContext.Current.Session["FinalList"] = null;
                    
                    _context.SaveChanges();

                }

                else
                {
                    if (model != null)
                    {
                        for (int i = 0; i < model.Count; i++)
                        {
                            errorCategory = errorCategory + model[i].SelecetedError + ",";
                            errorSubCategory = errorSubCategory + model[i].SelectedSubError + ",";
                            errorCount = errorCount + Convert.ToInt32(model[i].ErrorCount);                           
                        }
                    }
                    errorCorrection = array[2];
                    /************************SUBHAJA********************************///new fileds aaded
                    errorMicroCategory = array[3];
                    errorSeverity = array[4];
                    errorFinancialImpact = array[6];
                    errorBehaviour = array[5];
                    /************************SUBHAJA********************************///new fileds aaded
                    string accountNumber = "";
                    accountNumber = projectId == 16 ? CryptoGraphy.Encrypt(array[7].Trim()) : array[7];//array position changed from 3 to 7 after adding 4 new fileds--subhaja
                    var import = _context.tbl_IMPORT_TABLE.Where(x => x.ACCOUNT_NO == accountNumber.Trim() && x.PROJECT_ID == projectId).FirstOrDefault();
                    var transaction = _context.tbl_TRANSACTION.Where(x => x.BATCH_ID == import.BATCH_ID).FirstOrDefault();

                    import.BATCH_STATUS = "QC";
                    transaction.IS_AUDITED = 1;
                    transaction.ERROR_CATEGORY = string.IsNullOrEmpty(transaction.ERROR_CATEGORY) ? errorCategory.TrimEnd(',') : transaction.ERROR_CATEGORY + ";" + errorCategory.TrimEnd(',');
                    transaction.ERROR_SUBCATEGORY = string.IsNullOrEmpty(transaction.ERROR_SUBCATEGORY) ? errorSubCategory.TrimEnd(',') : transaction.ERROR_SUBCATEGORY + ";" + errorSubCategory.TrimEnd(',');
                    transaction.ERROR_WEIGHTAGE = string.IsNullOrEmpty(transaction.ERROR_WEIGHTAGE) ? errorCount.ToString() : transaction.ERROR_WEIGHTAGE + ";" + errorCount.ToString();
                    transaction.QC_COMMENTS = array[1];
                    transaction.QC_BY = HttpContext.Current.Session[Constants.UserName].ToString();
                    transaction.QC_DATE = DateTime.Now;

                    /************************SUBHAJA********************************///new fileds aaded
                    transaction.Error_Micro_Category = errorMicroCategory ;
                    transaction.Severity_Level = errorSeverity ;
                    transaction.Behaviour = errorBehaviour;
                    transaction.Financial_Impact = errorFinancialImpact;
                    transaction.Timestamp = DateTime.Now;
                    /************************SUBHAJA********************************///new fileds aaded

                    //if ((errorCount == 0 && selectedAccounts.Contains("Yes"))||(errorCount==0 && selectedAccounts.Contains("No")))
                    if (errorCount <= 0)
                    {
                        transaction.QC_STATUS = "QC";
                        transaction.IS_SKIPPED = 0;
                    }
                    // if ((errorCount > 0 && selectedAccounts.Contains("Yes")) || (errorCount > 0 && selectedAccounts.Contains("No")))
                    else
                    {
                        transaction.QC_STATUS = "Error";
                        if (array[2] == "Yes")
                        {
                            transaction.QC_ERROR_CORRECTION = "Y";
                        }
                        else
                        {
                            transaction.QC_ERROR_CORRECTION = "N";
                        }


                    }

                    
                    //if (selectedAccounts.Contains("Error"))
                    //{  
                    //    if (errorCorrection.ToUpper().Contains("NO"))
                    //    {
                    //        transaction.QC_STATUS = "Error";
                    //        transaction.SEND_TO_CODER = "Y";
                    //    }
                    //    else
                    //    {
                    //        transaction.QC_STATUS = "Error";
                    //    }
                    //}
                    //else
                    //{  
                    //      transaction.QC_STATUS = "Qced";
                    //}

                    _context.SaveChanges();
                }
            }
            if (projectId == 16)
            {
                HttpContext.Current.Session["FinalList"] = null;
            }
        }
        #endregion

        #region DeleteCPT
        public void DeleteCPT(int transDetailsId)
        {
            using (CBI_Anes_HighEntities _context = new CBI_Anes_HighEntities())
            {
                var transDetails = _context.tbl_TRANSACTION_DETAILS.Where(x => x.TRANS_DETAIL_ID == transDetailsId).FirstOrDefault();
                _context.tbl_TRANSACTION_DETAILS.Remove(transDetails);
                _context.SaveChanges();
                var updateTransDetails = _context.tbl_TRANSACTION_DETAILS.Where(x => x.CPT == transDetails.CPT).ToList();
           
               if(updateTransDetails!=null && updateTransDetails.Count>0)
               {
                   string icdcodeResult = updateTransDetails.Select(query => query.ICD_CODE).Aggregate((a, b) => a + ";" + b);
                   foreach (var item in updateTransDetails)
                   {
                       item.ICD_RESULT = icdcodeResult;
                      
                   }
                   _context.SaveChanges();
               }
               
            }
        }
        #endregion

    }
}
