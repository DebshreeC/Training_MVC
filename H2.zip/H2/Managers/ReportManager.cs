﻿using CBIplus.BAL.Generics;
using CBIplus.BAL.ViewModels;
using CBIplus.DAL;
using Microsoft.Win32.SafeHandles;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using System.Web.Mvc;

namespace CBIplus.BAL.Managers
{
    public class ReportManager : IReportManager
    {
        int taskid;
        public ReportsViewModel GetReportDetails(string taskName)
        {
            int projectId = Convert.ToInt32(HttpContext.Current.Session[Constants.ProjectId]);
          //  int practiceid = Convert.ToInt32(HttpContext.Current.Session[Constants.PracticeID]);
              ReportsViewModel model = new ReportsViewModel();
            using (CBI_Anes_HighEntities _context = new CBI_Anes_HighEntities())
            {
                var taskTable = _context.tbl_TASK_TABLE.Where(x => x.PROJECT_ID == projectId && x.TASK_NAME == taskName).FirstOrDefault();
              
                model.ProjectId = projectId.ToString();
                model.PracticeID = Convert.ToInt32(HttpContext.Current.Session[Constants.PracticeID]).ToString();
                model.UserName = HttpContext.Current.Session[Constants.UserName].ToString();


                if(taskTable!=null)
                {
                    model.TaskId = taskTable.TASK_ID.ToString();
                    taskid = Convert.ToInt32(taskTable.TASK_ID.ToString());
                }
            }
            return model;
        }

        //public List<SelectListItem> GetFacilityNames(string fromDate,string toDate)
        //{
        //    DateTime fromDos = Convert.ToDateTime(fromDate),toDos=Convert.ToDateTime(toDate);
        //     int projectId = Convert.ToInt32(HttpContext.Current.Session[Constants.ProjectId]);
        //    using (CBI_Anes_HighEntities _context = new CBI_Anes_HighEntities())
        //    {
        //        var data= (from I in _context.tbl_IMPORT_TABLE where I.PROJECT_ID == projectId && I.DOS >= fromDos && I.DOS <= toDos select new SelectListItem { Text = I.FACILITY, Value = I.FACILITY }).Distinct().ToList();
        //        var uniqueItems = data.GroupBy(s => s.Value, i => i, (k, item) => new SelectListItem
        //        {
        //            Text = item.First().Text,
        //            Value = k,

        //        }).ToList();
        //        return uniqueItems;
        //    }
        //}

        public List<SelectListItem> GetFacilityNames(string fromDate, string toDate)
        {
            DateTime fromDos = Convert.ToDateTime(fromDate), toDos = Convert.ToDateTime(toDate);
            int projectId = Convert.ToInt32(HttpContext.Current.Session[Constants.ProjectId]);
            using (CBI_Anes_HighEntities _context = new CBI_Anes_HighEntities())
            {
                var data = (from I in _context.tbl_IMPORT_TABLE
                            join t in _context.tbl_TRANSACTION on I.BATCH_ID equals t.BATCH_ID
                            where I.PROJECT_ID == projectId && t.CODED_DATE >= fromDos && t.CODED_DATE <= toDos
                            select new SelectListItem { Text = I.FACILITY, Value = I.FACILITY }).Distinct().ToList();
                var uniqueItems = data.GroupBy(s => s.Value, i => i, (k, item) => new SelectListItem
                {
                    Text = item.First().Text,
                    Value = k,
                }).ToList();
                return uniqueItems;
            }
        }

        public List<SelectListItem> GetFacilityCode(string BatchName)
        {
            int projectId = Convert.ToInt32(HttpContext.Current.Session[Constants.ProjectId]);

            string batchName=CryptoGraphy.Encrypt(BatchName);
            using (CBI_Anes_HighEntities _context = new CBI_Anes_HighEntities())
            {
                var data = (from I in _context.tbl_IMPORT_TABLE
                            where I.PROJECT_ID == projectId && I.BATCH_NAME == batchName 
                            select new SelectListItem { Text = I.FACILITY, Value = I.FACILITY }).Distinct().ToList();
                var uniqueItems = data.GroupBy(s => s.Value, i => i, (k, item) => new SelectListItem
                {
                    Text = item.First().Text,
                    Value = k,
                }).ToList();
                return uniqueItems;
            }
        }
        
        public List<SelectListItem> GetPracticeName(string fromDate, string toDate)
        {
            int projectId = Convert.ToInt32(HttpContext.Current.Session[Constants.ProjectId]);

            using (CBI_Anes_HighEntities _context = new CBI_Anes_HighEntities())
            {
                DateTime fromDos = Convert.ToDateTime(fromDate);
                DateTime toDos = Convert.ToDateTime(toDate);

                //if (projectId == 17)
                //{
                    // var data = (from I in _context.tbl_IMPORT_TABLE where I.PROJECT_ID == projectId && I.DOS >= fromDos && I.DOS <= toDos select new SelectListItem { Text = I.BATCH_NAME, Value = I.BATCH_NAME.ToString() }).Distinct().ToList();
                    var data = (from I in _context.tbl_IMPORT_TABLE
                                join t in _context.tbl_TRANSACTION on I.BATCH_ID equals t.BATCH_ID


                                where I.PROJECT_ID == projectId && t.CODED_DATE >= fromDos && t.CODED_DATE <= toDos
                                select new SelectListItem { Text = I.BATCH_NAME, Value = I.BATCH_NAME.ToString() }).Distinct().ToList();

                    var uniqueItems = data.GroupBy(s => s.Value, i => i, (k, item) => new SelectListItem
                    {
                        Text = item.First().Text.Substring(0,2)=="CB"?item.First().Text.Substring(8,4):item.First().Text.Substring(7,4),
                        Value = k.Substring(0,2)=="CB"?k.Substring(8,4):k.Substring(7,4),

                    }).GroupBy(p => p.Text).Select(g => g.First()).ToList();
                    return uniqueItems;
                //}
                //else
                //{
                //    var data = (from I in _context.tbl_IMPORT_TABLE where I.PROJECT_ID == projectId && I.RECEIVED_DATE >= fromDos && I.RECEIVED_DATE <= toDos select new SelectListItem { Text = I.BATCH_NAME, Value = I.BATCH_NAME.ToString() }).Distinct().ToList();

                //    var uniqueItems = data.GroupBy(s => s.Value, i => i, (k, item) => new SelectListItem
                //    {
                //        Text = item.First().Text,
                //        Value = k,

                //    }).ToList();
                //    return uniqueItems;

                //}

            }

        }

        public List<SelectListItem> GetBatchNames(string fromDate, string toDate)
        {
            int projectId = Convert.ToInt32(HttpContext.Current.Session[Constants.ProjectId]);

            using (CBI_Anes_HighEntities _context = new CBI_Anes_HighEntities())
            {
                DateTime fromDos = Convert.ToDateTime(fromDate);
                DateTime toDos = Convert.ToDateTime(toDate);
                toDos = toDos.AddDays(1);

                if (taskid == 115)
                {
                   // var data = (from I in _context.tbl_IMPORT_TABLE where I.PROJECT_ID == projectId && I.DOS >= fromDos && I.DOS <= toDos select new SelectListItem { Text = I.BATCH_NAME, Value = I.BATCH_NAME.ToString() }).Distinct().ToList();
                    var data = (from I in _context.tbl_IMPORT_TABLE
                                join t in _context.tbl_TRANSACTION on I.BATCH_ID equals t.BATCH_ID


                                where I.PROJECT_ID == projectId && t.CODED_DATE >= fromDos && t.CODED_DATE <= toDos
                                select new SelectListItem { Text = I.BATCH_NAME, Value = I.BATCH_NAME.ToString() }).Distinct().ToList();

                    var uniqueItems = data.GroupBy(s => s.Value, i => i, (k, item) => new SelectListItem
                    {
                        Text = item.First().Text,
                        Value = k,

                    }).ToList();
                    return uniqueItems;
                }
                else
                {
                    var data = (from I in _context.tbl_IMPORT_TABLE
                                join t in _context.tbl_TRANSACTION on I.BATCH_ID equals t.BATCH_ID
                                where I.PROJECT_ID == projectId && t.QC_DATE >= fromDos && t.QC_DATE <= toDos select new SelectListItem { Text = I.BATCH_NAME, Value = I.BATCH_NAME.ToString() }).Distinct().ToList();

                    var uniqueItems = data.GroupBy(s => s.Value, i => i, (k, item) => new SelectListItem
                    {
                        Text =CryptoGraphy.Decrypt(item.First().Text),
                        Value =CryptoGraphy.Decrypt(k),

                    }).ToList();
                    return uniqueItems;

                }
            }
        }

        public List<SelectListItem> GetBatches(string fromDate, string toDate)
        {
            int projectId = Convert.ToInt32(HttpContext.Current.Session[Constants.ProjectId]);

            using (CBI_Anes_HighEntities _context = new CBI_Anes_HighEntities())
            {
                DateTime fromDos = Convert.ToDateTime(fromDate);
                DateTime toDos = Convert.ToDateTime(toDate);
                toDos = toDos.AddDays(1);

                    var data = (from I in _context.tbl_IMPORT_TABLE
                                where I.PROJECT_ID == projectId && I.ALLOTTED_DATE >= fromDos && I.ALLOTTED_DATE <= toDos
                                select new SelectListItem { Text = I.BATCH_NAME, Value = I.BATCH_NAME.ToString() }).Distinct().ToList();

                    var uniqueItems = data.GroupBy(s => s.Value, i => i, (k, item) => new SelectListItem
                    {
                        Text = CryptoGraphy.Decrypt(item.First().Text),
                        Value = k,
                    }).ToList();
                    return uniqueItems;
            }
        }

        public List<SelectListItem> GetBatchName1(string Facility)
        {
            int projectId = Convert.ToInt32(HttpContext.Current.Session[Constants.ProjectId]);

            using (CBI_Anes_HighEntities _context = new CBI_Anes_HighEntities())
            {

                var data = (from I in _context.tbl_IMPORT_TABLE where I.PROJECT_ID == projectId && I.FACILITY == Facility select new SelectListItem { Text = I.BATCH_NAME, Value = I.BATCH_NAME.ToString() }).Distinct().ToList();
                var uniqueItems = data.GroupBy(s => s.Value, i => i, (k, item) => new SelectListItem
                {
                    Text = item.First().Text,
                    Value = k,

                }).ToList();
                return uniqueItems;
            }
        }

        public List<SelectListItem> GetCodingStatus()
        {
               ReportsViewModel model = GetReportDetails("Coding_Production_Report");
            int projectId = Convert.ToInt32(model.ProjectId);
            int taskId = Convert.ToInt32(model.TaskId);
          
            using (CBI_Anes_HighEntities _context = new CBI_Anes_HighEntities())
            {
                return (from SM in _context.tbl_STATUS_MASTER where SM.PROJECT_ID == projectId && SM.TASK_ID == taskId select new SelectListItem { Text = SM.STATUS_TYPE, Value = SM.STATUS_ID.ToString() }).ToList();
            }
        }

        public List<SelectListItem> GetCoderNames()
        {
            ReportsViewModel model = GetReportDetails("QC_Production_Report");
            int projectId = Convert.ToInt32(model.ProjectId);
            // int taskId = Convert.ToInt32(model.TaskId);

            using (CBI_Anes_HighEntities _context = new CBI_Anes_HighEntities())
            {
                return (from UA in _context.tbl_USER_ACCESS where UA.PROJECT_ID == projectId select new SelectListItem { Text = UA.USER_NAME, Value = UA.USER_NTLG }).ToList();
            }
        }

        public List<SelectListItem> GetStatusForQC()
        {
            ReportsViewModel model = GetReportDetails("QC_Production_Report");
            int projectId = Convert.ToInt32(model.ProjectId);
            int taskId = Convert.ToInt32(model.TaskId);

            using (CBI_Anes_HighEntities _context = new CBI_Anes_HighEntities())
            {
                return (from SM in _context.tbl_STATUS_MASTER where SM.PROJECT_ID == projectId && SM.TASK_ID == taskId select new SelectListItem { Text = SM.STATUS_TYPE, Value = SM.STATUS_TYPE }).ToList();
            }
        }

        public List<SelectListItem> GetLocation()
        {
            ReportsViewModel model = GetReportDetails("Coding_Production_Report");
            int projectId = Convert.ToInt32(model.ProjectId);
            int taskId = Convert.ToInt32(model.TaskId);

            using (CBI_Anes_HighEntities _context = new CBI_Anes_HighEntities())
            {
                return (from L in _context.tbl_LOCATION where L.PROJECT_ID == projectId select new SelectListItem { Text = L.LOCATION, Value = L.LOCATION.ToString() }).ToList();
            }
        }

        public List<SelectListItem> GetEncounterType()
        {
            int projectId = Convert.ToInt32(HttpContext.Current.Session[Constants.ProjectId]);

            using (CBI_Anes_HighEntities _context = new CBI_Anes_HighEntities())
            {

                var data = (from I in _context.TBL_ENCOUNTER_TYPE_MASTER where I.PROJECT_ID == projectId select new SelectListItem { Text = I.ENCOUNTER_TYPE, Value = I.ENCOUNTER_TYPE.ToString() }).Distinct().ToList();
                var uniqueItems = data.GroupBy(s => s.Value, i => i, (k, item) => new SelectListItem
                {
                    Text = item.First().Text,
                    Value = k,

                }).ToList();
                return uniqueItems;
            }
        }

        #region AuditCategoryList
        public List<SelectListItem> AuditCategoryList()
        {
            List<SelectListItem> listItems = new List<SelectListItem>();
            listItems.Add(new SelectListItem { Text = "Regular Audit", Value = "Regular Audit" });
            listItems.Add(new SelectListItem { Text = "Incremental HCC", Value = "Incremental HCC" });
            listItems.Add(new SelectListItem { Text = "Blind Code Audit", Value = "Blind Code Audit" });


            return listItems;
        }
        #endregion

        #region Get Production Details (Paremeter)

        public DataTable GetProductionReportDetails(string fromDos, string toDos, string batchName, string facility, string status)
        {
            int projectId = Convert.ToInt32(HttpContext.Current.Session[Constants.ProjectId]);
            DataSet dsCommon = new DataSet();
            DataSet dsReport = new DataSet();
            using (CBI_Anes_HighEntities _context = new CBI_Anes_HighEntities())
            {
                try
                {
                    dsCommon.Clear();
                    SqlConnection conObj = new SqlConnection(Constants.ConnectionString);
                    conObj.Open();
                    SqlCommand cmdObj = new SqlCommand(Constants.ProductionTransDetails, conObj);
                    cmdObj.CommandType = CommandType.StoredProcedure;
                    cmdObj.Parameters.AddWithValue("@FromDate", fromDos);
                    cmdObj.Parameters.AddWithValue("@ToDate", toDos);
                    cmdObj.Parameters.AddWithValue("@BatchName", CryptoGraphy.Encrypt(batchName));
                    cmdObj.Parameters.AddWithValue("@Facility", facility);
                    cmdObj.Parameters.AddWithValue("@CodingStatus", status);
                    cmdObj.Parameters.AddWithValue("@PROJ_ID", projectId);
                    SqlDataAdapter adapter1 = new SqlDataAdapter(cmdObj);
                    adapter1.Fill(dsCommon);
                    conObj.Close();
                    if (dsCommon.Tables[0].Rows.Count > 0)
                    {
                        SqlCommand cmdObj1 = new SqlCommand(Constants.PeriProductionReport, conObj);
                        cmdObj1.CommandType = CommandType.StoredProcedure;
                        cmdObj1.Parameters.AddWithValue("@TT", dsCommon.Tables[0]);
                        SqlDataAdapter SqlDataAdapter = new SqlDataAdapter(cmdObj1);
                        SqlDataAdapter.Fill(dsReport);
                        HttpContext.Current.Session["ProReportData"]=dsReport;
                        if (dsReport.Tables[0].Rows.Count > 0)
                        {
                            var fac = (from F in _context.tbl_FACILITY where F.PROJECT_ID == projectId && F.CODE == facility select new SelectListItem { Text = F.DESCRIPTION.ToString() }).ToList();

                            HttpContext.Current.Session["Hospital"] = fac[0].Text.Trim();

                            string encriptBatchname = CryptoGraphy.Encrypt(batchName);

                            var firstTable = (from p in dsReport.Tables[0].AsEnumerable()
                                                 select new
                                                 {
                                                    coder= p.Field<string>("Coder").ToString()
                                                 }).FirstOrDefault();

                            var secondTable = (from p in dsReport.Tables[1].AsEnumerable()
                                              select new ReportsViewModel
                                              {
                                                  BatchName=batchName.ToString(),
                                                  Facility = HttpContext.Current.Session["Hospital"].ToString(),
                                                  //Facility=facility.ToString(),
                                                  CoderNames = firstTable.coder,
                                                  CodedDate = p.Field<DateTime>("Coded_Date").ToShortDateString(),
                                                  ChartCoded = p.Field<int>("Charts Coded").ToString(),
                                                  LWBS = p.Field<int>("LWBS").ToString(),
                                                  PVTS = p.Field<int>("PVT/Void/Suture Removal/Global").ToString(),
                                                  ChartsSendBack = p.Field<int>("Charts to send back").ToString(),
                                              }).FirstOrDefault();

                            HttpContext.Current.Session["SecondTabale"] = secondTable;
                            HttpContext.Current.Session["BatchName"] = batchName;
                            var thirdTable = (from row in _context.tbl_IMPORT_TABLE
                                         where row.PROJECT_ID == projectId && row.BATCH_NAME == encriptBatchname && row.FACILITY == facility
                                         select row).Count();

                            ReportsViewModel model = new ReportsViewModel();
                            model.BatchCount = Convert.ToInt32(thirdTable);
                            model.CompletedAccounts = Convert.ToInt32(dsReport.Tables[0].Rows.Count);
                            model.PendingAcounts = Convert.ToInt32(thirdTable) - Convert.ToInt32(dsReport.Tables[0].Rows.Count);
                            HttpContext.Current.Session["ThirdTabale"] = model;

                            return dsReport.Tables[0];
                        }
                        else
                        {
                            return null;
                        }
                    }
                    else
                    {
                        return null;
                    }
                }
                catch (Exception e)
                {
                    throw e;
                }
            }
        }
        #endregion

        public List<SelectListItem> GetStatus()
        {
            ReportsViewModel model = GetReportDetails("Production_Report");
            int projectId = Convert.ToInt32(model.ProjectId);
            int taskId = Convert.ToInt32(model.TaskId);

            using (CBI_Anes_HighEntities _context = new CBI_Anes_HighEntities())
            {
                return (from SM in _context.tbl_STATUS_MASTER where SM.PROJECT_ID == projectId && SM.TASK_ID == taskId select new SelectListItem { Text = SM.STATUS_TYPE, Value = SM.STATUS_ID.ToString() }).ToList();
            }
        }

        public void GetProductionReport()
        {
            int projectId = Convert.ToInt32(HttpContext.Current.Session[Constants.ProjectId]);
            DataSet dsCommon = new DataSet();
            using (CBI_Anes_HighEntities _context = new CBI_Anes_HighEntities())
            {
                try 
	                {
                    dsCommon = HttpContext.Current.Session["ProReportData"] as DataSet;
                    if (!dsCommon.Tables[1].Columns.Contains("Hospital"))
                    {
                        dsCommon.Tables[1].Columns.Add(new DataColumn("Hospital", typeof(System.String)));
                        dsCommon.Tables[1].Columns.Add(new DataColumn("Filename", typeof(System.String)));
                        dsCommon.Tables[1].Columns.Add(new DataColumn("Coder Name", typeof(System.String)));
                        dsCommon.Tables[1].Columns.Add(new DataColumn("Coded Date", typeof(System.String)));
                        foreach (DataRow d in dsCommon.Tables[1].Rows)
                        {
                            d["Hospital"] = HttpContext.Current.Session["Hospital"];
                            d["Filename"] = HttpContext.Current.Session["BatchName"];
                            d["Coder Name"] = dsCommon.Tables[0].Rows[0][43];
                            d["Coded Date"] = dsCommon.Tables[0].Rows[0][44];
                        }    
                    }

                    DataTable dtAll = new DataTable();
                    dtAll = dsCommon.Tables[0].Copy();
                    dtAll.Merge(dsCommon.Tables[1]);
                    HttpContext.Current.Response.ClearContent();
                    HttpContext.Current.Response.AddHeader("content-disposition", "attachment;filename=ProductionReport.csv");
                    HttpContext.Current.Response.ContentType = "text/csv";    
                    StringWriter activityStringWriter = new StringWriter();
                    activityStringWriter.WriteLine("\"DOS\",\"Account #\",\"Attending Physician\",\"NP/PA\",\"Scribe\",\"Resident\",\"D/C Status\",\"CPT1\",\"ICD-9 1\",\"ICD-9 2\",\"ICD-9 3\",\"ICD-9 4\",\"ICD-10 1\",\"ICD-10 2\",\"ICD-10 3\",\"ICD-10 4\",\"CPT 2\",\"ICD-9\",\"ICD-10\",\"CPT 3\",\"ICD-9\",\"ICD-10\",\"CPT 4\",\"ICD-9\",\"ICD-10\",\"CPT 5\",\"ICD-9\",\"ICD-10\",\"CPT 6\",\"ICD-9\",\"ICD-10\",\"CPT 7\",\"ICD-9\",\"ICD-10\",\"CPT 8\",\"ICD-9\",\"ICD-10\",\"DownCoded FROM\",\"HPI\",\"ROS\",\"PFSH\",\"EXAM\",\"Comments\",\"Charts Coded\",\"LWBS\",\"PVT/Void/Suture Removal/Global\",\"Charts to send back\",\"Hospital\",\"Filename\",\"Coder\",\"Coded Date\"");
                    foreach (DataRow DRow in dtAll.Rows)
                    {
                        activityStringWriter.WriteLine(string.Format("\"{0}\",\"{1}\",\"{2}\",\"{3}\",\"{4}\",\"{5}\",\"{6}\",\"{7}\",\"{8}\",\"{9}\",\"{10}\",\"{11}\",\"{12}\",\"{13}\",\"{14}\",\"{15}\",\"{16}\",\"{17}\",\"{18}\",\"{19}\",\"{20}\",\"{21}\",\"{22}\",\"{23}\",\"{24}\",\"{25}\",\"{26}\",\"{27}\",\"{28}\",\"{29}\",\"{30}\",\"{31}\",\"{32}\",\"{33}\",\"{34}\",\"{35}\",\"{36}\",\"{37}\",\"{38}\",\"{39}\",\"{40}\",\"{41}\",\"{42}\",\"{43}\",\"{44}\",\"{45}\",\"{46}\",\"{47}\",\"{48}\",\"{49}\",\"{50}\"",
                        DRow[1].ToString(), CryptoGraphy.Decrypt(DRow[2].ToString()), DRow[3].ToString(), DRow[4].ToString(), DRow[5].ToString(), DRow[6].ToString(), DRow[7].ToString(), DRow[8].ToString(), DRow[9].ToString(), DRow[10].ToString(), DRow[11].ToString(), DRow[12].ToString(), DRow[13].ToString(), DRow[14].ToString(), DRow[15].ToString(), DRow[16].ToString(), DRow[17].ToString(), DRow[18].ToString(), DRow[19].ToString(), DRow[20].ToString(), DRow[21].ToString(), DRow[22].ToString(),
                        DRow[23].ToString(), DRow[24].ToString(), DRow[25].ToString(), DRow[26].ToString(), DRow[27].ToString(), DRow[28].ToString(), DRow[29].ToString(), DRow[30].ToString(), DRow[31].ToString(), DRow[32].ToString(), DRow[33].ToString(), DRow[34].ToString(), DRow[35].ToString(), DRow[36].ToString(), DRow[37].ToString(), DRow[38].ToString(), DRow[39].ToString(), DRow[40].ToString(), DRow[41].ToString(), DRow[42].ToString(), DRow[45].ToString(), DRow[46].ToString(), DRow[47].ToString(), DRow[48].ToString(), DRow[49].ToString(), DRow[50].ToString(), DRow[51].ToString(), DRow[52].ToString(), DRow[53].ToString()));
                    }
                    HttpContext.Current.Response.Write(activityStringWriter.ToString());
                    HttpContext.Current.Response.End();
                }
                catch (Exception e)
                {   
                    throw e;
                }
            }
        }
    }
}
