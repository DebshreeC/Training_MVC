﻿using CBIplus.BAL.ViewModels;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.Mvc;

namespace CBIplus.BAL.Managers
{
    public interface IHighMarkCoderTransactionService
    {
        List<HighMarkCoderTransactionModel> HighMarkCoderInbox(string selecetedText);

        List<SelectListItem> GetEncounterType();
        HighMarkCoderTransactionModel HighMarkCoderTransaction();
        HighMarkCoderTransactionModel HighMarkCoderTransaction(string whoCorrected);
        List<HighMarkCoderTransactionModel> LoadDXGrid(int batchId);
        void SaveHighMarkCoderTransaction(HighMarkCoderTransactionModel model, string eodList, string screeenName);
        List<HighMarkCoderTransactionModel> GetTrackingGridData();
        void SaveFinalStatus(int batchId, string status, string coderComment, string Gender, int totalPages);
        void DeleteDXRow(int transDetailsId, string screenName);
        void UpdateTrackingGridData(HighMarkCoderTransactionModel model);

        void UpdateQCAck(string TID);
        string UpdateQCAckByICD(string TID, string screenName);

        List<HighMarkCoderTransactionModel> CheckDXCode(string dxvalue, string dxTp, string memberDOB, string endingDOS);
        List<HighMarkCoderTransactionModel> GetTrackingGridDataBytrackingID(string trackingID);

        string CheckDuplicateRecords(string Beginning_DOS, string Ending_DOS, string Dx_Type, string DXCode, string PageNo, int Batch_Id);

        //Qc Feed Back Section

        QCFeedBackModel QCFeedBack();
        List<SelectListItem> GetQCStatusList();
        DataTable QCFeedBackGrid(string status);

        //QC Clarification

        DataTable QCClarificationGrid();
        QCFeedBackModel GetOldComment(int transId);
        string SaveComment(QCFeedBackModel model, string screenName);
        void SaveQcClarification(List<QCClarificationModel> model);
        void SaveQcAcknowledge(List<QCClarificationModel> model);

        string CheckErrorAccounts();
        List<QCFeedBackModel> GetErrorDetails(string transId);
        string SaveQCFeedbackDetails(string transId);

        DataTable QCClarificationAccounts();
        List<HighMarkCoderTransactionModel> ClarificationDXGrid(int trackingId);
        void SaveQCClarificationDetails(string transId);
        HighMarkCoderTransactionModel QCClarificationTransaction(string transId, string AccNo, string FName, string Lname, string MemberDOB, string MemberGender, string EncounterType, string CodedBy, string PDFpath);
        string ICDCodeValidation(string dxCode, string EndingDOS, int batchId, string buttonName, int transDetailsID);
    }
}
