﻿using CBIplus.BAL.ViewModels;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.Mvc;

namespace CBIplus.BAL.Managers
{
    public interface IMedDataAllotmentManager
    {
        AllotmentModel All(string status = null, string facility = null, string fromDos = null, string toDos = null);
        DataTable GetAccountDetails(string status, string fromDos, string toDos, string encounterType);
        DataTable GetQCAccountDetails(string status, string fromDos, string toDos);//GetQcAccountDetailsHighMark
        DataTable GetQcAccountDetailsHighMark(string status, string fromDos, string toDos, string auditType, string encounterType);
        void AllotToCoder(AllotmentModel model, string listOfAccounts);
        void SubmitAllotment(AllotmentModel model, string listOfAccounts);
        void Reassign(AllotmentModel model, string listOfAccounts);
        void AllotToQC(AllotmentModel model, string listOfAccounts);
        void SubmitQCAllotment(AllotmentModel model, string listOfAccounts, string auditType = null);
        //List<AllotmentModel> GetQCAccountDetails(string status, string fromDos, string toDos);
        List<SelectListItem> getStatusNames(string taskName);
        List<SelectListItem> getCoderNames(string tl, string user,string location);

        //Auto allotment-- by subhaja 23/05/2017
        int availableCount(string encounter, string batch, string loc);
        List<SelectListItem> getTLNames(string location);
        List<SelectListItem> getBatchNamesBULK(string location, string fromDate, string toDate);
        string AllotToCoderBulk(AllotmentModel model, string listOfCoders, int ToBeAllocateCount, string location, int NOOFUSERS, string ENCOUNTERTYPE, string BATCHNAME);
        //Auto allotment-- by subhaja 23/05/2017

        DataTable ReleaseScreenData(string fromDate, string toDate, int Auditstatus);
        DataTable ReleaseGridWithBatchName(string fromDate, string toDate,string batchName, int Auditstatus);
        void ReleaseAccounts(List<ReleaseAccountModel> model);
        DataTable BatchWiseFilterAccounts(string batchName,string status);
        DataTable EncounterTypeWiseFilterAccounts(string status, string encounterType);
        void GetAllotmentDetails();
        void GetQCAllotmentDetails();
        string QCSkip(AllotmentModel model, string listOfAccounts);

        //Auto allotment-- by subhaja 23/05/2017
        List<SelectListItem> GetCoderforSelectedTL(string tl, string location);
        List<SelectListItem> GetCoderforSelectedTL(string tl, string location,string access_type);
        //Auto allotment-- by subhaja 23/05/2017

        //Added by DebshreeC
        void ChangeCoderAccess(string NoofCoder, string location, string access_type);
        void SendBackAccountQC2CODER(string selectedAccounts);
        //Added by DebshreeC

    }
}
