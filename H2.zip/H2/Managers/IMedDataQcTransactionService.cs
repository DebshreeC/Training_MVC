﻿using CBIplus.BAL.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.Mvc;

namespace CBIplus.BAL.Managers
{
   public interface IMedDataQcTransactionService
    {
       MedDataQcTransactionModel GetQcTransactionDetails();
       List<MedDataQcTransactionModel> GetCodedData();
       void QCAddNewCPT(MedDataQcTransactionModel model);
       MedDataQcTransactionModel All(int transDetailsId = 0);
       List<SelectListItem> GetErrorSubCategory(string errorType);
       List<MedDataQcTransactionModel> GetCPTGridData(int transId, string accountNumber);
       void UpdateAccountDetails(MedDataQcTransactionModel model);

       void FinalQcSubmit(List<MedDataQcTransactionModel> model, string selectedAccounts);
       void DeleteCPT(int transDetailsId);
       List<SelectListItem> GetPhysacalStatus();
       List<SelectListItem> GetStartTimeDropdown();
       List<SelectListItem> GetEndTimeDropdown();
    }
}
