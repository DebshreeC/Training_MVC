﻿using Microsoft.Win32.SafeHandles;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using CBIplus.BAL.Managers;
using CBIplus.BAL.ViewModels;
using CBIplus.DAL;
using System.Web.Mvc;
using System.Web;
using CBIplus.BAL.Generics;

namespace CBIplus.BAL.Managers
{
    public class PeriMeterMasterManager : IPeriMeterMasterService
    {
       

        #region Get Facility Names
        public List<SelectListItem> GetFacilityNames()
        {
            using (CBI_Anes_HighEntities _context = new CBI_Anes_HighEntities())
            {
                int projectId = Convert.ToInt32(HttpContext.Current.Session[Constants.ProjectId]);

                var list = (from facility in _context.tbl_FACILITY
                            where facility.PROJECT_ID == projectId
                            select new SelectListItem
                            {
                                Text = facility.DESCRIPTION,
                                Value = facility.CODE.ToString()
                            }).ToList();
                return list;
            }
        }
        #endregion

        #region Save Master Data

        public void SaveMasterData(PerimeterMasterModel MasterModel)
        {
            int projectId = Convert.ToInt32(HttpContext.Current.Session[Constants.ProjectId]);
            using (CBI_Anes_HighEntities _context = new CBI_Anes_HighEntities())
            {
                switch (MasterModel.MasterDropdownValue)
                {
                    case "Facility":

                        tbl_FACILITY facility = new tbl_FACILITY();
                        facility.CODE = MasterModel.Code;
                        facility.DESCRIPTION = MasterModel.Description;
                        facility.PROJECT_ID = projectId;
                        facility.CLIENT_LOCATION = "";
                        facility.IS_DELETED = "N";
                        _context.tbl_FACILITY.Add(facility);
                        break;

                    case "NPPA":

                        tbl_NP_PA_MASTER nppa = new tbl_NP_PA_MASTER();
                        nppa.NP_PA_NAME = MasterModel.NPPAName;
                        nppa.NP_PA_CODE = MasterModel.NPPACode;
                        nppa.FACILITY_CODE = MasterModel.NPPAFacility;
                        nppa.PROJECT_ID = projectId;
                        _context.tbl_NP_PA_MASTER.Add(nppa);
                        break;

                    case "Attending Phy":

                        tbl_ATTENDING_PHYSICIAN_MASTER attendingPhy = new tbl_ATTENDING_PHYSICIAN_MASTER();
                        attendingPhy.PROJECT_ID = projectId;
                        attendingPhy.FACILITY_CODE = MasterModel.attFacility;
                        attendingPhy.PHYSICIAN_NAME = MasterModel.PhysicianName;
                        attendingPhy.PHYSICIAN_ID = MasterModel.PhysicianID;
                        _context.tbl_ATTENDING_PHYSICIAN_MASTER.Add(attendingPhy);
                        break;

                    case "Comments":

                        tbl_COMMENT_MASTER comment = new tbl_COMMENT_MASTER();
                        comment.PROJECT_ID = Convert.ToString(projectId);
                        comment.COMMENT_NAME = MasterModel.Comment.ToString();
                        _context.tbl_COMMENT_MASTER.Add(comment);
                        break;

                    case "CPT":

                        tbl_CPT1_MASTER cpt = new tbl_CPT1_MASTER();
                        cpt.PROJECT_ID = projectId;
                        cpt.CPT1 = MasterModel.addCPT;
                        cpt.CPT1_NAME = MasterModel.CPTName;
                        _context.tbl_CPT1_MASTER.Add(cpt);
                        break;

                    case "Disposition":

                        tbl_DISPOSITION_MASTER disposition = new tbl_DISPOSITION_MASTER();
                        disposition.DISPOSITION = MasterModel.Disposition;
                        _context.tbl_DISPOSITION_MASTER.Add(disposition);
                        break;

                    case "DownCoding":

                        tbl_DOWN_CODING_MASTER downCoding = new tbl_DOWN_CODING_MASTER();
                        downCoding.DESCRIPTION = MasterModel.DownCodedFrom;
                        _context.tbl_DOWN_CODING_MASTER.Add(downCoding);
                        break;
                    case "Error Category":

                        tbl_ERROR_CATEGORY errorCategory = new tbl_ERROR_CATEGORY();
                        errorCategory.PROJECT_ID = projectId;
                        errorCategory.ERROR_CATEGORY = MasterModel.ErrorCategory;
                        errorCategory.SUB_CATEGORY1 = MasterModel.ErrorCategory;
                        _context.tbl_ERROR_CATEGORY.Add(errorCategory);
                        break;

                    case "Modifier":

                        tbl_MODIFIER_MASTER modifier = new tbl_MODIFIER_MASTER();
                        modifier.MODIFIERS = MasterModel.Mod;
                        modifier.PROJECT_ID = projectId;
                        _context.tbl_MODIFIER_MASTER.Add(modifier);
                        break;

                    case "Other CPT":

                        tbl_OTHER_CPT_MASTER otherCPT = new tbl_OTHER_CPT_MASTER();
                        otherCPT.PROJECT_ID = projectId;
                        otherCPT.OCPT = MasterModel.OtherCPTT;
                        otherCPT.OCPT_NAME = MasterModel.OtherCPTName;
                        _context.tbl_OTHER_CPT_MASTER.Add(otherCPT);
                        break;

                    case "Scribe":

                        tbl_SCRIBE_MASTER scribe = new tbl_SCRIBE_MASTER();
                        scribe.PROJECT_ID = projectId;
                        scribe.SCRIBE_ID = MasterModel.ScribeID;
                        scribe.SCRIBE_NAME = MasterModel.Scribee;
                        scribe.FACILITY_CODE = MasterModel.ScribeFacility;
                        _context.tbl_SCRIBE_MASTER.Add(scribe);
                        break;

                    default:
                        break;
                }
                _context.SaveChanges();
            }
        }

        #endregion
    }
}
