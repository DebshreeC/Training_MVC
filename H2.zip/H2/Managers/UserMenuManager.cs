﻿
#region Includes
using CBIplus.BAL.Generics;
using CBIplus.BAL.ViewModels;
using CBIplus.DAL;
using Microsoft.Win32.SafeHandles;
using System;
using System.Collections.Generic;
using System.Data;
//using System.Data.Entity;
using System.Data.Entity.Validation;
using System.Data.SqlClient;
using System.Globalization;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
//using System.Threading.Tasks;
using System.Web;
using System.Web.Mvc;
using System.Web.Routing;
using System.Data.Entity;
using System.Data.Entity.SqlServer;
using System.Data.Entity.Core.Objects;
#endregion

namespace CBIplus.BAL.Managers
{
    public class UserMenuManager : IUserMenuService
    {
        UserMenuModel model = new UserMenuModel();
        int Practice_ID = Convert.ToInt32(HttpContext.Current.Session[Constants.PracticeID]);
        
        #region GetUserMenu
        public void GetSideMenu()
        {
            //HttpContext.Current.Session["PracID"] = Practice_ID;
            using (CBI_Anes_HighEntities _context = new CBI_Anes_HighEntities())
            {
                string menuName = string.Empty;
                string subMenu = string.Empty;
                string oldMenuName = string.Empty;
                string menuDiv = string.Empty;

                int count = 0;
                int menuCount = 0;
                var httpContext = new HttpContextWrapper(System.Web.HttpContext.Current);
                var menuList = _context.SP_Get_Menu_Details(HttpContext.Current.Session[Constants.UserName].ToString(), HttpContext.Current.Session[Constants.ProjectId].ToString(),HttpContext.Current.Session[Constants.PracticeID].ToString()).ToList();
                var urlHelper = new UrlHelper(new RequestContext(httpContext, new RouteData()));
                for (int i = 0; i < menuList.Count; i++)
                {
                    string url = string.Empty;
                    menuName = menuList[i].MENU_NAME;
                    if (menuList[i].URL.ToString().Contains("/"))
                    {
                        string[] arry = menuList[i].URL.Split('/'); ;
                        url = urlHelper.Action(arry[1], arry[0], new RouteValueDictionary());
                    }
                    if (count == 0)
                    {
                        menuCount = menuList.Where(x => x.MENU_NAME == menuName).Select(x => x.MENU_NAME).Count();
                        menuDiv += "<li>";
                    }
                    subMenu = menuList[i].SUB_MENU_NAME;
                    if (menuName != oldMenuName)
                    {
                        count = menuCount;
                        menuDiv += "<a><i class='" + GetFontIcons("Font" + menuName.Replace(" ", string.Empty)) + "'></i>" + menuName + " <span class='fa fa-chevron-down'></span></a>";
                        menuDiv += "<ul class='nav child_menu' style='display: none'>";
                    }
                    if (subMenu != null && subMenu != string.Empty)
                    {
                        int PracticeID = Convert.ToInt32(HttpContext.Current.Session[Constants.PracticeID]);
                        if (PracticeID == 2 && subMenu == "Upload HCC")
                        {
                            
                        }
                        else
                        {
                            menuDiv += "<li><a href=" + url + ">" + subMenu + "</a></li>";
                        }
                    }
                    count = count - 1;
                    if (count == 0)
                    {
                        menuDiv += "</ul>";
                        menuDiv += "</li>";
                    }
                    oldMenuName = menuName;
                }
                HttpContext.Current.Session[Constants.UserMenu] = menuDiv;

            }

        }
        #endregion


        #region GetFontIcon

        public string GetFontIcons(string iconName)
        {
            if (iconName == "FontImport")
            {
                return Constants.FontImport;
            }
            else if (iconName == "FontTransaction")
            {
                return Constants.FontTransaction;
            }
            else if (iconName == "FontAllotment")
            {
                return Constants.FontAllotment;
            }
            else if (iconName == "FontReports")
            {
                return Constants.FontReports;
            }
            else if (iconName == "FontErrorLog")
            {
                return Constants.FontErrorLog;
            }
            else if (iconName == "FontFeedBack")
            {
                return Constants.FontFeedBack;
            }
            else if (iconName == "FontAllottment")
            {
                return Constants.Allottment;
            }
            else if (iconName == "FontClarification")
            {
                return Constants.Clarification;
            }
            else if (iconName == "FontQCTransaction")
            {
                return Constants.QCTransaction;
            }
            else if (iconName == "FontReleaseScreen")
            {
                return Constants.ReleaseScreen;
            }
            else
            {
                return string.Empty;
            }
        }
        #endregion
        #region Get Client Names
        public UserMenuModel GetClietList()
        {
            using (CBI_Anes_HighEntities _context = new CBI_Anes_HighEntities())
            {
               
                model.ClientList = (from user in _context.tbl_USER_ACCESS
                                    join project in _context.tbl_PROJECT_MASTER on user.PROJECT_ID equals project.PROJECT_ID
                                    join client in _context.tbl_CLIENT_MASTER on project.CLIENT_ID equals client.CLIENT_ID
                                    where user.USER_NTLG == System.Environment.UserName.ToString()
                                    select new SelectListItem
                                        {
                                            Text = client.CLIENT_NAME,
                                            Value = client.CLIENT_ID.ToString()
                                        }).Distinct().ToList();
                return model;
            }
        }
        #endregion

        #region Get Practice Names
        public UserMenuModel GetPractices()
        {
            using (CBI_Anes_HighEntities _context=new CBI_Anes_HighEntities())
            {
                model.PracticeList = (from p in _context.tbl_PRACTICE_MASTER
                                    where p.PROJECT_ID == 18
                                    select new SelectListItem
                                    {
                                        Text = p.PRACTICE.ToString(),
                                        Value = p.PRACTICE_ID.ToString()
                                    }).ToList();
                return model;
            }
        }
        #endregion

        #region GetPractice

        public string GetPractice(UserMenuModel model)
        {  
            using (CBI_Anes_HighEntities _context = new CBI_Anes_HighEntities())
            {
                int practiceId = Convert.ToInt32(model.SelectedPractice);
                string UserNtlg = System.Environment.UserName.ToString();
                var PracID = (from U in _context.tbl_USER_ACCESS where U.USER_NTLG == UserNtlg && U.PRACTICE_ID == practiceId select new { U.PRACTICE_ID }).FirstOrDefault();
                if (PracID!=null)
                {
                    return PracID.ToString();
                }
                else
                {
                    return "";
                }
            }
        }

        #endregion

        #region Store SessionDetails
        public void SaveSessionDetails(UserMenuModel model)
        {
            using (CBI_Anes_HighEntities _context = new CBI_Anes_HighEntities())
            {
                int clientId = Convert.ToInt32(model.SelectedClient);
                string UserNtlg = System.Environment.UserName.ToString();
                int PraID = Convert.ToInt32(model.SelectedPractice);
                var Location = (from U in _context.tbl_USER_ACCESS where U.USER_NTLG == UserNtlg && U.PRACTICE_ID == PraID select new { U.Location, U.ACCESS_TYPE }).FirstOrDefault(); ;
                var project = (from c in _context.tbl_CLIENT_MASTER
                               join p in _context.tbl_PROJECT_MASTER on c.CLIENT_ID equals p.CLIENT_ID
                               where p.CLIENT_ID == clientId
                               select new
                               {
                                   c.CLIENT_NAME,
                                   p.PROJECT_ID

                               }).FirstOrDefault();

                if (clientId > 0)
                {
                    HttpContext.Current.Session[Constants.ProjectId] = project.PROJECT_ID;
                    HttpContext.Current.Session[Constants.ClientId] = model.SelectedClient;
                    HttpContext.Current.Session[Constants.ProjectName] = project.CLIENT_NAME;
                    HttpContext.Current.Session[Constants.UserName] = System.Environment.UserName.ToString();
                    HttpContext.Current.Session[Constants.PracticeID] = model.SelectedPractice;
                    HttpContext.Current.Session[Constants.LocationName] =Location.Location;
                    HttpContext.Current.Session[Constants.AccessID] = Location.ACCESS_TYPE;
                }
                else
                {
                    HttpContext.Current.Session[Constants.ProjectId] = HttpContext.Current.Session[Constants.ProjectId];
                    HttpContext.Current.Session[Constants.ClientId] = HttpContext.Current.Session[Constants.ClientId];
                    HttpContext.Current.Session[Constants.ProjectName] = HttpContext.Current.Session[Constants.ProjectName];
                    HttpContext.Current.Session[Constants.UserName] = System.Environment.UserName.ToString();
                    HttpContext.Current.Session[Constants.PracticeID] = HttpContext.Current.Session[Constants.PracticeID];
                    HttpContext.Current.Session[Constants.LocationName] = HttpContext.Current.Session[Constants.AccessID];
                }
            }

        }
        #endregion

        #region GetUnsuccessFullUploadData
        public DataTable GetUnsuccessFullUploadData()
        {
            DataSet dsCommon = new DataSet();
            using (CBI_Anes_HighEntities _context = new CBI_Anes_HighEntities())
            {

                int projectId = Convert.ToInt32(HttpContext.Current.Session[Constants.ProjectId]);
                int practiceId = Convert.ToInt32(HttpContext.Current.Session[Constants.PracticeID]);

                CBI_Anes_HighEntities dbObj = Singleton.Instance;

                List<SqlParameter> Parameter = new List<SqlParameter>();
                dsCommon.Clear();
                Parameter.Add(new SqlParameter("@ProjectId", projectId));
                Parameter.Add(new SqlParameter("@PracticeId", practiceId));
                dsCommon = DBExtension.ExecuteDataset(dbObj.Database, Constants.SpImportData, Parameter);
                var tt = dsCommon;
                //try
                //{
                //    dsCommon.Clear();
                //    SqlConnection conObj = new SqlConnection(Constants.ConnectionString);
                //    conObj.Open();
                //    SqlCommand cmdObj = new SqlCommand(Constants.SpImportData, conObj);
                //    cmdObj.CommandType = CommandType.StoredProcedure;
                //    cmdObj.Parameters.AddWithValue("@ProjectId", projectId);
                //    cmdObj.Parameters.AddWithValue("@PracticeId", practiceId);
                //    SqlDataAdapter adapter1 = new SqlDataAdapter(cmdObj);
                //    adapter1.Fill(dsCommon);
                //    conObj.Close();
                //    var tt = dsCommon;
                //}
                //catch (Exception e)
                //{
                //    throw e;
                //}

                return dsCommon.Tables[0];
            }
        }
        #endregion

        #region InsertHCC
        public ImportModel InsertHCC(DataSet ds)
        {
            using (CBI_Anes_HighEntities _context = new CBI_Anes_HighEntities())
            {
                int projectId = Convert.ToInt32(HttpContext.Current.Session[Constants.ProjectId].ToString());
                string userName = HttpContext.Current.Session[Constants.UserName].ToString();
                ImportModel model = new ImportModel();
                model.TotalExcelCount = ds.Tables[0].Rows.Count;
                foreach (DataRow dr in ds.Tables[0].Rows)
                {
                    if (!string.IsNullOrEmpty(dr["ECI"].ToString()) && !string.IsNullOrEmpty(dr["Dx_Type"].ToString()) && !string.IsNullOrEmpty(dr["Dx_Code"].ToString()) && !string.IsNullOrEmpty(dr["HCC"].ToString()))
                    {
                        tbl_IMPORT_HCC_DXCODE_MASTER hcc = new tbl_IMPORT_HCC_DXCODE_MASTER();
                        hcc.ECI = CryptoGraphy.Encrypt(dr["ECI"].ToString());
                        hcc.DX_TYPE = Convert.ToString(dr["Dx_Type"]);
                        // hcc.DX_TYPE = dr["Dx_Type"].ToString();
                        hcc.DX_CODE = dr["Dx_Code"].ToString();
                        hcc.HCC = Convert.ToInt32(dr["HCC"]);
                        hcc.PROJECT_ID = projectId;
                        hcc.DELETE_FLAG = "N";
                        hcc.UPLOADED_BY = userName;
                        hcc.UPLOADED_DATE = DateTime.Now;
                        _context.tbl_IMPORT_HCC_DXCODE_MASTER.Add(hcc);
                        //_context.SaveChanges();
                        model.SuccessfullCount = model.SuccessfullCount + 1;
                    }
                    else
                    {
                        model.UnsuccessfullCount = model.UnsuccessfullCount + 1;
                    }
                }
                _context.SaveChanges();
                ds.Dispose();
                return model;
            }
        }
        #endregion

        #region InsertHighMark
        public ImportModel InsertHighMark(DataSet ds)
        {
            using (CBI_Anes_HighEntities _context = new CBI_Anes_HighEntities())
            {
                int projectId = Convert.ToInt32(HttpContext.Current.Session[Constants.ProjectId]);
                var locationList = _context.tbl_LOCATION.Where(x => x.PROJECT_ID == projectId).Select(x => x.LOCATION).ToList();
                int practiceId=Convert.ToInt32(HttpContext.Current.Session[Constants.PracticeID]);

                ImportModel model = new ImportModel();
                model.TotalExcelCount = ds.Tables[0].Rows.Count;
                model.UnsuccessfullCount = 0;
                model.SuccessfullCount = 0;

                foreach (DataRow dr in ds.Tables[0].Rows)
                {
                    tbl_IMPORT_TABLE tb_Import = new tbl_IMPORT_TABLE();
                    tbl_UNSUCCESSFUL_IMPORTED_TABLE tb_UnsuccessImport = new tbl_UNSUCCESSFUL_IMPORTED_TABLE();
                    StringBuilder builder = new StringBuilder();
                    string location = Convert.ToString(dr["Location"]);
                    if (string.IsNullOrEmpty(Convert.ToString(dr["Tracking_Code"])) || string.IsNullOrEmpty(Convert.ToString(dr["ECI"])) || string.IsNullOrEmpty(Convert.ToString(dr["UMI"])) || string.IsNullOrEmpty(Convert.ToString(dr["Member_First_Name"])) ||
                        string.IsNullOrEmpty(Convert.ToString(dr["Member_Last_Name"])) || (string.IsNullOrEmpty(location) && locationList.Any(x => x.Contains(location))) || string.IsNullOrEmpty(Convert.ToString(dr["Batch_Name"])) || string.IsNullOrEmpty(Convert.ToString(dr["Member_DOB"])) || string.IsNullOrEmpty(Convert.ToString(dr["Encounter_Type"])) || string.IsNullOrEmpty(Convert.ToString(dr["Scheduled_Retrieval_Date"])) || string.IsNullOrEmpty(Convert.ToString(dr["TL_Name"])) || string.IsNullOrEmpty(Convert.ToString(dr["Page_Range"])) || string.IsNullOrEmpty(Convert.ToString(dr["PDF_Path"])))
                    {
                        StringBuilder str = new StringBuilder();
                        if (!string.IsNullOrEmpty(Convert.ToString(dr["Tracking_Code"])))
                        {
                            tb_UnsuccessImport.ACCOUNT_NO = dr["Tracking_Code"].ToString();
                        }
                        else
                        {
                            tb_UnsuccessImport.ACCOUNT_NO = string.Empty;
                            str.Append("Account number is empty/");
                        }
                        if (!string.IsNullOrEmpty(Convert.ToString(dr["ECI"])))
                        {
                            tb_UnsuccessImport.ECI = Convert.ToString(dr["ECI"]);
                        }
                        else
                        {
                            tb_UnsuccessImport.ECI = string.Empty;
                            str.Append("ECI is empty/");
                        }
                        if (!string.IsNullOrEmpty(Convert.ToString(dr["UMI"])))
                        {
                            tb_UnsuccessImport.UMI = Convert.ToString(dr["UMI"]);
                        }
                        else
                        {
                            tb_UnsuccessImport.UMI = string.Empty;
                            str.Append("UMI is empty/");
                        }
                        if (!string.IsNullOrEmpty(Convert.ToString(dr["Member_First_Name"])))
                        {
                            tb_UnsuccessImport.FIRST_NAME = Convert.ToString(dr["Member_First_Name"]);
                        }
                        else
                        {
                            tb_UnsuccessImport.FIRST_NAME = string.Empty;
                            str.Append("First name is empty/");
                        }
                        if (!string.IsNullOrEmpty(Convert.ToString(dr["Member_Last_Name"])))
                        {
                            tb_UnsuccessImport.LAST_NAME = Convert.ToString(dr["Member_Last_Name"]);
                        }
                        else
                        {
                            tb_UnsuccessImport.LAST_NAME = "";
                            str.Append("Last name is empty/");
                        }
                        if (!string.IsNullOrEmpty(Convert.ToString(dr["Member_DOB"])))
                        {
                            tb_UnsuccessImport.MEMBER_DOB = Convert.ToString(dr["Member_DOB"]);
                        }
                        else
                        {
                            tb_UnsuccessImport.MEMBER_DOB = null;
                            str.Append("Member DOB is empty/");
                        }
                        if (!string.IsNullOrEmpty(Convert.ToString(dr["Encounter_Type"])))
                        {
                            tb_UnsuccessImport.ENCOUNTER_TYPE = Convert.ToString(dr["Encounter_Type"]);
                        }
                        else
                        {
                            tb_UnsuccessImport.ENCOUNTER_TYPE = string.Empty;
                            str.Append("Encounter type is empty/");
                        }
                        if (!string.IsNullOrEmpty(Convert.ToString(dr["Scheduled_Retrieval_Date"])))
                        {
                            tb_UnsuccessImport.RECEIVED_DATE = Convert.ToDateTime(dr["Scheduled_Retrieval_Date"]);
                        }
                        else
                        {
                            tb_UnsuccessImport.RECEIVED_DATE = null;
                            str.Append("Received date is empty/");
                        }
                        if (!string.IsNullOrEmpty(Convert.ToString(dr["Batch_Name"])))
                        {
                            tb_UnsuccessImport.BATCH_NAME = Convert.ToString(dr["Batch_Name"]);
                        }
                        else
                        {
                            tb_UnsuccessImport.BATCH_NAME = string.Empty;
                            str.Append("Batch name is empty/");
                        }
                        if (!string.IsNullOrEmpty(Convert.ToString(dr["Location"])))
                        {
                            tb_UnsuccessImport.LOCATION = Convert.ToString(dr["Location"]);
                        }
                        else
                        {
                            tb_UnsuccessImport.LOCATION = string.Empty;
                            str.Append("Location is empty /");
                        }
                        if (!string.IsNullOrEmpty(Convert.ToString(dr["TL_Name"])))
	                    {
		                    tb_UnsuccessImport.TL_NAME=Convert.ToString(dr["TL_Name"]);
	                    }
                        else{
                            tb_UnsuccessImport.TL_NAME=string.Empty;
                            str.Append("TL Name is empty /");
                        }
                        if (!string.IsNullOrEmpty(Convert.ToString(dr["Page_Range"])))
	                    {
		                    tb_UnsuccessImport.Total_Pages=Convert.ToString(dr["Page_Range"]);
	                    }
                        else{
                            tb_UnsuccessImport.Total_Pages=string.Empty;
                            str.Append("Page Range is empty /");
                        }
                        if (!string.IsNullOrEmpty(Convert.ToString(dr["PDF_Path"])))
	                    {
                            tb_UnsuccessImport.PDF_Path=Convert.ToString(dr["PDF_Path"]);
		                    str.Append("PDF Path is empty /");
	                    }
                        tb_UnsuccessImport.BATCH_NAME = string.Empty;
                        tb_UnsuccessImport.HIC = Convert.ToString(dr["HIC"]);
                        tb_UnsuccessImport.MEMBER_GENDER = Convert.ToString(dr["Member_Gender"]);
                        tb_UnsuccessImport.Performing_Provider_NPI = Convert.ToString(dr["Performing_Provider_NPI"]);
                        tb_UnsuccessImport.Performing_Provider_BSID = Convert.ToString(dr["Performing_Provider_BSID"]);
                        tb_UnsuccessImport.Billing_Provider_NPI = Convert.ToString(dr["Billing_Provider_NPI"]);
                        tb_UnsuccessImport.Billing_Provider_BSID = Convert.ToString(dr["Billing_Provider_BSID"]);
                        tb_UnsuccessImport.TL_NAME=Convert.ToString(dr["TL_Name"]);
                        tb_UnsuccessImport.Total_Pages=Convert.ToString(dr["Page_Range"]);
                        tb_UnsuccessImport.PDF_Path=Convert.ToString(dr["PDF_Path"]);
                        tb_UnsuccessImport.REMARKS = Convert.ToString(str).TrimEnd('/');
                        tb_UnsuccessImport.UPLOAD_BY = HttpContext.Current.Session[Constants.UserName].ToString();
                        tb_UnsuccessImport.PROJECT_ID = Convert.ToInt32(HttpContext.Current.Session[Constants.ProjectId]);
                        tb_UnsuccessImport.PRACTICE_ID = Convert.ToInt32(HttpContext.Current.Session[Constants.PracticeID]);
                        _context.tbl_UNSUCCESSFUL_IMPORTED_TABLE.Add(tb_UnsuccessImport);

                        model.UnsuccessfullCount = model.UnsuccessfullCount + 1;
                    }
                    else
                    {
                        string accountNumber = dr["Tracking_Code"].ToString();
                        //int projectId = Convert.ToInt32(HttpContext.Current.Session[Constants.ProjectId]);
                        string memberGender = Convert.ToString(dr["Member_Gender"]);
                        string eType = Convert.ToString(dr["Encounter_Type"]);
                        string PPBSID = Convert.ToString(dr["Performing_Provider_BSID"]);
                        string BPBSID = Convert.ToString(dr["Billing_Provider_BSID"]);

                        string acc = CryptoGraphy.Encrypt(accountNumber);
                        var import = _context.tbl_IMPORT_TABLE.Where(x => x.ACCOUNT_NO == acc && x.PROJECT_ID == projectId).FirstOrDefault();

                        bool aco = ((accountNumber.StartsWith("MA") || accountNumber.StartsWith("AC")) && accountNumber.Length == 11);
                        bool srd = CheckDateFormat(Convert.ToDateTime(dr["Scheduled_Retrieval_Date"]).ToString("MM/dd/yyyy"));
                        bool mdob = (Convert.ToDateTime(dr["Member_DOB"]) < DateTime.Now);
                        bool mge = (((memberGender.Any(c => c == 'M' || c == 'F') || memberGender == string.Empty) && memberGender.Length <= 1));
                        bool etype = (eType.Any(c => c == 'P' || c == 'I' || c == 'O') && eType.Length == 1);
                        bool ppbsid = (PPBSID.All(char.IsDigit) && PPBSID.Length == 9);
                        bool bpb = (BPBSID.All(char.IsDigit) && BPBSID.Length == 9);
                        bool loca = locationList.Any(x => x.Contains(location));

                        builder.Append(import != null ? "Duplicate Account" : string.Empty);
                        builder.Append(aco ? string.Empty : "Account Number not in format/");
                        builder.Append(srd ? string.Empty : "RetrivalDate not in format/");
                        builder.Append(mdob ? string.Empty : "Member DOB not in format/");
                        builder.Append(mge ? string.Empty : "Member Gender not in format/");
                        builder.Append(etype ? string.Empty : "Encounter Type not in format/");
                        builder.Append(ppbsid ? string.Empty : "Performing_Provider_BSID not in format/");
                        builder.Append(bpb ? string.Empty : "Billing_Provider_BSID not in format/");
                        builder.Append(loca ? string.Empty : "Location not belongs to this project/");


                        if (practiceId==1 && import == null && ((accountNumber.StartsWith("MA")  && accountNumber.Length == 11) && CheckDateFormat(Convert.ToDateTime(dr["Scheduled_Retrieval_Date"]).ToString("MM/dd/yyyy")) && (Convert.ToDateTime(dr["Member_DOB"]) < DateTime.Now) && (((memberGender.Any(c => c == 'M' || c == 'F') || memberGender == string.Empty) && memberGender.Length <= 1)) && (eType.Any(c => c == 'P' || c == 'I' || c == 'O') && eType.Length == 1) && (PPBSID.All(char.IsDigit) && PPBSID.Length == 9) && (BPBSID.All(char.IsDigit) && BPBSID.Length == 9)))
                        {
                            tb_Import.BATCH_NAME = CryptoGraphy.Encrypt(Convert.ToString(dr["BATCH_NAME"]));
                            tb_Import.LOCATION = Convert.ToString(dr["Location"]);
                            tb_Import.ACCOUNT_NO = CryptoGraphy.Encrypt(AddZeroAsPrefix(accountNumber, 11));
                            tb_Import.ECI = CryptoGraphy.Encrypt(Convert.ToString(dr["ECI"]));
                            tb_Import.UMI = CryptoGraphy.Encrypt(Convert.ToString(dr["UMI"]));
                            tb_Import.First_Name = CryptoGraphy.Encrypt(Convert.ToString(dr["Member_First_Name"]));
                            tb_Import.Last_Name = CryptoGraphy.Encrypt(Convert.ToString(dr["Member_Last_Name"]));
                            tb_Import.MEMBER_DOB = CryptoGraphy.Encrypt(Convert.ToString(dr["Member_DOB"]));
                            tb_Import.ENCOUNTER_TYPE = eType;
                            tb_Import.RECEIVED_DATE = Convert.ToDateTime(dr["Scheduled_Retrieval_Date"]);
                            tb_Import.HIC = CryptoGraphy.Encrypt(Convert.ToString(dr["HIC"]));
                            tb_Import.MEMBER_GENDER = string.IsNullOrEmpty(memberGender) ? CryptoGraphy.Encrypt(string.Empty) : CryptoGraphy.Encrypt(memberGender);
                            tb_Import.Performing_Provider_NPI = Convert.ToString(dr["Performing_Provider_NPI"]);
                            tb_Import.Performing_Provider_BSID = AddZeroAsPrefix(PPBSID, 9);
                            tb_Import.Billing_Provider_NPI = Convert.ToString(dr["Billing_Provider_NPI"]);
                            tb_Import.TL_NAME=Convert.ToString(dr["TL_Name"]);
                            tb_Import.Total_Pages=Convert.ToString(dr["Page_Range"]);
                            tb_Import.PDF_Path=Convert.ToString(dr["PDF_Path"]);
                            tb_Import.Billing_Provider_BSID = AddZeroAsPrefix(BPBSID, 9);
                            tb_Import.UPLOAD_DATE = DateTime.Now;
                            tb_Import.BATCH_STATUS = "Fresh";
                            tb_Import.UPLOAD_BY = HttpContext.Current.Session[Constants.UserName].ToString();
                            tb_Import.PROJECT_ID = Convert.ToInt32(HttpContext.Current.Session[Constants.ProjectId]);
                            tb_Import.PRACTICE_ID = Convert.ToInt32(HttpContext.Current.Session[Constants.PracticeID]);
                            _context.tbl_IMPORT_TABLE.Add(tb_Import);
                            model.SuccessfullCount = model.SuccessfullCount + 1;
                        }
                        else if (practiceId==2 && import == null && (((accountNumber.StartsWith("AC")|| accountNumber.StartsWith("ACA")) && accountNumber.Length == 11) && CheckDateFormat(Convert.ToDateTime(dr["Scheduled_Retrieval_Date"]).ToString("MM/dd/yyyy")) && (Convert.ToDateTime(dr["Member_DOB"]) < DateTime.Now) && (((memberGender.Any(c => c == 'M' || c == 'F') || memberGender == string.Empty) && memberGender.Length <= 1)) && (eType.Any(c => c == 'P' || c == 'I' || c == 'O') && eType.Length == 1) && (PPBSID.All(char.IsDigit) && PPBSID.Length == 9) && (BPBSID.All(char.IsDigit) && BPBSID.Length == 9)))
                        {
                            tb_Import.BATCH_NAME = CryptoGraphy.Encrypt(Convert.ToString(dr["BATCH_NAME"]));
                            tb_Import.LOCATION = Convert.ToString(dr["Location"]);
                            tb_Import.ACCOUNT_NO = CryptoGraphy.Encrypt(AddZeroAsPrefix(accountNumber, 11));
                            tb_Import.ECI = CryptoGraphy.Encrypt(Convert.ToString(dr["ECI"]));
                            tb_Import.UMI = CryptoGraphy.Encrypt(Convert.ToString(dr["UMI"]));
                            tb_Import.First_Name = CryptoGraphy.Encrypt(Convert.ToString(dr["Member_First_Name"]));
                            tb_Import.Last_Name = CryptoGraphy.Encrypt(Convert.ToString(dr["Member_Last_Name"]));
                            tb_Import.MEMBER_DOB = CryptoGraphy.Encrypt(Convert.ToString(dr["Member_DOB"]));
                            tb_Import.ENCOUNTER_TYPE = eType;
                            tb_Import.RECEIVED_DATE = Convert.ToDateTime(dr["Scheduled_Retrieval_Date"]);
                            tb_Import.HIC = CryptoGraphy.Encrypt(Convert.ToString(dr["HIC"]));
                            tb_Import.MEMBER_GENDER = string.IsNullOrEmpty(memberGender) ? CryptoGraphy.Encrypt(string.Empty) : CryptoGraphy.Encrypt(memberGender);
                            tb_Import.Performing_Provider_NPI = Convert.ToString(dr["Performing_Provider_NPI"]);
                            tb_Import.Performing_Provider_BSID = AddZeroAsPrefix(PPBSID, 9);
                            tb_Import.Billing_Provider_NPI = Convert.ToString(dr["Billing_Provider_NPI"]);
                            tb_Import.TL_NAME=Convert.ToString(dr["TL_Name"]);
                            tb_Import.Total_Pages=Convert.ToString(dr["Page_Range"]);
                            tb_Import.PDF_Path=Convert.ToString(dr["PDF_Path"]);
                            tb_Import.Billing_Provider_BSID = AddZeroAsPrefix(BPBSID, 9);
                            tb_Import.UPLOAD_DATE = DateTime.Now;
                            tb_Import.BATCH_STATUS = "Fresh";
                            tb_Import.UPLOAD_BY = HttpContext.Current.Session[Constants.UserName].ToString();
                            tb_Import.PROJECT_ID = Convert.ToInt32(HttpContext.Current.Session[Constants.ProjectId]);
                            tb_Import.PRACTICE_ID = Convert.ToInt32(HttpContext.Current.Session[Constants.PracticeID]);
                            _context.tbl_IMPORT_TABLE.Add(tb_Import);
                            model.SuccessfullCount = model.SuccessfullCount + 1;
                        }
                        else if (practiceId == 1 && accountNumber.StartsWith("MA"))
                        {
                            tbl_UNSUCCESSFUL_IMPORTED_TABLE duplicate = new tbl_UNSUCCESSFUL_IMPORTED_TABLE();
                            duplicate.ACCOUNT_NO = dr["Tracking_Code"].ToString();
                            duplicate.ECI = Convert.ToString(dr["ECI"]);
                            duplicate.UMI = Convert.ToString(dr["UMI"]);
                            duplicate.FIRST_NAME = Convert.ToString(dr["Member_First_Name"]);
                            duplicate.LAST_NAME = Convert.ToString(dr["Member_Last_Name"]);
                            duplicate.MEMBER_DOB = Convert.ToString(dr["Member_DOB"]);
                            duplicate.ENCOUNTER_TYPE = Convert.ToString(dr["Encounter_Type"]);
                            duplicate.RECEIVED_DATE = Convert.ToDateTime(dr["Scheduled_Retrieval_Date"]);
                            duplicate.BATCH_NAME = Convert.ToString(dr["BATCH_NAME"]);
                            duplicate.LOCATION = Convert.ToString(dr["Location"]);
                            duplicate.HIC = Convert.ToString(dr["HIC"]);
                            duplicate.MEMBER_GENDER = Convert.ToString(dr["Member_Gender"]);
                            duplicate.Performing_Provider_NPI = Convert.ToString(dr["Performing_Provider_NPI"]);
                            duplicate.Performing_Provider_BSID = Convert.ToString(dr["Performing_Provider_BSID"]);
                            duplicate.Billing_Provider_NPI = Convert.ToString(dr["Billing_Provider_NPI"]);
                            duplicate.Billing_Provider_BSID = Convert.ToString(dr["Billing_Provider_BSID"]);
                            duplicate.REMARKS = builder.ToString().TrimEnd('/');
                            duplicate.UPLOAD_BY = HttpContext.Current.Session[Constants.UserName].ToString();
                            duplicate.PROJECT_ID = Convert.ToInt32(HttpContext.Current.Session[Constants.ProjectId]);
                            duplicate.PRACTICE_ID = Convert.ToInt32(HttpContext.Current.Session[Constants.PracticeID]);
                            _context.tbl_UNSUCCESSFUL_IMPORTED_TABLE.Add(duplicate);
                            model.UnsuccessfullCount = model.UnsuccessfullCount + 1;
                        }
                        else if (practiceId == 2 && (accountNumber.StartsWith("AC") || accountNumber.StartsWith("ACA")))
                        {
                            tbl_UNSUCCESSFUL_IMPORTED_TABLE duplicate = new tbl_UNSUCCESSFUL_IMPORTED_TABLE();
                            duplicate.ACCOUNT_NO = dr["Tracking_Code"].ToString();
                            duplicate.ECI = Convert.ToString(dr["ECI"]);
                            duplicate.UMI = Convert.ToString(dr["UMI"]);
                            duplicate.FIRST_NAME = Convert.ToString(dr["Member_First_Name"]);
                            duplicate.LAST_NAME = Convert.ToString(dr["Member_Last_Name"]);
                            duplicate.MEMBER_DOB = Convert.ToString(dr["Member_DOB"]);
                            duplicate.ENCOUNTER_TYPE = Convert.ToString(dr["Encounter_Type"]);
                            duplicate.RECEIVED_DATE = Convert.ToDateTime(dr["Scheduled_Retrieval_Date"]);
                            duplicate.BATCH_NAME = Convert.ToString(dr["BATCH_NAME"]);
                            duplicate.LOCATION = Convert.ToString(dr["Location"]);
                            duplicate.HIC = Convert.ToString(dr["HIC"]);
                            duplicate.MEMBER_GENDER = Convert.ToString(dr["Member_Gender"]);
                            duplicate.Performing_Provider_NPI = Convert.ToString(dr["Performing_Provider_NPI"]);
                            duplicate.Performing_Provider_BSID = Convert.ToString(dr["Performing_Provider_BSID"]);
                            duplicate.Billing_Provider_NPI = Convert.ToString(dr["Billing_Provider_NPI"]);
                            duplicate.Billing_Provider_BSID = Convert.ToString(dr["Billing_Provider_BSID"]);
                            duplicate.REMARKS = builder.ToString().TrimEnd('/');
                            duplicate.UPLOAD_BY = HttpContext.Current.Session[Constants.UserName].ToString();
                            duplicate.PROJECT_ID = Convert.ToInt32(HttpContext.Current.Session[Constants.ProjectId]);
                            duplicate.PRACTICE_ID = Convert.ToInt32(HttpContext.Current.Session[Constants.PracticeID]);
                            _context.tbl_UNSUCCESSFUL_IMPORTED_TABLE.Add(duplicate);
                            model.UnsuccessfullCount = model.UnsuccessfullCount + 1;
                        }
                    }
                }
                _context.SaveChanges();
                return model;

            }
        }

        #endregion

        #region InsertMedData
        public ImportModel InsertMedData(DataSet ds)
        {

            ImportModel model = new ImportModel();
            model.TotalExcelCount = ds.Tables[0].Rows.Count;
            model.UnsuccessfullCount = 0;
            model.SuccessfullCount = 0;

            using (CBI_Anes_HighEntities _context = new CBI_Anes_HighEntities())
            {
                int projectId = Convert.ToInt32(HttpContext.Current.Session[Constants.ProjectId].ToString());
                var locationList = _context.tbl_LOCATION.Where(x => x.PROJECT_ID == projectId).Select(x => x.LOCATION).ToList();

                foreach (DataRow dr in ds.Tables[0].Rows)
                {
                    tbl_IMPORT_TABLE tb_Import = new tbl_IMPORT_TABLE();
                    tbl_UNSUCCESSFUL_IMPORTED_TABLE tb_UnsuccessImport = new tbl_UNSUCCESSFUL_IMPORTED_TABLE();
                    StringBuilder builder = new StringBuilder();
                    string location = Convert.ToString(dr[Constants.Location]);
                    if (string.IsNullOrEmpty(Convert.ToString(dr[Constants.JobName])) || string.IsNullOrEmpty(Convert.ToString(dr[Constants.DateImage])) || string.IsNullOrEmpty(Convert.ToString(dr[Constants.PageCount]))
                         || string.IsNullOrEmpty(Convert.ToString(dr[Constants.DateImage])) || string.IsNullOrEmpty(Convert.ToString(dr[Constants.Description])) || string.IsNullOrEmpty(Convert.ToString(dr[Constants.BatchNo])) ||
                        (string.IsNullOrEmpty(location) && locationList.Any(x => x.Contains(location))))
                    {
                        StringBuilder str = new StringBuilder();
                        if (!string.IsNullOrEmpty(Convert.ToString(dr[Constants.JobName])))
                        {
                            tb_UnsuccessImport.JOB_NAME = dr[Constants.JobName].ToString();
                        }
                        else
                        {
                            tb_UnsuccessImport.JOB_NAME = "";
                            str.Append("Job name is empty /");
                        }
                        if (!string.IsNullOrEmpty(Convert.ToString(dr[Constants.DateImage])))
                        {
                            tb_UnsuccessImport.DOS = Convert.ToDateTime(dr[Constants.DateImage]);
                        }
                        else
                        {
                            tb_UnsuccessImport.DOS = null;
                            str.Append("DOS is empty /");
                        }
                        if (!string.IsNullOrEmpty(Convert.ToString(dr[Constants.PageCount])))
                        {
                            tb_UnsuccessImport.PAGE_COUNT = Convert.ToInt32(dr[Constants.PageCount]);
                        }
                        else
                        {
                            tb_UnsuccessImport.PAGE_COUNT = 0;
                            str.Append("Page count is empty /");
                        }
                        if (!string.IsNullOrEmpty(Convert.ToString(dr[Constants.ImagingType])))
                        {
                            tb_UnsuccessImport.FACILITY = dr[Constants.ImagingType].ToString();
                        }
                        else
                        {
                            tb_UnsuccessImport.FACILITY = "";
                            str.Append("Facility is empty /");
                        }
                        if (!string.IsNullOrEmpty(Convert.ToString(dr[Constants.Description])))
                        {
                            tb_UnsuccessImport.ACCOUNT_NO = dr[Constants.Description].ToString();
                        }
                        else
                        {
                            tb_UnsuccessImport.ACCOUNT_NO = "";
                            str.Append("Account number is empty /");
                        }
                        if (!string.IsNullOrEmpty(Convert.ToString(dr[Constants.BatchNo])))
                        {
                            tb_UnsuccessImport.BATCH_NAME = dr[Constants.BatchNo].ToString();
                        }
                        else
                        {
                            tb_UnsuccessImport.BATCH_NAME = "";
                            str.Append("Batch name is empty /");
                        }
                        if (!string.IsNullOrEmpty(Convert.ToString(dr[Constants.Location])))
                        {
                            tb_UnsuccessImport.LOCATION = dr[Constants.Location].ToString();
                        }
                        else
                        {
                            tb_UnsuccessImport.LOCATION = "";
                            str.Append("Location is empty /");
                        }


                        tb_UnsuccessImport.REMARKS = Convert.ToString(str).TrimEnd('/');
                        tb_UnsuccessImport.RECEIVED_DATE = DateTime.Now;
                        tb_UnsuccessImport.UPLOAD_BY = HttpContext.Current.Session[Constants.UserName].ToString();
                        tb_UnsuccessImport.PROJECT_ID = Convert.ToInt32(HttpContext.Current.Session[Constants.ProjectId]);
                        _context.tbl_UNSUCCESSFUL_IMPORTED_TABLE.Add(tb_UnsuccessImport);

                        model.UnsuccessfullCount = model.UnsuccessfullCount + 1;
                    }
                    else
                    {
                        string accountNumber = dr[Constants.Description].ToString();

                        var import = _context.tbl_IMPORT_TABLE.Where(x => x.ACCOUNT_NO == accountNumber && x.PROJECT_ID == projectId).FirstOrDefault();

                        bool loca = locationList.Any(x => x.Contains(location));

                        builder.Append(import != null ? "Duplicate Account /" : string.Empty);
                        builder.Append(loca ? string.Empty : "Location not belongs to this project/");

                        if (import == null && CheckDateFormat(Convert.ToDateTime(dr[Constants.DateImage]).ToString("MM/dd/yyyy")) && loca)
                        {
                            tb_Import.JOB_NAME = dr[Constants.JobName].ToString();
                            tb_Import.DOS = Convert.ToDateTime(dr[Constants.DateImage]);
                            tb_Import.PAGE_COUNT = Convert.ToInt32(dr[Constants.PageCount]);
                            tb_Import.FACILITY = dr[Constants.ImagingType].ToString();
                            tb_Import.ACCOUNT_NO = dr[Constants.Description].ToString();
                            tb_Import.BATCH_NAME = dr[Constants.BatchNo].ToString();
                            tb_Import.UPLOAD_BY = HttpContext.Current.Session[Constants.UserName].ToString();
                            tb_Import.PROJECT_ID = Convert.ToInt32(HttpContext.Current.Session[Constants.ProjectId]);
                            tb_Import.UPLOAD_DATE = DateTime.Now;
                            tb_Import.BATCH_STATUS = "Fresh";
                            tb_Import.LOCATION = Convert.ToString(dr["Location"]);
                            _context.tbl_IMPORT_TABLE.Add(tb_Import);
                            model.SuccessfullCount = model.SuccessfullCount + 1;

                        }
                        else
                        {
                            tbl_UNSUCCESSFUL_IMPORTED_TABLE duplicate = new tbl_UNSUCCESSFUL_IMPORTED_TABLE();
                            duplicate.DOS = Convert.ToDateTime(dr[Constants.DateImage]);
                            duplicate.JOB_NAME = dr[Constants.JobName].ToString();
                            duplicate.PAGE_COUNT = Convert.ToInt32(dr[Constants.PageCount]);
                            duplicate.FACILITY = dr[Constants.ImagingType].ToString();
                            duplicate.ACCOUNT_NO = dr[Constants.Description].ToString();
                            duplicate.BATCH_NAME = dr[Constants.BatchNo].ToString();
                            duplicate.REMARKS = builder.ToString().TrimEnd('/');
                            duplicate.LOCATION = Convert.ToString(dr["Location"]);
                            duplicate.RECEIVED_DATE = DateTime.Now;
                            duplicate.UPLOAD_BY = HttpContext.Current.Session[Constants.UserName].ToString();
                            duplicate.PROJECT_ID = Convert.ToInt32(HttpContext.Current.Session[Constants.ProjectId]);
                            _context.tbl_UNSUCCESSFUL_IMPORTED_TABLE.Add(duplicate);
                            model.UnsuccessfullCount = model.UnsuccessfullCount + 1;
                        }


                    }



                }
                _context.SaveChanges();
            }

            return model;
        }
        #endregion

        #region InsertPerimeter
        public ImportModel InsertPerimeter(DataSet ds, string type)
        {
            ImportModel model = new ImportModel();
            model.TotalExcelCount = ds.Tables[0].Rows.Count;
            model.UnsuccessfullCount = 0;
            model.SuccessfullCount = 0;

            using (CBI_Anes_HighEntities _context = new CBI_Anes_HighEntities())
            {
                int projectId = Convert.ToInt32(HttpContext.Current.Session[Constants.ProjectId].ToString());
                string userName = HttpContext.Current.Session[Constants.UserName].ToString();
                foreach (DataRow dr in ds.Tables[0].Rows)
                {
                    StringBuilder builder = new StringBuilder();
                    string accountNumber = Convert.ToString(dr[Constants.AccountNumber]);
                    string facility = Convert.ToString(dr[Constants.Facility]);
                    string mrn = Convert.ToString(dr[Constants.MRN]);
                    string firstName = Convert.ToString(dr[Constants.FirstName]);
                    string lastName = Convert.ToString(dr[Constants.LastName]);
                    string patientName = Convert.ToString(dr[Constants.PatientName]);
                    DateTime receivedDate = Convert.ToDateTime(dr[Constants.ReceivedDate]);
                    string payerClass = Convert.ToString(dr[Constants.PayerClass]);
                    string batchName = Convert.ToString(dr[Constants.PeriBatchName]);
                    //string location=Convert.ToString(dr[Constants.Location]);
                    string speciality = Convert.ToString(dr[Constants.Speciality]);
                    string icdCode = Convert.ToString(dr[Constants.IcdCode]);
                    DateTime dos = Convert.ToDateTime(dr[Constants.DOS]);

                    string acc = CryptoGraphy.Encrypt(accountNumber);
                    var import = _context.tbl_IMPORT_TABLE.Where(x => x.ACCOUNT_NO == acc && x.PROJECT_ID == projectId).FirstOrDefault();
                    builder.Append(import != null ? "Duplicate Account /" : string.Empty);

                    if (import == null)
                    {
                        tbl_IMPORT_TABLE record = new tbl_IMPORT_TABLE();
                        record.ACCOUNT_NO = CryptoGraphy.Encrypt(accountNumber);
                        // record.FACILITY =CryptoGraphy.Encrypt(facility);
                        record.FACILITY = facility;
                        record.MRN = CryptoGraphy.Encrypt(mrn);
                        record.Last_Name = CryptoGraphy.Encrypt(lastName);
                        record.First_Name = CryptoGraphy.Encrypt(firstName);
                        record.PATIENT_NAME = CryptoGraphy.Encrypt(patientName);
                        record.RECEIVED_DATE = receivedDate;
                        record.PAYER_CLASS = CryptoGraphy.Encrypt(payerClass);
                        record.BATCH_NAME = CryptoGraphy.Encrypt(batchName);
                        //record.LOCATION =CryptoGraphy.Encrypt(location) ;
                        record.SPECIALITY = CryptoGraphy.Encrypt(speciality);
                        record.ICD_CODE = icdCode;
                        record.DOS = dos;
                        record.UPLOAD_BY = userName;
                        record.PROJECT_ID = projectId;
                        record.UPLOAD_DATE = DateTime.Now;
                        record.BATCH_STATUS = "Fresh";
                        record.MEMBER_DOB = string.Empty;
                        _context.tbl_IMPORT_TABLE.Add(record);
                        model.SuccessfullCount = model.SuccessfullCount + 1;
                    }
                    else
                    {
                        tbl_UNSUCCESSFUL_IMPORTED_TABLE dummyrecord = new tbl_UNSUCCESSFUL_IMPORTED_TABLE();
                        dummyrecord.ACCOUNT_NO = accountNumber;
                        dummyrecord.FACILITY = facility;
                        dummyrecord.MRN = mrn;
                        dummyrecord.LAST_NAME = lastName;
                        dummyrecord.FIRST_NAME = firstName;
                        dummyrecord.PATIENT_NAME = patientName;
                        dummyrecord.RECEIVED_DATE = receivedDate;
                        dummyrecord.PAYER_CLASS = payerClass;
                        dummyrecord.BATCH_NAME = batchName;
                        //dummyrecord.LOCATION = location;
                        dummyrecord.SPECIALITY = speciality;
                        dummyrecord.ICD_CODE = icdCode;
                        dummyrecord.DOS = dos;
                        dummyrecord.UPLOAD_BY = userName;
                        dummyrecord.PROJECT_ID = projectId;
                        dummyrecord.MEMBER_DOB = string.Empty;
                        dummyrecord.BATCH_STATUS = "Fresh";
                        dummyrecord.REMARKS = builder.ToString().TrimEnd('/');
                        _context.tbl_UNSUCCESSFUL_IMPORTED_TABLE.Add(dummyrecord);
                        model.UnsuccessfullCount = model.UnsuccessfullCount + 1;
                    }
                }
                _context.SaveChanges();
            }

            return model;
        }
        #endregion

        #region InsertExcelData
        public ImportModel InsertExcelData(DataSet ds, string type)
        {
            ImportModel model = new ImportModel();
            try
            {

                if (ds.Tables[0].Rows.Count > 0)
                {
                    if (type == "HCC")
                    {
                        model = InsertHCC(ds);
                        ds.Clear();
                        ds = null;
                    }
                    else
                    {
                        if (Convert.ToString(HttpContext.Current.Session[Constants.ProjectId]) == Constants.HighMark)
                        {
                            model = InsertHighMark(ds);
                            ds.Dispose();
                        }
                        else if (Convert.ToString(HttpContext.Current.Session[Constants.ProjectId]) == Constants.MedData)
                        {
                            model = InsertMedData(ds);
                            ds.Clear();
                            ds = null;
                        }
                        else if (Convert.ToString(HttpContext.Current.Session[Constants.ProjectId]) == Constants.PeriMeter)
                        {
                            model = InsertPerimeter(ds, type);
                            ds.Clear();
                            ds = null;
                        }
                    }
                }

            }

            catch (DbEntityValidationException ex)
            {
                var errorMessages = ex.EntityValidationErrors.SelectMany(x => x.ValidationErrors).Select(x => x.ErrorMessage);
                var fullErrorMessage = string.Join(Constants.CommaSpace, errorMessages);
                var exceptionMessage = string.Concat(ex.Message, Constants.ValidationError, fullErrorMessage);
                throw new DbEntityValidationException(exceptionMessage, ex.EntityValidationErrors);
            }
            return model;

        }
        #endregion

        #region ApplySeleceted Header
        public void ApplyHeaderStatus(List<ImportModel> model)
        {
            try
            {
                using (CBI_Anes_HighEntities _context = new CBI_Anes_HighEntities())
                {
                    if (Convert.ToString(HttpContext.Current.Session[Constants.ProjectId]) == Constants.MedData)
                    {
                        foreach (var item in model)
                        {
                            //if (item.RECORD_STATUS == true)
                            //{

                            var batch = _context.tbl_UNSUCCESSFUL_IMPORTED_TABLE.Where(x => x.BATCH_ID == item.BATCH_ID).FirstOrDefault();
                            if (batch != null)
                            {
                                batch.RECORD_STATUS = item.RECORD_STATUS;
                                batch.JOB_NAME = (model[0].SelectedHeader == Constants.JobName) ? model[0].SearchText : item.JobName;

                                batch.MEMBER_DOB = (model[0].SelectedHeader == Constants.MemberDob) ? Convert.ToString(model[0].SearchText) : string.IsNullOrEmpty(item.MemberDOB) ? null : item.MemberDOB;

                                batch.DOS = (model[0].SelectedHeader == Constants.DateImage) ? Convert.ToDateTime(model[0].SearchText) : string.IsNullOrEmpty(item.DataImage) ? (DateTime?)null : Convert.ToDateTime(item.DataImage);
                                batch.PAGE_COUNT = (model[0].SelectedHeader == Constants.PageCount) ? Convert.ToInt32(model[0].SearchText) : Convert.ToInt32(item.PageCount);
                                batch.FACILITY = (model[0].SelectedHeader == Constants.ImagingType) ? model[0].SearchText : item.Facility;
                                batch.ACCOUNT_NO = (model[0].SelectedHeader == Constants.Description) ? model[0].SearchText : item.AccountNumber;
                                batch.BATCH_NAME = (model[0].SelectedHeader == Constants.BatchNo) ? model[0].SearchText : item.BatchNumber == null ? string.Empty : item.BatchNumber;
                                batch.LOCATION = (model[0].SelectedHeader == Constants.Location) ? model[0].SearchText : item.Location;

                                //  _context.SaveChanges();
                            }

                            //}
                        }
                        _context.SaveChanges();
                    }
                    else if (Convert.ToString(HttpContext.Current.Session[Constants.ProjectId]) == Constants.PeriMeter)
                    {

                        foreach (var item in model)
                        {
                            var batch = _context.tbl_UNSUCCESSFUL_IMPORTED_TABLE.Where(x => x.BATCH_ID == item.BATCH_ID).FirstOrDefault();
                            if (batch != null)
                            {
                                batch.RECORD_STATUS = item.RECORD_STATUS;
                                batch.FACILITY = (model[0].SelectedHeader == "Facility") ? model[0].SearchText : item.Facility;
                                batch.ACCOUNT_NO = (model[0].SelectedHeader == "Acc No") ? model[0].SearchText : item.AccountNumber;
                                batch.MRN = (model[0].SelectedHeader == "MRN") ? model[0].SearchText : item.MRN;
                                batch.PATIENT_NAME = (model[0].SelectedHeader == "Patient Name") ? model[0].SearchText : item.PatientName;
                                batch.RECEIVED_DATE = (model[0].SelectedHeader == "Received Date") ? Convert.ToDateTime(model[0].SearchText) : Convert.ToDateTime(item.ReceivedDate);
                                batch.PAYER_CLASS = (model[0].SelectedHeader == "Payer Class") ? model[0].SearchText : item.PayerClass;
                                batch.BATCH_NAME = (model[0].SelectedHeader == "Batch Name") ? model[0].SearchText : item.BatchNumber;
                                //batch.LOCATION = (model[0].SelectedHeader == "Location") ? model[0].SearchText : item.Location;
                                batch.SPECIALITY = (model[0].SelectedHeader == "Speciality") ? model[0].SearchText : item.Speciality;
                                batch.ICD_CODE = (model[0].SelectedHeader == "ICD CODE") ? model[0].SearchText : item.ICDCode;
                                batch.DOS = (model[0].SelectedHeader == "DOS") ? Convert.ToDateTime(model[0].SearchText) : item.DOS;
                            }
                        }
                        _context.SaveChanges();
                    }
                    else if (Convert.ToString(HttpContext.Current.Session[Constants.ProjectId]) == Constants.HighMark)
                    {
                        foreach (var item in model)
                        {
                            //if (item.RECORD_STATUS == true)
                            //{

                            var batch = _context.tbl_UNSUCCESSFUL_IMPORTED_TABLE.Where(x => x.BATCH_ID == item.BATCH_ID).FirstOrDefault();
                            if (batch != null)
                            {

                                batch.RECORD_STATUS = item.RECORD_STATUS;
                                batch.BATCH_NAME = (model[0].SelectedHeader == Constants.BatchName) ? model[0].SearchText : item.BatchNumber == null ? string.Empty : item.BatchNumber;
                                batch.ACCOUNT_NO = (model[0].SelectedHeader == Constants.TrackingCode) ? model[0].SearchText : item.TrackingCode;
                                batch.ECI = (model[0].SelectedHeader == Constants.ECI) ? model[0].SearchText : item.ECI;
                                batch.UMI = (model[0].SelectedHeader == Constants.UMI) ? model[0].SearchText : item.UMI;
                                batch.HIC = (model[0].SelectedHeader == Constants.HIC) ? model[0].SearchText : item.HIC;
                                batch.FIRST_NAME = (model[0].SelectedHeader == Constants.MemberFirstName) ? model[0].SearchText : item.MemberFirstName;
                                batch.LAST_NAME = (model[0].SelectedHeader == Constants.MemberLastName) ? model[0].SearchText : item.MemberLastName;
                                //batch.MEMBER_DOB = (model[0].SelectedHeader == Constants.MemberDob) ? Convert.ToDateTime(model[0].SearchText) : Convert.ToDateTime(item.MemberDOB);

                                // DateTime? ref1=string.IsNullOrEmpty(item.MemberDOB)? (DateTime?)null : Convert.ToDateTime(item.MemberDOB);


                                batch.MEMBER_DOB = (model[0].SelectedHeader == Constants.MemberDob) ? Convert.ToString(model[0].SearchText) : string.IsNullOrEmpty(item.MemberDOB) ? null : item.MemberDOB;

                                batch.ENCOUNTER_TYPE = (model[0].SelectedHeader == Constants.EncounterType) ? model[0].SearchText : item.EncounterType;
                                batch.MEMBER_GENDER = (model[0].SelectedHeader == Constants.MemberGender) ? model[0].SearchText : item.MemberGender;
                                batch.Performing_Provider_NPI = (model[0].SelectedHeader == Constants.PerformingProviderNPI) ? model[0].SearchText : item.PerformProviderNPI;
                                batch.Performing_Provider_BSID = (model[0].SelectedHeader == Constants.PerformingProviderBSID) ? model[0].SearchText : item.PerformProviderBSID;
                                batch.Billing_Provider_NPI = (model[0].SelectedHeader == Constants.BillingProviderNPI) ? model[0].SearchText : item.BillingProviderNPI;
                                batch.Billing_Provider_BSID = (model[0].SelectedHeader == Constants.BillingProviderBSID) ? model[0].SearchText : item.BillingProviderBSID;
                                batch.RECEIVED_DATE = (model[0].SelectedHeader == Constants.ScheduledRetrievalDate) ? Convert.ToDateTime(model[0].SearchText) : Convert.ToDateTime(item.RetrivalDate);
                                batch.UPLOAD_BY = HttpContext.Current.Session[Constants.UserName].ToString();
                                batch.LOCATION = (model[0].SelectedHeader == Constants.Location) ? model[0].SearchText : item.Location;

                                //  _context.SaveChanges();
                            }

                            //}
                        }
                        _context.SaveChanges();
                    }

                }
            }
            catch (DbEntityValidationException ex)
            {
                var errorMessages = ex.EntityValidationErrors.SelectMany(x => x.ValidationErrors).Select(x => x.ErrorMessage);
                var fullErrorMessage = string.Join(Constants.CommaSpace, errorMessages);
                var exceptionMessage = string.Concat(ex.Message, Constants.ValidationError, fullErrorMessage);
                throw new DbEntityValidationException(exceptionMessage, ex.EntityValidationErrors);
            }

        }

        #endregion

        #region ManageImportAccounts
        public void ManageImportAccounts(List<ImportModel> model, string status)
        {
            if (status == Constants.ApplyAll)
            {
                ApplyHeaderStatus(model);
            }
            else if (status == Constants.Upload)
            {
                ReUploadAccounts(model);
            }
            else if (status == Constants.Delete)
            {
                DeleteUnsuccessfullRecords(model);
            }
        }
        #endregion

        #region ReUploadAccounts
        public void ReUploadAccounts(List<ImportModel> model)
        {
            try
            {
                if (model.Count > 0)
                {
                    int projectId = Convert.ToInt32(HttpContext.Current.Session[Constants.ProjectId]);
                    using (CBI_Anes_HighEntities _context = new CBI_Anes_HighEntities())
                    {
                        var locationList = _context.tbl_LOCATION.Where(x => x.PROJECT_ID == projectId).Select(x => x.LOCATION).ToList();
                        if (Convert.ToString(HttpContext.Current.Session[Constants.ProjectId]) == Constants.MedData)
                        {
                            foreach (var item in model)
                            {
                                if (!string.IsNullOrEmpty(item.AccountNumber))
                                {
                                    StringBuilder builder = new StringBuilder();
                                    item.Location = item.Location == null ? string.Empty : item.Location;
                                    var import = _context.tbl_IMPORT_TABLE.Where(x => x.ACCOUNT_NO == item.AccountNumber && x.PROJECT_ID == projectId).FirstOrDefault();
                                    tbl_IMPORT_TABLE tblImport = new tbl_IMPORT_TABLE();
                                    bool dateImage = CheckDateFormat(Convert.ToDateTime(item.DataImage).ToString("MM/dd/yyyy"));
                                    bool loca = locationList.Any(x => x.Contains(item.Location));
                                    builder.Append(import != null ? "Duplicate Account/" : string.Empty);
                                    builder.Append(dateImage ? string.Empty : "Date Image not in format/");
                                    builder.Append(loca ? string.Empty : "Location not belongs to this project/");
                                    if (import == null && dateImage && loca)
                                    {
                                        var batch = _context.tbl_UNSUCCESSFUL_IMPORTED_TABLE.Where(x => x.BATCH_ID == item.BATCH_ID).FirstOrDefault();

                                        tblImport.JOB_NAME = item.JobName;
                                        tblImport.DOS = Convert.ToDateTime(item.DataImage);
                                        tblImport.PAGE_COUNT = Convert.ToInt32(item.PageCount);
                                        tblImport.FACILITY = item.Facility;
                                        tblImport.ACCOUNT_NO = item.AccountNumber;
                                        tblImport.BATCH_NAME = item.BatchNumber;
                                        tblImport.LOCATION = item.Location;
                                        tblImport.UPLOAD_BY = HttpContext.Current.Session[Constants.UserName].ToString();
                                        tblImport.UPLOAD_DATE = DateTime.Now;
                                        tblImport.PROJECT_ID = projectId;
                                        tblImport.BATCH_STATUS = "Fresh";
                                        tblImport.MEMBER_DOB = string.Empty;
                                        tblImport.PRACTICE_ID = Practice_ID;
                                        _context.tbl_IMPORT_TABLE.Add(tblImport);
                                        _context.tbl_UNSUCCESSFUL_IMPORTED_TABLE.Remove(batch);
                                        // _context.SaveChanges();
                                    }
                                    else
                                    {
                                        var batch = _context.tbl_UNSUCCESSFUL_IMPORTED_TABLE.Where(x => x.BATCH_ID == item.BATCH_ID).FirstOrDefault();
                                        batch.REMARKS = builder.ToString().TrimEnd('/');
                                        //  _context.SaveChanges();
                                    }
                                }
                            }
                            _context.SaveChanges();
                        }
                        else if (Convert.ToString(HttpContext.Current.Session[Constants.ProjectId]) == Constants.PeriMeter)
                        {
                            foreach (var item in model)
                            {
                                string AccNo = CryptoGraphy.Encrypt(item.AccountNumber);
                                var import = _context.tbl_IMPORT_TABLE.Where(x => x.ACCOUNT_NO == AccNo && x.PROJECT_ID == projectId).FirstOrDefault();

                                StringBuilder builder = new StringBuilder();

                                tbl_IMPORT_TABLE tblImport = new tbl_IMPORT_TABLE();
                                builder.Append(import != null ? "Duplicate Account/" : string.Empty);
                                if (import == null)
                                {
                                    var batch = _context.tbl_UNSUCCESSFUL_IMPORTED_TABLE.Where(x => x.BATCH_ID == item.BATCH_ID).FirstOrDefault();
                                    tblImport.FACILITY = item.Facility;
                                    tblImport.ACCOUNT_NO = CryptoGraphy.Encrypt(item.AccountNumber);
                                    tblImport.MRN = CryptoGraphy.Encrypt(item.MRN);
                                    //tblImport.First_Name = CryptoGraphy.Encrypt(item.MemberFirstName);
                                    //tblImport.Last_Name = CryptoGraphy.Encrypt(item.MemberLastName);
                                    tblImport.PATIENT_NAME = CryptoGraphy.Encrypt(item.PatientName);
                                    tblImport.RECEIVED_DATE = Convert.ToDateTime(item.ReceivedDate);
                                    tblImport.PAYER_CLASS = CryptoGraphy.Encrypt(item.PayerClass);
                                    tblImport.BATCH_NAME = CryptoGraphy.Encrypt(item.BatchNumber);
                                    //tblImport.LOCATION = item.Location;
                                    tblImport.UPLOAD_BY = HttpContext.Current.Session[Constants.UserName].ToString();
                                    tblImport.UPLOAD_DATE = DateTime.Now;
                                    tblImport.PROJECT_ID = projectId;
                                    tblImport.BATCH_STATUS = "Fresh";
                                    tblImport.MEMBER_DOB = "";
                                    tblImport.SPECIALITY = CryptoGraphy.Encrypt(item.Speciality);
                                    tblImport.ICD_CODE = item.ICDCode;
                                    tblImport.DOS = item.DOS;
                                    tblImport.PRACTICE_ID = Practice_ID;
                                    _context.tbl_IMPORT_TABLE.Add(tblImport);
                                    _context.tbl_UNSUCCESSFUL_IMPORTED_TABLE.Remove(batch);
                                }
                                else
                                {
                                    var batch = _context.tbl_UNSUCCESSFUL_IMPORTED_TABLE.Where(x => x.BATCH_ID == item.BATCH_ID).FirstOrDefault();
                                    batch.REMARKS = builder.ToString().TrimEnd('/');
                                }
                            }
                            _context.SaveChanges();
                        }
                        else if (Convert.ToString(HttpContext.Current.Session[Constants.ProjectId]) == Constants.HighMark)
                        {
                            foreach (var item in model)
                            {
                                if (!string.IsNullOrEmpty(item.TrackingCode))
                                {
                                    StringBuilder builder = new StringBuilder();
                                    string message = string.Empty;
                                    item.Location = item.Location == null ? string.Empty : item.Location;
                                    tbl_IMPORT_TABLE tblImport = new tbl_IMPORT_TABLE();
                                    string accountNumber = item.TrackingCode;
                                    string memberGender = item.MemberGender;
                                    string eType = item.EncounterType;
                                    string PPBSID = item.PerformProviderBSID;
                                    string BPBSID = item.BillingProviderBSID;

                                    bool acc = ((accountNumber.StartsWith("MA") || accountNumber.StartsWith("AC")) && accountNumber.Length == 11);
                                    bool rd = string.IsNullOrEmpty(item.RetrivalDate) ? false : CheckDateFormat(Convert.ToDateTime(item.RetrivalDate).ToString("MM/dd/yyyy"));
                                    bool mdob = (Convert.ToDateTime(item.MemberDOB) < DateTime.Now);
                                    bool mg = ((memberGender.Any(c => c == 'M' || c == 'F') || memberGender == string.Empty) && memberGender.Length <= 1);
                                    bool et = (eType.Any(c => c == 'P' || c == 'I' || c == 'O') && eType.Length == 1);
                                    bool ppb = (PPBSID.All(char.IsDigit) && PPBSID.Length == 9);
                                    bool bpb = (BPBSID.All(char.IsDigit) && BPBSID.Length == 9);
                                    bool loca = locationList.Any(x => x.Contains(item.Location));

                                    string acctNumber = CryptoGraphy.Encrypt(item.TrackingCode);

                                    var import = _context.tbl_IMPORT_TABLE.Where(x => x.ACCOUNT_NO == acctNumber && x.PROJECT_ID == projectId).FirstOrDefault();
                                    builder.Append(acc ? string.Empty : " Account Number not in format/");
                                    builder.Append(rd ? string.Empty : " RetrivalDate not in format/");
                                    builder.Append(mdob ? string.Empty : " Member DOB not in format/");
                                    builder.Append(mg ? string.Empty : " Member Gender not in format/");
                                    builder.Append(et ? string.Empty : " Encounter Type not in format/");
                                    builder.Append(ppb ? string.Empty : " Performing_Provider_BSID not in format/");
                                    builder.Append(bpb ? string.Empty : " Billing_Provider_BSID not in format/");
                                    builder.Append(loca ? string.Empty : " Location not belongs to this project/");
                                    builder.Append(import != null ? "Duplicate Account/" : string.Empty);



                                    if (import == null && acc && rd && mdob && mg && et && ppb && bpb && loca)
                                    {
                                        var batch = _context.tbl_UNSUCCESSFUL_IMPORTED_TABLE.Where(x => x.BATCH_ID == item.BATCH_ID).FirstOrDefault();


                                        tblImport.ACCOUNT_NO = acctNumber;
                                        tblImport.ECI = CryptoGraphy.Encrypt(item.ECI);
                                        tblImport.UMI = CryptoGraphy.Encrypt(item.UMI);
                                        tblImport.HIC = item.HIC != null ? CryptoGraphy.Encrypt(item.HIC) : CryptoGraphy.Encrypt(string.Empty);
                                        tblImport.First_Name = CryptoGraphy.Encrypt(item.MemberFirstName);
                                        tblImport.Last_Name = CryptoGraphy.Encrypt(item.MemberLastName);
                                        tblImport.MEMBER_DOB = CryptoGraphy.Encrypt(Convert.ToString(item.MemberDOB));
                                        tblImport.ENCOUNTER_TYPE = eType;
                                        tblImport.MEMBER_GENDER = item.MemberGender != null ? CryptoGraphy.Encrypt(item.MemberGender) : CryptoGraphy.Encrypt(string.Empty);
                                        tblImport.Performing_Provider_NPI = item.PerformProviderNPI;
                                        tblImport.Performing_Provider_BSID = AddZeroAsPrefix(PPBSID, 10);
                                        tblImport.Billing_Provider_NPI = item.BillingProviderNPI;
                                        tblImport.Billing_Provider_BSID = AddZeroAsPrefix(BPBSID, 10);
                                        tblImport.RECEIVED_DATE = Convert.ToDateTime(item.RetrivalDate);
                                        tblImport.UPLOAD_BY = HttpContext.Current.Session[Constants.UserName].ToString();
                                        tblImport.PROJECT_ID = Convert.ToInt32(HttpContext.Current.Session[Constants.ProjectId].ToString());
                                        tblImport.UPLOAD_DATE = DateTime.Now;
                                        tblImport.BATCH_STATUS = "Fresh";
                                        tblImport.BATCH_NAME = CryptoGraphy.Encrypt(item.BatchNumber);
                                        tblImport.LOCATION = item.Location;
                                        tblImport.PRACTICE_ID = Practice_ID;
                                        _context.tbl_IMPORT_TABLE.Add(tblImport);
                                        _context.tbl_UNSUCCESSFUL_IMPORTED_TABLE.Remove(batch);
                                        //   _context.SaveChanges();
                                    }
                                    else
                                    {
                                        var batch = _context.tbl_UNSUCCESSFUL_IMPORTED_TABLE.Where(x => x.BATCH_ID == item.BATCH_ID).FirstOrDefault();
                                        batch.REMARKS = builder.ToString().TrimEnd('/');
                                        //  _context.SaveChanges();
                                    }

                                }
                            }
                            _context.SaveChanges();
                        }


                    }
                }
            }
            catch (DbEntityValidationException ex)
            {
                var errorMessages = ex.EntityValidationErrors.SelectMany(x => x.ValidationErrors)
                    .Select(x => x.ErrorMessage);
                var fullErrorMessage = string.Join(Constants.CommaSpace, errorMessages);
                var exceptionMessage = string.Concat(ex.Message, Constants.ValidationError, fullErrorMessage);
                throw new DbEntityValidationException(exceptionMessage, ex.EntityValidationErrors);
            }
        }
        #endregion

        #region DeleteUnsuccessfullRecords
        public void DeleteUnsuccessfullRecords(List<ImportModel> model)
        {
            try
            {
                using (CBI_Anes_HighEntities _context = new CBI_Anes_HighEntities())
                {
                    foreach (var item in model)
                    {
                        if (item.BATCH_ID != 0)
                        {
                            var batch = _context.tbl_UNSUCCESSFUL_IMPORTED_TABLE.Where(x => x.BATCH_ID == item.BATCH_ID).FirstOrDefault();
                            _context.tbl_UNSUCCESSFUL_IMPORTED_TABLE.Remove(batch);
                            // _context.SaveChanges();
                        }
                    }
                    _context.SaveChanges();
                }
            }
            catch (DbEntityValidationException ex)
            {
                var errorMessages = ex.EntityValidationErrors.SelectMany(x => x.ValidationErrors)
                    .Select(x => x.ErrorMessage);
                var fullErrorMessage = string.Join(Constants.CommaSpace, errorMessages);
                var exceptionMessage = string.Concat(ex.Message, Constants.ValidationError, fullErrorMessage);
                throw new DbEntityValidationException(exceptionMessage, ex.EntityValidationErrors);
            }
        }
        #endregion

        #region CheckDateFormat
        private bool CheckDateFormat(string date)
        {
            DateTime parsed;
            bool dt = DateTime.TryParseExact(date, "MM/dd/yyyy",
                                                CultureInfo.InvariantCulture,
                                                DateTimeStyles.None,
                                                out parsed);
            return dt;
        }
        #endregion

        #region AddZeroAsPrefix
        private string AddZeroAsPrefix(string text, int size)
        {
            if (size == 11)
            {
                if (size == text.Length)
                {
                    return text;
                }
                else
                {
                    if (text.Contains("MA"))
                    {
                        string str = text.Replace("MA", "");
                        return "MA" + text.PadLeft(str.Length, '0');
                    }
                    else if (text.Contains("AC"))
                    {
                        string str = text.Replace("AC", "");
                        return "AC" + text.PadLeft(str.Length, '0');
                    }
                }
            }
            if (size == text.Length)
            {
                return text;
            }
            else
            {
                return text.PadLeft(size, '0');
            }
        }
        #endregion

        #region HeaderCount
        public void GetHeaderCounts()
        {
            using (CBI_Anes_HighEntities _context = new CBI_Anes_HighEntities())
            {

                
                    HttpContext.Current.Session[Constants.userNtlg]=Constants.userNtlg;
                    string test = HttpContext.Current.Session[Constants.userNtlg].ToString();
               // DateTime todayDate = DateTime.Parse("2017-02-01 12:14:03.827").Date;
               DateTime todayDate = DateTime.Now.Date;
               string today=todayDate.ToString("d");
               
                int projectId = Convert.ToInt32(HttpContext.Current.Session[Constants.ProjectId]);
                string userNtlg = HttpContext.Current.Session[Constants.UserName].ToString();
                string Location = HttpContext.Current.Session[Constants.LocationName].ToString();
                int practiceId=Convert.ToInt32(HttpContext.Current.Session[Constants.PracticeID]);
                var UserLocation = _context.tbl_USER_ACCESS.Where(x => x.PROJECT_ID == projectId && x.PRACTICE_ID == practiceId && x.USER_NTLG==userNtlg).ToList();
                String UserLocationSpec;
                foreach (var item in UserLocation)
                {
              
                    UserLocationSpec = item.Location.ToString();
                }
                try
                {
                    var statusList = new String[] {"Qced","Qc" };
                    var importCount = _context.tbl_IMPORT_TABLE.Where(x => x.PROJECT_ID == projectId  && x.LOCATION == Location && x.PRACTICE_ID==practiceId ).ToList();
                    var importAllotedCount = _context.tbl_IMPORT_TABLE.Where(x => x.PROJECT_ID == projectId && DbFunctions.TruncateTime(x.ALLOTTED_DATE) == todayDate && x.LOCATION == Location && x.PRACTICE_ID == practiceId).ToList();
                    var importReleasedCount = (from I in _context.tbl_IMPORT_TABLE join T in _context.tbl_TRANSACTION on I.BATCH_ID equals T.BATCH_ID where T.PROJECT_ID == projectId && DbFunctions.TruncateTime(I.RELEASED_DATE) == todayDate && I.LOCATION == Location && I.PRACTICE_ID == practiceId && T.PRACTICE_ID == practiceId select new { I.BATCH_STATUS, T.CODED_BY, T.QC_BY }).ToList();
                    var InProcessCount = (from T in _context.tbl_TRANSACTION join I in _context.tbl_IMPORT_TABLE on T.BATCH_ID equals I.BATCH_ID where T.PROJECT_ID == projectId && DbFunctions.TruncateTime(T.CODED_DATE) == todayDate && I.LOCATION == Location && T.PRACTICE_ID == practiceId && I.PRACTICE_ID == practiceId select new { T.CODING_STATUS, I.ALLOTTED_TO, I.BATCH_STATUS }).ToList();
                    var QcedforCoder = _context.tbl_TRANSACTION.Where(x => x.PROJECT_ID == projectId && DbFunctions.TruncateTime(x.QC_DATE) == todayDate && x.CODED_BY == userNtlg && x.PRACTICE_ID == practiceId).ToList();
                    var Coded_transCount = (from T in _context.tbl_TRANSACTION join U in _context.tbl_USER_ACCESS on T.CODED_BY equals U.USER_NTLG where T.PROJECT_ID == projectId && DbFunctions.TruncateTime(T.CODED_DATE) == todayDate && U.Location == Location && T.PRACTICE_ID == practiceId && U.PRACTICE_ID == practiceId select new { T.CODING_STATUS, T.QC_STATUS,T.CODED_BY ,T.CODED_DATE,today}).ToList();
                    var Coded_transCountForTL = _context.tbl_TRANSACTION.Where(x => x.PROJECT_ID == projectId && DbFunctions.TruncateTime(x.CODED_DATE) == todayDate && x.PRACTICE_ID == practiceId).ToList();
                    var QCed_transCount = (from T in _context.tbl_TRANSACTION join I in _context.tbl_IMPORT_TABLE on T.BATCH_ID equals I.BATCH_ID where T.PROJECT_ID == projectId && DbFunctions.TruncateTime(T.QC_DATE) == todayDate && I.LOCATION == Location && T.PRACTICE_ID == practiceId && I.PRACTICE_ID == practiceId select new { T.CODING_STATUS, T.QC_STATUS, T.QC_BY,I.BATCH_STATUS }).ToList();
                    var QCCountForQCAlone = (from T in _context.tbl_TRANSACTION join I in _context.tbl_IMPORT_TABLE on T.BATCH_ID equals I.BATCH_ID where T.PROJECT_ID == projectId && DbFunctions.TruncateTime(T.QC_DATE) == todayDate && I.LOCATION == Location && T.PRACTICE_ID == practiceId && I.PRACTICE_ID == practiceId && statusList.Contains(T.QC_STATUS) && T.IS_AUDITED==1 select new { T.QC_BY, T.QC_STATUS, T.QC_DATE }).ToList();
                    var QCAllottedTL_transCount = (from T in _context.tbl_TRANSACTION join I in _context.tbl_IMPORT_TABLE on T.BATCH_ID equals I.BATCH_ID where T.PROJECT_ID == projectId && DbFunctions.TruncateTime(I.QC_ALLOTTED_DATE) == todayDate && I.LOCATION == Location && T.PRACTICE_ID == practiceId && I.PRACTICE_ID == practiceId && I.ALLOTTED_TO == userNtlg select new { I.BATCH_STATUS }).ToList();
                    var QCAllottedTL_transCount1 = (from T in _context.tbl_TRANSACTION join I in _context.tbl_IMPORT_TABLE on T.BATCH_ID equals I.BATCH_ID where T.PROJECT_ID == projectId && DbFunctions.TruncateTime(I.QC_ALLOTTED_DATE) == todayDate && I.LOCATION == Location && T.PRACTICE_ID == practiceId && I.PRACTICE_ID == practiceId  select new { I.BATCH_STATUS }).ToList();

                    var Role = (from U in _context.tbl_USER_ACCESS where U.PROJECT_ID == projectId && U.USER_NTLG == userNtlg && U.Location == Location && U.PRACTICE_ID == practiceId select new { U.ACCESS_TYPE }).FirstOrDefault();

                    if (Role.ACCESS_TYPE.ToUpper().Trim() == "CODER")
                    {
                        HttpContext.Current.Session[Constants.HeaderAllotted] = importAllotedCount.Where(x => x.BATCH_STATUS == "Coding Allotted" && x.ALLOTTED_TO==userNtlg).ToList().Count;
                        HttpContext.Current.Session[Constants.HeaderCoded] = Coded_transCount.Where(x => x.CODING_STATUS == Constants.HeaderCoded && x.CODED_BY == userNtlg).ToList().Count;
                        HttpContext.Current.Session[Constants.HeaderQced] = QcedforCoder.Where(x => x.QC_STATUS == "Qc" || x.QC_STATUS == "Qced" || x.QC_STATUS == "Completed").ToList().Count;
                        HttpContext.Current.Session[Constants.HeaderReleased] = importReleasedCount.Where(x => x.BATCH_STATUS == Constants.HeaderReleased && x.CODED_BY==userNtlg).ToList().Count;
                        HttpContext.Current.Session[Constants.HeaderCodingInProcess] = InProcessCount.Where(x => x.BATCH_STATUS == "Coding Allotted" && x.ALLOTTED_TO == userNtlg && x.CODING_STATUS == Constants.CodingInProgress).ToList().Count;
                        
                    }
                    else if (Role.ACCESS_TYPE.ToUpper().Trim() == "QC")
                    {
                        HttpContext.Current.Session[Constants.HeaderQced] = (QCCountForQCAlone.Where(x => x.QC_STATUS == "Qc" && x.QC_BY == userNtlg).ToList().Count) + (QCCountForQCAlone.Where(x => x.QC_STATUS == Constants.HeaderQced && x.QC_BY == userNtlg).ToList().Count) + (QCCountForQCAlone.Where(x => x.QC_STATUS == Constants.HeaderReleased && x.QC_BY == userNtlg).ToList().Count);
                        HttpContext.Current.Session[Constants.QCAllotted] = QCAllottedTL_transCount.Where(x => x.BATCH_STATUS == Constants.QCAllotted).ToList().Count;
                        HttpContext.Current.Session[Constants.HeaderReleased] = importReleasedCount.Where(x => x.BATCH_STATUS == Constants.HeaderReleased && x.QC_BY == userNtlg).ToList().Count;
                    }
                    else if (Role.ACCESS_TYPE.ToUpper().Trim() == "CODER-QC-TL" || Role.ACCESS_TYPE.ToUpper().Trim() == "CODER-TL")
                    {
                        HttpContext.Current.Session[Constants.HeaderQced] = (QCCountForQCAlone.Where(x => x.QC_STATUS == "Qc").ToList().Count) + (QCCountForQCAlone.Where(x => x.QC_STATUS == Constants.HeaderQced).ToList().Count) + (QCCountForQCAlone.Where(x => x.QC_STATUS == Constants.HeaderReleased).ToList().Count);
                        HttpContext.Current.Session[Constants.HeaderCoded] = InProcessCount.Where(x => x.CODING_STATUS == Constants.HeaderCoded).ToList().Count;
                        HttpContext.Current.Session[Constants.HeaderCodingInProcess] = InProcessCount.Where(x => x.CODING_STATUS == Constants.CodingInProgress).ToList().Count;
                        HttpContext.Current.Session[Constants.HeaderFresh] = (importCount.Where(x => x.BATCH_STATUS.ToUpper() == Constants.HeaderFresh.ToUpper()).ToList()).Count;
                        HttpContext.Current.Session[Constants.HeaderAllotted] = importAllotedCount.Where(x => x.BATCH_STATUS == "Coding Allotted").ToList().Count;
                        HttpContext.Current.Session[Constants.HeaderReleased] = importReleasedCount.Where(x => x.BATCH_STATUS == Constants.HeaderReleased).ToList().Count;
                        HttpContext.Current.Session[Constants.QCAllotted] = QCAllottedTL_transCount1.Where(x => x.BATCH_STATUS == Constants.QCAllotted).ToList().Count;                        
                    }
                }
                catch (Exception e)
                {

                }
            }
        }
        #endregion

        #region GetHCCUploadedAccounts
        public List<ImportModel> GetHCCUploadedAccounts()
        {
            DateTime todayDate = DateTime.Now.Date;
            using (CBI_Anes_HighEntities _context = new CBI_Anes_HighEntities())
            {
                List<ImportModel> list = new List<ImportModel>();
                var data = _context.tbl_IMPORT_HCC_DXCODE_MASTER.ToList();
                for (int i = 0; i < data.Count; i++)
                {
                    if (Convert.ToDateTime(data[i].UPLOADED_DATE).Date == todayDate)
                    {
                        ImportModel model = new ImportModel();
                        model.HCC = data[i].HCC.ToString();
                        model.DxType = data[i].DX_TYPE.ToString();
                        model.DxCode = data[i].DX_CODE;
                        model.ECI = CryptoGraphy.Decrypt(data[i].ECI);
                        list.Add(model);
                    }
                }
                return list;
            }
        }
        #endregion

        #region Delete Records
        public string DeleteRecords()
        {
            using (CBI_Anes_HighEntities _context = new CBI_Anes_HighEntities())
            {
                string Status;
                int projectId = Convert.ToInt32(HttpContext.Current.Session[Constants.ProjectId]);
                int practiceId = Convert.ToInt32(HttpContext.Current.Session[Constants.PracticeID]);
                string userNtlg = HttpContext.Current.Session[Constants.UserName].ToString();
                try
                {
                    SqlConnection conObj = new SqlConnection(Constants.ConnectionString);
                    conObj.Open();
                    SqlCommand cmdObj = new SqlCommand(Constants.SPDeleteAccounts, conObj);
                    cmdObj.CommandType = CommandType.StoredProcedure;
                    cmdObj.Parameters.AddWithValue("@ProjectID", projectId);
                    cmdObj.Parameters.AddWithValue("@PracticeID", practiceId);
                    cmdObj.Parameters.AddWithValue("@UserNtlg", userNtlg);
                    int result=cmdObj.ExecuteNonQuery();
                    conObj.Close();
                    if (result>=1)
                    {
                        return Status="Success";
                    }
                    else
                    {
                        return Status="False";
                    }
                }
                catch (Exception e)
                {
                    throw e;
                }
            }
        }
        #endregion
    }
}
