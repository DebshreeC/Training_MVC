﻿using CBIplus.BAL.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.Mvc;

namespace CBIplus.BAL.Managers
{
    public interface IPerimeterQCService
    {
        List<SelectListItem> getCoderNames(string tl, string user);
        List<PerimeterQCTransactionModel> GetCodedData(string selecetedText);
        PerimeterQCTransactionModel All(int transDetailsId = 0, int Tran_Id = 0);
        List<PerimeterQCTransactionModel> GetPerimeterCPTGridData(int transId, string accountNumber);
      
        List<SelectListItem> GetSelectedCPT(string CPT);
        void PerimeterQCAddNewCPT(PerimeterQCTransactionModel model);
        List<SelectListItem> DowncodedFormList();
        List<SelectListItem> GetErrorDataDetails();
        List<SelectListItem> GetErrorSubCategory(string errorType);
        /************************SUBHAJA******************new fileds aaded**************/
        List<SelectListItem> GetErrorParameter();
        List<SelectListItem> GetErrorSubParameter(string errorType);
        List<SelectListItem> GetErrorMicroCategory(string errorType);
        /************************SUBHAJA******************new fileds aaded**************/
        void UpdateErrorList(List<MedDataQcTransactionModel> model, string listOfAccounts);
        PerimeterQCTransactionModel LoadPDF(string AccNum);
    }
}
