﻿using CBIplus.BAL.Generics;
using CBIplus.BAL.ViewModels;
using CBIplus.DAL;
using Microsoft.Win32.SafeHandles;
using System;
using System.Collections.Generic;
using System.Data.Entity.Validation;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using System.Web.Mvc;

namespace CBIplus.BAL.Managers
{
    public class PerimeterQCManager : IPerimeterQCService
    {
        

        #region Get Coder Names
        public List<SelectListItem> getCoderNames(string tl, string user)
        {
            HttpContext.Current.Session["FinalList"] = null;
            using (CBI_Anes_HighEntities _context = new CBI_Anes_HighEntities())
            {
                int projectId = Convert.ToInt32(HttpContext.Current.Session[Constants.ProjectId]);
                return (from coder in _context.tbl_USER_ACCESS
                        where coder.PROJECT_ID == projectId && (coder.ACCESS_TYPE == tl || coder.ACCESS_TYPE == user)
                        select new SelectListItem
                        {
                            Text = coder.USER_NTLG,
                            Value = coder.USER_ID.ToString()
                        }).ToList();
            }
        }
        #endregion

        #region Get Coded Details

        public List<PerimeterQCTransactionModel> GetCodedData(string selecetedText)
        {
            using (CBI_Anes_HighEntities _context = new CBI_Anes_HighEntities())
            {
                int projectId = Convert.ToInt32(HttpContext.Current.Session[Constants.ProjectId]);
                string useName = HttpContext.Current.Session[Constants.UserName].ToString();

                if (HttpContext.Current.Session["FinalList"] == null)
                {
                    var finalList = (from I in _context.tbl_IMPORT_TABLE
                                     join T in _context.tbl_TRANSACTION on I.BATCH_ID equals T.BATCH_ID
                                     join TD in _context.tbl_TRANSACTION_DETAILS on T.TRANS_ID equals TD.TRANS_ID
                                     where I.BATCH_STATUS == "QC Allotted" && T.PROJECT_ID == projectId && I.QC_ALLOTTED_BY == useName
                                     select new PerimeterQCTransactionModel
                                     {
                                         Facility=I.FACILITY,
                                         PatientStatusDCStatus=T.PATIENT_STATUS,
                                         PatientName=T.PATIENT_NAME,
                                         DOS = I.DOS.ToString(),
                                         SCRIBE = T.SCRIBE,
                                         AccountNumber = I.ACCOUNT_NO,
                                         Insurance = T.INSURANCE,
                                         AttendingPhysician = T.ATTENDING_PHY,
                                         NPPA = T.NPPA,
                                         Resident = T.RESIDENT,
                                         DCStatus = T.DISPOSITION,
                                         Coder = T.CODED_BY,
                                         CodedDate = T.CODED_DATE.ToString(),
                                         Comments = T.CODING_COMMENTS,
                                         BATCH_ID = I.BATCH_ID,
                                         TRANS_ID = T.TRANS_ID,
                                         TRANS_DETAIL_ID = TD.TRANS_DETAIL_ID,
                                         Downcoded = TD.Downcoded,
                                         HPI = TD.HPI,
                                         PFSH = TD.PFSH,
                                         ROS = TD.ROS,
                                         EXAM = TD.EXAM,
                                         PayerClass =I.PAYER_CLASS,
                                     }).GroupBy(x => x.AccountNumber).Select(x => x.FirstOrDefault()).ToList();
                    HttpContext.Current.Session["FinalList"] = finalList;
                }


                if (selecetedText.Contains("SelectedCoder"))
                {
                    string[] array = selecetedText.Split('*');
                    string SelectedCoder = array[0].ToString();

                    return (from item in HttpContext.Current.Session["FinalList"] as List<PerimeterQCTransactionModel>
                            where item.Coder == SelectedCoder
                            select new PerimeterQCTransactionModel
                            {
                                DOS = item.DOS.ToString(),
                                SCRIBE = item.SCRIBE,
                                AccountNumber = CryptoGraphy.Decrypt(item.AccountNumber),
                                Insurance = item.Insurance,
                                AttendingPhysician = item.AttendingPhysician,
                                NPPA = item.NPPA,
                                Resident = item.Resident,
                                DCStatus = item.DCStatus,
                                Coder = item.Coder,
                                CodedDate = item.CodedDate,
                                Comments = item.Comments,
                                BATCH_ID = item.BATCH_ID,
                                TRANS_ID = item.TRANS_ID,
                                TRANS_DETAIL_ID = item.TRANS_DETAIL_ID,
                                Downcoded = item.Downcoded,
                                HPI = item.HPI,
                                PFSH = item.PFSH,
                                ROS = item.ROS,
                                EXAM = item.EXAM,
                                PayerClass=CryptoGraphy.Decrypt(item.PayerClass),
                            }).ToList();
                }
                else if (selecetedText.Contains("CodedDate"))
                {
                    string[] array = selecetedText.Split('*');
                    DateTime CodedDate = Convert.ToDateTime(array[0].ToString());
                    return (from item in HttpContext.Current.Session["FinalList"] as List<PerimeterQCTransactionModel>
                            where Convert.ToDateTime(item.CodedDate) == CodedDate
                            select new PerimeterQCTransactionModel
                            {
                                DOS = item.DOS.ToString(),
                                SCRIBE = item.SCRIBE,
                                AccountNumber = CryptoGraphy.Decrypt(item.AccountNumber),
                                Insurance = item.Insurance,
                                AttendingPhysician = item.AttendingPhysician,
                                NPPA = item.NPPA,
                                Resident = item.Resident,
                                DCStatus = item.DCStatus,
                                Coder = item.Coder,
                                CodedDate = item.CodedDate,
                                Comments = item.Comments,
                                BATCH_ID = item.BATCH_ID,
                                TRANS_ID = item.TRANS_ID,
                                TRANS_DETAIL_ID = item.TRANS_DETAIL_ID,
                                Downcoded = item.Downcoded,
                                HPI = item.HPI,
                                PFSH = item.PFSH,
                                ROS = item.ROS,
                                EXAM = item.EXAM,
                                PayerClass=CryptoGraphy.Decrypt(item.PayerClass),
                            }).ToList();
                }
                else
                {
                    return (from item in HttpContext.Current.Session["FinalList"] as List<PerimeterQCTransactionModel>
                            select new PerimeterQCTransactionModel
                            {
                                Facility = item.Facility,
                                PatientStatusDCStatus = item.PatientStatusDCStatus,
                                PatientName = item.PatientName,
                                DOS = item.DOS.ToString(),
                                SCRIBE = item.SCRIBE,
                                AccountNumber = CryptoGraphy.Decrypt(item.AccountNumber),
                                Insurance = item.Insurance,
                                AttendingPhysician = item.AttendingPhysician,
                                NPPA = item.NPPA,
                                Resident = item.Resident,
                                DCStatus = item.DCStatus,
                                Coder = item.Coder,
                                CodedDate = item.CodedDate,
                                Comments = item.Comments,
                                BATCH_ID = item.BATCH_ID,
                                TRANS_ID = item.TRANS_ID,
                                TRANS_DETAIL_ID = item.TRANS_DETAIL_ID,
                                Downcoded = item.Downcoded,
                                HPI = item.HPI,
                                PFSH = item.PFSH,
                                ROS = item.ROS,
                                EXAM = item.EXAM,
                                PayerClass=CryptoGraphy.Decrypt(item.PayerClass),
                            }).ToList();
                }
            }
        }
        #endregion

        #region Show Modifier
        public List<SelectListItem> ShowModifierList()
        {
            using (CBI_Anes_HighEntities _context = new CBI_Anes_HighEntities())
            {
                int projectId = Convert.ToInt32(HttpContext.Current.Session[Constants.ProjectId]);
                var list = (from M in _context.tbl_MODIFIER_MASTER
                            where projectId == projectId
                            select new SelectListItem
                            {
                                Text = M.MODIFIERS,
                                Value = M.MODIFIERS
                            }).ToList();
                return list;
            }
        }
        #endregion

        #region Show Static Comments
        public List<SelectListItem> StaticCommentsList()
        {
            using (CBI_Anes_HighEntities _context = new CBI_Anes_HighEntities())
            {
                int projectId = Convert.ToInt32(HttpContext.Current.Session[Constants.ProjectId]);
                var list = (from SC in _context.tbl_COMMENT_MASTER
                            where projectId == projectId
                            select new SelectListItem
                            {
                                Text = SC.COMMENT_NAME,
                                Value = SC.COMMENT_NAME
                            }).ToList();
                return list;
            }
        }
        #endregion

        #region Show CPT List
        public List<SelectListItem> CPTList()
        {
            using (CBI_Anes_HighEntities _context = new CBI_Anes_HighEntities())
            {
                int projectId = Convert.ToInt32(HttpContext.Current.Session[Constants.ProjectId]);
                var list = (from CP in _context.tbl_CPT1_MASTER
                            where projectId == projectId
                            select new SelectListItem
                            {
                                Text = CP.CPT1,
                                Value = CP.CPT1
                            }).ToList();
                return list;
            }
        }
        #endregion

        #region Downcoded Form List
        public List<SelectListItem> DowncodedFormList()
        {
            using (CBI_Anes_HighEntities _context = new CBI_Anes_HighEntities())
            {
                int projectId = Convert.ToInt32(HttpContext.Current.Session[Constants.ProjectId]);
                var list = (from CP in _context.tbl_CPT1_MASTER
                            where projectId == projectId
                            select new SelectListItem
                            {
                                Text = CP.CPT1,
                                Value = CP.CPT1
                            }).ToList();
                return list;
            }
        }
        #endregion

        public PerimeterQCTransactionModel All(int transDetailsId = 0, int transId = 0)
        {
            PerimeterQCTransactionModel model = new PerimeterQCTransactionModel();
            using (CBI_Anes_HighEntities _context = new CBI_Anes_HighEntities())
            {
                var TD = _context.tbl_TRANSACTION_DETAILS.Where(x => x.TRANS_DETAIL_ID == transDetailsId).FirstOrDefault();
                if (TD != null)
                {
                    model.CPT = TD.CPT;
                    model.ICD = TD.ICD;
                    model.Type = TD.ICD_CODE;
                    model.Modifier = TD.MODIFIER;
                    model.Comments = TD.COMMENTS;
                    model.ICD_Results = TD.ICD;
                    model.DowncodedForm = TD.Downcoded;
                    model.HPI = TD.HPI;
                    model.PFSH = TD.PFSH;
                    model.ROS = TD.ROS;
                    model.EXAM = TD.EXAM;
                    model.SelectedICDType = TD.ICD_CODE;
                    model.CPTorder = TD.CPT_ORDER;
                }
            }

            model.ModifierList = ShowModifierList();
            model.StaticCommentsList = StaticCommentsList();
            model.CPTList = CPTList();
            model.DowncodedFormList = DowncodedFormList();
            model.LoadIcdType = LIcdType(transId);
            return model;
        }

        #region GetPerimeterCPTGridData
        public List<PerimeterQCTransactionModel> GetPerimeterCPTGridData(int transId, string accountNumber)
        {
            using (CBI_Anes_HighEntities _context = new CBI_Anes_HighEntities())
            {
                int projectId = Convert.ToInt32(HttpContext.Current.Session[Constants.ProjectId]);

                return (from TD in _context.tbl_TRANSACTION_DETAILS
                        where TD.TRANS_ID == transId
                        select new PerimeterQCTransactionModel
                        {
                            CPTorder=TD.CPT_ORDER,
                            AccountNumber = accountNumber,
                            TRANS_ID = transId,
                            CPT = TD.CPT,
                            Modifier = TD.MODIFIER,
                            ICD = TD.ICD,
                            TRANS_DETAIL_ID = TD.TRANS_DETAIL_ID,
                            DowncodedForm = TD.Downcoded,
                            HPI = TD.HPI,
                            PFSH = TD.PFSH,
                            ROS = TD.ROS,
                            EXAM = TD.EXAM
                        }).OrderBy(x=>x.CPTorder).ToList();
            }
        }
        #endregion

        #region GetSelectedCPT
        public List<SelectListItem> GetSelectedCPT(string CPT)
        {
            using (CBI_Anes_HighEntities _context = new CBI_Anes_HighEntities())
            {
                if (CPT == "CPT1")
                {
                    return (from E in _context.tbl_CPT1_MASTER select new SelectListItem { Text = E.CPT1, Value = E.CPT1 }).ToList();
                }
                else
                {
                    return (from E in _context.tbl_OTHER_CPT_MASTER where E.PROJECT_ID == 16 select new SelectListItem { Text = E.OCPT, Value = E.OCPT }).ToList();
                }
            }
        }
        #endregion

        #region SaveCPTChanges
        public void PerimeterQCAddNewCPT(PerimeterQCTransactionModel model)
        {
            using (CBI_Anes_HighEntities _context = new CBI_Anes_HighEntities())
            {
                var transaction = _context.tbl_TRANSACTION.Where(x => x.TRANS_ID == model.TRANS_ID).FirstOrDefault();
                var tblTransDetails = _context.tbl_TRANSACTION_DETAILS.Where(x => x.TRANS_DETAIL_ID == model.TRANS_DETAIL_ID).FirstOrDefault();
                if (tblTransDetails == null)
                {
                    var Max_TRANS_DETAIL_ID = (from x in _context.tbl_TRANSACTION_DETAILS where (x.TRANS_ID == model.TRANS_ID) select x.TRANS_DETAIL_ID).Max();//
                    var res = (from x in _context.tbl_TRANSACTION_DETAILS where (x.TRANS_DETAIL_ID == Max_TRANS_DETAIL_ID) select x.CPT_ORDER.Remove(0, 3)).FirstOrDefault();//


                    int value = 0;

                    try { value = int.Parse(res); }
                    catch { }

                    string icdres = model.ICD_Results.Trim(';');
                    string[] icdArray = icdres.Split(';');
                    for (int j = 0; j < icdArray.Length; j++)
                    {
                        tbl_TRANSACTION_DETAILS transDetails = new tbl_TRANSACTION_DETAILS();
                        transDetails.TRANS_ID = model.TRANS_ID;
                        transDetails.CPT_LEVEL = model.CPTLevel;
                        transDetails.CPT = model.CPT;
                        transDetails.MODIFIER = model.Modifier == null ? "" : model.Modifier;
                        transDetails.ICD = icdArray[j];
                        transDetails.ICD_CODE = model.Type;
                        transDetails.ICD_RESULT = model.ICD_Results;
                        transDetails.COMMENTS = model.Comments;
                        transDetails.HPI = model.HPI;
                        transDetails.PFSH = model.PFSH;
                        transDetails.ROS = model.ROS;
                        transDetails.EXAM = model.EXAM;
                        transDetails.Downcoded = model.DowncodedForm;
                        transDetails.CPT_ORDER = "CPT" + (value + 1).ToString();

                        _context.tbl_TRANSACTION_DETAILS.Add(transDetails);
                    }
                    //transaction.START_TIME = Convert.ToDateTime(model.CodingStartTime).TimeOfDay;
                    //  transaction.END_TIME = DateTime.Now.TimeOfDay;
                }
                else
                {
                    if (model.PopUpStatus == "Update ICD")
                    {
                        tblTransDetails.CPT_LEVEL = model.CPTLevel;
                        tblTransDetails.ICD = model.ICD_Results;
                        tblTransDetails.ICD_CODE = model.Type;
                        tblTransDetails.ICD_RESULT = model.ICD_Results == null ? model.ICD : model.ICD_Results;
                        var tblTransactionDetails2 = _context.tbl_TRANSACTION_DETAILS.Where(x => x.TRANS_ID == model.TRANS_ID && x.CPT_ORDER == model.CPTorder).ToList();
                        foreach (var item in tblTransactionDetails2)
                        {
                            var tblTransactionDetails = _context.tbl_TRANSACTION_DETAILS.Where(x => x.TRANS_DETAIL_ID == item.TRANS_DETAIL_ID && x.TRANS_ID == model.TRANS_ID && x.CPT_ORDER == model.CPTorder).FirstOrDefault();
                            tblTransactionDetails.CPT = model.CPT;
                            tblTransactionDetails.MODIFIER = model.Modifier == null ? "" : model.Modifier;
                            tblTransactionDetails.COMMENTS = model.Comments;
                            tblTransactionDetails.HPI = model.HPI;
                            tblTransactionDetails.PFSH = model.PFSH;
                            tblTransactionDetails.ROS = model.ROS;
                            tblTransactionDetails.EXAM = model.EXAM;
                            tblTransactionDetails.Downcoded = model.DowncodedForm;
                        }
                    }
                    else
                    {
                        tblTransDetails.CPT_LEVEL = model.CPTLevel;
                        tblTransDetails.CPT = model.CPT;
                        tblTransDetails.MODIFIER = model.Modifier == null ? "" : model.Modifier;
                        tblTransDetails.ICD = model.ICD_Results;
                        tblTransDetails.ICD_CODE = model.Type;
                        tblTransDetails.ICD_RESULT = model.ICD_Results == null ? model.ICD : model.ICD_Results;
                        tblTransDetails.COMMENTS = model.Comments;
                        tblTransDetails.HPI = model.HPI;
                        tblTransDetails.PFSH = model.PFSH;
                        tblTransDetails.ROS = model.ROS;
                        tblTransDetails.EXAM = model.EXAM;
                        tblTransDetails.Downcoded = model.DowncodedForm;
                    }
                    

                    var icdRes = _context.tbl_TRANSACTION_DETAILS.Where(x => x.TRANS_DETAIL_ID == model.TRANS_DETAIL_ID && x.TRANS_ID == model.TRANS_ID).ToList();

                    string icdcodeResult = string.Empty;

                    icdcodeResult = icdRes.Select(query => query.ICD_CODE).Aggregate((a, b) => a + ";" + b);

                    foreach (var item in icdRes)
                    {
                        item.ICD_RESULT = icdcodeResult;

                    }
                }
                _context.SaveChanges();
            }
        }
        #endregion

        #region GetErrorDataDetails
        public List<SelectListItem> GetErrorDataDetails()
        {
            int projectId = Convert.ToInt32(HttpContext.Current.Session[Constants.ProjectId]);
            using (CBI_Anes_HighEntities _context = new CBI_Anes_HighEntities())
            {
                var data = (from E in _context.tbl_ERROR_CATEGORY where E.PROJECT_ID == projectId select new SelectListItem { Text = E.ERROR_CATEGORY, Value = E.ERROR_CATEGORY }).Distinct().ToList();
                var uniqueItems = data.GroupBy(s => s.Value, i => i, (k, item) => new SelectListItem
                {
                    Text = item.First().Text,
                    Value = k,

                }).ToList();
                return uniqueItems;
            }
        }
        #endregion

        #region GetErrorSubCategory

        public List<SelectListItem> GetErrorSubCategory(string errorType)
        {
            int projectId = Convert.ToInt32(HttpContext.Current.Session[Constants.ProjectId]);
            using (CBI_Anes_HighEntities _context = new CBI_Anes_HighEntities())
            {
                return (from E in _context.tbl_ERROR_CATEGORY where E.PROJECT_ID == projectId && E.ERROR_CATEGORY == errorType select new SelectListItem { Text = E.SUB_CATEGORY1, Value = E.E_ID.ToString() }).Distinct().ToList();

            }
        }
        #endregion
        /************************SUBHAJA******************new fileds aaded**************/
        #region GetErrorParameter
        public List<SelectListItem> GetErrorParameter()
        {
            int projectId = Convert.ToInt32(HttpContext.Current.Session[Constants.ProjectId]);
            using (CBI_Anes_HighEntities _context = new CBI_Anes_HighEntities())
            {
                var result = (from E in _context.tbl_Error_Micro_Category select new SelectListItem { Text = E.Parameter, Value = E.Parameter }).ToList();
                var uniqueItems = result.GroupBy(s => s.Value, i => i, (k, item) => new SelectListItem
                {
                    Text = item.First().Text,
                    Value = k,

                }).ToList();
                return uniqueItems;

            }
        }
        #endregion GetErrorParameter

        #region GetErrorSubParameter

        public List<SelectListItem> GetErrorSubParameter(string errorType)
        {
            int projectId = Convert.ToInt32(HttpContext.Current.Session[Constants.ProjectId]);
            using (CBI_Anes_HighEntities _context = new CBI_Anes_HighEntities())
            {
                var result = (from E in _context.tbl_Error_Micro_Category where E.Parameter == errorType select new SelectListItem { Text = E.Sub_Parameter, Value = E.Sub_Parameter }).ToList();
                var uniqueItems = result.GroupBy(s => s.Value, i => i, (k, item) => new SelectListItem
                {
                    Text = item.First().Text,
                    Value = k,

                }).ToList();
                return uniqueItems;
            }
        }
        #endregion

        #region GetErrorMicroCategory

        public List<SelectListItem> GetErrorMicroCategory(string errorType)
        {
            int projectId = Convert.ToInt32(HttpContext.Current.Session[Constants.ProjectId]);
            using (CBI_Anes_HighEntities _context = new CBI_Anes_HighEntities())
            {
                var result = (from E in _context.tbl_Error_Micro_Category where E.Sub_Parameter == errorType select new SelectListItem { Text = E.Micro_Parameter, Value = E.Micro_Parameter }).ToList();
                var uniqueItems = result.GroupBy(s => s.Value, i => i, (k, item) => new SelectListItem
                {
                    Text = item.First().Text,
                    Value = k,

                }).ToList();
                return uniqueItems;
            }
        }
        #endregion
        /************************SUBHAJA******************new fileds aaded**************/
        #region LIcdType
        private List<SelectListItem> LIcdType(int value)
        {
            List<SelectListItem> listItems = new List<SelectListItem>();
            using (CBI_Anes_HighEntities _context = new CBI_Anes_HighEntities())
            {
                var data = (from I in _context.tbl_IMPORT_TABLE
                            join T in _context.tbl_TRANSACTION on I.BATCH_ID equals T.BATCH_ID                            
                            where T.TRANS_ID == value
                            select I.ICD_CODE).FirstOrDefault();

                if (data == "Y")
                {
                    listItems.Add(new SelectListItem { Text = "ICD-9", Value = "ICD-9" });
                    listItems.Add(new SelectListItem { Text = "ICD-10", Value = "ICD-10" });
                }
                else
                {
                    listItems.Add(new SelectListItem { Text = "ICD-10", Value = "ICD-10" });
                }
                return listItems;
            }
        }
        #endregion

        #region UpdateErrorList
        public void UpdateErrorList(List<MedDataQcTransactionModel> model, string listOfAccounts)
        { 
        
        }
        #endregion

        public PerimeterQCTransactionModel LoadPDF(string accountNumber)
        {
            PerimeterQCTransactionModel model = new PerimeterQCTransactionModel();
            model.ListOfAccountPDF = ListOfAccountPDF(accountNumber);
            return model;
        }

        #region ListOfAccountPDF
        private List<string> ListOfAccountPDF(string accountNumber)
        {
            string[] filePaths;
            string PDFFileDestination;
            string[] filelist;

            int count = 0;
            int i = 0;

            //PDFFileDestination = Constants.PDFPath;
            //var Path = Constants.PDFPath;
            PDFFileDestination = HttpContext.Current.Server.MapPath(@"~/PeriMeter_PDF/");
            var Path = HttpContext.Current.Server.MapPath(@"~/PeriMeter_PDF/");
            filePaths = Directory.GetFiles(Path, "*" + accountNumber + "*.tif");
            i = filePaths.Count();
            if (i != 0)
            {
                for (i = 0; filePaths.Count() > i; i++)
                {
                    string directory = filePaths[i].Substring(0, filePaths[i].LastIndexOf('\\'));
                    filelist = Directory.GetFiles(directory, accountNumber+"*.TIF");

                    iTextSharp.text.Document document = new iTextSharp.text.Document(iTextSharp.text.PageSize.A1, 0, 50, 0, 2);
                    string file = filelist[i].Substring(filelist[i].LastIndexOf('\\') + 1);
                    string temp = (PDFFileDestination + file.Replace(".tif", ".pdf").Replace(".tif", ".pdf"));

                    if (!File.Exists(temp))
                    {
                        iTextSharp.text.pdf.PdfWriter writer = iTextSharp.text.pdf.PdfWriter.GetInstance(document, new System.IO.FileStream((PDFFileDestination + file.Replace(".tif", ".pdf")), System.IO.FileMode.Create));
                        //File Source
                        System.Drawing.Bitmap bm = new System.Drawing.Bitmap(filelist[i]);
                        //ImageLoad();
                        int total = bm.GetFrameCount(System.Drawing.Imaging.FrameDimension.Page);
                        document.Open();
                        iTextSharp.text.pdf.PdfContentByte cb = writer.DirectContent;
                        for (int k = 0; k < total; ++k)
                        {
                            bm.SelectActiveFrame(System.Drawing.Imaging.FrameDimension.Page, k);
                            iTextSharp.text.Image img = iTextSharp.text.Image.GetInstance(bm, System.Drawing.Imaging.ImageFormat.Bmp);

                            img.ScalePercent(72f / img.DpiX * 96);

                            img.SetAbsolutePosition(0, 0);
                            cb.AddImage(img);
                            document.NewPage();
                        }
                        document.Close();
                        count++;
                    }
                }
            }
            string[] dirs = Directory.GetFiles(Path, "*" + accountNumber + "*.pdf");
            List<string> listdropdown = new List<string>();
            foreach (string dir in dirs)
            {
                string[] value = dir.Split(new[] { "\\PeriMeter_PDF\\" }, StringSplitOptions.None);
                listdropdown.Add(value[1]);
            }
            return listdropdown;
        }
        #endregion
    }
}