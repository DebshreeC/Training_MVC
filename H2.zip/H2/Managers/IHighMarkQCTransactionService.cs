﻿#region History

//-----------------------------------------------------------------------
// Created By & Created Date : Jagadeesh J & 05/26/2016
// Description: Created QC Transaction Services interface to maintain all the tranction details related to QC.
//-----------------------------------------------------------------------
// Modified By & Modified Date:
// Description:
//-----------------------------------------------------------------------
// Modified By & Modified Date:
// Description:
//-----------------------------------------------------------------------
// Modified By & Modified Date:
// Description:
//-----------------------------------------------------------------------

#endregion

#region Usings

using CBIplus.BAL.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.Mvc;

#endregion

namespace CBIplus.BAL.Managers
{
   public interface IHighMarkQCTransactionService
    {
       HighMarkQCTransactionModel HighMarkQCTransactionModel();

       List<HighMarkQCTransactionModel> GetTrackingGridDataRegularAudit();

       List<HighMarkQCTransactionModel> GetTrackingGridDataRegularAuditForACA();
       
       List<HighMarkQCTransactionModel> GetTrackingGridDataIncrementalHCC();
       
       List<HighMarkQCTransactionModel> GetTrackingGridDataBlind();
       
       List<SelectListItem> GetErrorSubCategory(string errorType);

       string GetErrorSubCategoryWeightage(string errorType, string SubCategory);

       void FinalQcSubmit(string selectedAccounts, string TabText);

       HighMarkQCTransactionModel GetTrackingPopupData(int transId, int transDetailsId, int batchId, string firstName, string lastName, string memberDOB,string codedDate, string codedBy);

       List<SelectListItem> GetEncounterType();

       List<HighMarkQCTransactionModel> LoadQCDXGrid(int batchId);

       void SaveHighMarkQCTransaction(HighMarkQCTransactionModel model, string eodList);

       void SaveFinalStatus(int batchId, string status, string coderComment, string Gender);
       void DeleteDXRow(int transDetailsId);
       
       void UpdateTrackingGridData(HighMarkQCTransactionModel model);

       //string CheckDXCode(string dxvalue);
       List<HighMarkCoderTransactionModel> CheckDXCode(string dxvalue, string dxTp,string memberDOB,string endingDOS);
       ErrorGridModel QcErrorMarking(int transdetaisId);
       List<ErrorGridModel> GetErrorGridData(int transdetailsId);
       void SaveMarkErrorDetails(ErrorGridModel model, string arrayOfIds);
       void DeleteMarkedError(string errorCategory, string subCategory, string errorComments, int transdetailsId);
       string ICDCodeValidation(string dxCode, string EndingDOS, int batchId, string buttonName,int transDetailsID);

       

       
    }
}
