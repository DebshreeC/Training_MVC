﻿using CBIplus.BAL.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.Mvc;

namespace CBIplus.BAL.Managers
{
    public interface ITransactionService
    {
        CoderTransactionModel All(int transDetailsId = 0);
        List<CoderTransactionModel> GetFacilityForTransaction();
        List<SelectListItem> GetFacilityNames();
        List<SelectListItem> getAsaCross(string CPTCode);
        void InsertOrUpdateChartDetails(List<CoderTransactionModel> coder, string status);
        void SaveBatchStatus(List<CoderTransactionModel> coder);
        List<CoderTransactionModel> GetCodedData(string accountNumber);
        void UpdateAccountDetails(CoderTransactionModel model);
        void AddNewCPT(CoderTransactionModel model);
        List<CoderTransactionModel> GetCPTGridData(int transId, string accountNumber);
        void DeleteCPT(int transDetailsId);
        List<SelectListItem> GetPhysacalStatus();
        List<SelectListItem> GetStartTimeDropdown();
        List<SelectListItem> GetEndTimeDropdown();
        List<ProviderCRNAModel> GetAutoProviderNames(string Prefix);
        string CheckIcd(string icd);
    }
}
