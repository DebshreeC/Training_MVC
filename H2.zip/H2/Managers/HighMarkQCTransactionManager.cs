﻿#region History

//-----------------------------------------------------------------------
// Created By & Created Date : Jagadeesh J & 05/26/2016
// Description: Created QC Transaction manager class to maintain all the tranction details related to QC.
//-----------------------------------------------------------------------
// Modified By & Modified Date:
// Description:
//-----------------------------------------------------------------------
// Modified By & Modified Date:
// Description:
//-----------------------------------------------------------------------
// Modified By & Modified Date:
// Description:
//-----------------------------------------------------------------------

#endregion

#region Usings

using CBIplus.BAL.Generics;
using CBIplus.BAL.ViewModels;
using CBIplus.DAL;
using Microsoft.Win32.SafeHandles;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using System.Web.Mvc;
using System.Configuration;
using System.Collections;



#endregion


namespace CBIplus.BAL.Managers
{
    public class HighMarkQCTransactionManager : IHighMarkQCTransactionService
    {
        #region GetTrackingGridDataRegularAudit
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        int PracticeID = Convert.ToInt32(HttpContext.Current.Session[Constants.PracticeID]);


        public List<HighMarkQCTransactionModel> GetTrackingGridDataRegularAudit()
        {
            List<HighMarkQCTransactionModel> listRegAccounts = new List<HighMarkQCTransactionModel>();
            using (CBI_Anes_HighEntities _context = new CBI_Anes_HighEntities())
            {
                int projectId = Convert.ToInt32(HttpContext.Current.Session[Constants.ProjectId]);
                string strUserName = HttpContext.Current.Session[Constants.UserName].ToString();
                int practiceId = Convert.ToInt32(HttpContext.Current.Session[Constants.PracticeID]);

                var RegAccountDetails = _context.UPS_QC_TRANSACTION_AUDITS(strUserName, projectId, "Regular", practiceId).ToList();
                if (RegAccountDetails.Count > 0)
                {
                    listRegAccounts = RegAccountDetails.Select(IncAcc => new HighMarkQCTransactionModel
                    {
                        BatchId = IncAcc.BATCH_ID,
                        TrackingCode = CryptoGraphy.Decrypt(IncAcc.ACCOUNT_NO),
                        MemberGender = IncAcc.MEMBER_GENDER != null ? CryptoGraphy.Decrypt(IncAcc.MEMBER_GENDER) : string.Empty,
                        TRANS_ID = IncAcc.TRANS_ID.ToString(),
                        IsAcknowledge = IncAcc.is_acknowledge == "Y" ? "YES" : "NO",
                        ReleaseReauditStatus = IncAcc.RELEASE_REAUDIT_STATUS == 1 ? "YES" : "NO",
                        CodedDate = IncAcc.CODED_DATE.ToString(),
                        CodedBy=IncAcc.Coded_By.ToUpper(),
                        MemberFirstName = CryptoGraphy.Decrypt(IncAcc.First_Name),
                        MemberLastName = CryptoGraphy.Decrypt(IncAcc.Last_Name),
                        EncounterType = IncAcc.ENCOUNTER_TYPE,
                        ErrorSentDate = IncAcc.ERROR_SENT_DATE.ToString(),  
                        MemberDOB = CryptoGraphy.Decrypt(IncAcc.MEMBER_DOB),
                        QC_ALLOTED_DATE=IncAcc.QC_ALLOTTED_DATE.ToString(),
                        //TotalPages = IncAcc.Total_Pages
                    }).ToList();
                }

                return listRegAccounts.ToList();
            }
        }
        #endregion

        #region 

        public List<HighMarkQCTransactionModel> GetTrackingGridDataRegularAuditForACA()
        {
            //List<HighMarkQCTransactionModel> listRegAccounts = new List<HighMarkQCTransactionModel>();
            using (CBI_Anes_HighEntities _context = new CBI_Anes_HighEntities())
            {
                int projectId = Convert.ToInt32(HttpContext.Current.Session[Constants.ProjectId]);
                int practiceId = Convert.ToInt32(HttpContext.Current.Session[Constants.PracticeID]);
                string userNtlg = HttpContext.Current.Session[Constants.UserName].ToString();
                
                var listResult = (from I in _context.tbl_IMPORT_TABLE
                                  join T in _context.tbl_TRANSACTION on I.BATCH_ID equals T.BATCH_ID
                                  //join TD in _context.tbl_TRANSACTION_DETAILS on T.TRANS_ID equals TD.TRANS_ID
                                  where I.PROJECT_ID == projectId && I.PRACTICE_ID == practiceId && I.QC_ALLOTTED_BY == userNtlg
                                  && I.BATCH_STATUS == "QC Allotted" //&& T.QC_STATUS == "QC Allotted"
                                  select new
                                  {
                                      I.BATCH_ID,
                                      I.ACCOUNT_NO,
                                      I.MEMBER_GENDER,
                                      T.TRANS_ID,
                                      T.IS_ACKNOWLEDGE,
                                      T.RELEASE_REAUDIT_STATUS,
                                      T.CODED_DATE,
                                      T.CODED_BY,
                                      I.First_Name,
                                      I.Last_Name,
                                      I.BATCH_NAME,
                                      I.ENCOUNTER_TYPE,
                                      T.ERROR_SENT_DATE,
                                      I.MEMBER_DOB,
                                      I.QC_ALLOTTED_DATE,
                                      T.Total_Pages,
                                      T.Financial_Impact
                                  }).ToList();
                var listRegAccounts = (from item in listResult
                                 select new HighMarkQCTransactionModel
                                 {
                                     BatchId = item.BATCH_ID,
                                     TrackingCode = CryptoGraphy.Decrypt(item.ACCOUNT_NO),
                                     MemberGender = item.MEMBER_GENDER != null ? CryptoGraphy.Decrypt(item.MEMBER_GENDER) : string.Empty,
                                     TRANS_ID = item.TRANS_ID.ToString(),
                                     IsAcknowledge = item.IS_ACKNOWLEDGE == "Y" ? "YES" : "NO",
                                     ReleaseReauditStatus = item.RELEASE_REAUDIT_STATUS == 1 ? "YES" : "NO",
                                     CodedDate = item.CODED_DATE.ToString(),
                                     CodedBy = item.CODED_BY,
                                     MemberFirstName = CryptoGraphy.Decrypt(item.First_Name),
                                     MemberLastName = CryptoGraphy.Decrypt(item.Last_Name),
                                     BatchName = CryptoGraphy.Decrypt(item.BATCH_NAME),
                                     EncounterType = item.ENCOUNTER_TYPE,
                                     ErrorSentDate = item.ERROR_SENT_DATE.ToString(),
                                     MemberDOB = CryptoGraphy.Decrypt(item.MEMBER_DOB),
                                     QC_ALLOTED_DATE=item.QC_ALLOTTED_DATE.ToString(),
                                     TotalPages = Convert.ToInt32(item.Total_Pages),
                                     FinancialImpact=item.Financial_Impact
                                 }).ToList();

                //var RegAccountDetails = _context.UPS_QC_TRANSACTION_AUDITS(strUserName, projectId, "Regular", practiceId).ToList();
                //if (RegAccountDetails.Count > 0)
                //{
                //    listRegAccounts = RegAccountDetails.Select(IncAcc => new HighMarkQCTransactionModel
                //    {
                        //BatchId = IncAcc.BATCH_ID,
                        //TrackingCode = CryptoGraphy.Decrypt(IncAcc.ACCOUNT_NO),
                        //MemberGender = IncAcc.MEMBER_GENDER != null ? CryptoGraphy.Decrypt(IncAcc.MEMBER_GENDER) : string.Empty,
                        //TRANS_ID = IncAcc.TRANS_ID.ToString(),
                        //IsAcknowledge = IncAcc.is_acknowledge == "Y" ? "YES" : "NO",
                        //ReleaseReauditStatus = IncAcc.RELEASE_REAUDIT_STATUS == 1 ? "YES" : "NO",
                        //CodedDate = IncAcc.CODED_DATE.ToString(),
                        //MemberFirstName = CryptoGraphy.Decrypt(IncAcc.First_Name),
                        //MemberLastName = CryptoGraphy.Decrypt(IncAcc.Last_Name),
                        //EncounterType = IncAcc.ENCOUNTER_TYPE,
                        //ErrorSentDate = IncAcc.ERROR_SENT_DATE.ToString(),
                        //MemberDOB = CryptoGraphy.Decrypt(IncAcc.MEMBER_DOB)

                //    }).ToList();
                //}

                return listRegAccounts.ToList();
            }
        }
        #endregion

        #region GetTrackingGridDataIncrementalHCC
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public List<HighMarkQCTransactionModel> GetTrackingGridDataIncrementalHCC()
        {
            List<HighMarkQCTransactionModel> listIncAccounts = new List<HighMarkQCTransactionModel>();
            using (CBI_Anes_HighEntities _context = new CBI_Anes_HighEntities())
            {
                int projectId = Convert.ToInt32(HttpContext.Current.Session[Constants.ProjectId]);
                string strUserName = HttpContext.Current.Session[Constants.UserName].ToString();
                int practiceId = Convert.ToInt32(HttpContext.Current.Session[Constants.PracticeID]);
                try
                {
                    var IncAccountDetails = _context.UPS_QC_TRANSACTION_AUDITS(strUserName, projectId, "incremental", practiceId).ToList();
                    if (IncAccountDetails.Count > 0)
                    {
                        listIncAccounts = IncAccountDetails.Select(IncAcc => new HighMarkQCTransactionModel
                        {
                            BatchId = IncAcc.BATCH_ID,
                            TrackingCode = CryptoGraphy.Decrypt(IncAcc.ACCOUNT_NO),
                            MemberGender = IncAcc.MEMBER_GENDER != null ? CryptoGraphy.Decrypt(IncAcc.MEMBER_GENDER) : string.Empty,
                            TRANS_ID = IncAcc.TRANS_ID.ToString(),
                            CodedDate = IncAcc.CODED_DATE.ToString(),
                            CodedBy=IncAcc.Coded_By,
                            MemberFirstName = CryptoGraphy.Decrypt(IncAcc.First_Name),
                            MemberLastName = CryptoGraphy.Decrypt(IncAcc.Last_Name),
                            EncounterType = IncAcc.ENCOUNTER_TYPE,
                            IsAcknowledge = IncAcc.is_acknowledge == "Y" ? "YES" : "NO",
                            ReleaseReauditStatus = IncAcc.RELEASE_REAUDIT_STATUS == 1 ? "YES" : "NO",
                            ErrorSentDate = IncAcc.ERROR_SENT_DATE.ToString(),
                            MemberDOB =  CryptoGraphy.Decrypt(IncAcc.MEMBER_DOB)
                        }).ToList();
                    }
                    var test = listIncAccounts.ToList();
                    return listIncAccounts;
                }
                catch (Exception e)
                {
                    throw e;
                }

            }
        }
        #endregion


        #region GetTrackingGridDataBlind
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public List<HighMarkQCTransactionModel> GetTrackingGridDataBlind()
        {
            using (CBI_Anes_HighEntities _context = new CBI_Anes_HighEntities())
            {
                int projectId = Convert.ToInt32(HttpContext.Current.Session[Constants.ProjectId]);
                string strUserName = HttpContext.Current.Session[Constants.UserName].ToString();
                var listResult = (from I in _context.tbl_IMPORT_TABLE
                                  join IHDM in _context.tbl_IMPORT_HCC_DXCODE_MASTER on I.ECI equals IHDM.ECI
                                  join T in _context.tbl_TRANSACTION on I.BATCH_ID equals T.BATCH_ID
                                  join TD in _context.tbl_TRANSACTION_DETAILS on T.TRANS_ID equals TD.TRANS_ID
                                  where (IHDM.DX_CODE == TD.ICD) && (IHDM.DX_TYPE.ToString() == TD.ICD_CODE.ToString()) && (I.PROJECT_ID == projectId)
                                  && (I.ECI == IHDM.ECI)
                                  && (T.IS_SKIPPED == 1)
                                  && (I.PROJECT_ID == IHDM.PROJECT_ID)
                                  && (I.QC_ALLOTTED_BY == strUserName)
                                  && (I.BATCH_STATUS == "QC")
                                  && (T.QC_STATUS == "Qced")
                                  select new
                                  {
                                      I.BATCH_ID,
                                      I.ACCOUNT_NO,
                                      TD.IS_ACKNOWLEDGE,
                                      T.RELEASE_REAUDIT_STATUS,
                                      T.ERROR_SENT_DATE
                                  }).ToList();
                var finalList = (from item in listResult
                                 select new HighMarkQCTransactionModel
                                 {
                                     BatchId = item.BATCH_ID,
                                     TrackingCode = item.ACCOUNT_NO,
                                     IsAcknowledge = item.IS_ACKNOWLEDGE == "Y" ? "YES" : "NO",
                                     ReleaseReauditStatus = item.RELEASE_REAUDIT_STATUS == 1 ? "YES" : "NO",
                                     ErrorSentDate = item.ERROR_SENT_DATE.ToString()
                                 }).ToList();
                var Res = finalList.ToList();
                if (Res.Count > 0)
                {
                    string webKey = ConfigurationSettings.AppSettings["SkippedPercentage"].ToString();
                    Decimal value = Convert.ToDecimal((Convert.ToDecimal(ConfigurationSettings.AppSettings["SkippedPercentage"].ToString()) * Res.Count) / 100);
                    Res = Res.Take(Convert.ToInt32(value)).ToList();
                }
                return Res;
            }
        }
        #endregion

        #region Get Status Nammes
        public List<SelectListItem> GetStatusNames()
        {
            using (CBI_Anes_HighEntities _context = new CBI_Anes_HighEntities())
            {
                var list = (from status in _context.tbl_STATUS_MASTER
                            select new SelectListItem
                            {
                                Text = status.STATUS_TYPE,
                                Value = status.STATUS_ID.ToString()
                            }).ToList();
                return list;
            }
        }
        #endregion

        #region GetErrorDataDetails
        public List<SelectListItem> GetErrorDataDetails()
        {
            int projectId = Convert.ToInt32(HttpContext.Current.Session[Constants.ProjectId]);
            using (CBI_Anes_HighEntities _context = new CBI_Anes_HighEntities())
            {
                var data = (from E in _context.tbl_ERROR_CATEGORY where E.PROJECT_ID == projectId select new SelectListItem { Text = E.ERROR_CATEGORY, Value = E.ERROR_CATEGORY }).Distinct().ToList();
                var uniqueItems = data.GroupBy(s => s.Value, i => i, (k, item) => new SelectListItem
                {
                    Text = item.First().Text,
                    Value = k,

                }).ToList();
                return uniqueItems;
            }
        }
        #endregion

        #region GetErrorSubCategory

        public List<SelectListItem> GetErrorSubCategory(string errorType)
        {
            int projectId = Convert.ToInt32(HttpContext.Current.Session[Constants.ProjectId]);
            using (CBI_Anes_HighEntities _context = new CBI_Anes_HighEntities())
            {
                // return (from E in _context.tbl_ERROR_CATEGORY where E.PROJECT_ID == projectId select new SelectListItem { Text = E.SUB_CATEGORY1, Value = E.E_ID.ToString() }).ToList();
                return (from E in _context.tbl_ERROR_CATEGORY where E.PROJECT_ID == projectId && E.ERROR_CATEGORY == errorType select new SelectListItem { Text = E.SUB_CATEGORY1, Value = E.E_ID.ToString() }).ToList();

            }
        }
        #endregion

        #region GetErrorSubCategory

        public string GetErrorSubCategoryWeightage(string errorType, string SubCategory)
        {
            int projectId = Convert.ToInt32(HttpContext.Current.Session[Constants.ProjectId]);
            using (CBI_Anes_HighEntities _context = new CBI_Anes_HighEntities())
            {
                var list = _context.tbl_ERROR_CATEGORY.Where(E => E.PROJECT_ID == projectId && E.ERROR_CATEGORY == errorType && E.E_ID.ToString() == SubCategory).Select(E => E.ERROR_WEIGHTAGE).FirstOrDefault();
                return list;
            }
        }
        #endregion

        #region HighMarkQCTransactionModel
        public HighMarkQCTransactionModel HighMarkQCTransactionModel()
        {
            HighMarkQCTransactionModel model = new HighMarkQCTransactionModel();
            int practiceId = Convert.ToInt32(HttpContext.Current.Session[Constants.PracticeID]);
            model.ErrorList = GetErrorDataDetails();
            model.DXTypeList = StaticDXTypeList();
            model.Practice_Id = practiceId;
            model.CommentsList = CommentList();
            return model;
        }
        #endregion

        #region CommentList
        private static List<SelectListItem> CommentList()
        {
            using (CBI_Anes_HighEntities _context = new CBI_Anes_HighEntities())
            {
                int projectId = Convert.ToInt32(HttpContext.Current.Session[Constants.ProjectId]);

                var list = (from comments in _context.tbl_COMMENT_MASTER
                            where comments.PROJECT_ID == projectId.ToString()
                            select new SelectListItem
                            {
                                Text = comments.COMMENT_NAME,
                                Value = comments.COMMENT_NAME
                            }).ToList();
                return list;
            }
        }
        #endregion

        public ErrorGridModel QcErrorMarking(int transdetaisId)
        {
            ErrorGridModel model = new ErrorGridModel();
            model.ErrorList = GetErrorDataDetails();
            model.QCErrorCorrectionList = StaticErrorStatus();
            model.TransDetailsId=transdetaisId;
            return model;
        }
        public void SaveMarkErrorDetails(ErrorGridModel model, string arrayOfIds)
        {
            int ErrCount;
            string ErrCunt;

            using (CBI_Anes_HighEntities _context = new CBI_Anes_HighEntities())
            {
                if (!string.IsNullOrEmpty(arrayOfIds))
                {

                    List<string> listOfIds = arrayOfIds.Split(',').ToList();
                    List<int> myStringList = listOfIds.Select(s => int.Parse(s)).ToList();
                    _context.tbl_TRANSACTION_DETAILS.Where(x => myStringList.Contains(x.TRANS_DETAIL_ID)).ToList().ForEach(x =>
                    {
                        if (!string.IsNullOrEmpty(x.ERROR_CATEGORY))
                        {
                            ErrCunt = x.ERROR_CATEGORY.Split('*').Last().Split('_').First().ToString();
                            ErrCount = Convert.ToInt32(ErrCunt) + 1;
                        }
                        else
                        {
                            ErrCount = 1;
                        }
                       
                        x.ERROR_CATEGORY = !string.IsNullOrEmpty(x.ERROR_CATEGORY) ? x.ERROR_CATEGORY + "*" + ErrCount + "_" + model.QCErrorCategory :  ErrCount + "_"+ model.QCErrorCategory;
                        x.ERROR_SUBCATEGORY = !string.IsNullOrEmpty(x.ERROR_SUBCATEGORY) ? x.ERROR_SUBCATEGORY + "*" + ErrCount + "_" + model.QCErrorSubCategory : ErrCount + "_" + model.QCErrorSubCategory;
                        x.Error_Correction = model.QCErrorCorrection;
                        x.QC_COMMENTS = !string.IsNullOrEmpty(x.QC_COMMENTS) ? x.QC_COMMENTS + "*" + ErrCount + "_" +model.QCErrorComments : ErrCount + "_"  +model.QCErrorComments;
                        x.Error_Count = "1";
                    });
                   
                }
                else
                {
                    var data = _context.tbl_TRANSACTION_DETAILS.Where(x => x.TRANS_DETAIL_ID == model.TransDetailsId).FirstOrDefault();

                    if (!string.IsNullOrEmpty(data.ERROR_CATEGORY))
                    {
                        ErrCunt = data.ERROR_CATEGORY.Split('*').Last().Split('_').First().ToString();
                        ErrCount = Convert.ToInt32(ErrCunt) + 1;
                    }
                    else
                    {
                        ErrCount = 1;
                    }
                        data.ERROR_CATEGORY = !string.IsNullOrEmpty(data.ERROR_CATEGORY) ? data.ERROR_CATEGORY + "*" + ErrCount + "_" + model.QCErrorCategory : ErrCount + "_" + model.QCErrorCategory;
                        data.ERROR_SUBCATEGORY = !string.IsNullOrEmpty(data.ERROR_SUBCATEGORY) ? data.ERROR_SUBCATEGORY + "*" + ErrCount + "_" + model.QCErrorSubCategory : ErrCount + "_" + model.QCErrorSubCategory;
                        data.Error_Correction = model.QCErrorCorrection;
                        data.QC_COMMENTS = !string.IsNullOrEmpty(data.QC_COMMENTS) ? data.QC_COMMENTS + "*" + ErrCount + "_"+model.QCErrorComments : ErrCount + "_"+model.QCErrorComments;
                        data.Error_Count = "1";
                }
                _context.SaveChanges();
            }
        }
        public List<ErrorGridModel> GetErrorGridData(int transdetailsId) 
        {
            using (CBI_Anes_HighEntities _context = new CBI_Anes_HighEntities())
            {
                List<ErrorGridModel> list = new List<ErrorGridModel>();
                var data = (from item in _context.tbl_TRANSACTION_DETAILS.Where(x => x.TRANS_DETAIL_ID == transdetailsId) select new {item.ERROR_CATEGORY,item.Error_Correction,item.ERROR_SUBCATEGORY,item.QC_COMMENTS }).FirstOrDefault();
                if (data.ERROR_CATEGORY!=null)
                {
                string[] errorCategory = data.ERROR_CATEGORY.Split('*');
                string[] subCategory = data.ERROR_SUBCATEGORY.Split('*');
                string errorCorrection = data.Error_Correction;
                string[] errorComments = data.QC_COMMENTS.Split('*');
                for (int i = 0; i < errorCategory.Length; i++)
                {
                    ErrorGridModel model = new ErrorGridModel();
                    model.QCErrorCategory = errorCategory[i];
                    model.QCErrorSubCategory = subCategory[i];
                    model.QCErrorCorrection = errorCorrection=="Y"?"QA Corrected":"Coder to correct";
                    //model.QCErrorComments = errorComments[i]!=null?errorComments[i]:"";
                    model.QCErrorComments = errorComments[i];
                    model.TransDetailsId = transdetailsId;
                    list.Add(model);
                }
                }
                return list; 
            }
        }
        public void DeleteMarkedError(string errorCategory,string subCategory,string errorComments,int transdetailsId)
        {
            using (CBI_Anes_HighEntities _context = new CBI_Anes_HighEntities())
            {
                var data = _context.tbl_TRANSACTION_DETAILS.Where(x => x.TRANS_DETAIL_ID == transdetailsId).FirstOrDefault();

                string StrVal = data.ERROR_CATEGORY.Split('_').First().ToString();

                if (errorCategory.Contains(StrVal))
                {
                    data.Error_Correction = data.ERROR_CATEGORY.Contains('*') ? data.Error_Correction : null;
                    data.Error_Count = data.ERROR_CATEGORY.Contains('*') ? data.Error_Count : "0";
                    data.ERROR_CATEGORY = data.ERROR_CATEGORY.Contains('*') ? data.ERROR_CATEGORY.Replace(errorCategory, "").Trim('*') : null;
                    data.ERROR_SUBCATEGORY = data.ERROR_SUBCATEGORY.Contains('*') ? data.ERROR_SUBCATEGORY.Replace(subCategory, "").Trim('*') : null;
                    data.QC_COMMENTS = data.QC_COMMENTS.Contains('*') ? data.QC_COMMENTS.Replace( errorComments, "").Trim('*') : null;

                }
                else
                {
                    data.Error_Correction = data.ERROR_CATEGORY.Contains('*') ? data.Error_Correction : null;
                    data.Error_Count = data.ERROR_CATEGORY.Contains('*') ? data.Error_Count : "0";
                    data.ERROR_CATEGORY = data.ERROR_CATEGORY.Contains('*') ? data.ERROR_CATEGORY.Replace("*" + errorCategory, "").Trim('*') : null;
                    data.ERROR_SUBCATEGORY = data.ERROR_SUBCATEGORY.Contains('*') ? data.ERROR_SUBCATEGORY.Replace("*"+subCategory, "").Trim('*') : null;
                    data.QC_COMMENTS = data.QC_COMMENTS.Contains('*') ? data.QC_COMMENTS.Replace('*' + errorComments, "").Trim('*') : null;
                }
                _context.SaveChanges();
            }
        }

        #region GetEncounter Type
        public List<SelectListItem> GetEncounterType()
        {
            using (CBI_Anes_HighEntities _context = new CBI_Anes_HighEntities())
            {
                int projectId = Convert.ToInt32(HttpContext.Current.Session[Constants.ProjectId]);

                var list = (from encounterType in _context.TBL_ENCOUNTER_TYPE_MASTER
                            where encounterType.PROJECT_ID == projectId
                            select new SelectListItem
                            {
                                Text = encounterType.ENCOUNTER_TYPE,
                                Value = encounterType.EN_ID.ToString()
                            }).ToList();
                return list;
            }
        }
        #endregion

        #region SaveFinalStatus
        public void SaveFinalStatus(int batchId, string status, string coderComment, string Gender)
        {
            using (CBI_Anes_HighEntities _context = new CBI_Anes_HighEntities())
            {
                var import = _context.tbl_IMPORT_TABLE.Where(x => x.BATCH_ID == batchId).FirstOrDefault();
                var trans = _context.tbl_TRANSACTION.Where(x => x.BATCH_ID == batchId).FirstOrDefault();
                if (import != null && trans != null)
                {
                    import.BATCH_STATUS = "Coded";
                    trans.QC_STATUS = null;
                    if (status == "Completed")
                    {
                        trans.CODING_STATUS = "Coded";
                    }
                    else
                    {
                        trans.CODING_STATUS = status;
                    }
                   // import.MEMBER_GENDER =!string.IsNullOrEmpty(Gender)? CryptoGraphy.Encrypt(Gender):CryptoGraphy.Encrypt(string.Empty);
                    trans.CODING_COMMENTS = coderComment;
                    trans.CODING_ENDTIME = System.DateTime.Now;
                    _context.SaveChanges();
                }
            }
        }
        #endregion

        #region DeleteDXRow

        public void DeleteDXRow(int transDetailsId)
        {
            using (CBI_Anes_HighEntities _context = new CBI_Anes_HighEntities())
            {
                var transDetails = _context.tbl_TRANSACTION_DETAILS.Where(x => x.TRANS_DETAIL_ID == transDetailsId).FirstOrDefault();
                var transaction = _context.tbl_TRANSACTION.Where(x => x.TRANS_ID == transDetails.TRANS_ID).FirstOrDefault();
                if (transDetails != null)
                {
                    var transDetailsCount = _context.tbl_TRANSACTION_DETAILS.Where(x => x.TRANS_ID == transDetails.TRANS_ID).Count();
                    if (transDetailsCount>1)
                    {
                        _context.tbl_TRANSACTION_DETAILS.Remove(transDetails);
                    }
                    #region Insert Transaction History

                    tbl_TRANSACTION_HISTORY objtbl_TRANSACTION_HISTORY = new tbl_TRANSACTION_HISTORY();

                    objtbl_TRANSACTION_HISTORY.TRANS_ID = Convert.ToInt32(transaction.TRANS_ID);
                    //objtbl_TRANSACTION_HISTORY.TYPE_OF_ACCIDENT = transaction.typeofde;
                    objtbl_TRANSACTION_HISTORY.PROJECT_ID = transaction.PROJECT_ID;
                    objtbl_TRANSACTION_HISTORY.BATCH_ID = transaction.BATCH_ID;
                    //objtbl_TRANSACTION_HISTORY.INSURANCE = transaction.INSURANCE;
                    objtbl_TRANSACTION_HISTORY.ADMITTING_PHY = transaction.ADMITTING_PHY;
                    objtbl_TRANSACTION_HISTORY.ATTENDING_PHY = transaction.ATTENDING_PHY;
                    objtbl_TRANSACTION_HISTORY.EDMD = transaction.EDMD;
                    objtbl_TRANSACTION_HISTORY.DOI = transaction.DOI;
                    objtbl_TRANSACTION_HISTORY.TOI = transaction.TOI;
                    objtbl_TRANSACTION_HISTORY.CHART_NO = transaction.CHART_NO;
                    //objtbl_TRANSACTION_HISTORY.PAGE_NO = transaction.PAGE_NO;
                    objtbl_TRANSACTION_HISTORY.CODING_COMMENTS = transaction.CODING_COMMENTS;
                    objtbl_TRANSACTION_HISTORY.CODED_DATE = transaction.CODED_DATE;
                    objtbl_TRANSACTION_HISTORY.CODED_BY = transaction.CODED_BY;
                    objtbl_TRANSACTION_HISTORY.UPDATED_BY = transaction.UPDATED_BY;
                    objtbl_TRANSACTION_HISTORY.UPDATED_DATE = transaction.UPDATED_DATE;
                    objtbl_TRANSACTION_HISTORY.CODING_STATUS = transaction.CODING_STATUS;
                    objtbl_TRANSACTION_HISTORY.QC_BY = HttpContext.Current.Session[Constants.UserName].ToString();
                    objtbl_TRANSACTION_HISTORY.QC_DATE = DateTime.Now;
                    objtbl_TRANSACTION_HISTORY.QC_STATUS = transaction.QC_STATUS;

                    if (!string.IsNullOrEmpty(objtbl_TRANSACTION_HISTORY.QC_COMMENTS))
                        objtbl_TRANSACTION_HISTORY.QC_COMMENTS = ";" + transaction.QC_COMMENTS;
                    else
                        objtbl_TRANSACTION_HISTORY.QC_COMMENTS = transaction.QC_COMMENTS + ";";

                    if (!string.IsNullOrEmpty(objtbl_TRANSACTION_HISTORY.ERROR_SUBCATEGORY))
                        objtbl_TRANSACTION_HISTORY.ERROR_SUBCATEGORY = ";" + transaction.ERROR_SUBCATEGORY;
                    else
                        objtbl_TRANSACTION_HISTORY.ERROR_SUBCATEGORY = transaction.ERROR_SUBCATEGORY + ";";

                    if (!string.IsNullOrEmpty(objtbl_TRANSACTION_HISTORY.ERROR_CATEGORY))
                        objtbl_TRANSACTION_HISTORY.ERROR_CATEGORY = ";" + transaction.ERROR_CATEGORY;
                    else
                        objtbl_TRANSACTION_HISTORY.ERROR_CATEGORY = transaction.ERROR_CATEGORY + ";";

                    objtbl_TRANSACTION_HISTORY.QC_ERROR_CORRECTION = transaction.QC_ERROR_CORRECTION;
                    objtbl_TRANSACTION_HISTORY.IS_ACKNOWLEDGE = transaction.IS_ACKNOWLEDGE;
                    objtbl_TRANSACTION_HISTORY.ACKNOWLEDGE_COMMENTS = transaction.ACKNOWLEDGE_COMMENTS;
                    objtbl_TRANSACTION_HISTORY.PROVIDER_MD = transaction.PROVIDER_MD;
                    objtbl_TRANSACTION_HISTORY.ASSISTANT_PROVIDER = transaction.ASSISTANT_PROVIDER;
                    objtbl_TRANSACTION_HISTORY.DISPOSITION = transaction.DISPOSITION;
                    objtbl_TRANSACTION_HISTORY.PATIENT_STATUS = transaction.PATIENT_STATUS;
                    objtbl_TRANSACTION_HISTORY.TYPE_OF_ACCIDENT = transaction.TYPE_OF_ACCIDENT;
                    objtbl_TRANSACTION_HISTORY.ACCOUNT_STATUS = transaction.ACCOUNT_STATUS;
                    objtbl_TRANSACTION_HISTORY.DOS_CHANGED = transaction.DOS_CHANGED;
                    objtbl_TRANSACTION_HISTORY.IS_AUDITED = transaction.IS_AUDITED;
                    objtbl_TRANSACTION_HISTORY.PENDING_UPDATED_BY = transaction.PENDING_UPDATED_BY;
                    objtbl_TRANSACTION_HISTORY.W_O_ATTESTATION = transaction.W_O_ATTESTATION;
                    objtbl_TRANSACTION_HISTORY.IS_ACKNOWLEDGE_BY = transaction.IS_ACKNOWLEDGE_BY;
                    objtbl_TRANSACTION_HISTORY.IS_SKIPPED = transaction.IS_SKIPPED;
                    objtbl_TRANSACTION_HISTORY.IS_REOPENED = transaction.IS_REOPENED;
                    objtbl_TRANSACTION_HISTORY.KEYING_COMMENTS = transaction.KEYING_COMMENTS;
                    objtbl_TRANSACTION_HISTORY.AR_STATUS = transaction.AR_STATUS;
                    objtbl_TRANSACTION_HISTORY.DOS = transaction.DOS;
                    objtbl_TRANSACTION_HISTORY.IS_PENDING = transaction.IS_PENDING;
                    objtbl_TRANSACTION_HISTORY.RESPONSIBILITY = transaction.RESPONSIBILITY;
                    objtbl_TRANSACTION_HISTORY.SEND_TO_CLIENT_DATE = transaction.SEND_TO_CLIENT_DATE;
                    objtbl_TRANSACTION_HISTORY.CLIENT_RESPONSE = transaction.CLIENT_RESPONSE;
                    objtbl_TRANSACTION_HISTORY.CLIENT_RESPONSE_DATE = transaction.CLIENT_RESPONSE_DATE;
                    objtbl_TRANSACTION_HISTORY.PENDING_UPDAED_DATE = transaction.PENDING_UPDAED_DATE;
                    objtbl_TRANSACTION_HISTORY.PENDING_WORKED_DATE = transaction.PENDING_WORKED_DATE;
                    objtbl_TRANSACTION_HISTORY.NPPA = transaction.NPPA;
                    objtbl_TRANSACTION_HISTORY.SCRIBE = transaction.SCRIBE;
                    objtbl_TRANSACTION_HISTORY.RESIDENT = transaction.RESIDENT;
                    objtbl_TRANSACTION_HISTORY.START_TIME = transaction.START_TIME;
                    objtbl_TRANSACTION_HISTORY.END_TIME = transaction.END_TIME;
                    objtbl_TRANSACTION_HISTORY.TOTAL_TIME = transaction.TOTAL_TIME;
                    objtbl_TRANSACTION_HISTORY.ANES_TYPE = transaction.ANES_TYPE;
                    objtbl_TRANSACTION_HISTORY.PHYSICAL_STATUS = transaction.PHYSICAL_STATUS;
                    objtbl_TRANSACTION_HISTORY.PATIENT_NAME = transaction.PATIENT_NAME;
                    objtbl_TRANSACTION_HISTORY.CODING_STARTTIME = transaction.CODING_STARTTIME;
                    objtbl_TRANSACTION_HISTORY.CODING_ENDTIME = transaction.CODING_ENDTIME;
                    if (!string.IsNullOrEmpty(objtbl_TRANSACTION_HISTORY.ERROR_WEIGHTAGE))
                        objtbl_TRANSACTION_HISTORY.ERROR_WEIGHTAGE = ";" + transaction.ERROR_WEIGHTAGE;
                    else
                        objtbl_TRANSACTION_HISTORY.ERROR_WEIGHTAGE = transaction.ERROR_WEIGHTAGE + ";";
                    objtbl_TRANSACTION_HISTORY.IS_ACKNOWLEDGE_DATE = transaction.IS_ACKNOWLEDGE_DATE;

                    if (transaction.ERROR_SENT_DATE == null)
                        objtbl_TRANSACTION_HISTORY.ERROR_SENT_DATE = DateTime.Now;
                    else
                        objtbl_TRANSACTION_HISTORY.ERROR_SENT_DATE = transaction.ERROR_SENT_DATE;

                    objtbl_TRANSACTION_HISTORY.RELEASE_REAUDIT_STATUS = transaction.RELEASE_REAUDIT_STATUS;
                    objtbl_TRANSACTION_HISTORY.RELEASE_REAUDIT_BY = transaction.RELEASE_REAUDIT_BY;
                    objtbl_TRANSACTION_HISTORY.RELEASE_REAUDIT_DATE = transaction.RELEASE_REAUDIT_DATE;
                    objtbl_TRANSACTION_HISTORY.ACTIONS_PERFORMED = "DELETE";

                    _context.tbl_TRANSACTION_HISTORY.Add(objtbl_TRANSACTION_HISTORY);
                    #endregion

                    #region Insert TRANSACTION DETAILS HISTORY

                    tbl_TRANSACTION_DETAILS_HISTORY transDetailsHis = new tbl_TRANSACTION_DETAILS_HISTORY();

                    transDetailsHis.TRANS_DETAIL_ID = transDetails.TRANS_DETAIL_ID;
                    transDetailsHis.TRANS_ID = transaction.TRANS_ID;
                    transDetailsHis.CPT = transDetails.CPT;
                    transDetailsHis.ICD = transDetails.ICD;
                    transDetailsHis.MODIFIER = transDetails.MODIFIER;
                    transDetailsHis.UNITS = transDetails.UNITS;
                    transDetailsHis.COMMENTS = transDetails.COMMENTS;
                    transDetailsHis.UPDATED_BY = transaction.UPDATED_BY;
                    transDetailsHis.UPDATED_DATE = transaction.UPDATED_DATE;
                    transDetailsHis.QC_BY = transaction.QC_BY;
                    transDetailsHis.QC_DATE = transaction.QC_DATE;
                    transDetailsHis.QC_STATUS = transaction.QC_STATUS;
                    transDetailsHis.ERROR_CATEGORY = transaction.ERROR_CATEGORY;
                    transDetailsHis.ERROR_SUBCATEGORY = transaction.ERROR_SUBCATEGORY;
                    transDetailsHis.QC_COMMENTS = transaction.QC_COMMENTS;
                    transDetailsHis.IS_ACKNOWLEDGE = transaction.IS_ACKNOWLEDGE;
                    transDetailsHis.ACKNOWLEDGE_COMMENTS = transaction.ACKNOWLEDGE_COMMENTS;
                    transDetailsHis.ICD_RESULT = transDetails.ICD_RESULT;
                    transDetailsHis.DOWNLOADING_COMMENTS = transDetails.DOWNLOADING_COMMENTS;
                    transDetailsHis.DEFICIENCY_INDICATOR = transDetails.DEFICIENCY_INDICATOR;
                    transDetailsHis.ACCOUNT_STATUS = transaction.ACCOUNT_STATUS;
                    transDetailsHis.CPT_ORDER = transDetails.CPT_ORDER;
                    transDetailsHis.PROVIDER_MD = transDetails.PROVIDER_MD;
                    transDetailsHis.ASSISTANT_PROVIDER = transDetails.ASSISTANT_PROVIDER;
                    transDetailsHis.CPT_LEVEL = transDetails.CPT_LEVEL;
                    transDetailsHis.ICD_CODE = transDetails.ICD_CODE;
                    transDetailsHis.ASA_CROSS = transDetails.ASA_CROSS;
                    transDetailsHis.ANCILLARY_SERVICES = transDetails.ANCILLARY_SERVICES;
                    transDetailsHis.ANCILLARY_MODIFIER = transDetails.ANCILLARY_MODIFIER;
                    transDetailsHis.ACUTE_PAIN_CPT = transDetails.ACUTE_PAIN_CPT;
                    transDetailsHis.ACUTE_PAIN_DX = transDetails.ACUTE_PAIN_DX;
                    transDetailsHis.ACUTE_PAIN_POS = transDetails.ACUTE_PAIN_POS;
                    transDetailsHis.PQRS = transDetails.PQRS;
                    transDetailsHis.MEDICAL_DIRECTION = transDetails.MEDICAL_DIRECTION;
                    transDetailsHis.ANCILLARY_SERVICE_PROVIDERS = transDetails.ANCILLARY_SERVICE_PROVIDERS;
                    transDetailsHis.QUALIFYING_CIRCUMSTANCES = transDetails.QUALIFYING_CIRCUMSTANCES;
                    transDetailsHis.BEGINNING_DOS = transDetails.BEGINNING_DOS;
                    transDetailsHis.ENDING_DOS = transDetails.ENDING_DOS;
                    transDetailsHis.PLACE_OF_SERVICE = transDetails.PLACE_OF_SERVICE;
                    transDetailsHis.DELETE_INDICATOR = transDetails.DELETE_INDICATOR;
                    transDetailsHis.PROCEDURE_TYPE = transDetails.PROCEDURE_TYPE;
                    transDetailsHis.PAGE_NO = Convert.ToInt32(transDetails.PAGE_NO);
                    transDetailsHis.EO_CODE1 = transDetails.EO_CODE1;
                    transDetailsHis.EO_COMMENT1 = transDetails.EO_COMMENT1;
                    transDetailsHis.EO_CODE2 = transDetails.EO_CODE2;
                    transDetailsHis.EO_COMMENT2 = transDetails.EO_COMMENT2;
                    transDetailsHis.EO_CODE3 = transDetails.EO_CODE3;
                    transDetailsHis.EO_COMMENT3 = transDetails.EO_COMMENT3;
                    transDetailsHis.EO_CODE4 = transDetails.EO_CODE4;
                    transDetailsHis.EO_COMMENT4 = transDetails.EO_COMMENT4;
                    transDetailsHis.EO_CODE5 = transDetails.EO_CODE5;
                    transDetailsHis.EO_COMMENT5 = transDetails.EO_COMMENT5;
                    transDetailsHis.EO_CODE6 = transDetails.EO_CODE6;
                    transDetailsHis.EO_COMMENT6 = transDetails.EO_COMMENT6;
                    transDetailsHis.ACTIONS_PERFORMED = "DELETE";

                    _context.tbl_TRANSACTION_DETAILS_HISTORY.Add(transDetailsHis);

                    #endregion

                    _context.SaveChanges();
                }
            }
        }
        #endregion

        #region UpdateTrackingGridData
        public void UpdateTrackingGridData(HighMarkQCTransactionModel model)
        {
            using (CBI_Anes_HighEntities _context = new CBI_Anes_HighEntities())
            {
                var transDetails = _context.tbl_TRANSACTION_DETAILS.Where(x => x.TRANS_DETAIL_ID == model.TRANS_DETAIL_ID).FirstOrDefault();
                if (transDetails != null)
                {
                    transDetails.BEGINNING_DOS = CryptoGraphy.Encrypt(model.BeginningDOS);
                    transDetails.ENDING_DOS = CryptoGraphy.Encrypt(model.EndingDOS);
                    transDetails.ICD_CODE = model.DxType;
                    transDetails.ICD = model.DXCode;
                    transDetails.PAGE_NO = model.Page;
                    _context.SaveChanges();
                }
            }
        }
        #endregion

        #region GetMultipleSelectedItems

        private string GetMultipleSelectedEoComment(List<SelectListItem> selectedItems)
        {
            string selectedArrar = string.Empty;
            if (selectedItems != null)
            {
                foreach (var item in selectedItems)
                {
                    if (item.Selected == true)
                    {
                        selectedArrar = selectedArrar + "," + item.Value;
                    }
                }
                return selectedArrar.TrimStart(',');
            }
            else
            {
                return null;
            }
        }

        private string GetMultipleSelectedEoCode(List<SelectListItem> selectedItems)
        {
            string selectedArrar = string.Empty;
            if (selectedItems != null)
            {
                foreach (var item in selectedItems)
                {
                    if (item.Selected == true)
                    {
                        selectedArrar = selectedArrar + "," + item.Text;
                    }
                }
                return selectedArrar.TrimStart(',');
            }
            else
            {
                return null;
            }
        }
        #endregion

        #region FinalQcSubmit
        public void FinalQcSubmit(string selectedAccounts, string TabText)
        {
            
            if (selectedAccounts.Contains("Tracking Code"))
            {
                selectedAccounts = selectedAccounts.Replace("Tracking Code,", "");
            }
            int projectId = Convert.ToInt32(HttpContext.Current.Session[Constants.ProjectId]);
            using (CBI_Anes_HighEntities _context = new CBI_Anes_HighEntities())
            {
                string[] array = selectedAccounts.Split(',');
                string Status = "";
                string userName = HttpContext.Current.Session[Constants.UserName].ToString();

                //if ((selectedAccounts.Contains("Skip")))
                //{

                        string[] newArray = array.Select(x => CryptoGraphy.Encrypt(x.Trim())).ToArray();
                        var myList = _context.tbl_IMPORT_TABLE.Where(x => newArray.Contains(x.ACCOUNT_NO) && x.PROJECT_ID == projectId).ToList();

                        var bathIds = myList.Select(x => x.BATCH_ID).ToList();
                        _context.tbl_TRANSACTION.Where(x => bathIds.Contains(x.BATCH_ID) && x.PROJECT_ID == projectId).ToList().ForEach(x => {
                            x.QC_BY = userName; 
                            x.QC_DATE = DateTime.Now;
                            x.QC_STATUS =_context.tbl_TRANSACTION_DETAILS.Where(y=>y.TRANS_ID==x.TRANS_ID && y.Error_Count=="1").Select(z=>z.Error_Count).ToList().Count>0?"Error": "Qced";
                            if (x.QC_STATUS=="Error")
                            {
                                Status = "Error";
                                x.QC_ERROR_CORRECTION = _context.tbl_TRANSACTION_DETAILS.Where(y => y.TRANS_ID == x.TRANS_ID && y.Error_Correction=="N").Select(z => z.Error_Correction).ToList().Count>0?"N":"Y";

                                var iterationCount = (from item in _context.tbl_TRANSACTION.Where(y => bathIds.Contains(y.BATCH_ID))select new { item.Financial_Impact}).FirstOrDefault();
                               
                                if ((Convert.ToInt32(iterationCount.Financial_Impact) >= 0) && (Convert.ToInt32(iterationCount.Financial_Impact) != 3) && (iterationCount.Financial_Impact!=null))
                                {
                                    var modificationStatus = (from item in _context.tbl_TRANSACTION_DETAILS.Where(a => a.TRANS_ID == x.TRANS_ID && (a.ICD_RESULT == "Q_INSERT" || a.ICD_RESULT == "Q_UPDATE" ||(a.ERROR_CATEGORY!=null)) && a.IS_ACKNOWLEDGE ==null) select new { item.ICD_RESULT,item.IS_ACKNOWLEDGE,item.Error_Correction }).ToList();
                                    if (modificationStatus.Count>0)
                                    {
                                        var modStatus = _context.tbl_TRANSACTION_DETAILS.Where(a => a.TRANS_ID == x.TRANS_ID && (a.ICD_RESULT == "Q_INSERT" || a.ICD_RESULT == "Q_UPDATE") && a.Error_Correction == "N" && a.IS_ACKNOWLEDGE == null).Select(a => a.Error_Correction).ToList().Count > 0 ? "N" : "Y";
                                       
                                        if (modStatus=="N")
                                        {
                                            x.QC_ERROR_CORRECTION = "N";
                                            x.IS_ACKNOWLEDGE = "N";
                                            x.ERROR_SENT_DATE = DateTime.Now;
                                            x.ACKNOWLEDGE_COMMENTS = "N";
                                        }
                                        else
                                        {
                                            //x.QC_STATUS = "Qc";
                                            x.QC_STATUS = "Error";
                                            x.QC_ERROR_CORRECTION = "Y";
                                            x.IS_ACKNOWLEDGE = "N";
                                            Status = "";
                                           
                                        }
                                        int count = Convert.ToInt32(iterationCount.Financial_Impact);
                                        count++;
                                        x.Financial_Impact = Convert.ToString(count);
                                    }
                                    else
                                    {
                                        x.QC_ERROR_CORRECTION = "Y";
                                        x.IS_ACKNOWLEDGE = "Y";
                                        x.ACKNOWLEDGE_COMMENTS = "N";
                                        x.QC_STATUS = "Qced";
                                        Status = "";
                                    }
                                }
                                else if (Convert.ToInt32(iterationCount.Financial_Impact) == 3)
                                {
                                     x.QC_ERROR_CORRECTION = "Y";
                                        x.IS_ACKNOWLEDGE = "Y";
                                        x.ACKNOWLEDGE_COMMENTS = "N";
                                        x.QC_STATUS = "Qced";
                                        Status = "";
                                }
                                else
                                {
                                    if (x.QC_ERROR_CORRECTION == "N")
                                    {
                                        x.QC_ERROR_CORRECTION = "N";
                                        x.ERROR_SENT_DATE = DateTime.Now;
                                        x.ACKNOWLEDGE_COMMENTS = "N";
                                        x.Financial_Impact = "1";//Claculating no.of iterations between Coder and QC
                                    }
                                    else
                                    {
                                        x.QC_STATUS = "Qc";
                                        x.QC_ERROR_CORRECTION = "Y";
                                        Status = "";
                                    }
                                }
                                x.ERROR_WEIGHTAGE = "1";
                                //    if (x.QC_ERROR_CORRECTION=="N")
                                //    {
                                //        x.PAGE_NO = _context.tbl_TRANSACTION_DETAILS.Where(y => y.TRANS_ID == x.TRANS_ID && ((y.IS_ACKNOWLEDGE == "N") || y.IS_ACKNOWLEDGE == "Y")).Select(z => z.IS_ACKNOWLEDGE).ToList().Count > 0 ? "N" : "Y";

                                //        if (x.PAGE_NO=="Y")
                                //        {
                                //            x.QC_ERROR_CORRECTION = "N";
                                //            x.ERROR_SENT_DATE = DateTime.Now;
                                //            x.ACKNOWLEDGE_COMMENTS = "N";
                                //        }
                                //        else
                                //        {
                                //            x.IS_ACKNOWLEDGE = _context.tbl_TRANSACTION_DETAILS.Where(y => y.TRANS_ID == x.TRANS_ID && y.IS_ACKNOWLEDGE == "N").Select(z => z.IS_ACKNOWLEDGE).ToList().Count > 0 ? "N" : "Y";
                                            
                                //            if (x.IS_ACKNOWLEDGE == "Y")
                                //            {
                                //                var data = (from T in _context.tbl_TRANSACTION
                                //                            where T.TRANS_ID == x.TRANS_ID && T.INSURANCE == "Y"
                                //                            select new
                                //                            {
                                //                                insurance = T.INSURANCE
                                //                            }).ToList();

                                //                if (data.Count==0)
                                //                {
                                //                    x.QC_STATUS = "Error";
                                //                }
                                //                else
                                //                {
                                //                    x.QC_STATUS = "Qced";
                                //                }
                                               
                                //                x.QC_ERROR_CORRECTION = "Y";
                                //                Status = "";
                                //                x.ACKNOWLEDGE_COMMENTS = "N";
                                //            }
                                //            else
                                //            {
                                //                x.IS_ACKNOWLEDGE = "Y";
                                //                x.QC_ERROR_CORRECTION = "N";
                                //                x.ERROR_SENT_DATE = DateTime.Now;
                                //                x.ACKNOWLEDGE_COMMENTS = "N";
                                //            }
                                //        }
                                       
                                //    }
                                //    else
                                //    {
                                //        x.QC_STATUS = "Qc";
                                //        x.QC_ERROR_CORRECTION = "Y";
                                //        Status = "";
                                //    }
                                //x.ERROR_WEIGHTAGE = "1";
                            }
                            
                                x.IS_SKIPPED = selectedAccounts.Contains("Skip") ? 1 : 0;
                                x.IS_AUDITED = selectedAccounts.Contains("Skip") ? 0 : 1;
                                //x.QC_ERROR_CORRECTION = array[2] == "Yes" ? "Y" : "N";
                        });
                        myList.ForEach(x => { x.BATCH_STATUS = "QC"; });

                        if (Status != "Error")
                        {
                            if (TabText == "regular")
                            {
                                for (int i = 0; i < bathIds.Count; i++)
                                {
                                    var localList = _context.USP_SELECT_INCREMENTALHCC_POPUP_Color(bathIds[i]).ToList();
                                    var myList1 = localList.Select(y => y.TRANS_DETAIL_ID).ToList();
                                    var list = _context.tbl_TRANSACTION_DETAILS.Where(x => myList1.Contains(x.TRANS_DETAIL_ID)).ToList();
                                    for (int j = 0; j < localList.Count; j++)
                                    {
                                        list[j].PQRS = localList[j].ICD.ToUpper().Trim() == "NO CODES" ? "" : "N";
                                    }
                                    //_context.tbl_TRANSACTION_DETAILS.Where(x => myList1.Contains(x.TRANS_DETAIL_ID)).ToList().ForEach(x => { x.PQRS = "N"; });
                                }
                            }
                            else if (TabText == "inc")
                            {
                                for (int i = 0; i < bathIds.Count; i++)
                                {
                                    var localList = _context.USP_SELECT_INCREMENTALHCC_POPUP_Color(bathIds[i]).ToList();
                                    var myList1 = localList.Select(y => y.TRANS_DETAIL_ID).ToList();
                                    var list = _context.tbl_TRANSACTION_DETAILS.Where(x => myList1.Contains(x.TRANS_DETAIL_ID)).ToList();
                                    for (int j = 0; j < localList.Count; j++)
                                    {
                                        list[j].PQRS = localList[j].Color == "3" && localList[j].HCCType != null ? "Y" : localList[j].ICD.ToUpper().Trim() == "NO CODES" ? "" : "N";
                                    }
                                }
                            }
                        }
                    _context.SaveChanges();
                //}
                //else
                //{
                //    string[] strErrorDetails = new string[] { };
                //    string[] model = new string[] { };

                //    tbl_TRANSACTION_HISTORY objtbl_TRANSACTION_HISTORY = new tbl_TRANSACTION_HISTORY();

               
                //    string accountNumber = CryptoGraphy.Encrypt(array[3]);
                //    var import = _context.tbl_IMPORT_TABLE.Where(x => x.ACCOUNT_NO == accountNumber.Trim() && x.PROJECT_ID == projectId).FirstOrDefault();
                //    var transaction = _context.tbl_TRANSACTION.Where(x => x.BATCH_ID == import.BATCH_ID && x.PROJECT_ID == projectId).FirstOrDefault();






                //    //Update Transaction details
                //    if (array[2] == "Yes")
                //        transaction.QC_ERROR_CORRECTION = "Y";
                //    else
                //        transaction.QC_ERROR_CORRECTION = "N";
                
                //    transaction.QC_BY = HttpContext.Current.Session[Constants.UserName].ToString();
                //    transaction.QC_DATE = DateTime.Now;
                  
                //        transaction.ERROR_SENT_DATE = DateTime.Now;
                //    transaction.QC_STATUS = "Error";
                 
                //    #region Update Batch Status

                //    import.BATCH_STATUS = "QC";

                //    #endregion

                //    _context.SaveChanges();
                //}
            }
        }
        #endregion

        #region GetTrackingPopupData

        public HighMarkQCTransactionModel GetTrackingPopupData(int transId, int transDetailsId, int batchId, string firstName, string lastName, string memberDOB,string codedDate, string codedBy)
        {

            using (CBI_Anes_HighEntities _context = new CBI_Anes_HighEntities())
            {
                var getList = (from transaction in _context.tbl_TRANSACTION
                               join import in _context.tbl_IMPORT_TABLE on transaction.BATCH_ID equals import.BATCH_ID
                               join transDetails in _context.tbl_TRANSACTION_DETAILS on transaction.TRANS_ID equals transDetails.TRANS_ID
                               join HCC in _context.tbl_IMPORT_HCC_DXCODE_MASTER on import.PROJECT_ID equals HCC.PROJECT_ID
                               where transaction.TRANS_ID == transId && import.BATCH_ID == batchId //&& transDetails.TRANS_DETAIL_ID == transDetailsId
                               select new
                               {
                                   transaction.BATCH_ID,
                                   import.MEMBER_GENDER,
                                   import.ACCOUNT_NO,
                                   transaction.TRANS_ID,
                                   transDetails.ICD,
                                   transDetails.ICD_CODE,
                                   transaction.PAGE_NO,
                                   import.ENCOUNTER_TYPE,
                                   import.PDF_Path
                               }).FirstOrDefault();

                HighMarkQCTransactionModel model = new HighMarkQCTransactionModel();
                model.BatchId = getList.BATCH_ID;
                model.MemberGender =getList.MEMBER_GENDER!=null ? CryptoGraphy.Decrypt(getList.MEMBER_GENDER):string.Empty;
                model.TrackingCode = CryptoGraphy.Decrypt(getList.ACCOUNT_NO);
                model.TRANS_ID = getList.TRANS_ID.ToString();
                model.ICD = getList.ICD;
                model.ICDCODE = getList.ICD_CODE;
                model.PageNo = "";
                model.EncounterType = getList.ENCOUNTER_TYPE;
                model.Practice_Id = PracticeID;
                model.EOCodeList = GetEcodeList("");
                model.DXTypeList = StaticDXTypeList();

                model.MemberFirstName = firstName;
                model.MemberLastName = lastName;
                model.MemberDOB=memberDOB;
                model.CodedDate = codedDate;
                model.CodedBy = codedBy;
                model.CommentsList = CommentList();
                model.PDFpath = getList.PDF_Path;
                return model;
            }
        }
        #endregion

        #region GetEcodeList
        public List<SelectListItem> GetEcodeList(string defaultvalue = "")
        {
            int projectId = Convert.ToInt32(HttpContext.Current.Session[Constants.ProjectId]);
            using (CBI_Anes_HighEntities _context = new CBI_Anes_HighEntities())
            {
                return (from E in _context.TBL_EO_CODE_MASTER where E.PROJECT_ID == projectId && E.DELETE_FLAG=="N" select new SelectListItem { Text = E.EO_CODE, Value = E.EO_COMMENT, Selected = defaultvalue.Contains(E.EO_CODE) }).ToList();
            }
        }
        #endregion

        #region SaveHighMarkQCTransaction
        public void SaveHighMarkQCTransaction(HighMarkQCTransactionModel model, string ecode)
        {

            string userNtlg = HttpContext.Current.Session[Constants.UserName].ToString();
            int projectId = Convert.ToInt32(HttpContext.Current.Session[Constants.ProjectId]);
            using (CBI_Anes_HighEntities _context = new CBI_Anes_HighEntities())
            {
                var transaction = _context.tbl_TRANSACTION.Where(x => x.BATCH_ID == model.BatchId).FirstOrDefault();
                int intTransID = Convert.ToInt32(model.TRANS_ID);
                //var TD = _context.tbl_TRANSACTION_DETAILS.Where(x => x.TRANS_ID == intTransID && x.ICD == model.DXCode).FirstOrDefault();  //TRANS_DETAIL_ID
                var TD = _context.tbl_TRANSACTION_DETAILS.Where(x => x.TRANS_DETAIL_ID == model.TRANS_DETAIL_ID).FirstOrDefault();  //TRANS_DETAIL_ID
                var import = _context.tbl_IMPORT_TABLE.Where(x => x.BATCH_ID == model.BatchId && x.PROJECT_ID == projectId).FirstOrDefault();

                #region AssignEOCodesToModel

                if (!string.IsNullOrEmpty(ecode))
                {
                    ecode = ecode.TrimEnd('%');
                    string[] array = ecode.Split('%');
                    if (array.Length == 1)
                    {
                        model.EOCode1 = array[0].Split('*')[0];
                        model.EOComment1 = array[0].Split('*')[1];
                    }
                    else if (array.Length == 2)
                    {
                        model.EOCode1 = array[0].Split('*')[0];
                        model.EOComment1 = array[0].Split('*')[1];
                        if (array[1] != " ")
                        {
                            model.EOCode2 = array[1].Split('*')[0];
                            model.EOComment2 = array[1].Split('*')[1];
                        }
                    }
                    else if (array.Length == 3)
                    {
                        model.EOCode1 = array[0].Split('*')[0];
                        model.EOComment1 = array[0].Split('*')[1];
                        model.EOCode2 = array[1].Split('*')[0];
                        model.EOComment2 = array[1].Split('*')[1];
                        model.EOCode3 = array[2].Split('*')[0];
                        model.EOComment3 = array[2].Split('*')[1];
                    }
                    else if (array.Length == 4)
                    {
                        model.EOCode1 = array[0].Split('*')[0];
                        model.EOComment1 = array[0].Split('*')[1];
                        model.EOCode2 = array[1].Split('*')[0];
                        model.EOComment2 = array[1].Split('*')[1];
                        model.EOCode3 = array[2].Split('*')[0];
                        model.EOComment3 = array[2].Split('*')[1];
                        model.EOCode4 = array[3].Split('*')[0];
                        model.EOComment4 = array[3].Split('*')[1];
                    }
                    else if (array.Length == 5)
                    {
                        model.EOCode1 = array[0].Split('*')[0];
                        model.EOComment1 = array[0].Split('*')[1];
                        model.EOCode2 = array[1].Split('*')[0];
                        model.EOComment2 = array[1].Split('*')[1];
                        model.EOCode3 = array[2].Split('*')[0];
                        model.EOComment3 = array[2].Split('*')[1];
                        model.EOCode4 = array[3].Split('*')[0];
                        model.EOComment4 = array[3].Split('*')[1];
                        model.EOCode5 = array[4].Split('*')[0];
                        model.EOComment5 = array[4].Split('*')[1];
                    }

                    else if (array.Length == 6)
                    {
                        model.EOCode1 = array[0].Split('*')[0];
                        model.EOComment1 = array[0].Split('*')[1];
                        model.EOCode2 = array[1].Split('*')[0];
                        model.EOComment2 = array[1].Split('*')[1];
                        model.EOCode3 = array[2].Split('*')[0];
                        model.EOComment3 = array[2].Split('*')[1];
                        model.EOCode4 = array[3].Split('*')[0];
                        model.EOComment4 = array[3].Split('*')[1];
                        model.EOCode5 = array[4].Split('*')[0];
                        model.EOComment5 = array[4].Split('*')[1];
                        model.EOCode6 = array[5].Split('*')[0];
                        model.EOComment6 = array[5].Split('*')[1];
                    }
                }

                #endregion

                if (TD == null)
                {

                    #region Insert TRANSACTION_DETAILS
                    tbl_TRANSACTION_DETAILS transactionDetails = new tbl_TRANSACTION_DETAILS();
                    transactionDetails.TRANS_ID = Convert.ToInt32(transaction.TRANS_ID);
                    transactionDetails.CPT = transactionDetails.CPT;
                    transactionDetails.ICD = model.DXCode;
                    transactionDetails.MODIFIER = transactionDetails.MODIFIER;
                    transactionDetails.UNITS = transactionDetails.UNITS;
                    transactionDetails.COMMENTS = transactionDetails.COMMENTS;
                    transactionDetails.UPDATED_BY = transaction.UPDATED_BY;
                    transactionDetails.UPDATED_DATE = transaction.UPDATED_DATE;
                    transactionDetails.ERROR_CATEGORY = transaction.ERROR_CATEGORY;
                    transactionDetails.ERROR_SUBCATEGORY = transaction.ERROR_SUBCATEGORY;
                    transactionDetails.QC_COMMENTS = transaction.QC_COMMENTS;
                    //transactionDetails.IS_ACKNOWLEDGE = transaction.IS_ACKNOWLEDGE;
                    //transactionDetails.ACKNOWLEDGE_COMMENTS = transaction.ACKNOWLEDGE_COMMENTS;
                    transactionDetails.ICD_RESULT = "Q_INSERT";
                    transactionDetails.DOWNLOADING_COMMENTS = transactionDetails.DOWNLOADING_COMMENTS;
                    transactionDetails.DEFICIENCY_INDICATOR = transactionDetails.DEFICIENCY_INDICATOR;
                    transactionDetails.ACCOUNT_STATUS = transaction.ACCOUNT_STATUS;
                    transactionDetails.CPT_ORDER = transactionDetails.CPT_ORDER;
                    transactionDetails.PROVIDER_MD = transactionDetails.PROVIDER_MD;
                    transactionDetails.ASSISTANT_PROVIDER = transactionDetails.ASSISTANT_PROVIDER;
                    transactionDetails.CPT_LEVEL = transactionDetails.CPT_LEVEL;
                    transactionDetails.ICD_CODE = model.DxType;
                    transactionDetails.ASA_CROSS = transactionDetails.ASA_CROSS;
                    transactionDetails.ANCILLARY_SERVICES = transactionDetails.ANCILLARY_SERVICES;
                    transactionDetails.ANCILLARY_MODIFIER = transactionDetails.ANCILLARY_MODIFIER;
                    transactionDetails.ACUTE_PAIN_CPT = transactionDetails.ACUTE_PAIN_CPT;
                    transactionDetails.ACUTE_PAIN_DX = transactionDetails.ACUTE_PAIN_DX;
                    transactionDetails.ACUTE_PAIN_POS = transactionDetails.ACUTE_PAIN_POS;
                    transactionDetails.PQRS = transactionDetails.PQRS;
                    transactionDetails.MEDICAL_DIRECTION = transactionDetails.MEDICAL_DIRECTION;
                    transactionDetails.ANCILLARY_SERVICE_PROVIDERS = transactionDetails.ANCILLARY_SERVICE_PROVIDERS;
                    transactionDetails.QUALIFYING_CIRCUMSTANCES = transactionDetails.QUALIFYING_CIRCUMSTANCES;
                    transactionDetails.BEGINNING_DOS = CryptoGraphy.Encrypt(model.BeginningDOS);
                    transactionDetails.ENDING_DOS = CryptoGraphy.Encrypt(model.EndingDOS);
                    transactionDetails.PLACE_OF_SERVICE = transactionDetails.PLACE_OF_SERVICE;
                    transactionDetails.DELETE_INDICATOR = transactionDetails.DELETE_INDICATOR;
                    transactionDetails.PROCEDURE_TYPE = transactionDetails.PROCEDURE_TYPE;
                    transactionDetails.PAGE_NO = model.PageNo;
                    transactionDetails.EO_CODE1 = model.EOCode1;
                    transactionDetails.EO_COMMENT1 = model.EOComment1;
                    transactionDetails.EO_CODE2 = model.EOCode2;
                    transactionDetails.EO_COMMENT2 = model.EOComment2;
                    transactionDetails.EO_CODE3 = model.EOCode3;
                    transactionDetails.EO_COMMENT3 = model.EOComment3;
                    transactionDetails.EO_CODE4 = model.EOCode4;
                    transactionDetails.EO_COMMENT4 = model.EOComment4;
                    transactionDetails.EO_CODE5 = model.EOCode5;
                    transactionDetails.EO_COMMENT5 = model.EOComment5;
                    transactionDetails.EO_CODE6 = model.EOCode6;
                    transactionDetails.EO_COMMENT6 = model.EOComment6;
                    transactionDetails.CRNA = transactionDetails.CRNA;
                    transactionDetails.Anesthesia_Start_time = transactionDetails.Anesthesia_Start_time;
                    transactionDetails.Anesthesia_End_time = transactionDetails.Anesthesia_End_time;
                    transactionDetails.Anesthesia_Time_Diff = transactionDetails.Anesthesia_Time_Diff;
                    transactionDetails.COMMENTS = model.ICDComments;
                    _context.tbl_TRANSACTION_DETAILS.Add(transactionDetails);
                    _context.SaveChanges();

                    #endregion

                    #region Insert Transaction History

                    tbl_TRANSACTION_HISTORY objtbl_TRANSACTION_HISTORY = new tbl_TRANSACTION_HISTORY();

                    objtbl_TRANSACTION_HISTORY.TRANS_ID = Convert.ToInt32(model.TRANS_ID);
                    //objtbl_TRANSACTION_HISTORY.TYPE_OF_ACCIDENT = transaction.typeofde;
                    objtbl_TRANSACTION_HISTORY.PROJECT_ID = transaction.PROJECT_ID;
                    objtbl_TRANSACTION_HISTORY.BATCH_ID = transaction.BATCH_ID;
                    //objtbl_TRANSACTION_HISTORY.INSURANCE = transaction.INSURANCE;
                    objtbl_TRANSACTION_HISTORY.ADMITTING_PHY = transaction.ADMITTING_PHY;
                    objtbl_TRANSACTION_HISTORY.ATTENDING_PHY = transaction.ATTENDING_PHY;
                    objtbl_TRANSACTION_HISTORY.EDMD = transaction.EDMD;
                    objtbl_TRANSACTION_HISTORY.DOI = transaction.DOI;
                    objtbl_TRANSACTION_HISTORY.TOI = transaction.TOI;
                    objtbl_TRANSACTION_HISTORY.CHART_NO = transaction.CHART_NO;
                    //objtbl_TRANSACTION_HISTORY.PAGE_NO = transaction.PAGE_NO;
                    objtbl_TRANSACTION_HISTORY.CODING_COMMENTS = transaction.CODING_COMMENTS;
                    objtbl_TRANSACTION_HISTORY.CODED_DATE = transaction.CODED_DATE;
                    objtbl_TRANSACTION_HISTORY.CODED_BY = transaction.CODED_BY;
                    objtbl_TRANSACTION_HISTORY.UPDATED_BY = transaction.UPDATED_BY;
                    objtbl_TRANSACTION_HISTORY.UPDATED_DATE = transaction.UPDATED_DATE;
                    objtbl_TRANSACTION_HISTORY.CODING_STATUS = transaction.CODING_STATUS;
                    objtbl_TRANSACTION_HISTORY.QC_BY = HttpContext.Current.Session[Constants.UserName].ToString();
                    objtbl_TRANSACTION_HISTORY.QC_DATE = DateTime.Now;
                    objtbl_TRANSACTION_HISTORY.QC_STATUS = transaction.QC_STATUS;

                    if (!string.IsNullOrEmpty(objtbl_TRANSACTION_HISTORY.QC_COMMENTS))
                        objtbl_TRANSACTION_HISTORY.QC_COMMENTS = ";" + transaction.QC_COMMENTS;
                    else
                        objtbl_TRANSACTION_HISTORY.QC_COMMENTS = transaction.QC_COMMENTS + ";";

                    if (!string.IsNullOrEmpty(objtbl_TRANSACTION_HISTORY.ERROR_SUBCATEGORY))
                        objtbl_TRANSACTION_HISTORY.ERROR_SUBCATEGORY = ";" + transaction.ERROR_SUBCATEGORY;
                    else
                        objtbl_TRANSACTION_HISTORY.ERROR_SUBCATEGORY = transaction.ERROR_SUBCATEGORY + ";";

                    if (!string.IsNullOrEmpty(objtbl_TRANSACTION_HISTORY.ERROR_CATEGORY))
                        objtbl_TRANSACTION_HISTORY.ERROR_CATEGORY = ";" + transaction.ERROR_CATEGORY;
                    else
                        objtbl_TRANSACTION_HISTORY.ERROR_CATEGORY = transaction.ERROR_CATEGORY + ";";

                    objtbl_TRANSACTION_HISTORY.QC_ERROR_CORRECTION = transaction.QC_ERROR_CORRECTION;
                    objtbl_TRANSACTION_HISTORY.IS_ACKNOWLEDGE = transaction.IS_ACKNOWLEDGE;
                    objtbl_TRANSACTION_HISTORY.ACKNOWLEDGE_COMMENTS = transaction.ACKNOWLEDGE_COMMENTS;
                    objtbl_TRANSACTION_HISTORY.PROVIDER_MD = transaction.PROVIDER_MD;
                    objtbl_TRANSACTION_HISTORY.ASSISTANT_PROVIDER = transaction.ASSISTANT_PROVIDER;
                    objtbl_TRANSACTION_HISTORY.DISPOSITION = transaction.DISPOSITION;
                    objtbl_TRANSACTION_HISTORY.PATIENT_STATUS = transaction.PATIENT_STATUS;
                    objtbl_TRANSACTION_HISTORY.TYPE_OF_ACCIDENT = transaction.TYPE_OF_ACCIDENT;
                    objtbl_TRANSACTION_HISTORY.ACCOUNT_STATUS = transaction.ACCOUNT_STATUS;
                    objtbl_TRANSACTION_HISTORY.DOS_CHANGED = transaction.DOS_CHANGED;
                    objtbl_TRANSACTION_HISTORY.IS_AUDITED = transaction.IS_AUDITED;
                    objtbl_TRANSACTION_HISTORY.PENDING_UPDATED_BY = transaction.PENDING_UPDATED_BY;
                    objtbl_TRANSACTION_HISTORY.W_O_ATTESTATION = transaction.W_O_ATTESTATION;
                    objtbl_TRANSACTION_HISTORY.IS_ACKNOWLEDGE_BY = transaction.IS_ACKNOWLEDGE_BY;
                    objtbl_TRANSACTION_HISTORY.IS_SKIPPED = transaction.IS_SKIPPED;
                    objtbl_TRANSACTION_HISTORY.IS_REOPENED = transaction.IS_REOPENED;
                    objtbl_TRANSACTION_HISTORY.KEYING_COMMENTS = transaction.KEYING_COMMENTS;
                    objtbl_TRANSACTION_HISTORY.AR_STATUS = transaction.AR_STATUS;
                    objtbl_TRANSACTION_HISTORY.DOS = transaction.DOS;
                    objtbl_TRANSACTION_HISTORY.IS_PENDING = transaction.IS_PENDING;
                    objtbl_TRANSACTION_HISTORY.RESPONSIBILITY = transaction.RESPONSIBILITY;
                    objtbl_TRANSACTION_HISTORY.SEND_TO_CLIENT_DATE = transaction.SEND_TO_CLIENT_DATE;
                    objtbl_TRANSACTION_HISTORY.CLIENT_RESPONSE = transaction.CLIENT_RESPONSE;
                    objtbl_TRANSACTION_HISTORY.CLIENT_RESPONSE_DATE = transaction.CLIENT_RESPONSE_DATE;
                    objtbl_TRANSACTION_HISTORY.PENDING_UPDAED_DATE = transaction.PENDING_UPDAED_DATE;
                    objtbl_TRANSACTION_HISTORY.PENDING_WORKED_DATE = transaction.PENDING_WORKED_DATE;
                    objtbl_TRANSACTION_HISTORY.NPPA = transaction.NPPA;
                    objtbl_TRANSACTION_HISTORY.SCRIBE = transaction.SCRIBE;
                    objtbl_TRANSACTION_HISTORY.RESIDENT = transaction.RESIDENT;
                    objtbl_TRANSACTION_HISTORY.START_TIME = transaction.START_TIME;
                    objtbl_TRANSACTION_HISTORY.END_TIME = transaction.END_TIME;
                    objtbl_TRANSACTION_HISTORY.TOTAL_TIME = transaction.TOTAL_TIME;
                    objtbl_TRANSACTION_HISTORY.ANES_TYPE = transaction.ANES_TYPE;
                    objtbl_TRANSACTION_HISTORY.PHYSICAL_STATUS = transaction.PHYSICAL_STATUS;
                    objtbl_TRANSACTION_HISTORY.PATIENT_NAME = transaction.PATIENT_NAME;
                    objtbl_TRANSACTION_HISTORY.CODING_STARTTIME = transaction.CODING_STARTTIME;
                    objtbl_TRANSACTION_HISTORY.CODING_ENDTIME = transaction.CODING_ENDTIME;
                    if (!string.IsNullOrEmpty(objtbl_TRANSACTION_HISTORY.ERROR_WEIGHTAGE))
                        objtbl_TRANSACTION_HISTORY.ERROR_WEIGHTAGE = ";" + transaction.ERROR_WEIGHTAGE;
                    else
                        objtbl_TRANSACTION_HISTORY.ERROR_WEIGHTAGE = transaction.ERROR_WEIGHTAGE + ";";
                    objtbl_TRANSACTION_HISTORY.IS_ACKNOWLEDGE_DATE = transaction.IS_ACKNOWLEDGE_DATE;

                    if (transaction.ERROR_SENT_DATE == null)
                        objtbl_TRANSACTION_HISTORY.ERROR_SENT_DATE = DateTime.Now;
                    else
                        objtbl_TRANSACTION_HISTORY.ERROR_SENT_DATE = transaction.ERROR_SENT_DATE;

                    objtbl_TRANSACTION_HISTORY.RELEASE_REAUDIT_STATUS = transaction.RELEASE_REAUDIT_STATUS;
                    objtbl_TRANSACTION_HISTORY.RELEASE_REAUDIT_BY = transaction.RELEASE_REAUDIT_BY;
                    objtbl_TRANSACTION_HISTORY.RELEASE_REAUDIT_DATE = transaction.RELEASE_REAUDIT_DATE;
                    objtbl_TRANSACTION_HISTORY.ACTIONS_PERFORMED = "INSERT";

                    _context.tbl_TRANSACTION_HISTORY.Add(objtbl_TRANSACTION_HISTORY);
                    #endregion

                    #region Insert TRANSACTION DETAILS HISTORY

                    tbl_TRANSACTION_DETAILS_HISTORY transDetailsHis = new tbl_TRANSACTION_DETAILS_HISTORY();

                    transDetailsHis.TRANS_DETAIL_ID = transactionDetails.TRANS_DETAIL_ID;
                    transDetailsHis.TRANS_ID = Convert.ToInt32(model.TRANS_ID);
                    transDetailsHis.CPT = transactionDetails.CPT;
                    transDetailsHis.ICD = model.DXCode;
                    transDetailsHis.MODIFIER = transactionDetails.MODIFIER;
                    transDetailsHis.UNITS = transactionDetails.UNITS;
                    transDetailsHis.COMMENTS = transactionDetails.COMMENTS;
                    transDetailsHis.UPDATED_BY = transaction.UPDATED_BY;
                    transDetailsHis.UPDATED_DATE = transaction.UPDATED_DATE;
                    transDetailsHis.QC_BY = transaction.QC_BY;
                    transDetailsHis.QC_DATE = transaction.QC_DATE;
                    transDetailsHis.QC_STATUS = transaction.QC_STATUS;
                    transDetailsHis.ERROR_CATEGORY = transaction.ERROR_CATEGORY;
                    transDetailsHis.ERROR_SUBCATEGORY = transaction.ERROR_SUBCATEGORY;
                    transDetailsHis.QC_COMMENTS = transaction.QC_COMMENTS;
                    transDetailsHis.IS_ACKNOWLEDGE = transaction.IS_ACKNOWLEDGE;
                    transDetailsHis.ACKNOWLEDGE_COMMENTS = transaction.ACKNOWLEDGE_COMMENTS;
                    transDetailsHis.ICD_RESULT = transactionDetails.ICD_RESULT;
                    transDetailsHis.DOWNLOADING_COMMENTS = transactionDetails.DOWNLOADING_COMMENTS;
                    transDetailsHis.DEFICIENCY_INDICATOR = transactionDetails.DEFICIENCY_INDICATOR;
                    transDetailsHis.ACCOUNT_STATUS = transaction.ACCOUNT_STATUS;
                    transDetailsHis.CPT_ORDER = transactionDetails.CPT_ORDER;
                    transDetailsHis.PROVIDER_MD = transactionDetails.PROVIDER_MD;
                    transDetailsHis.ASSISTANT_PROVIDER = transactionDetails.ASSISTANT_PROVIDER;
                    transDetailsHis.CPT_LEVEL = transactionDetails.CPT_LEVEL;
                    transDetailsHis.ICD_CODE = model.DxType;
                    transDetailsHis.ASA_CROSS = transactionDetails.ASA_CROSS;
                    transDetailsHis.ANCILLARY_SERVICES = transactionDetails.ANCILLARY_SERVICES;
                    transDetailsHis.ANCILLARY_MODIFIER = transactionDetails.ANCILLARY_MODIFIER;
                    transDetailsHis.ACUTE_PAIN_CPT = transactionDetails.ACUTE_PAIN_CPT;
                    transDetailsHis.ACUTE_PAIN_DX = transactionDetails.ACUTE_PAIN_DX;
                    transDetailsHis.ACUTE_PAIN_POS = transactionDetails.ACUTE_PAIN_POS;
                    transDetailsHis.PQRS = transactionDetails.PQRS;
                    transDetailsHis.MEDICAL_DIRECTION = transactionDetails.MEDICAL_DIRECTION;
                    transDetailsHis.ANCILLARY_SERVICE_PROVIDERS = transactionDetails.ANCILLARY_SERVICE_PROVIDERS;
                    transDetailsHis.QUALIFYING_CIRCUMSTANCES = transactionDetails.QUALIFYING_CIRCUMSTANCES;
                    transDetailsHis.BEGINNING_DOS = model.BeginningDOS;
                    transDetailsHis.ENDING_DOS = model.EndingDOS;
                    transDetailsHis.PLACE_OF_SERVICE = transactionDetails.PLACE_OF_SERVICE;
                    transDetailsHis.DELETE_INDICATOR = transactionDetails.DELETE_INDICATOR;
                    transDetailsHis.PROCEDURE_TYPE = transactionDetails.PROCEDURE_TYPE;
                    transDetailsHis.PAGE_NO = Convert.ToInt32(model.PageNo);
                    transDetailsHis.EO_CODE1 = model.EOCode1;
                    transDetailsHis.EO_COMMENT1 = model.EOComment1;
                    transDetailsHis.EO_CODE2 = model.EOCode2;
                    transDetailsHis.EO_COMMENT2 = model.EOComment2;
                    transDetailsHis.EO_CODE3 = model.EOCode3;
                    transDetailsHis.EO_COMMENT3 = model.EOComment3;
                    transDetailsHis.EO_CODE4 = model.EOCode4;
                    transDetailsHis.EO_COMMENT4 = model.EOComment4;
                    transDetailsHis.EO_CODE5 = model.EOCode5;
                    transDetailsHis.EO_COMMENT5 = model.EOComment5;
                    transDetailsHis.EO_CODE6 = model.EOCode6;
                    transDetailsHis.EO_COMMENT6 = model.EOComment6;
                    transDetailsHis.ACTIONS_PERFORMED = "INSERT";

                    _context.tbl_TRANSACTION_DETAILS_HISTORY.Add(transDetailsHis);

                    #endregion

                    _context.SaveChanges();
                }
                else
                {
                    #region Update Member Gender

                    //import.MEMBER_GENDER =!string.IsNullOrEmpty(model.MemberGender)?CryptoGraphy.Encrypt(model.MemberGender):CryptoGraphy.Encrypt(string.Empty);
                    //  importTable.ACCOUNT_NO = model.TrackingCode;

                    #endregion

                    #region Update Transaction Details

                    //tbl_TRANSACTION_DETAILS transactionDetails = new tbl_TRANSACTION_DETAILS();
                    //transactionDetails.TRANS_ID = Convert.ToInt32(transaction.TRANS_ID);                   
                    bool Audit = false;

                    if (TD.BEGINNING_DOS != CryptoGraphy.Encrypt(model.BeginningDOS))
                    {
                        Audit = true;
                    }
                    if (TD.ENDING_DOS != CryptoGraphy.Encrypt(model.EndingDOS))
                    {
                        Audit = true;
                    }
                    if (TD.ICD_CODE != model.DxType)
                    {
                        Audit = true;
                    }
                    if (TD.PAGE_NO != model.PageNo)
                    {
                        Audit = true;
                    }
                    if (TD.EO_CODE1 != model.EOCode1)
                    {
                        Audit = true;
                    }
                    if (TD.EO_CODE2 != model.EOCode2)
                    {
                        Audit = true;
                    }
                    if (TD.EO_CODE3 != model.EOCode3)
                    {
                        Audit = true;
                    }
                    if (TD.EO_CODE4 != model.EOCode4)
                    {
                        Audit = true;
                    }
                    if (TD.EO_CODE5 != model.EOCode5)
                    {
                        Audit = true;
                    }
                    if (TD.EO_CODE6 != model.EOCode6)
                    {
                        Audit = true;
                    }
                    if (TD.COMMENTS != model.ICDComments)
                    {
                        Audit = true;
                    }
                    if (Audit == true)
                    {
                        TD.ICD_RESULT = "Q_UPDATE";
                        Audit = false;
                        TD.Error_Count = "1";
                    }
                    TD.BEGINNING_DOS = CryptoGraphy.Encrypt(model.BeginningDOS);
                    TD.ENDING_DOS = CryptoGraphy.Encrypt(model.EndingDOS);
                    TD.ICD_CODE = model.DxType;
                    TD.ICD = model.DXCode;
                    TD.PAGE_NO = model.PageNo;
                    TD.EO_CODE1 = GetMultipleSelectedEoCode(model.EOCodeList);
                    TD.EO_COMMENT1 = GetMultipleSelectedEoComment(model.EOCodeList);
                    TD.EO_CODE1 = model.EOCode1;
                    TD.EO_CODE2 = model.EOCode2;
                    TD.EO_CODE3 = model.EOCode3;
                    TD.EO_CODE4 = model.EOCode4;
                    TD.EO_CODE5 = model.EOCode5;
                    TD.EO_CODE6 = model.EOCode6;
                    TD.EO_COMMENT1 = model.EOComment1;
                    TD.EO_COMMENT2 = model.EOComment2;
                    TD.EO_COMMENT3 = model.EOComment3;
                    TD.EO_COMMENT4 = model.EOComment4;
                    TD.EO_COMMENT5 = model.EOComment5;
                    TD.EO_COMMENT6 = model.EOComment6;
                    TD.COMMENTS = model.ICDComments;
                    TD.ASA_CROSS = "Y";
                    
                    #endregion

                    #region Insert Transaction History

                    tbl_TRANSACTION_HISTORY objtbl_TRANSACTION_HISTORY = new tbl_TRANSACTION_HISTORY();

                    objtbl_TRANSACTION_HISTORY.TRANS_ID = Convert.ToInt32(model.TRANS_ID);
                    //objtbl_TRANSACTION_HISTORY.TYPE_OF_ACCIDENT = transaction.typeofde;
                    objtbl_TRANSACTION_HISTORY.PROJECT_ID = transaction.PROJECT_ID;
                    objtbl_TRANSACTION_HISTORY.BATCH_ID = transaction.BATCH_ID;
                    //objtbl_TRANSACTION_HISTORY.INSURANCE = transaction.INSURANCE;
                    objtbl_TRANSACTION_HISTORY.ADMITTING_PHY = transaction.ADMITTING_PHY;
                    objtbl_TRANSACTION_HISTORY.ATTENDING_PHY = transaction.ATTENDING_PHY;
                    objtbl_TRANSACTION_HISTORY.EDMD = transaction.EDMD;
                    objtbl_TRANSACTION_HISTORY.DOI = transaction.DOI;
                    objtbl_TRANSACTION_HISTORY.TOI = transaction.TOI;
                    objtbl_TRANSACTION_HISTORY.CHART_NO = transaction.CHART_NO;
                    //objtbl_TRANSACTION_HISTORY.PAGE_NO = transaction.PAGE_NO;
                    objtbl_TRANSACTION_HISTORY.CODING_COMMENTS = transaction.CODING_COMMENTS;
                    objtbl_TRANSACTION_HISTORY.CODED_DATE = transaction.CODED_DATE;
                    objtbl_TRANSACTION_HISTORY.CODED_BY = transaction.CODED_BY;
                    objtbl_TRANSACTION_HISTORY.UPDATED_BY = transaction.UPDATED_BY;
                    objtbl_TRANSACTION_HISTORY.UPDATED_DATE = transaction.UPDATED_DATE;
                    objtbl_TRANSACTION_HISTORY.CODING_STATUS = transaction.CODING_STATUS;
                    objtbl_TRANSACTION_HISTORY.QC_BY = HttpContext.Current.Session[Constants.UserName].ToString();
                    objtbl_TRANSACTION_HISTORY.QC_DATE = DateTime.Now;
                    objtbl_TRANSACTION_HISTORY.QC_STATUS = transaction.QC_STATUS;

                    if (!string.IsNullOrEmpty(objtbl_TRANSACTION_HISTORY.QC_COMMENTS))
                        objtbl_TRANSACTION_HISTORY.QC_COMMENTS = ";" + transaction.QC_COMMENTS;
                    else
                        objtbl_TRANSACTION_HISTORY.QC_COMMENTS = transaction.QC_COMMENTS + ";";

                    if (!string.IsNullOrEmpty(objtbl_TRANSACTION_HISTORY.ERROR_SUBCATEGORY))
                        objtbl_TRANSACTION_HISTORY.ERROR_SUBCATEGORY = ";" + transaction.ERROR_SUBCATEGORY;
                    else
                        objtbl_TRANSACTION_HISTORY.ERROR_SUBCATEGORY = transaction.ERROR_SUBCATEGORY + ";";

                    if (!string.IsNullOrEmpty(objtbl_TRANSACTION_HISTORY.ERROR_CATEGORY))
                        objtbl_TRANSACTION_HISTORY.ERROR_CATEGORY = ";" + transaction.ERROR_CATEGORY;
                    else
                        objtbl_TRANSACTION_HISTORY.ERROR_CATEGORY = transaction.ERROR_CATEGORY + ";";

                    objtbl_TRANSACTION_HISTORY.QC_ERROR_CORRECTION = transaction.QC_ERROR_CORRECTION;
                    objtbl_TRANSACTION_HISTORY.IS_ACKNOWLEDGE = transaction.IS_ACKNOWLEDGE;
                    objtbl_TRANSACTION_HISTORY.ACKNOWLEDGE_COMMENTS = transaction.ACKNOWLEDGE_COMMENTS;
                    objtbl_TRANSACTION_HISTORY.PROVIDER_MD = transaction.PROVIDER_MD;
                    objtbl_TRANSACTION_HISTORY.ASSISTANT_PROVIDER = transaction.ASSISTANT_PROVIDER;
                    objtbl_TRANSACTION_HISTORY.DISPOSITION = transaction.DISPOSITION;
                    objtbl_TRANSACTION_HISTORY.PATIENT_STATUS = transaction.PATIENT_STATUS;
                    objtbl_TRANSACTION_HISTORY.TYPE_OF_ACCIDENT = transaction.TYPE_OF_ACCIDENT;
                    objtbl_TRANSACTION_HISTORY.ACCOUNT_STATUS = transaction.ACCOUNT_STATUS;
                    objtbl_TRANSACTION_HISTORY.DOS_CHANGED = transaction.DOS_CHANGED;
                    objtbl_TRANSACTION_HISTORY.IS_AUDITED = transaction.IS_AUDITED;
                    objtbl_TRANSACTION_HISTORY.PENDING_UPDATED_BY = transaction.PENDING_UPDATED_BY;
                    objtbl_TRANSACTION_HISTORY.W_O_ATTESTATION = transaction.W_O_ATTESTATION;
                    objtbl_TRANSACTION_HISTORY.IS_ACKNOWLEDGE_BY = transaction.IS_ACKNOWLEDGE_BY;
                    objtbl_TRANSACTION_HISTORY.IS_SKIPPED = transaction.IS_SKIPPED;
                    objtbl_TRANSACTION_HISTORY.IS_REOPENED = transaction.IS_REOPENED;
                    objtbl_TRANSACTION_HISTORY.KEYING_COMMENTS = transaction.KEYING_COMMENTS;
                    objtbl_TRANSACTION_HISTORY.AR_STATUS = transaction.AR_STATUS;
                    objtbl_TRANSACTION_HISTORY.DOS = transaction.DOS;
                    objtbl_TRANSACTION_HISTORY.IS_PENDING = transaction.IS_PENDING;
                    objtbl_TRANSACTION_HISTORY.RESPONSIBILITY = transaction.RESPONSIBILITY;
                    objtbl_TRANSACTION_HISTORY.SEND_TO_CLIENT_DATE = transaction.SEND_TO_CLIENT_DATE;
                    objtbl_TRANSACTION_HISTORY.CLIENT_RESPONSE = transaction.CLIENT_RESPONSE;
                    objtbl_TRANSACTION_HISTORY.CLIENT_RESPONSE_DATE = transaction.CLIENT_RESPONSE_DATE;
                    objtbl_TRANSACTION_HISTORY.PENDING_UPDAED_DATE = transaction.PENDING_UPDAED_DATE;
                    objtbl_TRANSACTION_HISTORY.PENDING_WORKED_DATE = transaction.PENDING_WORKED_DATE;
                    objtbl_TRANSACTION_HISTORY.NPPA = transaction.NPPA;
                    objtbl_TRANSACTION_HISTORY.SCRIBE = transaction.SCRIBE;
                    objtbl_TRANSACTION_HISTORY.RESIDENT = transaction.RESIDENT;
                    objtbl_TRANSACTION_HISTORY.START_TIME = transaction.START_TIME;
                    objtbl_TRANSACTION_HISTORY.END_TIME = transaction.END_TIME;
                    objtbl_TRANSACTION_HISTORY.TOTAL_TIME = transaction.TOTAL_TIME;
                    objtbl_TRANSACTION_HISTORY.ANES_TYPE = transaction.ANES_TYPE;
                    objtbl_TRANSACTION_HISTORY.PHYSICAL_STATUS = transaction.PHYSICAL_STATUS;
                    objtbl_TRANSACTION_HISTORY.PATIENT_NAME = transaction.PATIENT_NAME;
                    objtbl_TRANSACTION_HISTORY.CODING_STARTTIME = transaction.CODING_STARTTIME;
                    objtbl_TRANSACTION_HISTORY.CODING_ENDTIME = transaction.CODING_ENDTIME;
                    if (!string.IsNullOrEmpty(objtbl_TRANSACTION_HISTORY.ERROR_WEIGHTAGE))
                        objtbl_TRANSACTION_HISTORY.ERROR_WEIGHTAGE = ";" + transaction.ERROR_WEIGHTAGE;
                    else
                        objtbl_TRANSACTION_HISTORY.ERROR_WEIGHTAGE = transaction.ERROR_WEIGHTAGE + ";";
                    objtbl_TRANSACTION_HISTORY.IS_ACKNOWLEDGE_DATE = transaction.IS_ACKNOWLEDGE_DATE;

                    if (transaction.ERROR_SENT_DATE == null)
                        objtbl_TRANSACTION_HISTORY.ERROR_SENT_DATE = DateTime.Now;
                    else
                        objtbl_TRANSACTION_HISTORY.ERROR_SENT_DATE = transaction.ERROR_SENT_DATE;

                    objtbl_TRANSACTION_HISTORY.RELEASE_REAUDIT_STATUS = transaction.RELEASE_REAUDIT_STATUS;
                    objtbl_TRANSACTION_HISTORY.RELEASE_REAUDIT_BY = transaction.RELEASE_REAUDIT_BY;
                    objtbl_TRANSACTION_HISTORY.RELEASE_REAUDIT_DATE = transaction.RELEASE_REAUDIT_DATE;
                    objtbl_TRANSACTION_HISTORY.ACTIONS_PERFORMED = "UPDATE";

                    _context.tbl_TRANSACTION_HISTORY.Add(objtbl_TRANSACTION_HISTORY);
                    #endregion

                    #region Insert TRANSACTION DETAILS HISTORY

                    tbl_TRANSACTION_DETAILS_HISTORY transDetailsHis = new tbl_TRANSACTION_DETAILS_HISTORY();

                    transDetailsHis.TRANS_DETAIL_ID = model.TRANS_DETAIL_ID;
                    transDetailsHis.TRANS_ID = Convert.ToInt32(model.TRANS_ID);
                    transDetailsHis.CPT = TD.CPT;
                    transDetailsHis.ICD = model.ICD;
                    transDetailsHis.MODIFIER = TD.MODIFIER;
                    transDetailsHis.UNITS = TD.UNITS;
                    transDetailsHis.COMMENTS = TD.COMMENTS;
                    transDetailsHis.UPDATED_BY = transaction.UPDATED_BY;
                    transDetailsHis.UPDATED_DATE = transaction.UPDATED_DATE;
                    transDetailsHis.QC_BY = transaction.QC_BY;
                    transDetailsHis.QC_DATE = transaction.QC_DATE;
                    transDetailsHis.QC_STATUS = transaction.QC_STATUS;
                    transDetailsHis.ERROR_CATEGORY = transaction.ERROR_CATEGORY;
                    transDetailsHis.ERROR_SUBCATEGORY = transaction.ERROR_SUBCATEGORY;
                    transDetailsHis.QC_COMMENTS = transaction.QC_COMMENTS;
                    transDetailsHis.IS_ACKNOWLEDGE = transaction.IS_ACKNOWLEDGE;
                    transDetailsHis.ACKNOWLEDGE_COMMENTS = transaction.ACKNOWLEDGE_COMMENTS;
                    transDetailsHis.ICD_RESULT = TD.ICD_RESULT;
                    transDetailsHis.DOWNLOADING_COMMENTS = TD.DOWNLOADING_COMMENTS;
                    transDetailsHis.DEFICIENCY_INDICATOR = TD.DEFICIENCY_INDICATOR;
                    transDetailsHis.ACCOUNT_STATUS = transaction.ACCOUNT_STATUS;
                    transDetailsHis.CPT_ORDER = TD.CPT_ORDER;
                    transDetailsHis.PROVIDER_MD = TD.PROVIDER_MD;
                    transDetailsHis.ASSISTANT_PROVIDER = TD.ASSISTANT_PROVIDER;
                    transDetailsHis.CPT_LEVEL = TD.CPT_LEVEL;
                    transDetailsHis.ICD_CODE = model.ICDCODE;
                    transDetailsHis.ASA_CROSS = TD.ASA_CROSS;
                    transDetailsHis.ANCILLARY_SERVICES = TD.ANCILLARY_SERVICES;
                    transDetailsHis.ANCILLARY_MODIFIER = TD.ANCILLARY_MODIFIER;
                    transDetailsHis.ACUTE_PAIN_CPT = TD.ACUTE_PAIN_CPT;
                    transDetailsHis.ACUTE_PAIN_DX = TD.ACUTE_PAIN_DX;
                    transDetailsHis.ACUTE_PAIN_POS = TD.ACUTE_PAIN_POS;
                    transDetailsHis.PQRS = TD.PQRS;
                    transDetailsHis.MEDICAL_DIRECTION = TD.MEDICAL_DIRECTION;
                    transDetailsHis.ANCILLARY_SERVICE_PROVIDERS = TD.ANCILLARY_SERVICE_PROVIDERS;
                    transDetailsHis.QUALIFYING_CIRCUMSTANCES = TD.QUALIFYING_CIRCUMSTANCES;
                    transDetailsHis.BEGINNING_DOS = model.BeginningDOS;
                    transDetailsHis.ENDING_DOS = model.EndingDOS;
                    transDetailsHis.PLACE_OF_SERVICE = TD.PLACE_OF_SERVICE;
                    transDetailsHis.DELETE_INDICATOR = TD.DELETE_INDICATOR;
                    transDetailsHis.PROCEDURE_TYPE = TD.PROCEDURE_TYPE;
                    transDetailsHis.PAGE_NO = Convert.ToInt32(model.PageNo);
                    transDetailsHis.EO_CODE1 = model.EOCode1;
                    transDetailsHis.EO_COMMENT1 = model.EOComment1;
                    transDetailsHis.EO_CODE2 = model.EOCode2;
                    transDetailsHis.EO_COMMENT2 = model.EOComment2;
                    transDetailsHis.EO_CODE3 = model.EOCode3;
                    transDetailsHis.EO_COMMENT3 = model.EOComment3;
                    transDetailsHis.EO_CODE4 = model.EOCode4;
                    transDetailsHis.EO_COMMENT4 = model.EOComment4;
                    transDetailsHis.EO_CODE5 = model.EOCode5;
                    transDetailsHis.EO_COMMENT5 = model.EOComment5;
                    transDetailsHis.EO_CODE6 = model.EOCode6;
                    transDetailsHis.EO_COMMENT6 = model.EOComment6;
                    transDetailsHis.ACTIONS_PERFORMED = "UPDATE";

                    _context.tbl_TRANSACTION_DETAILS_HISTORY.Add(transDetailsHis);

                    #endregion
                }
                _context.SaveChanges();
            }
        }

        #endregion

        #region LoadQCDXGrid
      
        public List<HighMarkQCTransactionModel> LoadQCDXGrid(int batchId)
        {
            List<HighMarkQCTransactionModel> listcolor = new List<HighMarkQCTransactionModel>();
            using (CBI_Anes_HighEntities _context = new CBI_Anes_HighEntities())
            {
                //string[] status = { "Completed", "Pending", "Clarifications" };
                int projectId = Convert.ToInt32(HttpContext.Current.Session[Constants.ProjectId]);

                var list = _context.USP_SELECT_INCREMENTALHCC_POPUP_Color(batchId).ToList();
                if (list.Count > 0)
                {
                    listcolor = list.Select(TD => new HighMarkQCTransactionModel
                    {
                        BeginningDOS = CryptoGraphy.Decrypt(TD.BEGINNING_DOS),
                        EndingDOS = CryptoGraphy.Decrypt(TD.ENDING_DOS),
                        DxType = TD.ICD_CODE,
                        DXCode = TD.ICD,
                        Page = TD.PAGE_NO,
                        EOCode1 = TD.EO_CODE1,
                        EOCode2 = TD.EO_CODE2,
                        EOCode3 = TD.EO_CODE3,
                        EOCode4 = TD.EO_CODE4,
                        EOCode5 = TD.EO_CODE5,
                        EOCode6 = TD.EO_CODE6,
                        EOComment1 = TD.EO_COMMENT1,
                        EOComment2 = TD.EO_COMMENT2,
                        EOComment3 = TD.EO_COMMENT3,
                        EOComment4 = TD.EO_COMMENT4,
                        EOComment5 = TD.EO_COMMENT5,
                        EOComment6 = TD.EO_COMMENT6,
                        TRANS_DETAIL_ID = TD.TRANS_DETAIL_ID,
                        Color = TD.Color,
                        HCCCode = TD.HCCCode,
                        HCCType = TD.HCCType,
                        ErrorCorrection=TD.Error_Correction,
                        TRANS_ID = TD.TRANS_ID.ToString(),
                        ICDComments=TD.COMMENTS,
                        ICDResult=TD.ICD_RESULT
                    }).OrderBy(x => x.TRANS_DETAIL_ID).ToList();
                }
                return listcolor;
            }
        }
        #endregion

        #region StaticDXTypeList
        private List<SelectListItem> StaticDXTypeList()
        {
            List<SelectListItem> listItems = new List<SelectListItem>();
            listItems.Add(new SelectListItem { Text = "0", Value = "0" });
            listItems.Add(new SelectListItem { Text = "9", Value = "9" });
            listItems.Add(new SelectListItem { Text = "", Value = "" });

            return listItems;
        }
        #endregion

        private List<SelectListItem> StaticErrorStatus()
        {
            List<SelectListItem> listItems = new List<SelectListItem>();
            listItems.Add(new SelectListItem { Text = "QA Corrected", Value = "Y" });
            listItems.Add(new SelectListItem { Text = "Coder to correct", Value = "N" });
            return listItems;
        }

        #region Check DXCode
        public List<HighMarkCoderTransactionModel> CheckDXCode(string dxvalue, string dxTp,string memberDOB, string endingDOS)
        {
            using (CBI_Anes_HighEntities _context = new CBI_Anes_HighEntities())
            {
                //int projectId = Convert.ToInt32(HttpContext.Current.Session[Constants.ProjectId]);

                //// int dxTpId =  int.Parse(dxTp);
                //string DxMatch = dxvalue.ToUpper();
                //var dxCode = _context.TBL_DX_CODE_MASTER.Where(x => x.PROJECT_ID == projectId && x.DX_CODE == DxMatch && x.DX_TYPE == dxTp && x.PRACTICE_ID==PracticeID).FirstOrDefault();
                //if (dxCode != null)
                //{
                //    return dxCode.DX_CODE.ToList();
                //}
                //else
                //{
                //    return "No matching found";
                //}
                List<HighMarkCoderTransactionModel> list = new List<HighMarkCoderTransactionModel>();
                HighMarkCoderTransactionModel model = new HighMarkCoderTransactionModel();
                int projectId = Convert.ToInt32(HttpContext.Current.Session[Constants.ProjectId]);
                int PracticeID = Convert.ToInt32(HttpContext.Current.Session[Constants.PracticeID]);

                if (PracticeID==1)
                {
                    if (endingDOS.ToUpper().Contains("NO DOS"))
                    {
                        var dxCode = (from item in _context.TBL_DX_CODE_MASTER.Where(x => x.DX_CODE == dxvalue && x.DX_TYPE == dxTp && x.PRACTICE_ID == PracticeID && x.PROJECT_ID == projectId) select new { item.AGE_VALIDATION, item.ERROR_POPUP, item.DX_CODE, item.EO_Code, item.DOS, item.Gender }).FirstOrDefault();
                        if (dxCode != null)
                        {
                            model.DXCode = dxCode.DX_CODE;
                            model.AgeValidation = dxCode.AGE_VALIDATION;
                            model.ErrorPopup = dxCode.ERROR_POPUP;
                            model.EEocode = dxCode.EO_Code;
                            model.MemberDOB = memberDOB;
                            model.EndingDOS = dxCode.DOS.ToString();
                            model.Gender = dxCode.Gender;
                            list.Add(model);
                            return list;
                        }
                        else
                        {
                            model.DXCode = "";
                            model.AgeValidation = "";
                            model.ErrorPopup = "";
                            model.EEocode = "";
                            model.MemberDOB = memberDOB;
                            model.EndingDOS = "";
                            model.Gender = "";
                            list.Add(model);
                            return list;
                        }
                    }
                    else
                    {
                        DateTime Edos = Convert.ToDateTime(Constants.dateKey);
                        DateTime DOS = Convert.ToDateTime(endingDOS);

                        if (Edos > DOS)
                        {
                            var dxCode = (from item in _context.TBL_DX_CODE_MASTER.Where(x => x.DX_CODE == dxvalue && x.DX_TYPE == dxTp && x.PRACTICE_ID == PracticeID && x.PROJECT_ID == projectId && (x.DOS >= DOS && x.DOS < Edos)) select new { item.AGE_VALIDATION, item.ERROR_POPUP, item.DX_CODE, item.EO_Code, item.DOS, item.Gender }).FirstOrDefault();
                            if (dxCode != null)
                            {
                                model.DXCode = dxCode.DX_CODE;
                                model.AgeValidation = dxCode.AGE_VALIDATION;
                                model.ErrorPopup = dxCode.ERROR_POPUP;
                                model.EEocode = dxCode.EO_Code;
                                model.MemberDOB = memberDOB;
                                model.EndingDOS = dxCode.DOS.ToString();
                                model.Gender = dxCode.Gender;
                                list.Add(model);
                                return list;
                            }
                            else
                            {
                                model.DXCode = "";
                                model.AgeValidation = "";
                                model.ErrorPopup = "";
                                model.EEocode = "";
                                model.MemberDOB = memberDOB;
                                model.EndingDOS = "";
                                model.Gender = "";
                                list.Add(model);
                                return list;
                            }
                        }
                        else
                        {
                            var dxCode = (from item in _context.TBL_DX_CODE_MASTER.Where(x => x.DX_CODE == dxvalue && x.DX_TYPE == dxTp && x.PRACTICE_ID == PracticeID && x.PROJECT_ID == projectId && (x.DOS <= DOS && x.DOS >= Edos)) select new { item.AGE_VALIDATION, item.ERROR_POPUP, item.DX_CODE, item.EO_Code, item.DOS, item.Gender }).FirstOrDefault();
                            if (dxCode != null)
                            {
                                model.DXCode = dxCode.DX_CODE;
                                model.AgeValidation = dxCode.AGE_VALIDATION;
                                model.ErrorPopup = dxCode.ERROR_POPUP;
                                model.EEocode = dxCode.EO_Code;
                                model.MemberDOB = memberDOB;
                                model.EndingDOS = dxCode.DOS.ToString();
                                model.Gender = dxCode.Gender;
                                list.Add(model);
                                return list;
                            }
                            else
                            {
                                model.DXCode = "";
                                model.AgeValidation = "";
                                model.ErrorPopup = "";
                                model.EEocode = "";
                                model.MemberDOB = memberDOB;
                                model.EndingDOS = "";
                                model.Gender = "";
                                list.Add(model);
                                return list;
                            }
                        }
                    }
                }
                else 
                {
                    if (endingDOS.ToUpper().Contains("NO DOS"))
                    {
                        var dxCode = (from item in _context.TBL_DX_CODE_MASTER.Where(x => x.DX_CODE == dxvalue && x.DX_TYPE == dxTp && x.PRACTICE_ID == PracticeID && x.PROJECT_ID == projectId) select new { item.AGE_VALIDATION, item.ERROR_POPUP, item.DX_CODE, item.EO_Code, item.DOS, item.Gender }).FirstOrDefault();
                        if (dxCode != null)
                        {
                            model.DXCode = dxCode.DX_CODE;
                            model.AgeValidation = dxCode.AGE_VALIDATION;
                            model.ErrorPopup = dxCode.ERROR_POPUP;
                            model.EEocode = dxCode.EO_Code;
                            model.MemberDOB = memberDOB;
                            model.EndingDOS = dxCode.DOS.ToString();
                            model.Gender = dxCode.Gender;
                            list.Add(model);
                            return list;
                        }
                        else
                        {
                            model.DXCode = "";
                            model.AgeValidation = "";
                            model.ErrorPopup = "";
                            model.EEocode = "";
                            model.MemberDOB = memberDOB;
                            model.EndingDOS = "";
                            model.Gender = "";
                            list.Add(model);
                            return list;
                        }
                    }
                    else
                    {
                        //DateTime Edos = Convert.ToDateTime(Constants.dateKey);
                        DateTime DOS = Convert.ToDateTime(endingDOS);

                        //if (Edos > DOS)
                        //{
                            var dxCode = (from item in _context.TBL_DX_CODE_MASTER.Where(x => x.DX_CODE == dxvalue && x.DX_TYPE == dxTp && x.PRACTICE_ID == PracticeID && x.PROJECT_ID == projectId ) select new { item.AGE_VALIDATION, item.ERROR_POPUP, item.DX_CODE, item.EO_Code, item.DOS, item.Gender }).FirstOrDefault();
                            if (dxCode != null)
                            {
                                model.DXCode = dxCode.DX_CODE;
                                model.AgeValidation = dxCode.AGE_VALIDATION;
                                model.ErrorPopup = dxCode.ERROR_POPUP;
                                model.EEocode = dxCode.EO_Code;
                                model.MemberDOB = memberDOB;
                                model.EndingDOS = dxCode.DOS.ToString();
                                model.Gender = dxCode.Gender;
                                list.Add(model);
                                return list;
                            }
                            else
                            {
                                model.DXCode = "";
                                model.AgeValidation = "";
                                model.ErrorPopup = "";
                                model.EEocode = "";
                                model.MemberDOB = memberDOB;
                                model.EndingDOS = "";
                                model.Gender = "";
                                list.Add(model);
                                return list;
                            }
                        //}
                        //else
                        //{
                        //    var dxCode = (from item in _context.TBL_DX_CODE_MASTER.Where(x => x.DX_CODE == dxvalue && x.DX_TYPE == dxTp && x.PRACTICE_ID == PracticeID && x.PROJECT_ID == projectId && (x.DOS <= DOS && x.DOS >= Edos)) select new { item.AGE_VALIDATION, item.ERROR_POPUP, item.DX_CODE, item.EO_Code, item.DOS, item.Gender }).FirstOrDefault();
                        //    if (dxCode != null)
                        //    {
                        //        model.DXCode = dxCode.DX_CODE;
                        //        model.AgeValidation = dxCode.AGE_VALIDATION;
                        //        model.ErrorPopup = dxCode.ERROR_POPUP;
                        //        model.EEocode = dxCode.EO_Code;
                        //        model.MemberDOB = memberDOB;
                        //        model.EndingDOS = dxCode.DOS.ToString();
                        //        model.Gender = dxCode.Gender;
                        //        list.Add(model);
                        //        return list;
                        //    }
                        //    else
                        //    {
                        //        model.DXCode = "";
                        //        model.AgeValidation = "";
                        //        model.ErrorPopup = "";
                        //        model.EEocode = "";
                        //        model.MemberDOB = memberDOB;
                        //        model.EndingDOS = "";
                        //        model.Gender = "";
                        //        list.Add(model);
                        //        return list;
                        //    }
                        //}
                    }
                }
            }
        }
        #endregion

        #region ICD Code Validation

        #region ICD Code Validation

        public string ICDCodeValidation(string dxCode, string EndingDOS, int batchId, string buttonName, int transDetailsID)
        {
            using (CBI_Anes_HighEntities _context = new CBI_Anes_HighEntities())
            {
                string DXCodeStatus = "";
                string Refernce = "";
                string eDOS = "";
                string EndDOS = EndingDOS;
                var transactionExits = _context.tbl_TRANSACTION.Where(x => x.BATCH_ID == batchId).FirstOrDefault();

                DateTime firstInterval = Convert.ToDateTime(Constants.FirstInterval);
                DateTime secondInterval = Convert.ToDateTime(Constants.SecondInterval);
                DateTime thirdInterval = Convert.ToDateTime(Constants.ThirdInterval);
                DateTime fifthInterval = Convert.ToDateTime(Constants.FifthInterval);
                DateTime sixthInterval = Convert.ToDateTime(Constants.SixthInterval);

                int practiceId = Convert.ToInt32(HttpContext.Current.Session[Constants.PracticeID]);
                if (practiceId == 1)
                {
                    if (!EndingDOS.ToUpper().Contains("NO DOS"))
                    {
                        DateTime EDOS = Convert.ToDateTime(EndingDOS);
                        var list = (from TD in _context.tbl_TRANSACTION_DETAILS
                                    join T in _context.tbl_TRANSACTION on TD.TRANS_ID equals T.TRANS_ID
                                    join I in _context.tbl_IMPORT_TABLE on T.BATCH_ID equals I.BATCH_ID
                                    where T.BATCH_ID == batchId
                                    select new
                                    {
                                        transID = TD.TRANS_ID,
                                        dxCode = TD.ICD,
                                        EndingDOS = TD.ENDING_DOS,
                                        transDetailsID = TD.TRANS_DETAIL_ID
                                    }).ToList();

                        if (list != null)
                        {
                            var dcCodeList = (from item in list
                                              select new HighMarkCoderTransactionModel
                                              {
                                                  Tid = Convert.ToInt32(item.transID),
                                                  DXCode = item.dxCode,
                                                  DOS = CryptoGraphy.Decrypt(item.EndingDOS).ToString(),
                                                  TRANS_DETAIL_ID = item.transDetailsID
                                              }).ToList();
                            if (transDetailsID != 0)
                            {
                                var endingDOS = _context.tbl_TRANSACTION_DETAILS.Where(x => x.TRANS_DETAIL_ID == transDetailsID).FirstOrDefault();
                                eDOS = CryptoGraphy.Decrypt(endingDOS.ENDING_DOS.ToString());
                            }

                            foreach (var item in dcCodeList)
                            {
                                string EndingDOSS = CryptoGraphy.Encrypt(EndDOS).ToString();
                                if (item.DXCode == dxCode && !EndingDOS.ToUpper().Contains("NO DOS"))
                                {
                                    if (!eDOS.Contains("NO DOS"))
                                    {
                                        if (Convert.ToDateTime(item.DOS) < firstInterval && EDOS < firstInterval)
                                        {
                                            if (buttonName == "Update DX Code")
                                            {
                                                var Code = from listItem in dcCodeList.Where(x => (Convert.ToDateTime(x.DOS) < firstInterval) && x.DXCode == dxCode && x.TRANS_DETAIL_ID == transDetailsID) select new { listItem.DXCode };
                                                int count = Code.ToArray().Count();
                                                if (count != 0)
                                                {
                                                    DXCodeStatus = "";
                                                    Refernce = "Success";
                                                }
                                            }
                                            else
                                            {
                                                DXCodeStatus = "DX Code available";
                                            }
                                        }
                                        else if (EDOS >= firstInterval && EDOS < secondInterval && Convert.ToDateTime(item.DOS) >= firstInterval && Convert.ToDateTime(item.DOS) < secondInterval)
                                        {
                                            if (buttonName == "Update DX Code")
                                            {
                                                var Code = from listItem in dcCodeList.Where(x => (Convert.ToDateTime(x.DOS) >= firstInterval && Convert.ToDateTime(x.DOS) < secondInterval) && x.DXCode == dxCode && x.TRANS_DETAIL_ID == transDetailsID) select new { listItem.DXCode };
                                                int count = Code.ToArray().Count();
                                                if (count != 0)
                                                {
                                                    DXCodeStatus = "";
                                                    Refernce = "Success";
                                                }
                                            }
                                            else
                                            {
                                                DXCodeStatus = "DX Code available";
                                            }
                                        }
                                        else if (EDOS >= secondInterval && EDOS < thirdInterval && Convert.ToDateTime(item.DOS) >= secondInterval && Convert.ToDateTime(item.DOS) < thirdInterval)
                                        {
                                            if (buttonName == "Update DX Code")
                                            {
                                                var Code = from listItem in dcCodeList.Where(x => (Convert.ToDateTime(x.DOS) >= secondInterval && Convert.ToDateTime(x.DOS) < thirdInterval) && x.DXCode == dxCode && x.TRANS_DETAIL_ID == transDetailsID) select new { listItem.DXCode };
                                                int count = Code.ToArray().Count();
                                                if (count != 0)
                                                {
                                                    DXCodeStatus = "";
                                                    Refernce = "Success";
                                                }
                                            }
                                            else
                                            {
                                                DXCodeStatus = "DX Code available";
                                            }
                                        }
                                        else if (EDOS > thirdInterval && Convert.ToDateTime(item.DOS) > thirdInterval)
                                        {
                                            if (buttonName == "Update DX Code")
                                            {
                                                var Code = from listItem in dcCodeList.Where(x => (Convert.ToDateTime(x.DOS) > thirdInterval) && x.DXCode == dxCode && x.TRANS_DETAIL_ID == transDetailsID) select new { listItem.DXCode };
                                                int count = Code.ToArray().Count();
                                                if (count != 0)
                                                {
                                                    DXCodeStatus = "";
                                                    Refernce = "Success";
                                                }
                                            }
                                            else
                                            {
                                                DXCodeStatus = "DX Code available";
                                            }
                                        }
                                    }
                                }
                            }

                            if (buttonName == "Update DX Code")
                            {
                                if (!eDOS.Contains("NO DOS"))
                                {
                                    if (EDOS < firstInterval)
                                    {
                                        var Code = from item in dcCodeList.Where(x => (Convert.ToDateTime(x.DOS) < firstInterval) && x.DXCode == dxCode) select new { item.DXCode };
                                        int count = Code.ToArray().Count();
                                        if (count != 0 && Refernce != "Success")
                                        {
                                            DXCodeStatus = "DX Code available";
                                        }
                                    }
                                    else if (EDOS >= firstInterval && EDOS < secondInterval)
                                    {
                                        var Code = from item in dcCodeList.Where(x => (Convert.ToDateTime(x.DOS) >= firstInterval && Convert.ToDateTime(x.DOS) < secondInterval) && x.DXCode == dxCode) select new { item.DXCode };
                                        int count = Code.ToArray().Count();
                                        if (count != 0 && Refernce != "Success")
                                        {
                                            DXCodeStatus = "DX Code available";
                                        }
                                    }
                                    else if (EDOS >= secondInterval && EDOS < thirdInterval)
                                    {
                                        var Code = from item in dcCodeList.Where(x => (Convert.ToDateTime(x.DOS) >= secondInterval && Convert.ToDateTime(x.DOS) < thirdInterval) && x.DXCode == dxCode) select new { item.DXCode };
                                        int count = Code.ToArray().Count();
                                        if (count != 0 && Refernce != "Success")
                                        {
                                            DXCodeStatus = "DX Code available";
                                        }
                                    }
                                    else if (EDOS > thirdInterval)
                                    {
                                        var Code = from item in dcCodeList.Where(x => (Convert.ToDateTime(x.DOS) > thirdInterval) && x.DXCode == dxCode) select new { item.DXCode };
                                        int count = Code.ToArray().Count();
                                        if (count != 0 && Refernce != "Success")
                                        {
                                            DXCodeStatus = "DX Code available";
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                else
                {
                    if (!EndingDOS.ToUpper().Contains("NO DOS"))
                    {
                        DateTime EDOS = Convert.ToDateTime(EndingDOS);
                        var list = (from TD in _context.tbl_TRANSACTION_DETAILS
                                    join T in _context.tbl_TRANSACTION on TD.TRANS_ID equals T.TRANS_ID
                                    join I in _context.tbl_IMPORT_TABLE on T.BATCH_ID equals I.BATCH_ID
                                    where T.BATCH_ID == batchId
                                    select new
                                    {
                                        transID = TD.TRANS_ID,
                                        dxCode = TD.ICD,
                                        EndingDOS = TD.ENDING_DOS,
                                        transDetailsID = TD.TRANS_DETAIL_ID
                                    }).ToList();

                        if (list != null)
                        {
                            var dcCodeList = (from item in list
                                              select new HighMarkCoderTransactionModel
                                              {
                                                  Tid = Convert.ToInt32(item.transID),
                                                  DXCode = item.dxCode,
                                                  DOS = CryptoGraphy.Decrypt(item.EndingDOS).ToString(),
                                                  TRANS_DETAIL_ID = item.transDetailsID
                                              }).ToList();
                            if (transDetailsID != 0)
                            {
                                var endingDOS = _context.tbl_TRANSACTION_DETAILS.Where(x => x.TRANS_DETAIL_ID == transDetailsID).FirstOrDefault();
                                eDOS = CryptoGraphy.Decrypt(endingDOS.ENDING_DOS.ToString());
                            }

                            foreach (var item in dcCodeList)
                            {
                                string EndingDOSS = CryptoGraphy.Encrypt(EndDOS).ToString();
                                if (item.DXCode == dxCode && !EndingDOS.ToUpper().Contains("NO DOS"))
                                {
                                    if (!eDOS.Contains("NO DOS"))
                                    {
                                        if (Convert.ToDateTime(item.DOS) < thirdInterval && EDOS < thirdInterval)
                                        {
                                            if (buttonName == "Update DX Code")
                                            {
                                                var Code = from listItem in dcCodeList.Where(x => (Convert.ToDateTime(x.DOS) < thirdInterval) && x.DXCode == dxCode && x.TRANS_DETAIL_ID == transDetailsID) select new { listItem.DXCode };
                                                int count = Code.ToArray().Count();
                                                if (count != 0)
                                                {
                                                    DXCodeStatus = "";
                                                    Refernce = "Success";
                                                }
                                            }
                                            else
                                            {
                                                DXCodeStatus = "DX Code available";
                                            }
                                        }
                                        else if (EDOS >= thirdInterval && EDOS < fifthInterval && Convert.ToDateTime(item.DOS) >= thirdInterval && Convert.ToDateTime(item.DOS) < fifthInterval)
                                        {
                                            if (buttonName == "Update DX Code")
                                            {
                                                var Code = from listItem in dcCodeList.Where(x => (Convert.ToDateTime(x.DOS) >= thirdInterval && Convert.ToDateTime(x.DOS) < fifthInterval) && x.DXCode == dxCode && x.TRANS_DETAIL_ID == transDetailsID) select new { listItem.DXCode };
                                                int count = Code.ToArray().Count();
                                                if (count != 0)
                                                {
                                                    DXCodeStatus = "";
                                                    Refernce = "Success";
                                                }
                                            }
                                            else
                                            {
                                                DXCodeStatus = "DX Code available";
                                            }
                                        }
                                        else if (EDOS >= fifthInterval && EDOS < sixthInterval && Convert.ToDateTime(item.DOS) >= fifthInterval && Convert.ToDateTime(item.DOS) < sixthInterval)
                                        {
                                            if (buttonName == "Update DX Code")
                                            {
                                                var Code = from listItem in dcCodeList.Where(x => (Convert.ToDateTime(x.DOS) >= fifthInterval && Convert.ToDateTime(x.DOS) < sixthInterval) && x.DXCode == dxCode && x.TRANS_DETAIL_ID == transDetailsID) select new { listItem.DXCode };
                                                int count = Code.ToArray().Count();
                                                if (count != 0)
                                                {
                                                    DXCodeStatus = "";
                                                    Refernce = "Success";
                                                }
                                            }
                                            else
                                            {
                                                DXCodeStatus = "DX Code available";
                                            }
                                        }
                                        else if (EDOS > sixthInterval && Convert.ToDateTime(item.DOS) > sixthInterval)
                                        {
                                            if (buttonName == "Update DX Code")
                                            {
                                                var Code = from listItem in dcCodeList.Where(x => (Convert.ToDateTime(x.DOS) > sixthInterval) && x.DXCode == dxCode && x.TRANS_DETAIL_ID == transDetailsID) select new { listItem.DXCode };
                                                int count = Code.ToArray().Count();
                                                if (count != 0)
                                                {
                                                    DXCodeStatus = "";
                                                    Refernce = "Success";
                                                }
                                            }
                                            else
                                            {
                                                DXCodeStatus = "DX Code available";
                                            }
                                        }
                                    }
                                }
                            }

                            if (buttonName == "Update DX Code")
                            {
                                if (!eDOS.Contains("NO DOS"))
                                {
                                    if (EDOS < thirdInterval)
                                    {
                                        var Code = from item in dcCodeList.Where(x => (Convert.ToDateTime(x.DOS) < thirdInterval) && x.DXCode == dxCode) select new { item.DXCode };
                                        int count = Code.ToArray().Count();
                                        if (count != 0 && Refernce != "Success")
                                        {
                                            DXCodeStatus = "DX Code available";
                                        }
                                    }
                                    else if (EDOS >= thirdInterval && EDOS < fifthInterval)
                                    {
                                        var Code = from item in dcCodeList.Where(x => (Convert.ToDateTime(x.DOS) >= thirdInterval && Convert.ToDateTime(x.DOS) < fifthInterval) && x.DXCode == dxCode) select new { item.DXCode };
                                        int count = Code.ToArray().Count();
                                        if (count != 0 && Refernce != "Success")
                                        {
                                            DXCodeStatus = "DX Code available";
                                        }
                                    }
                                    else if (EDOS >= fifthInterval && EDOS < sixthInterval)
                                    {
                                        var Code = from item in dcCodeList.Where(x => (Convert.ToDateTime(x.DOS) >= fifthInterval && Convert.ToDateTime(x.DOS) < sixthInterval) && x.DXCode == dxCode) select new { item.DXCode };
                                        int count = Code.ToArray().Count();
                                        if (count != 0 && Refernce != "Success")
                                        {
                                            DXCodeStatus = "DX Code available";
                                        }
                                    }
                                    else if (EDOS > sixthInterval)
                                    {
                                        var Code = from item in dcCodeList.Where(x => (Convert.ToDateTime(x.DOS) > sixthInterval) && x.DXCode == dxCode) select new { item.DXCode };
                                        int count = Code.ToArray().Count();
                                        if (count != 0 && Refernce != "Success")
                                        {
                                            DXCodeStatus = "DX Code available";
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                
                return DXCodeStatus;
            }
        }

        #endregion
        #endregion


    }
}
