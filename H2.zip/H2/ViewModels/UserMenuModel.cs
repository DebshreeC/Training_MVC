﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.Mvc;

namespace CBIplus.BAL.ViewModels
{
   public class UserMenuModel
    {
        public string UserName { get; set; }
        //public List<string> ListOfMainMenu { get; set; }
        //public List<string> ListOfSubMenu { get; set; }
        public string MainMenu { get; set; }
        public string SubMenu { get; set; }
        public List<SelectListItem> ClientList {get;set;}
        public List<SelectListItem> PracticeList { get; set; }
        public string SelectedClient{get;set;}
        public string SelectedPractice { get; set; }
        public string SelectedLocation { get; set; }
    }
}
