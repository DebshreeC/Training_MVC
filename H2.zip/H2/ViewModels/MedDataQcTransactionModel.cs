﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.Mvc;

namespace CBIplus.BAL.ViewModels
{
    public class MedDataQcTransactionModel
    {
        public string FromDos { get; set; }
        public string ToDos { get; set; }
        public List<SelectListItem> CoderList { get; set; }
        public string SelectedCoder { get; set; }
        public string CodedDate { get; set; }
        public List<SelectListItem> ProviderMdList { get; set; }
        public string SelecetedProvider { get; set; }
        public List<SelectListItem> NPPAList { get; set; }
        public string SelectedNPPA { get; set; }
        public string CPTLevel { get; set; }
        public string CPT { get; set; }
        public string AccountNumber { get; set; }
        public string Insurance { get; set; }
        public string Comments { get; set; }
        public string AnesType { get; set; }
        public List<SelectListItem> PhysicalStatusList { get; set; }
        public string PhysicalStatus { get; set; }
        public string DOS { get; set; }
        public string FacilityName { get; set; }
        public string BatchName { get; set; }
        public int BatchId { get; set; }
        public string JobName { get; set; }
        public string PageCount { get; set; }
        public int? TRANS_ID { get; set; }
        public string AsaCross { get; set; }
        public string Modifier { get; set; }
        public string DiadnosisResult { get; set; }
        public string AncillaryServices { get; set; }
        public string AncillaryModifier { get; set; }
        public string AcutePainCPT { get; set; }
        public string AcutePainDX { get; set; }
        public string AcutePainPOS { get; set; }
        public string SelectPQRS { get; set; }
        public string MedicalDirection { get; set; }
        public string AncillaryServiceProvider { get; set; }
        public string SelectQualifyingCircumstances { get; set; }
        public string BaseUnitModification { get; set; }
        public List<SelectListItem> QualifyingCircumstances { get; set; }
        public string Diagnosis { get; set; }
        public List<SelectListItem> PQRS { get; set; }
        public List<SelectListItem> StatusNames { get; set; }
        public int TRANS_DETAIL_ID { get; set; }
        public string PopUpStatus { get; set; }
        public string PatientName { get; set; }
        public string IcdCode { get; set; }

        public List<SelectListItem> ErrorList { get; set; }
        public List<SelectListItem> SubErrorList { get; set; }
        public string SelecetedError { get; set; }
        public string SelectedSubError { get; set; }
        public string QcComments { get; set; }
        public string ErrorCount { get; set; }
        public string ErrorCorrection { get; set; }
        /************************SUBHAJA******************new fileds aaded**************/
        public string errorMicroCategory { get; set; }
        public string erroSeverity { get; set; }
        public string errorBehaviour { get; set; }
        public string errorFinancialImpact { get; set; }
        /************************SUBHAJA******************new fileds aaded**************/
        public string ReviewReAudit { get; set; }
        public string ReviewReAuditStatus { get; set; }
        public string ProviderName { get; set; }
        public string CodedBy { get; set; }
        public List<SelectListItem> AnesthesiaStartTimeList { get; set; }
        public List<SelectListItem> AnesthesiaEndTimeList { get; set; }
        public string AnesthesiaStartTimeFrom { get; set; }
        public string AnesthesiaStartTimeTo { get; set; }
        public string AnesthesiaEndTimeFrom { get; set; }
        public string AnesthesiaEndTimeTo { get; set; }
        public string TimeDifference { get; set; }
        public string CRNA { get; set; }

        public string ProviderName1 { get; set; }
        public string ProviderName2 { get; set; }
        public string ProviderName3 { get; set; }
        public string ProviderName4 { get; set; }
        public string ProviderName5 { get; set; }
        public string CRNA1 { get; set; }
        public string CRNA2 { get; set; }
        public string CRNA3 { get; set; }
        public string CRNA4 { get; set; }
        public string CRNA5 { get; set; }
    }
}
