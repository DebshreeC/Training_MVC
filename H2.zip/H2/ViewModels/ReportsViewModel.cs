﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.Mvc;

namespace CBIplus.BAL.ViewModels
{
   public class ReportsViewModel
    {
        public string FromDate { get; set; }
        public string ToDate { get; set; }
        public string ErrorStatus { get; set; }
        public string ProjectId { get; set; }
        public string TaskId { get; set; }
        public string UserName { get; set; }
        public List<SelectListItem> FacilityList { get; set; }
        public string Facility { get; set; }
        public List<SelectListItem> BranchNameList { get; set; }
        public string BatchName { get; set; }
        public List<SelectListItem> CodingStatusList { get; set; }
        public string CodingStatus { get; set; }
        public string EncounterType { get; set; }
        public string Location { get; set; }
        public string CoderNames { get; set; }
        public string CodingStatusQC { get; set; }
        public string SelectUserNtlg { get; set; }
        public List<SelectListItem>UserNtlgList { get; set; }
        public string CodedDate { get; set; }
        public string PracticeName { get; set; }
        public string PracticeID { get; set; }
        public string AuditCategory { get; set; }
        public List<SelectListItem> AuditCategoryList { get; set; }
      
        public string ChartCoded { get; set; }
        public string LWBS { get; set; }
        public string PVTS { get; set; }
        public string ChartsSendBack { get; set; }

        public int BatchCount { get; set; }
        public int CompletedAccounts { get;set;}
        public int PendingAcounts{get;set;}
        public string Type { get; set; }

        //public string batchName { get; set; }
    }
}
