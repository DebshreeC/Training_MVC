﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.Mvc;

namespace CBIplus.BAL.ViewModels
{
    public class QCFeedBackModel
    {
        public string TrackingCode { get; set; }
        public string BATCH_NAME { get; set; }
        public string ACCOUNT_NO { get; set; }
        public string ECI { get; set; }
        public string UMI { get; set; }
        public string FIRST_NAME { get; set; }
        public string LAST_NAME { get; set; }
        public string HIC { get; set; }
        public string MEMBER_DOB { get; set; }
        public string Member_Gender { get; set; }
        public string ENCOUNTER_TYPE { get; set; }
        public string Beginning_DOS { get; set; }
        public string Ending_DOS { get; set; }
        public string Performing_Provider_NPI { get; set; }
        public string Performing_Provider_BSID { get; set; }
        public string Billing_Provider_NPI { get; set; }
        public string Billing_Provider_BSID { get; set; }
        public string ICD_CODE { get; set; }
        public string ICD { get; set; }
        public string Place_Of_Service { get; set; }
        public string Delete_Indicator { get; set; }
        public string CPT { get; set; }
        public string Procedure_Type { get; set; }
        public string PAGE_NO { get; set; }
        public string EO_CODE1 { get; set; }
        public string EO_COMMENT1 { get; set; }
        public string EO_CODE2 { get; set; }
        public string EO_CODE3 { get; set; }
        public string EO_COMMENT2 { get; set; }
        public string EO_COMMENT3 { get; set; }
        public string EO_CODE4 { get; set; }
        public string EO_COMMENT4 { get; set; }
        public string EO_CODE5 { get; set; }
        public string EO_COMMENT5 { get; set; }
        public string EO_CODE6 { get; set; }
        public string EO_COMMENT6 { get; set; }
        public string QC_Comments { get; set; }
        public string Error_Category { get; set; }
        public string ERROR_SUBCATEGORY { get; set; }
        public string ERROR_WEIGHTAGE { get; set; }
        public string QC_By { get; set; }
        public string QC_DATE { get; set; }
        public List<SelectListItem> QCStatusList { get; set; }
        public string QCStatus { get; set; }
        public string Comments { get; set; }
        public int TransId { get; set; }
        public int TransDetailsId { get; set; }
        public string Error_Correction { get; set; }
    }
}
