﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.Mvc;

namespace CBIplus.BAL.ViewModels
{
  public  class ErrorGridModel
    {
      public string QCErrorCategory { get; set; }
      public string QCErrorSubCategory { get; set; }
      public string QCErrorCount { get; set; }
      public string QCErrorCorrection { get; set; }
      public string QCErrorComments { get; set; }
      public string QCStatus { get; set; }
      public List<SelectListItem> QCErrorCorrectionList { get; set; }
     
      public List<SelectListItem> ErrorList { get; set; }
      public List<SelectListItem> SubErrorList { get; set; }
      public string SelecetedError { get; set; }
      public string SelectedSubError { get; set; }
      public int TransDetailsId { get; set; }
    }
}
