﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.Mvc;

namespace CBIplus.BAL.ViewModels
{
   public class ReleaseAccountModel
    {
       public int BatchId { get; set; }
       public int TransId{get;set;}
       public string AccountNumber { get; set; }
       public string ButtonText { get; set; }
       public List<SelectListItem> BranchNameList { get; set; }
       public string BatchName { get; set; }

       public List<SelectListItem> LocationList { get; set; }
       public string AutoSelectLocation { get; set; }
    }
}
