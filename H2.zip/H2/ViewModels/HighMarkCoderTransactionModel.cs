﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.Mvc;

namespace CBIplus.BAL.ViewModels
{
    public class HighMarkCoderTransactionModel
    {
        public string TrackingCode { get; set; }
        public int Practice_Id { get; set; }
        public string ReceivedDate { get; set; }      
        public List<SelectListItem> StatusList { get; set; }
        public List<SelectListItem> GenderList { get; set; }
        public string SelectStatus { get; set; }
        public string SelectGender { get; set; }
        public string CoderComment { get; set; }
        public string MemberFirstName { get; set; }
        public string Status { get; set; }       
        public string MemberLastName { get; set; }
        public string MemberDOB { get; set; }
        public string MemberGender { get; set; }       
        public string BeginningDOS { get; set; }
        public string EDos { get; set; }
        public string EndingDOS { get; set; }
        public string DxType { get; set; }
        public string DXCode { get; set; }
        public string Page { get; set; }
        public string EOCode1 { get; set; }
        public string EOComment1 { get; set; }
        public string EOCode2 { get; set; }
        public string EOComment2 { get; set; }
        public string EOCode3 { get; set; }
        public string EOComment3 { get; set; }
        public string EOCode4 { get; set; }
        public string EOComment4 { get; set; }
        public string EOCode5 { get; set; }
        public string EOComment5 { get; set; }
        public string EOCode6 { get; set; }
        public string EOComment6 { get; set; }
        public List<SelectListItem> EOCode { get; set; }
        public int TRANS_DETAIL_ID { get; set; }
        public string TRANS_ID { get; set; }
        public int BatchId { get; set; }
        public List<SelectListItem> EncounterTypeList { get; set; }
        public string EncounterType { get; set; }
        public string SelectedEncounter { get; set; }
        public List<SelectListItem> EOCodeList { get; set; }
        public string[] dummayArray { get; set; }
        public List<SelectListItem> DXTypeList { get; set; }
        public DateTime? InvReceivedDate { get; set; }
        public string ErrorCorrection { get; set; }
        public string QCcomments { get; set; }
        public string Duplicate { get; set; }
        public string AgeValidation { get; set; }
        public string ErrorPopup { get; set; }
        public string ICDComments { get; set; }
        public string EEocode { get; set; }
        public List<SelectListItem> CommentsList { get; set; }
        public string Modifier { get; set; }
        public string CodedBy { get; set; }
        public string CodedDate { get; set; }
        public string QACorrected { get; set; }
        public string is_Acknowledge { get; set; }
        public string BatchName { get; set; }
        public string DOS { get; set; }
        public int Tid { get; set; }
        public string MBRDOB { get; set; }
        public string MGender { get; set; }
        public int TotalPages { get; set; }
        public string EndDOSS { get; set; }
        public string AllottedDate { get; set; }
        public string ICDResult { get; set; }
        public string BatchStatus { get; set; }
        public string MRN { get; set; }
        public string PDFpath { get; set; }
        public string Gender { get; set; }
    }
}