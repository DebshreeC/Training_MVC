﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.Mvc;

namespace CBIplus.BAL.ViewModels
{
    public class PerimeterMasterModel
    {
        public string Code { get; set; }
        public string Description { get; set; }
        public string NPPAName { get; set; }
        public string NPPACode { get; set; }
        public string NPPAFacility { get; set; }
        public List<SelectListItem> FacilityList { get; set; }
        public string MasterDropdownValue { get; set; }
        public List<SelectListItem> MasterDropdownList { get; set; }
        public string attFacility { get; set; }
        public string PhysicianName { get; set; }
        public string PhysicianID { get; set; }
        public string Comment { get; set; }
        public string addCPT { get; set; }
        public string CPTName { get; set; }
        public string DownCodedFrom { get; set; }
        public string Disposition { get; set; }
        public string ErrorCategory { get; set; }
        public string SubCategory1 { get; set; }
        public string Mod { get; set; }
        public string OtherCPTT { get; set; }
        public string OtherCPTName { get; set; }
        public string Scribee { get; set; }
        public string ScribeID { get; set; }
        public string ProjectID { get; set; }
        public string ScribeFacility { get; set; }
        public string dcComment { get; set; }
    }
}
