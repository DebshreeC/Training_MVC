﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.Mvc;

namespace CBIplus.BAL.ViewModels
{
    public class QCClarificationModel
    {
        public string TrackingCode { get; set; }

        public string BATCH_NAME { get; set; }
        public string ACCOUNT_NO { get; set; }
        public string ECI { get; set; }
        public string UMI { get; set; }
        public string FIRST_NAME { get; set; }
        public string LAST_NAME { get; set; }
        public string HIC { get; set; }
        public string MEMBER_DOB { get; set; }
        public string Member_Gender { get; set; }
        public string ENCOUNTER_TYPE { get; set; }
        public string QC_Comments { get; set; }
        public string Error_Category { get; set; }
        public string ERROR_SUBCATEGORY { get; set; }
        public string ERROR_WEIGHTAGE { get; set; }
        public string QC_By { get; set; }
        public string QC_DATE { get; set; }
        public string CODED_DATE { get; set; }
        public string Coded_By { get; set; }
        public string Coding_Comments { get; set; }
        public string TransId { get; set; }
        public int TransDetailsId { get; set; }



        
        public int Practice_Id { get; set; }
        public string ReceivedDate { get; set; }
        public List<SelectListItem> StatusList { get; set; }
        public List<SelectListItem> GenderList { get; set; }
        public string SelectStatus { get; set; }
        public string SelectGender { get; set; }
        public string CoderComment { get; set; }
        public string MemberFirstName { get; set; }
        public string Status { get; set; }
        public string MemberLastName { get; set; }
        public string MemberDOB { get; set; }
        public string MemberGender { get; set; }
        public string BeginningDOS { get; set; }
        public string EDos { get; set; }
        public string EndingDOS { get; set; }
        public string DxType { get; set; }
        public string DXCode { get; set; }
        public string Page { get; set; }
        public string EOCode1 { get; set; }
        public string EOComment1 { get; set; }
        public string EOCode2 { get; set; }
        public string EOComment2 { get; set; }
        public string EOCode3 { get; set; }
        public string EOComment3 { get; set; }
        public string EOCode4 { get; set; }
        public string EOComment4 { get; set; }
        public string EOCode5 { get; set; }
        public string EOComment5 { get; set; }
        public string EOCode6 { get; set; }
        public string EOComment6 { get; set; }
        public List<SelectListItem> EOCode { get; set; }
        public int TRANS_DETAIL_ID { get; set; }
        public string TRANS_ID { get; set; }
        public int BatchId { get; set; }
        public List<SelectListItem> EncounterTypeList { get; set; }
        public string EncounterType { get; set; }
        public string SelectedEncounter { get; set; }
        public List<SelectListItem> EOCodeList { get; set; }
        public string[] dummayArray { get; set; }
        public List<SelectListItem> DXTypeList { get; set; }
        public DateTime? InvReceivedDate { get; set; }
        public string ErrorCorrection { get; set; }
        public string QCcomments { get; set; }
        public string Duplicate { get; set; }
        public string AgeValidation { get; set; }
        public string ErrorPopup { get; set; }
        public string ICDComments { get; set; }
        public string EEocode { get; set; }
        public List<SelectListItem> CommentsList { get; set; }
        public string Modifier { get; set; }
        public string CodedBy { get; set; }
        public string CodedDate { get; set; }
        public string Comments { get; set; }
    }
}
