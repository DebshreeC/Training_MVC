﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CBIplus.BAL.ViewModels
{
    public class ImportModel
    {
        public string FieldName { get; set; }
        public string AccountType { get; set; }
        public string FilterBy { get; set; }
        public string SearchText { get; set; }
        public List<string> GridHeaders { get; set; }
        public List<string> UniqueBatchList { get; set; }
        public string SelectedBatch { get; set; }
        public string JobName { get; set; }
        public string DataImage { get; set; }
        public string PageCount { get; set; }
        public string Facility { get; set; }
        public string AccountNumber { get; set; }
        public string BatchNumber { get; set; }
        public string Remarks { get; set; }

        public string Location { get; set; }
        public string Speciality { get; set; }
        public string PatientName { get; set; }
        public string MRN { get; set; }
        public string PayerClass { get; set; }
        public string ICDCode { get; set; }
        public string ReceivedDate { get; set; }
        public List<string> Headers { get; set; }
        public string SelectedHeader { get; set; }
        public string StatusMessage { get; set; }
        public int TotalExcelCount { get; set; }
        public int SuccessfullCount { get; set; }
        public int UnsuccessfullCount { get; set; }
        public bool RECORD_STATUS { get; set; }
        public int BATCH_ID { get; set; }
        public DateTime? DOS { get; set; }

        //High Mark Common Fileds

        public string TrackingCode { get; set; }
        public string ECI { get; set; }
        public string UMI { get; set; }
        public string HIC { get; set; }
        public string MemberFirstName { get; set; }
        public string MemberLastName { get; set; }
        public string MemberDOB { get; set; }
        public string MemberGender { get; set; }
        public string EncounterType { get; set; }
        public string PerformProviderNPI { get; set; }
        public string PerformProviderBSID { get; set; }
        public string BillingProviderNPI { get; set; }
        public string BillingProviderBSID { get; set; }
        public string RetrivalDate { get; set; }
        public string ProjectId { get; set; }
        public string DxType { get; set; }
        public string DxCode { get; set; }
        public string HCC { get; set; }
    }
}
