﻿#region History

//-----------------------------------------------------------------------
// Created By & Created Date : Jagadeesh J & 05/26/2016
// Description: Created QC Transaction manager class to maintain all the tranction details related to QC.
//-----------------------------------------------------------------------
// Modified By & Modified Date:
// Description:
//-----------------------------------------------------------------------
// Modified By & Modified Date:
// Description:
//-----------------------------------------------------------------------
// Modified By & Modified Date:
// Description:
//-----------------------------------------------------------------------

#endregion

#region Usings

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.Mvc;

#endregion


namespace CBIplus.BAL.ViewModels
{
    public class HighMarkQCTransactionModel
    {
       // #region Properties

        public string TransactionId { get; set; }
        public string ProjectId { get; set; }
        public int Practice_Id { get; set; }
        public string PageNo { get; set; }
        public string CodingComments { get; set; }
        public string CodedDate { get; set; }
        public string CodedBy { get; set; }
        public string QC_ALLOTED_DATE { get; set; }
        public string QCedBy { get; set; }
        public string QCedDate { get; set; }
        public string QCStatus { get; set; }
        public string ErrorCategory { get; set; }
        public string ErrorSubCategory { get; set; }
        public string QCComments { get; set; }
        public string QCErrorCorrection { get; set; }
        public string IsAcknowledge { get; set; }
        public string AcknoledgeComments { get; set; }
        public string IsAudited { get; set; }
        public string IsAcknowledgeBy { get; set; }
        public string IsSkipped { get; set; }
        public string IsRepoened { get; set; }
        public string DOS { get; set; }
        public string IsPending { get; set; }
        public string ErrorWeightage { get; set; }
        public string IsAcknowledgeDate { get; set; }
        public string ErrorSentDate { get; set; }
        public string ReleaseReauditStatus { get; set; }
        public string ReleaseReauditBy { get; set; }
        public string ReleaseReauditDate { get; set; }
        public string Color { get; set; }
        public string HCCCode { get; set; }
        public string HCCType { get; set; }
        //public string Insurance { get; set; }
        //public string AdmittingPhy { get; set; }
        //public string AttendingPhy { get; set; }
        //public string EDMD { get; set; }
        //public string DOI { get; set; }
        //public string TOI { get; set; }
        //public string ChartNo { get; set; }       
        //public string UpdatedBy { get; set; }
       // public string UpdatedDate { get; set; }
        //public string CodingStatus { get; set; }       
        //public string ProviderMD { get; set; }
        //public string AssistantProvider { get; set; }
        //public string DisPosition { get; set; }
        //public string PatientStatus { get; set; }
        //public string TypeOfAccident { get; set; }
        //public string ShardVisit { get; set; }
        //public string AccountStatus { get; set; }
        //public string DOSCharged { get; set; }       
        //public string PendingUpdatedBy { get; set; }
        //public string WOAttastation { get; set; }       
        //public string KeyingComments { get; set; }
        //public string ARStatus { get; set; }      
        //public string Responsibility { get; set; }
        //public string SendToClientDate { get; set; }
        //public string ClientResponse { get; set; }
        //public string ClientResponseDate { get; set; }
        //public string PendingUpdateDate { get; set; }
        //public string PendingWorkDate { get; set; }
        //public string NPPA { get; set; }
        //public string SCRIBE { get; set; }
        //public string Resident { get; set; }
        //public string StartTime { get; set; }
        //public string EndTime { get; set; }
        //public string TotalTime { get; set; }
        //public string AnesType { get; set; }
        //public string PhysicalStatus { get; set; }
        //public string PAtineTime { get; set; }
        //public string CodingStartTime { get; set; }
        //public string CodingEndTime { get; set; }

       

        //

        public string TrackingCode { get; set; }
        public string ReceivedDate { get; set; }
        public List<SelectListItem> StatusList { get; set; }
        public List<SelectListItem> GenderList { get; set; }
        public string SelectStatus { get; set; }
        public string SelectGender { get; set; }
        public string CoderComment { get; set; }
        public string MemberFirstName { get; set; }
        public string Status { get; set; }
        public string MemberLastName { get; set; }
        public string MemberDOB { get; set; }
        public string MemberGender { get; set; }
        public string BeginningDOS { get; set; }
        public string EndingDOS { get; set; }
        public string DxType { get; set; }
        public string DXCode { get; set; }
        public string Page { get; set; }
        public string EOCode1 { get; set; }
        public string EOComment1 { get; set; }
        public string EOCode2 { get; set; }
        public string EOComment2 { get; set; }
        public string EOCode3 { get; set; }
        public string EOComment3 { get; set; }
        public string EOCode4 { get; set; }
        public string EOComment4 { get; set; }
        public string EOCode5 { get; set; }
        public string EOComment5 { get; set; }
        public string EOCode6 { get; set; }
        public string EOComment6 { get; set; }
        public List<SelectListItem> EOCode { get; set; }
        public int TRANS_DETAIL_ID { get; set; }
        public string TRANS_ID { get; set; }
        public int BatchId { get; set; }
        public List<SelectListItem> EncounterTypeList { get; set; }
        public string EncounterType { get; set; }
        public string SelectedEncounter { get; set; }
        public List<SelectListItem> EOCodeList { get; set; }
        public string[] dummayArray { get; set; }

        public List<SelectListItem> ErrorList { get; set; }
        public List<SelectListItem> SubErrorList { get; set; }
        public string SelecetedError { get; set; }
        public string SelectedSubError { get; set; }
        public string ErrorCount { get; set; }
        public string ErrorCorrection { get; set; }
        public string ICDCODE { get; set; }
        public string ICD { get; set; }
        public string ECI { get; set; }
        public string ICDComments { get; set; }
        public List<SelectListItem> DXTypeList { get; set; }
        public List<SelectListItem> CommentsList { get; set; }
        public int TotalPages { get; set; }
        public string BatchName { get;set;}
        public string FinancialImpact { get; set; }
        public string ICDResult { get; set; }
        public string PDFpath { get; set; }
      // #endregion
    }
}
