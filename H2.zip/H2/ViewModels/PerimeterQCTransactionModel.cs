﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.Mvc;

namespace CBIplus.BAL.ViewModels
{
    public class PerimeterQCTransactionModel
    {
        public List<SelectListItem> CoderList { get; set; }
        public string DOS { get; set; }
        public string SCRIBE { get; set; }
        public string AccountNumber { get; set; }
        public string Insurance { get; set; }
        public string AttendingPhysician { get; set; }
        public string NPPA { get; set; }
        public string Resident { get; set; }
        public string DCStatus { get; set; }
        public string Coder { get; set; }
        public string CodedDate { get; set; }
        public string Comments { get; set; }
        public int BATCH_ID { get; set; }
        public int SeletedCoder { get; set; }

        public int TRANS_DETAIL_ID { get; set; }
        public int TRANS_ID { get; set; }

        public string Downcoded { get; set; }
        public string HPI { get; set; }
        public string PFSH { get; set; }
        public string ROS { get; set; }
        public string EXAM { get; set; }

        public List<SelectListItem> CPTList { get; set; }
        public string ICD { get; set; }
        public string ICD_Results { get; set; }
        public string Type { get; set; }
        public List<SelectListItem> ModifierList { get; set; }
        public List<SelectListItem> StaticCommentsList { get; set; }


        public string PopUpStatus { get; set; }
        public string CPT { get; set; }
        public string Modifier { get; set; }
        public string CPTLevel { get; set; }
        public string DowncodedForm { get; set; }
        public List<SelectListItem> DowncodedFormList { get; set; }

        public List<SelectListItem> ErrorList { get; set; }
        public List<SelectListItem> SubErrorList { get; set; }
        
        public string SelecetedError { get; set; }
        public string SelectedSubError { get; set; }
        public string QcComments { get; set; }
        public string ErrorCount { get; set; }
        /************************SUBHAJA******************new fileds aaded**************/
        public string errorMicroCategory { get; set; }
        public string erroSeverity { get; set; }
        public string errorBehaviour { get; set; }
        public string errorFinancialImpact { get; set; }
        public string errorParameter { get; set; }
        public string errorSubParameter { get; set; }
        public List<SelectListItem> ErrorParameterList { get; set; }
        /************************SUBHAJA******************new fileds aaded**************/
        public string SelectedICDType { get; set; }
        public List<SelectListItem> LoadIcdType { get; set; }
        public string CPTorder { get;set;}

        public string Facility { get; set; }
        public List<SelectListItem> AttendingPhyList { get; set; }
        public List<SelectListItem> NPPAList { get; set; }
        public List<SelectListItem> ScribeList { get; set; }
        public List<SelectListItem> PatientStatusDCStatusList { get; set; }
        public List<SelectListItem> ResidentList { get; set; }
        public string PatientName { get; set; }
        public string PatientStatusDCStatus { get; set; }
        public List<string> ListOfAccountPDF { get; set; }
        public string PayerClass { get; set; }
     //   public string CPTOrder { get; set; }
    }
}