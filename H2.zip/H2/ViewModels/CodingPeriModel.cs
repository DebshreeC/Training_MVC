﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.Mvc;

namespace CBIplus.BAL.ViewModels
{
   public class CodingPeriModel
    {
       public string AccountNumber { get; set; }
       public string DOS { get; set; }
       public string Status { get; set; }
       public string Facility { get; set; }
       public string PatientName { get; set; }
       public int? TRANS_ID { get; set; }
       public int TRANS_DETAIL_ID { get; set; }
       public DateTime? ReceivedDate { get; set; }
       public string BatchName { get; set; }
       public string PayerClass { get; set; }
       public string AccountType { get; set; }
       public int BatchId { get; set; }
       public string CPTLevel { get; set; }
       

       public List<SelectListItem> AttendingPhyList { get; set; }
       public string AttendingPhy { get; set; }
       public List<SelectListItem> NPPAList { get; set; }
       public string NPPA { get; set; }
       public List<SelectListItem> ScribeList { get; set; }
       public string Scribe { get; set; }
       public List<SelectListItem> PatientStatusDCStatusList { get; set; }
       public string PatientStatusDCStatus { get; set; }
       public List<SelectListItem> ResidentList { get; set; }
       public string Resident { get; set; }
       public List<SelectListItem> DowncodedFormList { get; set; }
       public string DowncodedForm { get; set; }
       public string CodingStartTime { get; set; }
       public string SelectedICDType { get; set; }
       public string SelectedCPT { get; set; }

       public List<SelectListItem> CPTList { get; set; }
       public string CPT { get; set; }
       public List<SelectListItem> ModifierList { get; set; }
       public string Modifier { get; set; }
       public List<SelectListItem> StaticCommentsList { get; set; }
       public string Comments { get; set; }
       public List<string> ListOfAccountPDF { get; set; }
       public string AccountPDF { get; set; }

       public string Type { get; set; }
       public string ICD_Results { get; set; }
       public string ICD { get; set; }
       public string HPI { get; set; }
       public string PFSH { get; set; }
       public string ROS { get; set; }
       public string EXAM { get; set; }
       public int? Is_Reopened { get; set; }
       public List<SelectListItem> LoadIcdType { get; set; }
       public string CPTOrder { get; set; }
       public List<string> ConvertToPDF { get; set; }
       public string CodedDate { get; set; }
       public string PriCPT { get; set; }
       public string PyrClass { get; set; }
    }
}
