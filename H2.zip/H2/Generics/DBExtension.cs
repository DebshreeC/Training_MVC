using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.SqlClient;
using System.Reflection;

public static class DBExtension
{

    /// <summary>
    /// 
    /// </summary>
    /// <param name="db"></param>
    /// <param name="storedProcedureName"></param>
    /// <param name="parameters"></param>
    public static int ExecuteNonQuery(this Database db, string storedProcedureName, params SqlParameter[] parameters)
    {
        var conn = db.Connection;
        var initialState = conn.State;
        DataSet dataSet = new DataSet();
        try
        {
            if (initialState != ConnectionState.Open)
                conn.Open();

            SqlCommand cmd = new SqlCommand(storedProcedureName, (SqlConnection)conn);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandTimeout = 0;
            foreach (var parameter in parameters)
            {
                cmd.Parameters.Add(parameter);
            }
            return cmd.ExecuteNonQuery();
        }
        catch (Exception exception)
        {
            throw new MyException();
        }
    }

    /// <summary>
    /// Executes sp with parameters and returns results in a dataset.
    /// </summary>
    /// <param name="db"></param>
    /// <param name="storedProcedureName"></param>
    /// <param name="parameters"></param>
    /// <returns></returns>
    public static DataSet ExecuteDataset(this Database db, string storedProcedureName, params SqlParameter[] parameters)
    {
        var conn = db.Connection;
        var initialState = conn.State;
        DataSet dataSet = new DataSet();
        try
        {
            if (initialState != ConnectionState.Open)
                conn.Open();
            SqlDataAdapter sda = new SqlDataAdapter(storedProcedureName, (SqlConnection)conn);
            sda.SelectCommand.CommandTimeout = 0;
            sda.SelectCommand.CommandType = CommandType.StoredProcedure;
            foreach (var parameter in parameters)
            {
                sda.SelectCommand.Parameters.Add(parameter);
            }
            sda.Fill(dataSet);
        }
        catch (Exception ex)
        {
        }
        return dataSet;
    }
    public static DataSet ExecuteDataset(this Database db, string storedProcedureName, List<SqlParameter> parameters)
    {
        var conn = db.Connection;
        var initialState = conn.State;
        DataSet dataSet = new DataSet();
        try
        {
            if (initialState != ConnectionState.Open)
                conn.Open();
            SqlDataAdapter sda = new SqlDataAdapter(storedProcedureName, (SqlConnection)conn);
            sda.SelectCommand.CommandTimeout = 0;
            sda.SelectCommand.CommandType = CommandType.StoredProcedure;
            foreach (var parameter in parameters)
            {
                sda.SelectCommand.Parameters.AddWithValue(parameter.ParameterName, parameter.SqlValue);
            }
            sda.Fill(dataSet);
        }
        catch (Exception ex)
        {
        }
        return dataSet;
    }
    /// <summary>
    /// Executes sp and returns results in a dataset.
    /// </summary>
    /// <param name="db"></param>
    /// <param name="storedProcedureName"></param>
    /// <returns></returns>
    public static DataSet ExecuteDataset(this Database db, string storedProcedureName)
    {
        var conn = db.Connection;
        var initialState = conn.State;
        DataSet dataSet = new DataSet();
        try
        {
            if (initialState != ConnectionState.Open)
                conn.Open();
            SqlDataAdapter sda = new SqlDataAdapter(storedProcedureName, (SqlConnection)conn);
            sda.SelectCommand.CommandTimeout = 0;
            sda.SelectCommand.CommandType = CommandType.StoredProcedure;
            sda.Fill(dataSet);
        }
        catch (Exception exception)
        {
        }
        return dataSet;
    }


    public static DataTable ExecuteDatatable(this Database db, string storedProcedureName, params SqlParameter[] parameters)
    {
        var conn = db.Connection;
        var initialState = conn.State;
        DataTable datatb = new DataTable();
        try
        {
            if (initialState != ConnectionState.Open)
                conn.Open();
            SqlDataAdapter sda = new SqlDataAdapter(storedProcedureName, (SqlConnection)conn);
            sda.SelectCommand.CommandType = CommandType.StoredProcedure;
            sda.SelectCommand.CommandTimeout = 0;
            foreach (var parameter in parameters)
            {
                sda.SelectCommand.Parameters.Add(parameter);
            }
            sda.Fill(datatb);
            sda.SelectCommand.Parameters.Clear();
        }
        catch (Exception ex)
        {
        }
        return datatb;
    }
    /// <summary>
    /// 
    /// </summary>
    /// <param name="db"></param>
    /// <param name="storedProcedureName"></param>
    /// <param name="parameters"></param>
    /// <returns></returns>
    public static DataTable ExecuteDatatable(this Database db, string storedProcedureName, List<SqlParameter> parameters)
    {
        var conn = db.Connection;
        var initialState = conn.State;
        DataTable datatb = new DataTable();
        try
        {
            if (initialState != ConnectionState.Open)
                conn.Open();
            SqlDataAdapter sda = new SqlDataAdapter(storedProcedureName, (SqlConnection)conn);
            sda.SelectCommand.CommandType = CommandType.StoredProcedure;
            sda.SelectCommand.CommandTimeout = 0;
            foreach (var parameter in parameters)
            {
                sda.SelectCommand.Parameters.Add(parameter);
            }
            sda.Fill(datatb);
            sda.SelectCommand.Parameters.Clear();
        }
        catch (Exception ex)
        {
        }
        return datatb;
    }
    /// <summary>
    /// Executes sp and returns results in a dataset.
    /// </summary>
    /// <param name="db"></param>
    /// <param name="storedProcedureName"></param>
    /// <returns></returns>
    public static DataTable ExecuteDatatable(this Database db, string storedProcedureName)
    {
        var conn = db.Connection;
        var initialState = conn.State;
        DataTable datatb = new DataTable();
        try
        {
            if (initialState != ConnectionState.Open)
                conn.Open();
            SqlDataAdapter sda = new SqlDataAdapter(storedProcedureName, (SqlConnection)conn);
            sda.SelectCommand.CommandType = CommandType.StoredProcedure;
            sda.SelectCommand.CommandTimeout = 0;
            sda.Fill(datatb);
        }
        catch (Exception ex)
        {
        }
        return datatb;
    }

    //function that set the given object from the given data row
    public static T GetEntity<T>(this DataRow row) where T : new()
    {
        T item = new T();
        // go through each column
        foreach (DataColumn c in row.Table.Columns)
        {
            // find the property for the column
            PropertyInfo pInfo = item.GetType().GetProperty(c.ColumnName);

            if (pInfo != null && row[c] != DBNull.Value)
            {
                Type pType = pInfo.PropertyType;
                var targetType = pType.IsNullableType() ? Nullable.GetUnderlyingType(pType) : pType;
                var pVal = Convert.ChangeType(row[c], targetType);
                // if exists, set the value
                pInfo.SetValue(item, pVal, null);
            }
        }
        return item;
    }

    public static List<T> ToList<T>(this DataTable dt) where T : new()
    {
        List<T> data = new List<T>();
        foreach (DataRow row in dt.Rows)
        {
            data.Add(row.GetEntity<T>());
        };
        return data;
    }

    private static bool IsNullableType(this Type type)
    {
        return type.IsGenericType && type.GetGenericTypeDefinition().Equals(typeof(Nullable<>));
    }


    /// <summary>
    /// Execute reader extension
    /// </summary>
    /// <param name="db"></param>
    /// <param name="storedProcedureName"></param>
    /// <param name="parameters"></param>
    /// <returns></returns>
    public static SqlDataReader ExecuteReader(this Database db, string storedProcedureName, SqlParameter[] parameters)
    {
        var conn = db.Connection;
        var initialState = conn.State;

        try
        {
            if (initialState != ConnectionState.Open)
                conn.Open();

            SqlCommand cmd = new SqlCommand(storedProcedureName, (SqlConnection)conn);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandTimeout = 0;
            foreach (var parameter in parameters)
            {
                cmd.Parameters.Add(parameter);
            }
            return cmd.ExecuteReader();
        }
        catch (Exception exception)
        {
            throw new MyException();
        }
    }

    class MyException : Exception
    {
        public MyException()
        {
        }
    }

}