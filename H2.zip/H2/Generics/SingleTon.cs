﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using CBIplus.DAL;

/// <summary>
/// Summary description for SingleTon
/// </summary>
public static class Singleton
{
    private static CBI_Anes_HighEntities instance;

    // private Singleton() { }

    public static CBI_Anes_HighEntities Instance
    {
        get
        {
            if (instance == null)
            {
                instance = new CBI_Anes_HighEntities();
            }
            return instance;
        }
    }
}