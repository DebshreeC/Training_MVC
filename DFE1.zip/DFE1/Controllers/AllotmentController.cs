﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Denial_Coding.BAL.Generics;
using Denial_Coding.BAL.Managers;
using Denial_Coding.BAL.ViewModels;

namespace Denial_Coding.Controllers
{
    public class AllotmentController : Controller
    {

        IAllotmentService managerObj = new AllotmentManager();

        //
        // GET: /Allotment/
        public ActionResult CodingAllotment()
        {
            AllotmentModel model = new AllotmentModel(); 
            if (Convert.ToInt32(Session[Constants.ProjectId].ToString()) == 1)
            {
                model.CoderList = managerObj.getCoderNames(2, 1).OrderBy(x => x.Text).ToList();
            }
            else if (Convert.ToInt32(Session[Constants.ProjectId].ToString()) == 2)
            {
                model.CoderList = managerObj.getCoderNames(6, 5).OrderBy(x => x.Text).ToList();
            }
            else
            {
                
            }              
            model.PracticeList = managerObj.GetPracticeList();
            return View(model);
        }
        public ActionResult GetAccountDetails(string status, string fromDos, string toDos, int PracticeId)
        {
            return PartialView("_CoderAllotmentGrid", managerObj.GetAccountDetails(status, fromDos, toDos,PracticeId));
        }
        [HttpPost]
        public JsonResult CodingAllotment(string listOfAccounts, string PracticeId,string codername, string buttonText)
        {
            if (buttonText == "Allot")
            {
                 managerObj.AllotToCoder(listOfAccounts, PracticeId,codername);
            }
            else if (buttonText == "Re-Allot")
            {
                managerObj.UpdateAllotToCoder(listOfAccounts, PracticeId, codername);
            }
            return Json("", JsonRequestBehavior.AllowGet);
        }

        public ActionResult GetDuplicateAccountDetails(string status, string fromDos, string toDos, int PracticeId)
        {
            return PartialView("_CoderAllotmentGrid", managerObj.GetDuplicateAccountDetails(status, fromDos, toDos, PracticeId));
        }

	}
}