﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Runtime.InteropServices;
using System.Windows.Forms;
using System.Drawing;
using System.Threading;
using System.Collections.Generic;

namespace MCK
{
  public class AdminClass
    {

      public static SortedDictionary<char, ulong> Count(string stringToCount)
      {
          SortedDictionary<char, ulong> characterCount = new SortedDictionary<char, ulong>();

          foreach (var character in stringToCount)
          {
              if (!characterCount.ContainsKey(character))
              {
                  characterCount.Add(character, 1);
              }
              else
              {
                  characterCount[character]++;
              }
          }

          return characterCount;
      }
      public DataTable getData(string system)
      {
          SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["MCK"].ConnectionString);
          SqlDataAdapter da = new SqlDataAdapter();
          try
          {
              con.Open();
              DataTable dt = new DataTable();

              da = new SqlDataAdapter("SELECT distinct Admin  FROM [MCK_Telnet_Master] where System='" + system + "' and Team='Rakshith'", con);

              da.Fill(dt);

              con.Close();
              return dt;

          }
          catch (Exception e)
          {

              throw e;
          }
      }

      public DataTable getClient(string system,string admin)
      {
          SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["MCK"].ConnectionString);
          SqlDataAdapter da = new SqlDataAdapter();
          try
          {
              con.Open();
              DataTable dt = new DataTable();

              da = new SqlDataAdapter("SELECT distinct *  FROM [MCK_Telnet_Master] where System='" + system + "' and  Admin='" + admin + "' and Team='Rakshith'", con);

              da.Fill(dt);

              con.Close();
              return dt;

          }
          catch (Exception e)
          {

              throw e;
          }
      }

      public DataTable getClientName(string system)
      {
          SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["MCK"].ConnectionString);
          SqlDataAdapter da = new SqlDataAdapter();
          try
          {
              con.Open();
              DataTable dt = new DataTable();

              da = new SqlDataAdapter("SELECT * FROM [MCK_Telnet_Master] where System='" + system + "' and Team='Rakshith'", con);

              da.Fill(dt);

              con.Close();
              return dt;

          }
          catch (Exception e)
          {

              throw e;
          }
      }
    }

 
}
