﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Automation;

namespace MCK
{
    public class AutomationHelper
    {
        
        public bool AutomationsysConnection(string str)
        {
            try
            {
                AutomationElement rootElement = AutomationElement.RootElement;//Omega Imgnow - desktop - Citrix online plug-in
                AutomationElement aeButton1 = rootElement.FindFirst(TreeScope.Children, new PropertyCondition(AutomationElement.NameProperty, "Medicare Remit EasyPrint v3.1"));
                AutomationElement aeButton2 = rootElement.FindFirst(TreeScope.Children, new PropertyCondition(AutomationElement.NameProperty, "Medicare Remit EasyPrint v3.1"));
                AutomationElement aeButton3 = rootElement.FindFirst(TreeScope.Children, new PropertyCondition(AutomationElement.NameProperty, "Medicare Remit EasyPrint v3.1"));
                Condition documentCondition = new PropertyCondition(AutomationElement.LocalizedControlTypeProperty, "window");

                AutomationElement aeButton = null;
                if (aeButton1 != null)
                {
                    aeButton = aeButton1;
                }
                else if (aeButton2 != null)
                {
                    aeButton = aeButton2;
                }

                else
                {
                    aeButton = aeButton3;
                }
                AutomationElement documentElement = aeButton.FindFirst(TreeScope.Subtree, documentCondition);
                documentElement.SetFocus();
                //int iHandle = SendKeys.NativeWin32.FindWindow(null, "Server - Citrix XenApp Plugins for Hosted Apps");
                //int iHandle = SendKeys.NativeWin32.FindWindow(null, "Server - Citrix Presentation Server Client");

                //SendKeys.NativeWin32.SetForegroundWindow(iHandle);
                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
        }


        public bool notepadfocus(string str)
        {
            try
            {
                AutomationElement rootElement = AutomationElement.RootElement;//Omega Imgnow - desktop - Citrix online plug-in
                // AutomationElement aeButton = rootElement.FindFirst(TreeScope.Children, new PropertyCondition(AutomationElement.NameProperty, "Server - Citrix XenApp Plugins for Hosted Apps"));
                //AutomationElement aeButton = rootElement.FindFirst(TreeScope.Children, new PropertyCondition(AutomationElement.NameProperty, "Server - Citrix Presentation Server Client"));
                AutomationElement aeButton1 = rootElement.FindFirst(TreeScope.Children, new PropertyCondition(AutomationElement.NameProperty, "Untitled - Notepad"));
                AutomationElement aeButton2 = rootElement.FindFirst(TreeScope.Children, new PropertyCondition(AutomationElement.NameProperty, "Untitled - Notepad"));
                //AutomationElement aeButton3 = rootElement.FindFirst(TreeScope.Children, new PropertyCondition(AutomationElement.NameProperty, "Omega Imgnow - desktop - Citrix online plug-in"));
                AutomationElement aeButton3 = rootElement.FindFirst(TreeScope.Children, new PropertyCondition(AutomationElement.NameProperty, "Untitled - Notepad"));
                Condition documentCondition = new PropertyCondition(AutomationElement.LocalizedControlTypeProperty, "window");

                AutomationElement aeButton = null;
                if (aeButton1 != null)
                {
                    aeButton = aeButton1;
                }
                else if (aeButton2 != null)
                {
                    aeButton = aeButton2;
                }

                else
                {
                    aeButton = aeButton3;
                }
                AutomationElement documentElement = aeButton.FindFirst(TreeScope.Subtree, documentCondition);
                documentElement.SetFocus();
                //int iHandle = SendKeys.NativeWin32.FindWindow(null, "Server - Citrix XenApp Plugins for Hosted Apps");
                //int iHandle = SendKeys.NativeWin32.FindWindow(null, "Server - Citrix Presentation Server Client");

                //SendKeys.NativeWin32.SetForegroundWindow(iHandle);
                return true;
            }
            catch (Exception ex)
            {
                return false;
            }


        }


        public bool DeleteWindowFinder(string str)
        {
            try
            {
                AutomationElement rootElement = AutomationElement.RootElement;//Omega Imgnow - desktop - Citrix online plug-in
                // AutomationElement aeButton = rootElement.FindFirst(TreeScope.Children, new PropertyCondition(AutomationElement.NameProperty, "Server - Citrix XenApp Plugins for Hosted Apps"));
                //AutomationElement aeButton = rootElement.FindFirst(TreeScope.Children, new PropertyCondition(AutomationElement.NameProperty, "Server - Citrix Presentation Server Client"));
                AutomationElement aeButton1 = rootElement.FindFirst(TreeScope.Children, new PropertyCondition(AutomationElement.NameProperty, "Delete selected import file(s)"));
                AutomationElement aeButton2 = rootElement.FindFirst(TreeScope.Children, new PropertyCondition(AutomationElement.NameProperty, "Delete selected import file(s)"));
                //AutomationElement aeButton3 = rootElement.FindFirst(TreeScope.Children, new PropertyCondition(AutomationElement.NameProperty, "Omega Imgnow - desktop - Citrix online plug-in"));
                AutomationElement aeButton3 = rootElement.FindFirst(TreeScope.Children, new PropertyCondition(AutomationElement.NameProperty, "Delete selected import file(s)"));
                Condition documentCondition = new PropertyCondition(AutomationElement.LocalizedControlTypeProperty, "window");

                AutomationElement aeButton = null;
                if (aeButton1 != null)
                {
                    aeButton = aeButton1;
                }
                else if (aeButton2 != null)
                {
                    aeButton = aeButton2;
                }

                else
                {
                    aeButton = aeButton3;
                }
                AutomationElement documentElement = aeButton.FindFirst(TreeScope.Subtree, documentCondition);
                documentElement.SetFocus();
                //int iHandle = SendKeys.NativeWin32.FindWindow(null, "Server - Citrix XenApp Plugins for Hosted Apps");
                //int iHandle = SendKeys.NativeWin32.FindWindow(null, "Server - Citrix Presentation Server Client");

                //SendKeys.NativeWin32.SetForegroundWindow(iHandle);
                return true;
            }
            catch (Exception ex)
            {
                return false;
            }


        }

        public bool Auto(string str)
        {
            AutomationElement rootElement = AutomationElement.RootElement;//Omega Imgnow - desktop - Citrix online plug-in

            AutomationElement aeButton3 = rootElement.FindFirst(TreeScope.Children, new PropertyCondition(AutomationElement.ClassNameProperty, "wMFService0013024E998"));
            aeButton3.SetFocus();
            return true;
        }

        public bool AutomationsysConnection2(string str)
        {
            try
            {
                AutomationElement rootElement = AutomationElement.RootElement;
                // AutomationElement aeButton = rootElement.FindFirst(TreeScope.Children, new PropertyCondition(AutomationElement.NameProperty, "Server - Citrix XenApp Plugins for Hosted Apps"));
                //AutomationElement aeButton = rootElement.FindFirst(TreeScope.Children, new PropertyCondition(AutomationElement.NameProperty, "Server - Citrix Presentation Server Client"));
                AutomationElement aeButton1 = rootElement.FindFirst(TreeScope.Children, new PropertyCondition(AutomationElement.NameProperty, "Server - Citrix Presentation Server Client"));
                AutomationElement aeButton2 = rootElement.FindFirst(TreeScope.Children, new PropertyCondition(AutomationElement.NameProperty, "Server - Citrix XenApp Plugins for Hosted Apps"));

                Condition documentCondition = new PropertyCondition(AutomationElement.LocalizedControlTypeProperty, "window");

                AutomationElement aeButton = null;
                if (aeButton1 != null)
                {
                    aeButton = aeButton1;
                }
                else
                {
                    aeButton = aeButton2;
                }
                AutomationElement documentElement = aeButton.FindFirst(TreeScope.Subtree, documentCondition);
                documentElement.SetFocus();
                //int iHandle = SendKeys.NativeWin32.FindWindow(null, "Server - Citrix XenApp Plugins for Hosted Apps");
                //int iHandle = SendKeys.NativeWin32.FindWindow(null, "Server - Citrix Presentation Server Client");

                //SendKeys.NativeWin32.SetForegroundWindow(iHandle);
                return true;
            }
            catch (Exception ex)
            {
                return false;
            }


        }


    }
}
