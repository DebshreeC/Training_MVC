﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.InteropServices;
using System.Windows.Forms;

namespace MCK
{
    class KIBDEVNTS
    {
        public bool AutomationKIBDEVNTS(string m_text)
        {

            try
            {
                IntPtr keyboardLayout = GetKeyboardLayout(0);

                while (!string.IsNullOrEmpty(m_text))
                {
                    int m_Index = 0;


                    if (m_text[m_Index] == '{')
                    {
                        #region [ Special chars ]
                        string m_SubString = m_text.Substring(
                                                    m_Index + 1, m_text.IndexOf("}") - 1);

                        string[] m_Splitted = m_SubString.Split(new char[] { '+' });

                        for (int i = 0; i < m_Splitted.Length; i++)
                        {

                            if (m_Splitted[i].Length > 1)
                                PressSpecial(m_Splitted[i]);
                            else
                            {

                                short vKey = VkKeyScanEx(
                                    char.Parse(m_Splitted[i]), keyboardLayout);

                                //Get the low byte from the virtual key.
                                byte m_LOWBYTE = (Byte)(vKey & 0xFF);

                                //Get the scan code of the key.
                                byte sScan = (byte)MapVirtualKey(m_LOWBYTE, 0);


                                keybd_event(m_LOWBYTE, sScan, 0, 0);
                            }
                        }

                        Application.DoEvents();


                        for (int i = m_Splitted.Length - 1; i > -1; i--)
                        {
                            if (m_Splitted[i].Length > 1)
                                ReleaseSpecial(m_Splitted[i]);
                            else
                            {
                                short vKey = VkKeyScanEx(
                                    char.Parse(m_Splitted[i]), keyboardLayout);

                                byte m_LOWBYTE = (Byte)(vKey & 0xFF);

                                byte sScan = (byte)MapVirtualKey(m_LOWBYTE, 0);


                                keybd_event(m_LOWBYTE, sScan, 0x0002, 0); //Key up
                            }
                        }

                        Application.DoEvents();

                        #endregion


                        m_Index = m_SubString.Length + 2;
                    }
                    else
                    {
                        #region [ One char ]
                        short vKey = VkKeyScanEx(m_text[m_Index], keyboardLayout);


                        byte m_HIBYTE = (Byte)(vKey >> 8);
                        byte m_LOWBYTE = (Byte)(vKey & 0xFF);

                        byte sScan = (byte)MapVirtualKey(m_LOWBYTE, 0);


                        if ((m_HIBYTE == 1))
                            PressShift();
                        else if ((m_HIBYTE == 2))
                            PressControl();
                        else if ((m_HIBYTE == 4))
                            PressAlt();
                        else if ((m_HIBYTE == 6))
                            Pressesc();
                        else if ((m_HIBYTE == 8))
                            Pressup();
                        else if ((m_HIBYTE == 10))
                            Pressdown();
                        else if ((m_HIBYTE == 12))
                            Pressspace();
                        else if ((m_HIBYTE == 14))
                            Pressend();
                        else if ((m_HIBYTE == 16))
                            Pressdelete();

                        else if ((m_HIBYTE == 18))
                            PressLeft();
                        else if ((m_HIBYTE == 20))
                            PressRight();

                        keybd_event(m_LOWBYTE, sScan, 0, 0); //Key down
                        keybd_event(m_LOWBYTE, sScan, 0x0002, 0); //Key up


                        if ((m_HIBYTE == 1))
                            ReleaseShift();
                        else if ((m_HIBYTE == 2))
                            ReleaseControl();
                        else if ((m_HIBYTE == 4))
                            ReleaseAlt();
                        else if ((m_HIBYTE == 6))
                            Releaseesc();
                        else if ((m_HIBYTE == 8))
                            Releaseup();
                        else if ((m_HIBYTE == 10))
                            Releasedown();
                        else if ((m_HIBYTE == 12))
                            Releasespace();
                        else if ((m_HIBYTE == 14))
                            Releaseend();
                        else if ((m_HIBYTE == 16))
                            Releasedelete();
                        else if ((m_HIBYTE == 18))
                            ReleaseLeft();
                        else if ((m_HIBYTE == 20))
                            ReleaseRight();

                        #endregion


                        m_Index++;
                    }


                    if (m_Index < m_text.Length)
                        m_text = m_text.Substring(m_Index);
                    else
                        m_text = string.Empty;
                }
                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
        }
        [DllImport("user32.dll", SetLastError = true)]
        static extern void keybd_event(byte bVk, byte bScan, uint dwFlags, UIntPtr dwExtraInfo);

        Keys[] numberKeys = new Keys[10] { Keys.D0, Keys.D1, Keys.D2, Keys.D3, Keys.D4, Keys.D5, Keys.D6, Keys.D7, Keys.D8, Keys.D9 };

        void PressKey(Keys key)
        {
            const int KEYEVENTF_EXTENDEDKEY = 0x1;
            const int KEYEVENTF_KEYUP = 0x2;
            // I had some Compile errors until I Casted the final 0 to UIntPtr like this...
            keybd_event((byte)key, 0x45, KEYEVENTF_EXTENDEDKEY, (UIntPtr)0);
            keybd_event((byte)key, 0x45, KEYEVENTF_EXTENDEDKEY | KEYEVENTF_KEYUP, (UIntPtr)0);
        }

        void PressKeyArray(Keys[] keys)
        {
            foreach (Keys key in keys)
            {
                PressKey(key);
            }
        }



        #region [ TAB ]
        private void Releasetab()
        {
            keybd_event(0x09, 0x0f, 0x0002, 0);
        }

        private void Presstab()
        {
            keybd_event(0x09, 0x0f, 0, 0);
        }

        #endregion


        #region [ ALT ]
        private void ReleaseAlt()
        {
            keybd_event(0xA4, 0x38, 0x0002, 0);
        }

        private void PressAlt()
        {
            keybd_event(0xA4, 0x38, 0, 0);
        }

        #endregion

        #region [ esc ]
        private void Releaseesc()
        {
            keybd_event(0x1B, 0x01, 0x0002, 0);
        }

        private void Pressesc()
        {
            keybd_event(0x1B, 0x01, 0, 0);
        }

        #endregion

        #region [ Press CTRL ]
        private void PressControl()
        {
            //0xA0 is the virtual key of 'shift'.
            //0x2A is the scan code of 'shift'.


            //keybd_event(0xA2, 0x1D, 0, 0);

            keybd_event(0xA3, 0x1D, 0, 0);
        }
        #endregion

        #region [ Release CTRL ]
        private void ReleaseControl()
        {
            //keybd_event(0xA2, 0x1D, 0x0002, 0);
            keybd_event(0xA3, 0x1D, 0x0002, 0);
        }
        #endregion

        #region [ Press shift ]
        private void PressShift()
        {
            //keybd_event(0xA0, 0x2A, 0, 0);
            keybd_event(0xA1, 0x2A, 0, 0);
        }
        #endregion

        #region [ Release shift ]
        private void ReleaseShift()
        {
            //keybd_event(0xA0, 0x2A, 0x0002, 0);
            keybd_event(0xA1, 0x2A, 0x0002, 0);
        }
        #endregion

        private void Releasedown()
        {



            keybd_event(0x28, 0x50, 0x0002, 0);


        }

        private void Releaseup()
        {

            keybd_event(0x26, 0x48, 0x0002, 0);
        }
        private void Pressdown()
        {

            keybd_event(0x28, 0x50, 0, 0);



        }

        private void Pressup()
        {

            keybd_event(0x26, 0x48, 0, 0);
        }

        private void Pressspace()
        {

            keybd_event(0x20, 0x39, 0, 0);



        }

        private void Pressend()
        {
            keybd_event(0x23, 0x4F, 0, 0);
        }
        private void Releaseend()
        {
            keybd_event(0x23, 0x4F, 0x0002, 0);
        }


        private void Pressdelete()
        {
            keybd_event(0x2E, 0x53, 0, 0);
        }
        private void Releasedelete()
        {
            keybd_event(0x2E, 0x53, 0x0002, 0);
        }

        private void Releasespace()
        {

            keybd_event(0x20, 0x39, 0x0002, 0);
        }

        private void PressLeft()
        {

            keybd_event(0x25, 0x4B, 0, 0);
        }
        private void ReleaseLeft()
        {

            keybd_event(0x25, 0x4B, 0x0002, 0);
        }
        private void PressRight()
        {

            keybd_event(0x27, 0x4D, 0, 0);
        }
        private void ReleaseRight()
        {

            keybd_event(0x27, 0x4D, 0x0002, 0);
        }


        private void PressSpecial(string p_Special)
        {
            switch (p_Special)
            {
                case "home":
                    keybd_event(0x24, 0x47, 0, 0);
                    break;
                case "end":
                    keybd_event(0x23, 0x4F, 0, 0);
                    break;
                case "tab":
                    keybd_event(0x09, 0x0f, 0, 0);
                    break;
                case "alt":
                    keybd_event(0xA4, 0x38, 0, 0);
                    break;
                case "enter":
                    keybd_event(0x0D, 0x1C, 0, 0);
                    break;
                //case "ctrl":
                //    keybd_event(0xA2, 0x1D, 0, 0);
                //    break;
                //case "shift":
                //    keybd_event(0xA0, 0x2A, 0, 0);
                //    break;

                case "ctrl":
                    keybd_event(0xA3, 0x1D, 0, 0);
                    break;

                case "shift":
                    keybd_event(0xA1, 0x2A, 0, 0);
                    break;
                case "escape":
                    keybd_event(0x1B, 0x01, 0, 0);
                    break;
                //case "down":
                //    keybd_event(0x62, 0x50, 0, 0);
                //    break;
                case "down":
                    keybd_event(0x28, 0x50, 0, 0);
                    break;
                case "up":
                    keybd_event(0x26, 0x48, 0, 0);
                    break;
                case "space":
                    keybd_event(0x20, 0x39, 0, 0);
                    break;
                case "delete":
                    keybd_event(0x2E, 0x53, 0, 0);
                    break;
                case "left":
                    keybd_event(0x25, 0x4B, 0, 0);
                    break;
                case "right":
                    keybd_event(0x27, 0x4D, 0, 0);
                    break;
                case "F1":
                    keybd_event(0x70, 0x3B, 0, 0);
                    break;
                case "F2":
                    keybd_event(0x71, 0x3B, 0, 0);
                    break;
                case "F3":
                    keybd_event(0x72, 0x3D, 0, 0);
                    break;

                case "F4":
                    keybd_event(0x73, 0x3E, 0, 0);
                    break;
                case "F5":
                    keybd_event(0x74, 0x3F, 0, 0);
                    break;
                case "F6":
                    keybd_event(0x75, 0x40, 0, 0);
                    break;
                case "F7":
                    keybd_event(0x76, 0x41, 0, 0);
                    break;
                case "F8":
                    keybd_event(0x77, 0x42, 0, 0);
                    break;
                case "F9":
                    keybd_event(0x78, 0x43, 0, 0);
                    break;
                case "F10":
                    keybd_event(0x79, 0x44, 0, 0);
                    break;


                case "F11":
                    keybd_event(0x7A, 0x57, 0, 0);
                    break;

                case "F12":
                    keybd_event(0x7B, 0x58, 0, 0);
                    break;

                case "printscreen":
                    keybd_event(0x2C, 0x37, 0, 0);
                    break;

                case "backspace":
                    keybd_event(0x08, 0x0E, 0, 0);
                    break;

                case "insert":
                    keybd_event(0x2D, 0x52, 0, 0);
                    break;

                case "pageup":
                    keybd_event(0x21, 0x49, 0, 0);
                    break;
                case "pagedown":
                    keybd_event(0x22, 0x51, 0, 0);
                    break;


            }
        }


        public void ReleaseSpecial(string p_Special)
        {
            switch (p_Special)
            {
                case "home":
                    keybd_event(0x24, 0x47, 0x0002, 0);
                    break;
                case "end":
                    keybd_event(0x23, 0x4F, 0x0002, 0);
                    break;
                case "tab":
                    keybd_event(0x09, 0x0f, 0x0002, 0);
                    break;
                case "alt":
                    keybd_event(0xA4, 0x38, 0x0002, 0);
                    break;
                case "enter":
                    keybd_event(0x0D, 0x1C, 0x0002, 0);
                    break;
                //case "ctrl":
                //    keybd_event(0xA2, 0x1D, 0x0002, 0);
                //    break;
                //case "shift":
                //    keybd_event(0xA0, 0x2A, 0x0002, 0);
                //    break;
                case "ctrl":
                    keybd_event(0xA3, 0x1D, 0x0002, 0);
                    break;

                case "shift":
                    keybd_event(0xA1, 0x2A, 0x0002, 0);
                    break;
                case "escape":
                    keybd_event(0x1B, 0x01, 0x0002, 0);
                    break;
                //case "down":
                //    keybd_event(0x62, 0x50, 0x0002, 0);
                //    break;
                case "down":
                    keybd_event(0x28, 0x50, 0x0002, 0);
                    break;
                case "up":
                    keybd_event(0x26, 0x48, 0x0002, 0);
                    break;
                case "space":
                    keybd_event(0x20, 0x39, 0x0002, 0);
                    break;
                case "delete":
                    keybd_event(0x2E, 0x53, 0x0002, 0);
                    break;
                case "left":
                    keybd_event(0x25, 0x4B, 0x0002, 0);
                    break;
                case "right":
                    keybd_event(0x27, 0x4D, 0x0002, 0);
                    break;

                case "F1":
                    keybd_event(0x70, 0x3B, 0x0002, 0);
                    break;
                case "F2":
                    keybd_event(0x71, 0x3B, 0x0002, 0);
                    break;
                case "F3":
                    keybd_event(0x72, 0x3D, 0x0002, 0);
                    break;
                case "F4":
                    keybd_event(0x73, 0x3E, 0x0002, 0);
                    break;
                case "F5":
                    keybd_event(0x74, 0x3F, 0x0002, 0);
                    break;
                case "F6":
                    keybd_event(0x75, 0x40, 0x0002, 0);
                    break;
                case "F7":
                    keybd_event(0x76, 0x41, 0x0002, 0);
                    break;
                case "F8":
                    keybd_event(0x77, 0x42, 0x0002, 0);
                    break;
                case "F9":
                    keybd_event(0x78, 0x43, 0x0002, 0);
                    break;
                case "F10":
                    keybd_event(0x79, 0x44, 0x0002, 0);
                    break;
                case "F11":
                    keybd_event(0x7A, 0x57, 0x0002, 0);
                    break;
                case "F12":
                    keybd_event(0x7B, 0x58, 0x0002, 0);
                    break;

                case "printscreen":
                    keybd_event(0x2C, 0x37, 0x0002, 0);
                    break;

                case "backspace":
                    keybd_event(0x08, 0x0E, 0x0002, 0);
                    break;

                case "insert":
                    keybd_event(0x2D, 0x52, 0x0002, 0);
                    break;

                case "pageup":
                    keybd_event(0x21, 0x49, 0x0002, 0);
                    break;
                case "pagedown":
                    keybd_event(0x22, 0x51, 0x0002, 0);
                    break;
            }
        }
        [DllImport("user32.dll", EntryPoint = "keybd_event", CharSet = CharSet.Auto, ExactSpelling = true)]
        public static extern void keybd_event(byte vk, byte scan, int flags, int extrainfo);

        [DllImport("user32.dll")]
        public static extern IntPtr GetKeyboardLayout(uint idThread);

        [DllImport("user32.dll")]
        public static extern short VkKeyScanEx(char ch, IntPtr dwhkl);

        [DllImport("user32.dll", CharSet = CharSet.Auto)]
        public static extern int MapVirtualKey(int uCode, int uMapType);

    }
}
